﻿Imports System.Globalization
Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class ImportTimetableSiteImporter
    Inherits CsvImporterBase

    Private ReadOnly Property _parameter As CsvImportParameterDto

    Private ReadOnly _components As CsvImportMasterComponents

    Public Sub New(parameter As CsvImportParameterDto, components As CsvImportMasterComponents)
        MyBase.New(parameter, components.Csv, components.Validator)
        _parameter = parameter
    End Sub

    Protected Overrides ReadOnly Property TargetTableName As String
        Get
            Return MasterImportTable.TIMETABLE_SITE
        End Get
    End Property

    Protected Overrides ReadOnly Property ImportTypeName As String
        Get
            Return MasterImportTypes.TimeTableSite
        End Get
    End Property

    Protected Overrides ReadOnly Property DataType As String
        Get
            Return TableImportHistoryConst.TYPE_TIME_TABLE_SITE
        End Get
    End Property

    Protected Overrides Function GetDtoType() As Type
        Return Nothing
    End Function

    Protected Overrides Sub DeleteSwapData(ByVal sqlDbConn As DbTransactionScope, delKeys As List(Of String))
        Dim repo As New TimetableSiteRepository(sqlDbConn)

        repo.DeleteSwapData(delKeys(0))
        Return
    End Sub

    ''' <summary>
    ''' CSV内データ対象年月度データのみであるかを確認します。
    ''' </summary>
    ''' <param name="impDataList"></param>
    Protected Overrides Function ValidationMonthPeriod(ByRef delKeys As List(Of String), ByVal impDataList As List(Of Dictionary(Of String, String))) As ImportDataErrorType
        ' 事前削除対象の年月日を取得する
        Dim storedDates As List(Of String) = GetYearMonthList(impDataList)

        If storedDates.Count <= 0 Then
            Return ImportDataErrorType.DataNotFound
        End If

        Dim intYear As Integer
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        For i As Integer = 0 To storedDates.Count - 1
            If Integer.TryParse(storedDates(i), intYear) Then
                If intYear = DateUtil.DateToNendoYear(_parameter.TargetDate) Then
                    delKeys.Add(storedDates(i))
                    trueCnt += 1
                Else
                    falseCnt += 1
                End If
            End If
        Next

        If trueCnt = 1 AndAlso falseCnt = 0 Then
            Return ImportDataErrorType.Success
        ElseIf trueCnt = 1 AndAlso falseCnt > 0 Then
            Return ImportDataErrorType.IncludingNonEligible
        ElseIf trueCnt = 0 AndAlso falseCnt > 1 Then
            Return ImportDataErrorType.OnlyNonEligible
        End If

        Return ImportDataErrorType.OtherError
    End Function

    ''' <summary>
    ''' CSVインポート前準備
    ''' </summary>
    ''' <param name="sqlDbConn"></param>
    ''' <param name="impDataList"></param>
    Protected Overrides Sub PreparatoryWork(sqlDbConn As DbTransactionScope, impDataList As List(Of Dictionary(Of String, String)), delKeys As List(Of String))
        DeleteSwapData(sqlDbConn, delKeys)
    End Sub

    '' <summary>
    '' 事前削除対象の年年度を収集します。
    '' CSVファイル内の年月日項目のサマリを取得して事前削除対象の年月日とします。
    '' </summary>
    '' <param name="list"></param>
    '' <returns></returns>
    Private Function GetYearMonthList(list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYears =
                  list.
                  Where(Function(d) d.ContainsKey("Year") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("Year"))).
                  Select(Function(d) d("Year")).
                  Where(Function(s) s IsNot Nothing).
                  Distinct().
                  OrderBy(Function(s) s).
                  ToList()
        Return distinctYears
    End Function

    ''' <summary>
    ''' 重複データがあるか否かを判定します。
    ''' </summary>
    ''' <param name="impDataDic"></param>
    ''' <returns></returns>
    Protected Overrides Function DuplicateValidation(ByVal impDataDic As List(Of Dictionary(Of String, String))) As Boolean
        ' 重複チェック
        Dim duplicates = impDataDic.
            GroupBy(Function(d) String.Join("|", {
                d("Year"),
                d("Site_Code"),
                d("Koma"),
                d("Day_Pattern")
            })).
            Where(Function(g) g.Count() > 1).
            ToList()
        Return duplicates.Any()
    End Function
End Class