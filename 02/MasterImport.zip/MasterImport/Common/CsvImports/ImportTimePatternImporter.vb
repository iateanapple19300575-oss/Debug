﻿Imports System.Globalization
Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class ImportTimePatternImporter
    Inherits CsvImporterBase

    Private ReadOnly Property _parameter As CsvImportParameterDto

    Private ReadOnly _components As CsvImportMasterComponents

    Public Sub New(parameter As CsvImportParameterDto, components As CsvImportMasterComponents)
        MyBase.New(parameter, components.Csv, components.Validator)
        _parameter = parameter
    End Sub

    Protected Overrides ReadOnly Property TargetTableName As String
        Get
            Return MasterImportTable.TIME_PATTERN
        End Get
    End Property

    Protected Overrides ReadOnly Property ImportTypeName As String
        Get
            Return MasterImportTypes.TimePattern
        End Get
    End Property

    Protected Overrides ReadOnly Property DataType As String
        Get
            Return TableImportHistoryConst.TYPE_TIME_PATTERN
        End Get
    End Property

    Protected Overrides Function GetDtoType() As Type
        Return Nothing
    End Function

    Protected Overrides Sub DeleteSwapData(ByVal sqlDbConn As DbTransactionScope, targetDates As List(Of String))
        Dim repo As New TimePatternRepository(sqlDbConn)
        For Each delMonth As String In targetDates
            repo.DeleteSwapData(delMonth)
        Next
        Return
    End Sub

    ''' <summary>
    ''' CSV内データ対象年月度データのみであるかを確認します。
    ''' </summary>
    ''' <param name="impDataList"></param>
    Protected Overrides Function ValidationMonthPeriod(ByRef delKeys As List(Of String), ByVal impDataList As List(Of Dictionary(Of String, String))) As ImportDataErrorType
        ' 事前削除対象の年月日を取得する
        Dim storedDates As List(Of String) = GetYearMonthList(impDataList)
        If storedDates.Count <= 0 Then
            Return ImportDataErrorType.DataNotFound
        End If

        ' 現在選択中の対象年月を元に現在の年度の開始年月、終了年月を取得する。
        Dim dtStartDate As Date
        Dim dtEndDate As Date
        DateUtil.NendoToMonthPeriod(dtStartDate, dtEndDate, _parameter.TargetDate)

        ' 年度の範囲外のデータが存在するならばエラーとして処理しない。
        Dim strStartDate As String = String.Format("{0:0000}-{1:00}", dtStartDate.Year, dtStartDate.Month)
        Dim strEndDate As String = String.Format("{0:0000}-{1:00}", dtEndDate.Year, dtEndDate.Month)
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        For Each ym As String In storedDates.ToArray
            If strStartDate <= ym AndAlso strEndDate >= ym Then
                delKeys.Add(ym)
                trueCnt += 1
            Else
                falseCnt += 1
            End If
        Next

        If trueCnt > 0 AndAlso falseCnt = 0 Then
            Return ImportDataErrorType.Success
        ElseIf trueCnt > 0 AndAlso falseCnt > 0 Then
            Return ImportDataErrorType.IncludingNonEligible
        ElseIf trueCnt = 0 AndAlso falseCnt > 0 Then
            Return ImportDataErrorType.OnlyNonEligible
        End If

        Return ImportDataErrorType.OtherError
    End Function

    ''' <summary>
    ''' CSVインポート前準備
    ''' </summary>
    ''' <param name="sqlDbConn"></param>
    ''' <param name="impDataList"></param>
    Protected Overrides Sub PreparatoryWork(sqlDbConn As DbTransactionScope, impDataList As List(Of Dictionary(Of String, String)), delMonths As List(Of String))
        DeleteSwapData(sqlDbConn, delMonths)
    End Sub

    '' <summary>
    '' 事前削除対象の年月日を収集します。
    '' CSVファイル内の年月日項目のサマリを取得して事前削除対象の年月日とします。
    '' </summary>
    '' <param name="list"></param>
    '' <returns></returns>
    Private Function GetYearMonthList(list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYearMonths =
                  list.
                  Where(Function(d) d.ContainsKey("年月日") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("年月日"))).
                  Select(Function(d)
                             Dim dt As DateTime
                             ' 日付変換（安全に TryParseExact）
                             If DateTime.TryParseExact(d("年月日"), {"yyyy/MM/dd", "yyyy-MM-dd"},
                                                   CultureInfo.InvariantCulture,
                                                   DateTimeStyles.None, dt) Then
                                 Return dt.ToString("yyyy-MM") ' 年月に変換
                             Else
                                 Return Nothing
                             End If
                         End Function).
                  Where(Function(s) s IsNot Nothing).
                  Distinct().
                  OrderBy(Function(s) s).
                  ToList()
        Return distinctYearMonths
    End Function

    ''' <summary>
    ''' 重複データがあるか否かを判定します。
    ''' </summary>
    ''' <param name="impDataDic"></param>
    ''' <returns></returns>
    Protected Overrides Function DuplicateValidation(ByVal impDataDic As List(Of Dictionary(Of String, String))) As Boolean
        ' 重複チェック
        Dim duplicates = impDataDic.
            GroupBy(Function(d) String.Join("|", {
                d("年度"),
                d("年月日")
            })).
            Where(Function(g) g.Count() > 1).
            ToList()
        Return duplicates.Any()
    End Function

End Class