﻿''' <summary>
''' 時間パターンCSVデータバリデーションエラー表示画面
''' </summary>
Public Class TimePatternCsvError
    Inherits FrmValidationErrors

	'''' <summary>
	'''' Windowタイトル名
	'''' </summary>
	'Protected Overrides Property WINDOW_TITLE As String = "エラー一覧（時間パターン）"

	'''' <summary>
	'''' 時間パターンCSVデータ
	'''' </summary>
	'Private csvFileInfo As New TimePatternCsv


	'''' <summary>
	'''' コンストラクタ
	'''' </summary>
	'''' <param name="validationResultList"></param>
	'Public Sub New(ByVal validationResultList As Dictionary(Of Integer, List(Of ValidationResult)), ByVal csvInfo As CsvAbstract)
	'	MyBase.New(validationResultList)
	'End Sub

	'''' <summary>
	'''' カラム情報設定
	'''' </summary>
	'Protected Overrides Sub InitializeDataGridView()
	'	' カラム名と表示位置
	'	Dim csvColumns() As String = csvFileInfo.Headers.ToArray()
	'	Add(csvColumns(0), DataGridViewContentAlignment.MiddleCenter, 60)
	'	Add(csvColumns(1), DataGridViewContentAlignment.MiddleCenter, 100)
	'	Add(csvColumns(2), DataGridViewContentAlignment.MiddleCenter, 40)
	'	Add(csvColumns(3), DataGridViewContentAlignment.MiddleLeft, 200)
	'End Sub
End Class
