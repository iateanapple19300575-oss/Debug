﻿Imports System.Data.SqlClient

Public Class TimeScheduleTran
  Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

#Region "時間パターン"

    ''' <summary>
    ''' 時間スケジュール情報取得
    ''' </summary>
    ''' <returns></returns>
    Public Function LoadTimePatternData(ByVal targetDate As Date) As ResultData
		Dim resultData As New ResultData
		Dim recData As New Dictionary(Of String, String)
		Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
		Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("SELECT" & " ")
		sqlString.Append("  Year" & " ")
		sqlString.Append("  , CONVERT(CHAR (10), Lecture_Date, 111) As Lecture_Date" & " ")
		sqlString.Append("  , Youbi As Youbi" & " ")
		sqlString.Append("  , Schedule_Pattern As Schedule_Pattern" & " ")
		sqlString.Append("FROM ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_TIME_PATTERN & " ")
		sqlString.Append("WHERE 1=1" & " ")
		If Not DateUtil.IsNullOrEmpty(targetDate) Then
			sqlString.Append("  AND Lecture_Date >= '" & firstDay & "' ")
			sqlString.Append("  AND Lecture_Date <= '" & lastDay & "' ")
		End If
		sqlString.Append("ORDER BY" & " ")
		sqlString.Append("  Lecture_Date ASC" & " ")
		sqlString.Append("; ")

		Using sqlConnection As New SqlConnection(ConnectString)
			Try
				sqlConnection.Open()
				Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
					Using reader As SqlDataReader = commandSourceData.ExecuteReader()
						resultData.ResDataTable = TimePatternMapping(reader)
					End Using
					resultData.Success = True
					resultData.DataCount = resultData.ResDataTable.Rows.Count
				End Using

			Catch ex As Exception
				System.Console.WriteLine(ex.Message)
				Throw

			Finally
				If sqlConnection.State = ConnectionState.Open Then
					sqlConnection.Close()
				End If
			End Try
		End Using

		Return resultData
	End Function


	Private Function TimePatternMapping(ByVal reader As SqlDataReader) As DataTable
		Dim dtTable As New DataTable
		TimePatternDefinition(dtTable)

		While reader.Read()
			Dim rowRec As DataRow = dtTable.NewRow()
			rowRec("年度") = SqlDataReaderUtil.GetValue(reader, "Year")
			rowRec("日付") = SqlDataReaderUtil.GetValue(reader, "Lecture_Date")
			rowRec("曜日") = SqlDataReaderUtil.GetValue(reader, "Youbi")
			rowRec("曜日区分") = SqlDataReaderUtil.GetValue(reader, "Schedule_Pattern")
			dtTable.Rows.Add(rowRec)
		End While

		Return dtTable
	End Function

	''' <summary>
	''' 教室データ格納用 DataTable定義
	''' </summary>
	Private Sub TimePatternDefinition(ByRef dtTable As DataTable)
		dtTable.Columns.Add("年度", GetType(String))
		dtTable.Columns.Add("日付", GetType(String))
		dtTable.Columns.Add("曜日", GetType(String))
		dtTable.Columns.Add("曜日区分", GetType(String))
	End Sub

#End Region

#Region "年取得"

    Public Function LoadYearData(ByVal targetDate As Date) As DataTable
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  YEAR(Lecture_Date) AS Year").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  M_Time_Pattern").Append(" ")
        sqlString.Append("GROUP BY").Append(" ")
        sqlString.Append("  YEAR(Lecture_Date)").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year").Append(" ")
        sqlString.Append(";").Append(" ")

        Return SqlCommandExecutor.ExecuteDataTable(sqlString.ToString(), Nothing)
    End Function

#End Region

#Region "月取得"

    Public Function LoadMonthData(ByVal targetDate As Date) As DataTable
        Dim resultData As New ResultData
        Dim recData As New Dictionary(Of String, String)
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  YEAR(Lecture_Date) AS Year").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  M_Time_Pattern").Append(" ")
        sqlString.Append("GROUP BY").Append(" ")
        sqlString.Append("  YEAR(Lecture_Date)").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year").Append(" ")
        sqlString.Append(";").Append(" ")

        Return SqlCommandExecutor.ExecuteDataTable(sqlString.ToString(), Nothing)
    End Function

#End Region

End Class
