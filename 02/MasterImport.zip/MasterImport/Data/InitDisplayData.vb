﻿''' <summary>
''' マスタデータ取込画面データクラス
''' </summary>
Public Class InitDisplayData
    Inherits ScreenData

    ''' <summary>
    ''' 月毎の設定期間リスト
    ''' </summary>
    ''' <returns></returns>
    Public Property TimePatternPeriodList As New DataTable

    ''' <summary>
    ''' 時間パターン：最終取込件数
    ''' </summary>
    ''' <returns></returns>
    Public Property TimePatternCount As Integer

	''' <summary>
	''' 時間パターン：ステータス
	''' </summary>
	''' <returns></returns>
	Public Property TimePatternStatus As String = ""

	''' <summary>
	''' 時間パターン：最終更新日時
	''' </summary>
	''' <returns></returns>
	Public Property TimePatternDate As Date

	''' <summary>
	''' 時間パターン：履歴情報
	''' </summary>
	''' <returns></returns>
	Public Property TimePatternHistory As New DataTable

    ''' <summary>
    '''教室時間割：最終取込件数
    ''' </summary>
    ''' <returns></returns>
    Public Property TimeTableCount As Integer

	''' <summary>
	'''教室時間割：最終取込日時
	''' </summary>
	''' <returns></returns>
	Public Property TimeTableStatus As String = ""

	''' <summary>
	'''教室時間割：最終取込日時
	''' </summary>
	''' <returns></returns>
	Public Property TimeTableDate As Date

	''' <summary>
	'''教室時間割：履歴情報
	''' </summary>
	''' <returns></returns>
	Public Property TimeTableHistory As New DataTable

    ''' <summary>
    ''' コマ単価：最終取込件数
    ''' </summary>
    ''' <returns></returns>
    Public Property KomaPriceCount As Integer

	''' <summary>
	''' コマ単価：ステータス
	''' </summary>
	''' <returns></returns>
	Public Property KomaPriceStatus As String = ""

	''' <summary>
	''' コマ単価：最終取込日時
	''' </summary>
	''' <returns></returns>
	Public Property KomaPriceDate As Date

	''' <summary>
	''' コマ単価：履歴情報
	''' </summary>
	''' <returns></returns>
	Public Property KomaPriceHistory As New DataTable

	''' <summary>
	''' 講師給与単価インポート情報
	''' </summary>
	''' <returns></returns>
	Public Property TeacherWageImportInfoData As New ImportInfoData

End Class


''' <summary>
''' インポート情報データクラス
''' </summary>
Public Class ImportInfoData

    ''' <summary>
    ''' 講師給与単価：前回処理結果
    ''' </summary>
    ''' <returns></returns>
    Public Property LastStatus As String = ""

    ''' <summary>
    ''' 講師給与単価：前回日時
    ''' </summary>
    ''' <returns></returns>
    Public Property LastDate As Date

	''' <summary>
	''' 講師給与単価：前回件数
	''' </summary>
	''' <returns></returns>
	Public Property LastCount As Integer

	''' <summary>
	''' 講師給与単価：今回処理結果
	''' </summary>
	''' <returns></returns>
	Public Property ThisStatus As String = ""

	''' <summary>
	''' 講師給与単価：今回処理日時
	''' </summary>
	''' <returns></returns>
	Public Property ThisDate As Date

	''' <summary>
	''' 講師給与単価：今回処理件数
	''' </summary>
	''' <returns></returns>
	Public Property ThisCount As Integer

End Class
