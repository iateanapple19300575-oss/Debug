﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 講師給与単価データ Repository
''' </summary>
Public Class TeacherWageRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

#Region "一括取得"

    ''' <summary>
    ''' 条件指定一括取得
    ''' </summary>
    ''' <param name="dto">条件情報</param>
    ''' <returns></returns>
    Public Function GetAll(ByVal dto As TeacherUnitPriceDto) As DataTable
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  TW.Id").Append(" ")
        sqlString.Append("  , TW.Teacher_Code As Teacher_Code").Append(" ")
        sqlString.Append("  , TR.講師名 As Teacher_Name").Append(" ")
        sqlString.Append("  , TW.Effective_Date As Effective_Date").Append(" ")
        sqlString.Append("  , TW.Lecture_Unit_Price As Lecture_Unit_Price").Append(" ")
        sqlString.Append("  , TW.Task_Unit_Price As Task_Unit_Price").Append(" ")
        sqlString.Append("  , TW.Create_Date").Append(" ")
        sqlString.Append("  , TW.Create_User").Append(" ")
        sqlString.Append("  , TW.Update_Date").Append(" ")
        sqlString.Append("  , TW.Update_User").Append(" ")
        sqlString.Append("  , TW.RowVersion ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  M_Teacher_Wage TW").Append(" ")

        If dto.LatestOnly Then
            sqlString.Append("  INNER JOIN (").Append(" ")
            sqlString.Append("    SELECT").Append(" ")
            sqlString.Append("      Teacher_Code").Append(" ")
            sqlString.Append("      , MAX(Effective_Date) As Effective_Date").Append(" ")
            sqlString.Append("    FROM").Append(" ")
            sqlString.Append("      M_Teacher_Wage ").Append(" ")
            sqlString.Append("    GROUP BY").Append(" ")
            sqlString.Append("      Teacher_Code").Append(" ")
            sqlString.Append("  ) TW1").Append(" ")
            sqlString.Append("    ON (").Append(" ")
            sqlString.Append("      TW.Teacher_Code = TW1.Teacher_Code").Append(" ")
            sqlString.Append("      AND TW.Effective_Date = TW1.Effective_Date").Append(" ")
            sqlString.Append("    )").Append(" ")
        End If

        sqlString.Append("  LEFT JOIN (").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      講師コード").Append(" ")
        sqlString.Append("      , 講師名").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      TeacherRegistry").Append(" ")
        sqlString.Append("    WHERE").Append(" ")
        sqlString.Append("      登録区分 IS NULL").Append(" ")
        sqlString.Append("  ) TR").Append(" ")
        sqlString.Append("    ON (TW.Teacher_Code = TR.講師コード)").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")

        If dto.Subjects.Count > 0 Then
            sqlString.Append(InSubjects(dto.Subjects))
        End If

        If Not StringUtil.IsNullOrEmpty(dto.TeacherCode) Then
            sqlString.Append("  AND TW.Teacher_Code LIKE @Teacher_Code").Append(" ")
        End If
        If Not StringUtil.IsNullOrEmpty(dto.TeacherName) Then
            sqlString.Append("  AND TR.講師名 LIKE @講師名").Append(" ")
        End If

        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  TW.Teacher_Code Asc").Append(" ")
        sqlString.Append("  , TW.Effective_Date Asc").Append(" ")
        sqlString.Append(";").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        If Not StringUtil.IsNullOrEmpty(dto.TeacherCode) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = dto.TeacherCode & "%"})
        End If
        If Not StringUtil.IsNullOrEmpty(dto.TeacherName) Then
            params.Add(New SqlParameter() With {.ParameterName = "@講師名", .Value = "%" & dto.TeacherName & "%"})
        End If

        Return ExecuteDataTable(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 科目の条件部分のSQL
    ''' </summary>
    ''' <param name="subjectsDic"></param>
    ''' <returns></returns>
    Private Function InSubjects(ByVal subjectsDic As Dictionary(Of String, Boolean)) As String
        Dim result As String = ""
        Dim subjectList As List(Of String) = subjectsDic.Keys.ToList()
        Dim isFirst As Boolean = True
        Dim queryInStr As String = ""
        For Each subject As String In subjectList
            If subjectsDic(subject) Then
                If isFirst Then
                    queryInStr &= "'" & subject & "'"
                    isFirst = False
                Else
                    queryInStr &= ", '" & subject & "'"
                End If
            End If
        Next

        If StringUtil.IsNotNullOrWhiteSpace(queryInStr) Then
            result = "AND  LEFT (TW.Teacher_Code, 1) IN (" & queryInStr & ")"
        End If

        Return result
    End Function

#End Region

#Region "1件削除"

    ''' <summary>
    ''' ID指定1件削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteById(ByVal id As Integer) As Integer
        Dim resultData As New ResultData

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(M_Teacher_WageEnum.講師コード.Table).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Id = @Id").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@Id", .Value = id}
        )
    End Function

#End Region

    ''' <summary>
    ''' データ取込前の削除処理
    ''' マージ処理のため何もしない
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Private Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Return 0
    End Function

#Region "データマージ：講師単価データ取込処理"

    ''' <summary>
    ''' 講師単価データをマージマージする。
    ''' </summary>
    ''' <returns></returns>
    Public Function MergeTeacherWage(ByVal sqlDb As DbTransactionScope) As Integer
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("MERGE M_Teacher_Wage AS target").Append(" ")
        SqlQuery.Append("USING W_Teacher_Wage AS source").Append(" ")
        SqlQuery.Append("ON target.Teacher_Code = source.Teacher_Code").Append(" ")
        SqlQuery.Append("AND target.Effective_Date = source.Effective_Date").Append(" ")
        SqlQuery.Append("WHEN MATCHED THEN").Append(" ")
        SqlQuery.Append("    UPDATE SET ").Append(" ")
        SqlQuery.Append("    target.Lecture_Unit_Price = source.Lecture_Unit_Price, ").Append(" ")
        SqlQuery.Append("    target.Task_Unit_Price = source.Task_Unit_Price, ").Append(" ")
        SqlQuery.Append("    target.Update_Date = source.Create_Date,").Append(" ")
        SqlQuery.Append("    target.Update_User = source.Create_User").Append(" ")
        SqlQuery.Append("WHEN NOT MATCHED BY TARGET THEN").Append(" ")
        SqlQuery.Append("    INSERT (").Append(" ")
        SqlQuery.Append("        Teacher_Code, ").Append(" ")
        SqlQuery.Append("        Effective_Date, ").Append(" ")
        SqlQuery.Append("        Lecture_Unit_Price,").Append(" ")
        SqlQuery.Append("        Task_Unit_Price,").Append(" ")
        SqlQuery.Append("        Create_Date,").Append(" ")
        SqlQuery.Append("        Create_User,").Append(" ")
        SqlQuery.Append("        Update_Date,").Append(" ")
        SqlQuery.Append("        Update_User").Append(" ")
        SqlQuery.Append("    ) VALUES (").Append(" ")
        SqlQuery.Append("        source.Teacher_Code, ").Append(" ")
        SqlQuery.Append("        source.Effective_Date, ").Append(" ")
        SqlQuery.Append("        source.Lecture_Unit_Price,").Append(" ")
        SqlQuery.Append("        source.Task_Unit_Price,").Append(" ")
        SqlQuery.Append("        source.Create_Date,").Append(" ")
        SqlQuery.Append("        source.Create_User,").Append(" ")
        SqlQuery.Append("        NULL,").Append(" ")
        SqlQuery.Append("        NULL").Append(" ")
        SqlQuery.Append("    )").Append(" ")
        SqlQuery.Append(";")

        Return ExecuteNonQuery(SqlQuery.ToString()
        )
    End Function

#End Region

End Class
