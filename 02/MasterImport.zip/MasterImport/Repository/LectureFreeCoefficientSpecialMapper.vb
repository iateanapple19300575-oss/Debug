﻿Imports Framework

Public Class LectureFreeCoefficientSpecialMapper
    Private Shared ReadOnly Def As New TableDefinition(
        "M_Lecture_Wage_Percentage",
        New List(Of String) From {"Year", "Half_Year", "Site_Code", "Grade", "Class_Code", "Lecture_Coefficient", "Remarks", "Create_Date", "Create_User", "Update_Date", "Update_User"},
        New List(Of String) From {"Year", "Half_Year", "Site_Code", "Grade", "Class_Code"}
    )

    'Public Function GetAll() As List(Of LectureFreeCoefficientEntity)
    '    Dim sql As String = QueryBuilder.BuildSelect(Def)
    '    Return SqlExecutor.Query(sql, AddressOf LectureFreeCoefficientSpecialMapper.Map)
    'End Function

    Public Sub Insert(e As LectureFreeCoefficientEntity)
        Dim sql As String = QueryBuilder.BuildInsert(Def)
        SqlCommandExecutor.Execute(sql, e)
    End Sub

    Public Sub Update(e As LectureFreeCoefficientEntity)
        Dim sql As String = QueryBuilder.BuildUpdate(Def)
        SqlCommandExecutor.Execute(sql, e)
    End Sub

    Public Sub Delete(e As LectureFreeCoefficientEntity)
        Dim sql As String = QueryBuilder.BuildDelete(Def)
        SqlCommandExecutor.Execute(sql, e)
    End Sub
End Class
