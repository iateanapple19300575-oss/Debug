﻿Imports MainApp.Data.Entity
Imports Nts.Freamwork.Common.Utilities

Public Class TimetableClassService

    ''' <summary>
    ''' グループトラン
    ''' </summary>
    Private vmGroupRepository As New VMGroupRepository

    ''' <summary>
    ''' 教室トラン
    ''' </summary>
    Private vmSiteRepository As New VMSiteRepository


    Private timeableClassTran As New TimetableClassRepository


    Private Property TargetDate As Date


    Public Sub New()

    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="p_dataGridView"></param>
    Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
        Me.TargetDate = targetDate
    End Sub

    Public Function LoadGroupData() As ResultData
        Dim result As New ResultData
        Try
            result.ResDataTable = vmGroupRepository.GetAll()
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadSiteData(ByVal group As String) As ResultData
        Dim result As New ResultData
        Try
            result.ResDataTable = vmSiteRepository.FetchByGroup(group)
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadGradeData(ByVal site As String) As ResultData
        Dim result As New ResultData
        Try
            result.ResDataTable = vmSiteRepository.GradeInSite(site)
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadClassData(ByVal site As String) As ResultData
        Dim result As New ResultData
        Try
            result.ResDataTable = vmSiteRepository.ClassInSite(site)
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function


    Public Function LoadTimeTableData(ByVal model As TimetableClassModel) As ResultData
        Dim result As New ResultData
        Try
            Dim entity As New TimetableClassEntity

            entity.Division_KND = model.Group_Code
            If model.NotIncludingPast Then
                DateUtil.NendoToYears(entity.FirstYear, entity.LastYear, model.TargetYear)
            End If
            entity.Site_Code = model.Site_Code
            Dim resultInt As Integer
            If Integer.TryParse(model.Grade, resultInt) Then
                entity.Grade = resultInt
            Else
                entity.Grade = Nothing
            End If
            entity.Class_Code = model.Class_Code

            result.ResDataTable = timeableClassTran.SelectPivotMonth(entity)
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

End Class
