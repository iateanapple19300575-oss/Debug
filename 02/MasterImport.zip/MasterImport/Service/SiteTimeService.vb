﻿'Public Class SiteTimeService

'  Private tran As New SiteTimeTran

'  Public Sub New()

'  End Sub

'  ''' <summary>
'  ''' コンストラクタ
'  ''' </summary>
'  ''' <param name="targetDate"></param>
'  ''' <param name="p_dataGridView"></param>
'  Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
'  End Sub

'  Public Function LoadDistrictData() As ResultData
'    Dim result As New ResultData
'    Try
'      result = tran.LoadDistrictData()
'    Catch ex As Exception
'      Throw
'    End Try

'    Return result
'  End Function

'  Public Function LoadClassRoomData() As ResultData
'    Dim result As New ResultData
'    Try
'      result = tran.LoadClassRoomData()
'    Catch ex As Exception
'      Throw
'    End Try

'    Return result
'  End Function

'  Public Function LoadTimeTableData() As ResultData
'    Dim result As New ResultData
'    Try
'      result = tran.LoadTimeTableData()
'    Catch ex As Exception
'      Throw
'    End Try

'    Return result
'  End Function

'End Class
