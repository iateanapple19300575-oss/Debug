﻿Imports MainApp.Data.Entity

Public Class TimetableSiteService

    ''' <summary>
    ''' グループトラン
    ''' </summary>
    Private vmGroupRepository As New VMGroupRepository

    ''' <summary>
    ''' 教室トラン
    ''' </summary>
    Private vmSiteRepository As New VMSiteRepository

    ''' <summary>
    ''' 教室時間割
    ''' </summary>
    Private timeTableSiteRepository As New TimetableSiteRepository


    Private Property TargetDate As Date

    Public Sub New()

    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="p_dataGridView"></param>
    Sub New(ByVal targetDate As Date, ByVal p_dataGridView As DataGridView)
        Me.TargetDate = targetDate
    End Sub


    Public Function GetYearHistory() As ResultData
        Dim result As New ResultData
        Try
            result.ResDataTable = timeTableSiteRepository.GetYearHistory()
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadGroupData() As ResultData
        Dim result As New ResultData
        Try
            result.ResDataTable = vmGroupRepository.GetAll()
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadSiteData(ByVal group As String) As ResultData
        Dim result As New ResultData
        Try
            result.ResDataTable = vmSiteRepository.FetchByGroup(group)
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function LoadTimeTableData(ByVal model As TimetableSiteModel) As ResultData
        Dim result As New ResultData
        Try
            Dim entity As New TimetableSiteEntity
            entity.TargetYear = model.TargetYear
            entity.Division_KND = model.Group_Code
            entity.Site_Code = model.Site_Code

            result.ResDataTable = timeTableSiteRepository.SelectPivotMonth(entity)
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Function SetComboForSiteCodeWithAll(ByRef cmbClassRoom As ComboBox) As DataTable
        Dim dtTable As New DataTable

        Dim result As ResultData = LoadSiteData("")
        If result.Success Then
            dtTable = result.ResDataTable

            With cmbClassRoom
                Dim newRow As DataRow
                newRow = dtTable.NewRow()
                newRow("Site_Code") = "ZZ"
                newRow("Site_Name") = "ZZ:全教室"
                dtTable.Rows.InsertAt(newRow, 0)

                .DataSource = dtTable
                .DisplayMember = "Site_Name"
                .ValueMember = "Site_Code"
            End With
        End If

        Return dtTable
    End Function



End Class
