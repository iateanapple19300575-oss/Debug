﻿Public Class LectureFeeCoefficientyService
    Inherits ServiceBase

    ''' <summary>
    ''' 講習授業給係数設定DAO
    ''' </summary>
    Private dao As New LectureWagePercentageDao()


    ''' <summary>
    ''' 画面初期表示データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetInitDisplayData() As DataTable
        Dim dt As New DataTable

        Try
            Dim param As New DaoParameter
            dt = dao.GetAll(param)

        Catch ex As Exception
            Throw
        End Try

        Return dt
    End Function

    ''' <summary>
    ''' データ追加
    ''' </summary>
    ''' <param name="data"></param>
    Public Sub Add(ByVal data As LectureWagePercentageData)
        Dim result As Integer

        result = dao.Add(data)
    End Sub

    ''' <summary>
    ''' データ更新
    ''' </summary>
    ''' <param name="param"></param>
    ''' <param name="data"></param>
    Public Sub Update(ByVal param As DaoParameter, ByVal data As LectureWagePercentageData)
        Dim result As Integer

        result = dao.Update(param, data)
    End Sub

    ''' <summary>
    ''' データ削除
    ''' </summary>
    ''' <param name="param"></param>
    Public Sub Delete(ByVal param As DaoParameter)
        Dim result As Integer

        result = dao.Delete(param)
    End Sub

End Class
