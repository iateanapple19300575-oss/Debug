﻿Imports System.ComponentModel

''' <summary>
''' 講師給与単価設定確認画面
''' </summary>
Public Class FrmCheckTeacherUnitPrice
    Inherits BaseEditForm

#Region "プロパティ関連"

    ' 科目識別
    Private Const SUBJECT_KOKU As String = "K"      ' 国語
    Private Const SUBJECT_SANS As String = "M"      ' 算数
    Private Const SUBJECT_SYAK As String = "S"      ' 社会
    Private Const SUBJECT_RIKA As String = "R"      ' 理科
    Private Const SUBJECT_GAKU As String = "G"      ' 学習

    ''' <summary>
    ''' 講師給与単価サービス
    ''' </summary>
    Private _service As New TeacherUnitPriceService()

    ''' <summary>
    ''' 入力欄の値を保持するModel
    ''' </summary>
    Private _editModel As New TeacherUnitPriceModel()

    ''' <summary>
    ''' 型付きで ViewState を扱うためのプロパティ。
    ''' </summary>
    Private ReadOnly Property VS As TeacherUnitPriceViewState
        Get
            Return DirectCast(_viewState, TeacherUnitPriceViewState)
        End Get
    End Property

#End Region

#Region "BaseForm 抽象メソッドの実装"

    ''' <summary>
    ''' Service から ViewState を取得する。
    ''' </summary>
    Protected Overrides Function LoadViewState() As BaseViewState
        BindUIToEditModel()

        ' 取得条件パラメタ生成
        'Dim req As New TeacherUnitPriceEntity
        'req.CondSubjectsDic.Add(SUBJECT_KOKU, _editModel.CondSubjectK)
        'req.CondSubjectsDic.Add(SUBJECT_SANS, _editModel.CondSubjectM)
        'req.CondSubjectsDic.Add(SUBJECT_SYAK, _editModel.CondSubjectS)
        'req.CondSubjectsDic.Add(SUBJECT_RIKA, _editModel.CondSubjectR)
        'req.CondSubjectsDic.Add(SUBJECT_GAKU, _editModel.CondSubjectG)
        'req.CondLatestOnly = _editModel.CondLatestOnly
        'req.CondTeacherCode = _editModel.CondTeacherCode
        'req.CondTeacherName = _editModel.CondTeacherName

        Return _service.LoadViewState(_editModel)
    End Function

    ''' <summary>
    ''' DataGridView に一覧データをバインドする。
    ''' </summary>
    Protected Overrides Sub BindGrid()
        ' データをバインドし一覧表示スタイル設定(DataGridViewカラム定義)
        dgvDataList.DataSource = TeacherUnitPriceMapper.ToDataTable(VS.Items)
        Dim def As New GridColDefTeacherUnitPrice()
        def.Apply(dgvDataList)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgvDataList)
    End Sub

    ''' <summary>
    ''' ViewState の状態に応じて UI の Enabled を制御する。
    ''' </summary>
    Protected Overrides Sub ApplyUIState()
        btnAdd.Enabled = VS.IsAddEnabled()
        btnEdit.Enabled = VS.IsEditEnabled()
        btnDelete.Enabled = VS.IsDeleteEnabled()
        btnSave.Enabled = VS.IsSaveEnabled()
        btnCancel.Enabled = VS.IsCancelEnabled()
        'txtTeacherCode.Text =
        'txtTeacherName =
        'chkLatestOnly =
        'chkSubjectK =
        'chkSubjectM =
        'chkSubjectS =
        'chkSubjectR =
        'chkSubjectG =
        btnSearch.Enabled = VS.IsSearchEnabled()
    End Sub

    ''' <summary>
    ''' EditModel → UI の反映。
    ''' </summary>
    Protected Overrides Sub BindEditModelToUI()
        _editModel.ToUI(Me)
    End Sub

    ''' <summary>
    ''' UI → EditModel の反映。
    ''' </summary>
    Protected Overrides Sub BindUIToEditModel()
        _editModel.FromUI(Me)
    End Sub

#End Region

#Region "画面初期表示"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        'MyBase.New("講師単価設定確認")
        InitializeComponent()
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmTutorUnitPriceSetting_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' TODO: 次期に対応（削除ボタンのみ表示）
        btnAdd.Visible = False
        btnEdit.Visible = False
        btnSave.Visible = False
        btnCancel.Visible = False
        btnDelete.Location = New Point(459, 633)
        ' ---------------------------------------------

        If VS.Items.Count > 0 Then
            dgvDataList.Rows(0).Selected = True
            Dim id = DataGridViewSelectionHelper.GetSelectedValue(Of Integer)(dgvDataList, "Id")
            _viewState.SelectedId = id
        End If
        ApplyUIState()
    End Sub

#End Region

#Region "ボタン押下イベント処理"

    ''' <summary>
    ''' ENTERキー押下：次の項目へ移動
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmTutorUnitPriceSetting_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' 次のコントロールへフォーカス移動
            Me.SelectNextControl(Me.ActiveControl, True, True, True, True)
            ' イベントを処理済みにする
            e.Handled = True
        End If
    End Sub

    ''' <summary>
    ''' [追加]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        VS.EnterAddMode()
        _editModel.Clear()
        BindEditModelToUI()
        ApplyUIState()
    End Sub

    ''' <summary>
    ''' [編集]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

    End Sub

    ''' <summary>
    ''' [削除]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim id = DataGridViewSelectionHelper.GetSelectedValue(Of Integer)(dgvDataList, "Id")
        Dim rowver As Byte() = DataGridViewSelectionHelper.GetSelectedValue(Of Byte())(dgvDataList, "RowVersion")
        If id = 0 Then
            Return
        End If

        Dim result = MessageBox.Show(
            "本当に削除しますか？",
            "確認",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        )

        If result = DialogResult.No Then
            Return
        End If

        VS.EnterDeleteMode(id, rowver)
        _service.Delete(New TeacherUnitPriceModel With {.Id = id, .RowVersion = rowver})

        ReloadView()
        VS.Reset()
        SetSelectedCursor()
        ApplyUIState()
    End Sub

    ''' <summary>
    ''' [保存]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Not VS.CanSave() Then
            Return
        End If

    End Sub

    ''' <summary>
    ''' [キャンセル]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        _editModel.Clear()
        BindEditModelToUI()
        VS.EnterInitMode()
        SetSelectedCursor()
        ApplyUIState()
    End Sub

    ''' <summary>
    ''' [検索]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        ReloadView()
        VS.Reset()
        SetSelectedCursor()
        ApplyUIState()
    End Sub

#End Region

#Region "画面共通部品"

    ''' <summary>
    ''' 選択カーソルを設定する。
    ''' </summary>
    Private Sub SetSelectedCursor()
        _viewState.SelectedId = -1
        If dgvDataList.Rows.Count > 0 Then
            If dgvDataList.SelectedRows.Count >= 0 Then
                Dim id = DataGridViewSelectionHelper.GetSelectedValue(Of Integer)(dgvDataList, "Id")
                Dim rowver As Byte() = DataGridViewSelectionHelper.GetSelectedValue(Of Byte())(dgvDataList, "RowVersion")
                _viewState.SelectedId = id
                _viewState.RowVersion = rowver
            End If
        End If
    End Sub

#End Region

End Class