﻿''' <summary>
''' 講師単価設定確認一覧の 1 行分を表す ViewState モデル。
''' DataGridView に表示されるデータ。
''' </summary>
Public Class TeacherUnitPriceItemViewState

    ''' <summary>
    ''' ID（主キー）
    ''' </summary>
    Public Property Id As Integer?

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property Teacher_Code As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    Public Property Teacher_Name As String = ""

    ''' <summary>
    ''' 適用開始日
    ''' </summary>
    Public Property Effective_Date As Date = DateTime.MinValue

    ''' <summary>
    '''授業給コマ単価
    ''' </summary>
    Public Property Lecture_Unit_Price As Integer?

    ''' <summary>
    ''' 業務給単価
    ''' </summary>
    Public Property Task_Unit_Price As Integer?

    ''' <summary>
    ''' 作成日
    ''' </summary>
    Public Property Create_Date As New Date?

    ''' <summary>
    ''' 作成者
    ''' </summary>
    Public Property Create_User As String = ""

    ''' <summary>
    ''' 更新日時
    ''' </summary>
    Public Property Update_Date As New Date?

    ''' <summary>
    ''' 更新者
    ''' </summary>
    Public Property Update_User As String = ""

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class