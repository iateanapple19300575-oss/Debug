﻿''' <summary>
''' 講師単価設定確認画面の入力欄モデル。
''' ・入力欄の値
''' ・UI ⇔ Model の変換
''' ・クリア処理
''' を担当する。
''' </summary>
Public Class TeacherUnitPriceModel
    Inherits BaseEditModel

    ''' <summary>
    ''' 追加／編集モード
    ''' </summary>
    Public Property Mode As EditMode

    ''' <summary>
    ''' ID
    ''' </summary>
    Public Property Id As Integer?

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property CondTeacherCode As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    Public Property CondTeacherName As String = ""

    ''' <summary>
    ''' 最新のみ
    ''' </summary>
    Public Property CondLatestOnly As Boolean = False

    ''' <summary>
    ''' 国語
    ''' </summary>
    Public Property CondSubjectK As Boolean = True

    ''' <summary>
    ''' 算数
    ''' </summary>
    Public Property CondSubjectM As Boolean = True

    ''' <summary>
    ''' 社会
    ''' </summary>
    Public Property CondSubjectS As Boolean = True

    ''' <summary>
    ''' 理科
    ''' </summary>
    Public Property CondSubjectR As Boolean = True

    ''' <summary>
    ''' 学習
    ''' </summary>
    Public Property CondSubjectG As Boolean = True

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property Teacher_Code As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    Public Property Teacher_Name As String = ""

    ''' <summary>
    ''' 適用年月日
    ''' </summary>
    Public Property Effective_Date As DateTime? = Nothing

    ''' <summary>
    ''' 授業給単価
    ''' </summary>
    Public Property Lecture_Unit_Price As String = ""

    ''' <summary>
    ''' 業務給単価
    ''' </summary>
    Public Property Task_Unit_Price As String = ""

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()


    ''' <summary>
    ''' 入力欄をクリアする。
    ''' </summary>
    Public Overrides Sub Clear()
        CondTeacherCode = ""
        CondTeacherName = ""
        CondLatestOnly = False
        CondSubjectK = True
        CondSubjectM = True
        CondSubjectS = True
        CondSubjectR = True
        CondSubjectG = True
    End Sub

    ''' <summary>
    ''' UI → Model の変換。
    ''' </summary>
    Public Overrides Sub FromUI(form As Form)
        Dim f = DirectCast(form, FrmCheckTeacherUnitPrice)

        CondTeacherCode = f.txtTeacherCode.Text
        CondTeacherName = f.txtTeacherName.Text
        CondLatestOnly = f.chkLatestOnly.Checked
        CondSubjectK = f.chkSubjectK.Checked
        CondSubjectM = f.chkSubjectM.Checked
        CondSubjectS = f.chkSubjectS.Checked
        CondSubjectR = f.chkSubjectR.Checked
        CondSubjectG = f.chkSubjectG.Checked
    End Sub

    ''' <summary>
    ''' Model → UI の反映。
    ''' </summary>
    Public Overrides Sub ToUI(form As Form)
        Dim f = DirectCast(form, FrmCheckTeacherUnitPrice)

        f.txtTeacherCode.Text = CondTeacherCode
        f.txtTeacherName.Text = CondTeacherName
        f.chkLatestOnly.Checked = CondLatestOnly
        f.chkSubjectK.Checked = CondSubjectK
        f.chkSubjectM.Checked = CondSubjectM
        f.chkSubjectS.Checked = CondSubjectS
        f.chkSubjectR.Checked = CondSubjectR
        f.chkSubjectG.Checked = CondSubjectG
    End Sub

End Class