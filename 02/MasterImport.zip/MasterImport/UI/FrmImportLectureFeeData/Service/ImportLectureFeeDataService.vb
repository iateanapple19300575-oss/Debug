﻿Imports ImportType
Imports MainApp.Data.Dto
Imports MasterImport.MainApp.Data.Dto

''' <summary>
''' 講師単価設定取込サービス
''' </summary>
Public Class ImportLectureFeeDataService

    ''' <summary>
    ''' インポート履歴トラン
    ''' </summary>
    Private importHistorysTran As New ImportHistoryRepository()


    ''' <summary>
    ''' 初期表示データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetInitDisplayData() As ImportTimetableOutputDto
        Dim model As New ImportTimetableOutputDto

        Try
            ' 講師給与単価インポート履歴情報取得
            Dim list As List(Of HistoryImportDto)
            list = importHistorysTran.HistoryFinalDateAll()
            For Each rec As HistoryImportDto In list
                ' 講師給与単価：前回件数、前回日時
                If rec.CsvType = ImportCsvType.TeacherUnitPrice Then
                    model.LectureUnitPriceInfo.Count = rec.ExecutionCount
                    model.LectureUnitPriceInfo.ExecDate = rec.ExecutionDate
                    model.LectureUnitPriceInfo.Status = rec.ExecutionStatus
                    Exit For
                End If
            Next
        Catch ex As Exception
            Throw
        End Try

        Return model
    End Function

    ''' <summary>
    ''' CSV取込要求
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function CsvImport(param As CsvImportParameterDto) As ImportTimetableOutputDto
        Dim components = MasterImportComponentFactory.Create(param.CsvType, param)
        Dim importer = New LnstructorUnitPriceCsvImporter(param, components)

        param.Phase = 0
        param.DataType = ImportDataType.TeacherUnitPrice
        param.CourseType = 0
        param.TargetDate = Nothing
        param.PeriodDates = Nothing

        Dim result As New ImportResultInfo
        result = importer.Execute()

        Dim model As New ImportTimetableOutputDto
        model.LectureUnitPriceInfo.ExecDate = result.ExecutDate
        model.LectureUnitPriceInfo.Count = result.ExecutCount
        model.LectureUnitPriceInfo.Status = IIf(result.Success, 0, 1)

        Return model
    End Function

End Class
