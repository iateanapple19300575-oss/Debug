﻿Public Class TeacherWageMergeRepository
  Implements IRepository

  ''' <summary>
  ''' 対象期間過去データ削除
  ''' </summary>
  ''' <param name="targetDate"></param>
  ''' <returns></returns>
  Public Function DeleteSwapData(ByVal targetDate As Date) As Integer
    Dim targetYear As Integer = DateUtil.DateToNendoYear(targetDate)

    Dim SqlQuery As New System.Text.StringBuilder
    SqlQuery.Length = 0
    SqlQuery.Append("MERGE M_Teacher_Wage AS target").Append(" ")
    SqlQuery.Append("USING W_Teacher_Wage AS source").Append(" ")
    SqlQuery.Append("ON target.Teacher_Code = source.Teacher_Code").Append(" ")
    SqlQuery.Append("AND target.Effective_Date = source.Effective_Date").Append(" ")
    SqlQuery.Append("WHEN MATCHED THEN").Append(" ")
    SqlQuery.Append("    UPDATE SET ").Append(" ")
    SqlQuery.Append("    target.Lecture_Unit_Price = source.Lecture_Unit_Price, ").Append(" ")
    SqlQuery.Append("    target.Task_Unit_Price = source.Task_Unit_Price, ").Append(" ")
    SqlQuery.Append("    target.Update_Date = source.Create_Date,").Append(" ")
    SqlQuery.Append("    target.Update_User = source.Create_User").Append(" ")
    SqlQuery.Append("WHEN NOT MATCHED BY TARGET THEN").Append(" ")
    SqlQuery.Append("    INSERT (").Append(" ")
    SqlQuery.Append("        Teacher_Code, ").Append(" ")
    SqlQuery.Append("        Effective_Date, ").Append(" ")
    SqlQuery.Append("        Lecture_Unit_Price,").Append(" ")
    SqlQuery.Append("        Task_Unit_Price,").Append(" ")
    SqlQuery.Append("        Create_Date,").Append(" ")
    SqlQuery.Append("        Create_User,").Append(" ")
    SqlQuery.Append("        Update_Date,").Append(" ")
    SqlQuery.Append("        Update_User").Append(" ")
    SqlQuery.Append("    ) VALUES (").Append(" ")
    SqlQuery.Append("        source.Teacher_Code, ").Append(" ")
    SqlQuery.Append("        source.Effective_Date, ").Append(" ")
    SqlQuery.Append("        source.Lecture_Unit_Price,").Append(" ")
    SqlQuery.Append("        source.Task_Unit_Price,").Append(" ")
    SqlQuery.Append("        source.Create_Date,").Append(" ")
    SqlQuery.Append("        source.Create_User,").Append(" ")
    SqlQuery.Append("        NULL,").Append(" ")
    SqlQuery.Append("        NULL").Append(" ")
    SqlQuery.Append("    )").Append(" ")
    SqlQuery.Append(";")

    Return SqlCommandExecutor.ExecuteNonQuery(SqlQuery.ToString(), Nothing)
  End Function

End Class
