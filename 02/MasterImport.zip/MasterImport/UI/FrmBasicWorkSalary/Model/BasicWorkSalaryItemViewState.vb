﻿''' <summary>
''' 業務給基本設定一覧の 1 行分を表す ViewState モデル。
''' DataGridView に表示されるデータ。
''' </summary>
Public Class BasicWorkSalaryItemViewState

    ''' <summary>ID（主キー）</summary>
    Public Property Id As Integer?

    ''' <summary>
    ''' 適用開始日
    ''' </summary>
    Public Property Effective_Date As Date = DateTime.MinValue

    ''' <summary>
    ''' 業務給標準単価
    ''' </summary>
    Public Property Task_Base_Unit_Price As String = ""

    ''' <summary>
    ''' みなし勤務時間(事前分)
    ''' </summary>
    Public Property Deemed_Time_Before As String = ""

    ''' <summary>
    ''' みなし勤務時間(事後分)
    ''' </summary>
    Public Property Deemed_Time_After As String = ""

    ''' <summary>
    ''' 作成日
    ''' </summary>
    Public Property Create_Date As New Date?

    ''' <summary>
    ''' 作成者
    ''' </summary>
    Public Property Create_User As String = ""

    ''' <summary>
    ''' 更新日時
    ''' </summary>
    Public Property Update_Date As New Date?

    ''' <summary>
    ''' 更新者
    ''' </summary>
    Public Property Update_User As String = ""

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class