Namespace MainApp.Data.Model

    ''' �Ɩ�����{�ݒ��ʂ̓��͗����f���B
    ''' �E���͗��̒l
    ''' �EUI �� Model �̕ϊ�
    ''' �E�N���A����
    ''' ��S������B
    Public Class BasicWorkSalaryModel
        Inherits BaseEditModel

        ''' <summary>
        ''' �ǉ��^�ҏW���[�h
        ''' </summary>
        Public Property Mode As EditMode

        ''' <summary>
        ''' ID
        ''' </summary>
        Public Property Id As Integer?

        ''' <summary>
        ''' �K�p�J�n��
        ''' </summary>
        Public Property Effective_Date_Str As String = ""

        ''' <summary>
        ''' �Ɩ����W���P��
        ''' </summary>
        Public Property Task_Base_Unit_Price_Str As String = ""

        ''' <summary>
        ''' �݂Ȃ��Ζ�����(���O��)
        ''' </summary>
        Public Property Deemed_Time_Before_Str As String = ""

        ''' <summary>
        ''' �݂Ȃ��Ζ�����(���㕪)
        ''' </summary>
        Public Property Deemed_Time_After_Str As String = ""

        ''' <summary>
        ''' �쐬��
        ''' </summary>
        Public Property Create_Date As DateTime?

        ''' <summary>
        ''' �쐬��
        ''' </summary>
        Public Property Create_User As String = ""

        ''' <summary>
        ''' �X�V��
        ''' </summary>
        Public Property Update_Date As DateTime?

        ''' <summary>
        ''' �X�V��
        ''' </summary>
        Public Property Update_User As String = ""

        ''' <summary>
        ''' RowVersion
        ''' </summary>
        Public Property RowVersion As Byte()


        ''' <summary>
        ''' ���͗����N���A����B
        ''' </summary>
        Public Overrides Sub Clear()
            Effective_Date_Str = ""
            Task_Base_Unit_Price_Str = ""
            Deemed_Time_Before_Str = ""
            Deemed_Time_After_Str = ""
        End Sub

        ''' <summary>
        ''' UI �� Model �̕ϊ��B
        ''' </summary>
        Public Overrides Sub FromUI(form As Form)
            Dim f = DirectCast(form, FrmBasicWorkSalary)

            Effective_Date_Str = f.txtEffectiveDate.DateValue
            Task_Base_Unit_Price_Str = f.txtTaskBaseUnitPrice.Value
            Deemed_Time_Before_Str = f.txtDeemedTimeBefore.Value
            Deemed_Time_After_Str = f.txtDeemedTimeAfter.Value
        End Sub

        ''' <summary>
        ''' Model �� UI �̔��f�B
        ''' </summary>
        Public Overrides Sub ToUI(form As Form)
            Dim f = DirectCast(form, FrmBasicWorkSalary)

            f.txtEffectiveDate.DateValue = DateUtil.DateStringToTryDate(Effective_Date_Str)
            f.txtTaskBaseUnitPrice.Value = NumberUtil.StringNumberToDecimal(Task_Base_Unit_Price_Str)
            f.txtDeemedTimeBefore.Value = NumberUtil.StringNumberToDecimal(Deemed_Time_Before_Str)
            f.txtDeemedTimeAfter.Value = NumberUtil.StringNumberToDecimal(Deemed_Time_After_Str)
        End Sub

    End Class

End Namespace
