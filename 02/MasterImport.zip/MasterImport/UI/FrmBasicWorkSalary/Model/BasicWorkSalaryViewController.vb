﻿'Imports MasterImport.MainApp.Data.Dto
'Imports MasterImport.MainApp.Data.Entity
'Imports MasterImport.MainApp.Data.Model
'Imports Repositories

'Public Class BasicWorkSalaryViewController

'  Private ReadOnly _view As FrmBasicWorkSalary
'  Private ReadOnly _service As BasicWorkSalaryService
'  Private ReadOnly _repository As IRepository(Of HourlyWageEntity)
'  Private ReadOnly _validator As IValidator(Of HourlyWageEntity)

'  Private Enum EditMode
'    None
'    Add
'    Edit
'  End Enum

'  Private _editMode As EditMode = EditMode.None

'  ''' <summary>
'  ''' コンストラクタ
'  ''' </summary>
'  ''' <param name="view"></param>
'  Public Sub New(ByVal view As FrmBasicWorkSalary)
'    _view = view
'    _repository = New HourlyWageRepository
'    _validator = New BasicWorkSalaryValidator
'    _service = New BasicWorkSalaryService(_repository, _validator)
'  End Sub

'  ''' <summary>
'  ''' 初期化処理
'  ''' </summary>
'  ''' <param name="model"></param>
'  Public Sub Initialize(ByVal model As BasicWorkSalaryModel)
'    SetBlankInTextBox(model)
'    _view.SetModel(model)
'  End Sub

'  ''' <summary>
'  ''' 
'  ''' </summary>
'  ''' <returns></returns>
'  Public Function LoadData() As DataTable
'    _editMode = EditMode.None

'    Return _service.GetAllDataTable()
'  End Function


'  ''' <summary>
'  ''' [追加]ボタン押下
'  ''' </summary>
'  ''' <param name="model"></param>
'  Public Sub AddButtonClick(ByVal model As BasicWorkSalaryModel)
'    _editMode = EditMode.Add
'    SetBlankInTextBox(model)
'    SetModel(model)
'  End Sub

'  ''' <summary>
'  ''' [編集]ボタン押下
'  ''' </summary>
'  ''' <param name="model"></param>
'  Public Sub EditButtonClick(ByVal model As BasicWorkSalaryModel)
'    _editMode = EditMode.Edit
'    SetModel(model)
'  End Sub

'  ''' <summary>
'  ''' [削除]ボタン押下
'  ''' </summary>
'  ''' <param name="model"></param>
'  Public Sub DeleteButtonClick(ByVal model As BasicWorkSalaryModel)
'    _editMode = EditMode.None
'    _service.ExecuteDelete(ToDto(model))
'    SetBlankInTextBox(model)
'    SetModel(model)
'  End Sub

'  ''' <summary>
'  ''' [保存]ボタン押下
'  ''' </summary>
'  ''' <param name="model"></param>
'  Public Sub SaveButtonClick(ByVal model As BasicWorkSalaryModel)
'    _editMode = EditMode.None

'    Dim dto As BasicWorkSalaryDto = ToDto(model)

'    If _editMode = EditMode.Add Then
'      _service.ExecuteInsert(dto)
'    Else
'      _service.ExecuteUpdate(dto)
'    End If

'    SetModel(model)
'  End Sub

'  ''' <summary>
'  ''' [キャンセル]ボタン押下
'  ''' </summary>
'  ''' <param name="model"></param>
'  Public Sub CancelButtonClick(ByVal model As BasicWorkSalaryModel)
'    _editMode = EditMode.None
'    SetBlankInTextBox(model)
'    SetModel(model)
'  End Sub

'  ''' <summary>
'  ''' 入力欄データをクリアする。
'  ''' </summary>
'  ''' <param name="model"></param>
'  Private Sub SetBlankInTextBox(ByRef model As BasicWorkSalaryModel)
'    model.Effective_Date = DateTime.MinValue
'    model.Task_Base_Unit_Price = ""
'    model.Deemed_Time_Before = ""
'    model.Deemed_Time_After = ""
'  End Sub

'    '''' <summary>
'    '''' Formに渡すデータをモデルに設定する。
'    '''' </summary>
'    '''' <param name="model"></param>
'    'Public Sub SetModel(ByVal model As BasicWorkSalaryModel)

'    '  '' 初期状態を空欄にする
'    '  'DateTimePicker1.Format = DateTimePickerFormat.Custom
'    '  'DateTimePicker1.CustomFormat = " " ' 半角スペースで空欄表示

'    '  'DateTimePicker1.Format = DateTimePickerFormat.Short
'    '  'DateTimePicker1.CustomFormat = Nothing

'    '  _view.SetModel(
'    '          New BasicWorkSalaryModel With {
'    '              .Effective_Date = model.Effective_Date,
'    '              .Task_Base_Unit_Price = model.Task_Base_Unit_Price,
'    '              .Deemed_Time_Before = model.Deemed_Time_Before,
'    '              .Deemed_Time_After = model.Deemed_Time_After,
'    '              .Btn_Add_Enabled = (_editMode = EditMode.None),
'    '              .Btn_Edit_Enabled = (_editMode = EditMode.None AndAlso model.CurrentRow IsNot Nothing),
'    '              .Btn_Delete_Enabled = (_editMode = EditMode.None AndAlso model.CurrentRow IsNot Nothing),
'    '              .Btn_Save_Enabled = (_editMode <> EditMode.None),
'    '              .Btn_Cancel_Enabled = (_editMode <> EditMode.None)
'    '          }
'    '      )
'    'End Sub

'    ''' <summary>
'    ''' MODEL→DTO変換
'    ''' </summary>
'    ''' <param name="model"></param>
'    ''' <returns></returns>
'    Public Shared Function ToDto(model As BasicWorkSalaryModel) As BasicWorkSalaryDto
'    If model Is Nothing Then
'      Return Nothing
'    End If

'    Return New BasicWorkSalaryDto With {
'            .Effective_Date = model.Effective_Date,
'            .Task_Base_Unit_Price = model.Task_Base_Unit_Price,
'            .Deemed_Time_Before = model.Deemed_Time_Before,
'            .Deemed_Time_After = model.Deemed_Time_After
'        }
'  End Function

'  ''' <summary>
'  ''' DTO→MODEL変換
'  ''' </summary>
'  ''' <param name="dto"></param>
'  ''' <returns></returns>
'  Public Shared Function ToModel(dto As BasicWorkSalaryDto) As BasicWorkSalaryModel
'    If dto Is Nothing Then
'      Return Nothing
'    End If

'    Return New BasicWorkSalaryModel With {
'            .Effective_Date = dto.Effective_Date,
'            .Task_Base_Unit_Price = dto.Task_Base_Unit_Price,
'            .Deemed_Time_Before = dto.Deemed_Time_Before,
'            .Deemed_Time_After = dto.Deemed_Time_After
'        }
'  End Function

'End Class
