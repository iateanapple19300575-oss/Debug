'Namespace MainApp.Data.Entity

'    ''' <summary>
'    ''' Entity�B
'    ''' </summary>
'    Public Class HourlyWageEntity

'        ''' <summary>�ǉ��^�ҏW���[�h</summary>
'        Public Property Mode As EditMode

'        ''' <summary>
'        ''' Id
'        ''' </summary>
'        Public Property Id As Long

'        ''' <summary>
'        ''' �K�p�J�n��
'        ''' </summary>
'        Public Property Effective_Date_Str As String = ""

'        ''' <summary>
'        ''' �Ɩ����W���P��
'        ''' </summary>
'        Public Property Task_Base_Unit_Price_Str As String = ""

'        ''' <summary>
'        ''' �݂Ȃ��Ζ�����(���O��)
'        ''' </summary>
'        Public Property Deemed_Time_Before_Str As String = ""

'        ''' <summary>
'        ''' �݂Ȃ��Ζ�����(���㕪)
'        ''' </summary>
'        Public Property Deemed_Time_After_Str As String = ""

'        ''' <summary>
'        ''' �쐬��
'        ''' </summary>
'        Public Property Create_Date As DateTime

'        ''' <summary>
'        ''' �쐬��
'        ''' </summary>
'        Public Property Create_User As String

'        ''' <summary>
'        ''' �X�V��
'        ''' </summary>
'        Public Property Update_Date As DateTime

'        ''' <summary>
'        ''' �X�V��
'        ''' </summary>
'        Public Property Update_User As String

'        ''' <summary>
'        ''' RowVersion
'        ''' </summary>
'        Public Property RowVersion As Byte()

'    End Class

'End Namespace
