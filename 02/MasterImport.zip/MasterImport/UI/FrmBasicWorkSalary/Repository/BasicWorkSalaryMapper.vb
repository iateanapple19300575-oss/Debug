﻿''' <summary>
''' DataTable と ViewState モデルの相互変換を行うマッパー。
''' DataGridView と内部モデルの橋渡しを担当する。
''' </summary>
Public Class BasicWorkSalaryMapper

    ''' <summary>
    ''' DataTable → List(Of MasterItemViewState)
    ''' </summary>
    Public Shared Function ToViewStateList(dt As DataTable) As List(Of BasicWorkSalaryItemViewState)
        Dim list As New List(Of BasicWorkSalaryItemViewState)
        Dim ts As TimeSpan = TimeSpan.Zero
        For Each row As DataRow In dt.Rows
            Dim rec As New BasicWorkSalaryItemViewState
            rec.Id = CInt(row("Id"))
            rec.Effective_Date = ConvertValue(row("Effective_Date"), GetType(Date))
            rec.Task_Base_Unit_Price = ConvertValue(row("Task_Base_Unit_Price"), GetType(Integer))
            rec.Deemed_Time_Before = ConvertValue(row("Deemed_Time_Before"), GetType(Integer))
            rec.Deemed_Time_After = ConvertValue(row("Deemed_Time_After"), GetType(Integer))
            rec.Create_Date = ConvertValue(row("Create_Date"), GetType(DateTime))
            rec.Create_User = ConvertValue(row("Create_User"), GetType(String))
            rec.Update_Date = ConvertValue(row("Update_Date"), GetType(DateTime))
            rec.Update_User = ConvertValue(row("Update_User"), GetType(String))
            rec.RowVersion = DirectCast(row("RowVersion"), Byte())

            list.Add(rec)
        Next

        Return list
    End Function

    ''' <summary>
    ''' List(Of MasterItemViewState) → DataTable（DataGridView 用）
    ''' </summary>
    Public Shared Function ToDataTable(items As List(Of BasicWorkSalaryItemViewState)) As DataTable
        Dim dt As New DataTable()

        dt.Columns.Add("Id", GetType(Integer))
        dt.Columns.Add("Effective_Date", GetType(Date))
        dt.Columns.Add("Task_Base_Unit_Price", GetType(Integer))
        dt.Columns.Add("Deemed_Time_Before", GetType(Integer))
        dt.Columns.Add("Deemed_Time_After", GetType(Integer))
        dt.Columns.Add("Create_Date", GetType(DateTime))
        dt.Columns.Add("Create_User", GetType(String))
        dt.Columns.Add("Update_Date", GetType(DateTime))
        dt.Columns.Add("Update_User", GetType(String))
        dt.Columns.Add("RowVersion", GetType(Byte()))

        For Each item In items
            Dim row As DataRow = dt.NewRow()

            row("Id") = item.Id
            row("Effective_Date") = item.Effective_Date
            row("Task_Base_Unit_Price") = item.Task_Base_Unit_Price
            row("Deemed_Time_Before") = item.Deemed_Time_Before
            row("Deemed_Time_After") = item.Deemed_Time_After
            'row("Create_Date") = item.Create_Date
            'row("Create_User") = item.Create_User
            'row("Update_Date") = item.Update_Date
            'row("Update_User") = item.Update_User
            row("RowVersion") = item.RowVersion

            dt.Rows.Add(row)
        Next

        Return dt
    End Function

    Private Shared Function ConvertValue(value As Object, targetType As Type) As Object
        If value Is Nothing OrElse value Is DBNull.Value Then
            Return Nothing
        End If

        If targetType.IsGenericType AndAlso targetType.GetGenericTypeDefinition() Is GetType(Nullable(Of )) Then
            targetType = Nullable.GetUnderlyingType(targetType)
        End If

        If targetType Is GetType(Byte()) Then
            Return DirectCast(value, Byte())
        End If
        If targetType.IsEnum Then
            Return [Enum].Parse(targetType, value.ToString())
        End If
        If targetType Is GetType(Guid) Then
            Return New Guid(value.ToString())
        End If
        'If targetType Is GetType(TimeSpan) Then
        '    Return DirectCast(value, TimeSpan)
        'End If

        Return Convert.ChangeType(value, targetType)
    End Function

End Class