﻿Public Class HourlyWageDto

    ''' <summary>
    ''' Id
    ''' </summary>
    Public Property Id As Long?

    ''' <summary>
    ''' Effective_Date
    ''' </summary>
    Public Property Effective_Date As Date?

    ''' <summary>
    ''' Task_Base_Unit_Price
    ''' </summary>
    Public Property Task_Base_Unit_Price As Integer?

    ''' <summary>
    ''' Deemed_Time_Before
    ''' </summary>
    Public Property Deemed_Time_Before As TimeSpan?

    ''' <summary>
    ''' Deemed_Time_After
    ''' </summary>
    Public Property Deemed_Time_After As TimeSpan?

    ''' <summary>
    ''' Create_Date
    ''' </summary>
    Public Property Create_Date As DateTime?

    ''' <summary>
    ''' Create_User
    ''' </summary>
    Public Property Create_User As String = ""

    ''' <summary>
    ''' Update_Date
    ''' </summary>
    Public Property Update_Date As DateTime?

    ''' <summary>
    ''' Update_User
    ''' </summary>
    Public Property Update_User As String = ""

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class