﻿Imports MasterImport.MainApp.Data.Model
Imports Repositories

''' <summary>
''' 業務給基本設定画面
''' </summary>
Public Class FrmBasicWorkSalary
    Inherits BaseEditForm

#Region "プロパティ関連"

    ''' <summary>
    ''' 業務給基本設定画面サービスクラス
    ''' </summary>
    Private _controller As New BasicWorkSalaryViewController

    ''' <summary>
    ''' 業務給基本設定画面サービスクラス
    ''' </summary>
    Private _service As New BasicWorkSalaryService

    ''' <summary>
    ''' 入力欄の値を保持する Model
    ''' </summary>
    Private _editModel As New BasicWorkSalaryModel()

    ''' <summary>
    ''' 型付きで ViewState を扱うためのプロパティ。
    ''' </summary>
    Private ReadOnly Property VS As BasicWorkSalaryViewState
        Get
            Return DirectCast(_viewState, BasicWorkSalaryViewState)
        End Get
    End Property

#End Region

#Region "BaseForm 抽象メソッドの実装"

    ''' <summary>
    ''' Service から ViewState を取得する。
    ''' </summary>
    Protected Overrides Function LoadViewState() As BaseViewState
        Return _service.LoadViewState()
    End Function

    ''' <summary>
    ''' DataGridView に一覧データをバインドする。
    ''' </summary>
    Protected Overrides Sub BindGrid()
        ' データをバインドし一覧表示スタイル設定(DataGridViewカラム定義)
        dgvDataList.DataSource = BasicWorkSalaryMapper.ToDataTable(VS.Items)
        Dim def As New GridColDefBasePriceStyle()
        def.Apply(dgvDataList)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgvDataList)
    End Sub

    ''' <summary>
    ''' ViewState の状態に応じて UI の Enabled を制御する。
    ''' </summary>
    Protected Overrides Sub ApplyUIState()
        btnAdd.Enabled = VS.IsAddEnabled()
        btnEdit.Enabled = VS.IsEditEnabled()
        btnDelete.Enabled = VS.IsDeleteEnabled()
        btnSave.Enabled = VS.IsSaveEnabled()
        btnCancel.Enabled = VS.IsCancelEnabled()

        pnlLeftRow1Panel.Visible = False
        pnlLeftRow2Panel.Visible = VS.IsInputPanelEnabled()
    End Sub

    ''' <summary>
    ''' EditModel → UI の反映。
    ''' </summary>
    Protected Overrides Sub BindEditModelToUI()
        _editModel.ToUI(Me)
    End Sub

    ''' <summary>
    ''' UI → EditModel の反映。
    ''' </summary>
    Protected Overrides Sub BindUIToEditModel()
        _editModel.FromUI(Me)
    End Sub

#End Region

#Region "画面初期表示"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        'MyBase.New("業務給基本設定")
        InitializeComponent()
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmBasicWorkSalary_Load(sender As Object, e As EventArgs) Handles Me.Load
        If VS.Items.Count > 0 Then
            dgvDataList.Rows(0).Selected = True
            Dim id = DataGridViewSelectionHelper.GetSelectedValue(Of Integer)(dgvDataList, "Id")
            _viewState.SelectedId = id
        End If
        ApplyUIState()
    End Sub

#End Region

#Region "ボタン押下イベント処理"

    ''' <summary>
    ''' ENTERキー押下：次の項目へ移動
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmTutorUnitPriceSetting_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' 次のコントロールへフォーカス移動
            Me.SelectNextControl(Me.ActiveControl, True, True, True, True)
            ' イベントを処理済みにする
            e.Handled = True
        End If
    End Sub

    ''' <summary>
    ''' [追加]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        VS.EnterAddMode()
        _editModel.Clear()
        BindEditModelToUI()
        ApplyUIState()
        txtEffectiveDate.Focus()
    End Sub

    ''' <summary>
    ''' [編集]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim id = DataGridViewSelectionHelper.GetSelectedValue(Of Integer)(dgvDataList, "Id")
        Dim rowver As Byte() = DataGridViewSelectionHelper.GetSelectedValue(Of Byte())(dgvDataList, "RowVersion")
        If id = 0 Then
            Return
        End If

        VS.EnterEditMode(id, rowver)
        Dim item = VS.Items.First(Function(x) x.Id = id)

        _editModel.Id = item.Id
        _editModel.Effective_Date_Str = item.Effective_Date
        _editModel.Task_Base_Unit_Price_Str = item.Task_Base_Unit_Price
        _editModel.Deemed_Time_Before_Str = item.Deemed_Time_Before
        _editModel.Deemed_Time_After_Str = item.Deemed_Time_After
        _editModel.RowVersion = item.RowVersion.Select(Function(b) CType(b, Byte)).ToArray()

        BindEditModelToUI()
        ApplyUIState()
        txtEffectiveDate.Focus()
        'txtEffectiveDate.txt.SelectionStart = 0
        'txtEffectiveDate.txt.SelectionLength = 0
        txtEffectiveDate.txt.SelectAll()

    End Sub

    ''' <summary>
    ''' [削除]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim id = DataGridViewSelectionHelper.GetSelectedValue(Of Integer)(dgvDataList, "Id")
        Dim rowver As Byte() = DataGridViewSelectionHelper.GetSelectedValue(Of Byte())(dgvDataList, "RowVersion")
        If id = 0 Then
            Return
        End If

        Dim result = MessageBox.Show(
            "本当に削除しますか？",
            "確認",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        )

        If result = DialogResult.No Then
            Return
        End If

        VS.EnterDeleteMode(id, rowver)
        _service.Delete(New BasicWorkSalaryModel With {.Id = id, .RowVersion = rowver})

        ReloadView()
        VS.Reset()
        SetSelectedCursor()
        ApplyUIState()
    End Sub

    ''' <summary>
    ''' [保存]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If Not VS.CanSave() Then
            Return
        End If

        BindUIToEditModel()

        Dim model As New BasicWorkSalaryModel With {
            .Mode = VS.Mode,
            .Id = _editModel.Id,
            .Effective_Date_Str = _editModel.Effective_Date_Str,
            .Task_Base_Unit_Price_Str = _editModel.Task_Base_Unit_Price_Str,
            .Deemed_Time_Before_Str = _editModel.Deemed_Time_Before_Str,
            .Deemed_Time_After_Str = _editModel.Deemed_Time_After_Str,
            .RowVersion = _viewState.RowVersion
        }

        Dim errors = _controller.Validate(model)
        If errors.Count > 0 Then
            MessageBox.Show(String.Join(Environment.NewLine, errors.ToArray))
            Return
        End If

        _service.Save(model)

        'Dim errors = _service.Save(model)
        'If errors.Count > 0 Then
        '    MessageBox.Show(String.Join(Environment.NewLine, errors.ToArray))
        '    Return
        'End If

        VS.Reset()
        ReloadView()
        SetSelectedCursor()
        ApplyUIState()
        IsDirty = False

    End Sub

    ''' <summary>
    ''' [キャンセル]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        _editModel.Clear()
        BindEditModelToUI()
        VS.EnterInitMode()
        SetSelectedCursor()
        ApplyUIState()
    End Sub

#End Region

#Region "画面共通部品"

    ''' <summary>
    ''' 選択カーソルを設定する。
    ''' </summary>
    Private Sub SetSelectedCursor()
        _viewState.SelectedId = -1
        If dgvDataList.Rows.Count > 0 Then
            If dgvDataList.SelectedRows.Count >= 0 Then
                Dim id = DataGridViewSelectionHelper.GetSelectedValue(Of Integer)(dgvDataList, "Id")
                Dim rowver As Byte() = DataGridViewSelectionHelper.GetSelectedValue(Of Byte())(dgvDataList, "RowVersion")
                _viewState.SelectedId = id
                _viewState.RowVersion = rowver
            End If
        End If
    End Sub

    Private Sub dgvDataList_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvDataList.CellFormatting
        If IsTimeFormat(dgvDataList.Columns(e.ColumnIndex).Name) AndAlso e.Value IsNot Nothing Then
            If TypeOf e.Value Is TimeSpan Then
                Dim ts As TimeSpan = DirectCast(e.Value, TimeSpan)
                e.Value = String.Format("{0:F0}", ts.TotalMinutes)
                e.FormattingApplied = True ' 書式適用済みをマーク
                'If TimeSpan.TryParse(e.Value.ToString(), dateValue) Then
                '    e.Value = dateValue.ToString("HH:mm")
                '    e.FormattingApplied = True ' 書式適用済みをマーク
                'End If
            End If
        End If
    End Sub

    ''' <summary>
    ''' 時間( HH:mm)フォーマット項目判定
    ''' </summary>
    ''' <param name="colName"></param>
    ''' <returns></returns>
    Private Function IsTimeFormat(ByVal colName As String) As Boolean
        Dim timeFields As String() = {
                "Deemed_Time_Before", "Deemed_Time_After"
            }
        Return timeFields.Contains(colName)
    End Function

#End Region

End Class