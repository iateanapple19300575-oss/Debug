﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmImportTimetableData
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ctlTimePattern = New UserControl.ImportCheckControl()
        Me.ctlSiteTimeTable = New UserControl.ImportCheckControl()
        Me.ctlClassTimeTable = New UserControl.ImportCheckControl()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ctlTimePattern
        '
        Me.ctlTimePattern.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ctlTimePattern.CurrentCount = "--,---件"
        Me.ctlTimePattern.CurrentResult = "状態"
        Me.ctlTimePattern.CurrentTime = "----/--/-- --:--"
        Me.ctlTimePattern.DataTypeLabel = "時間パターン"
        Me.ctlTimePattern.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ctlTimePattern.LastImportCount = "--,---件"
        Me.ctlTimePattern.LastImportTime = "----/--/-- --:--"
        Me.ctlTimePattern.LastResult = "状態"
        Me.ctlTimePattern.Location = New System.Drawing.Point(13, 13)
        Me.ctlTimePattern.Margin = New System.Windows.Forms.Padding(4)
        Me.ctlTimePattern.Name = "ctlTimePattern"
        Me.ctlTimePattern.Size = New System.Drawing.Size(788, 129)
        Me.ctlTimePattern.TabIndex = 1
        '
        'ctlSiteTimeTable
        '
        Me.ctlSiteTimeTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ctlSiteTimeTable.CurrentCount = "--,---件"
        Me.ctlSiteTimeTable.CurrentResult = "状態"
        Me.ctlSiteTimeTable.CurrentTime = "----/--/-- --:--"
        Me.ctlSiteTimeTable.DataTypeLabel = "教室時間割"
        Me.ctlSiteTimeTable.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ctlSiteTimeTable.LastImportCount = "--,---件"
        Me.ctlSiteTimeTable.LastImportTime = "----/--/-- --:--"
        Me.ctlSiteTimeTable.LastResult = "状態"
        Me.ctlSiteTimeTable.Location = New System.Drawing.Point(13, 150)
        Me.ctlSiteTimeTable.Margin = New System.Windows.Forms.Padding(4)
        Me.ctlSiteTimeTable.Name = "ctlSiteTimeTable"
        Me.ctlSiteTimeTable.Size = New System.Drawing.Size(788, 129)
        Me.ctlSiteTimeTable.TabIndex = 2
        '
        'ctlClassTimeTable
        '
        Me.ctlClassTimeTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ctlClassTimeTable.CurrentCount = "--,---件"
        Me.ctlClassTimeTable.CurrentResult = "状態"
        Me.ctlClassTimeTable.CurrentTime = "----/--/-- --:--"
        Me.ctlClassTimeTable.DataTypeLabel = "クラス別時間割"
        Me.ctlClassTimeTable.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ctlClassTimeTable.LastImportCount = "--,---件"
        Me.ctlClassTimeTable.LastImportTime = "----/--/-- --:--"
        Me.ctlClassTimeTable.LastResult = "状態"
        Me.ctlClassTimeTable.Location = New System.Drawing.Point(13, 287)
        Me.ctlClassTimeTable.Margin = New System.Windows.Forms.Padding(4)
        Me.ctlClassTimeTable.Name = "ctlClassTimeTable"
        Me.ctlClassTimeTable.Size = New System.Drawing.Size(788, 129)
        Me.ctlClassTimeTable.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(36, 433)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(358, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "「データ確認」からCSVファイルを出力することができます"
        '
        'FrmImportTimetableData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(814, 472)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ctlClassTimeTable)
        Me.Controls.Add(Me.ctlSiteTimeTable)
        Me.Controls.Add(Me.ctlTimePattern)
        Me.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmImportTimetableData"
        Me.Text = "時間割設定データ取込"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ctlTimePattern As UserControl.ImportCheckControl
  Friend WithEvents ctlSiteTimeTable As UserControl.ImportCheckControl
  Friend WithEvents ctlClassTimeTable As UserControl.ImportCheckControl
  Friend WithEvents Label1 As Label
End Class
