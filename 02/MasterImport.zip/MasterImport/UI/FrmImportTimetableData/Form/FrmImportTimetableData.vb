﻿Imports Freamwork.Common.Helper
Imports ImportType
Imports MainApp.Data.Dto
Imports MasterImport.MainApp.Data.Dto
Imports UserControl

''' <summary>
''' 時間割設定データ取込画面
''' 
''' 以下の時間割データの取り込みを行います。
''' ・時間パターン
''' ・教室時間割データ
''' ・クラス別時間割データ
''' </summary>
Public Class FrmImportTimetableData
    Inherits BaseForm

#Region "フィールド変数関連"

    ''' <summary>
    ''' CSV取込用ユーザコントロール
    ''' </summary>
    Private _currentUserControl As ImportCheckControl

    ''' <summary>
    ''' 時間割設定データ取込画面 ViewController
    ''' </summary>
    Private _viewController As ImportTimetableDataViewController

#End Region

#Region "Windowsイベント"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("時間割設定データ取込")
        InitializeComponent()

        FormLogWrapper.WrapFormLifecycle(Me)
        FormLogWrapper.WrapAllEvents(Me)
    End Sub

#End Region

#Region "初期表示処理"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmMasterImport_Load(sender As Object, e As EventArgs) Handles Me.Load
        MouseCursor.WaitCursor(Me)

        _viewController = New ImportTimetableDataViewController(Me)

        ' 画面初期表示処理
        InitDisplay()

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' 画面初期表示処理
    ''' </summary>
    Private Sub InitDisplay()

        ' 前回のCSV取込結果情報の取得と表示
        DisplayHistory()

    End Sub

#End Region

#Region "[データ取込]ボタン押下イベント"

    ''' <summary>
    ''' 時間パターン[取込]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlTimePattern_ImportButtonClick(ByVal sender As Object, e As EventArgs) Handles ctlTimePattern.ImportButtonClick
        MouseCursor.WaitCursor(Me)

        Dim param As New CsvImportParameterDto With {
          .FilePath = ctlTimePattern.FilePath,
          .CsvType = ImportCsvType.TimePattern
        }

        Dim result As CsvImportResultOutputDto
        result = _viewController.CsvImport(param)
        CsvImportResultDisplay(result, ctlTimePattern)

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' 教室時間割[取込]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlSiteTimeTable_ImportButtonClick(sender As Object, e As EventArgs) Handles ctlSiteTimeTable.ImportButtonClick
        MouseCursor.WaitCursor(Me)

        Dim param As New CsvImportParameterDto With {
          .FilePath = ctlSiteTimeTable.FilePath,
          .CsvType = ImportCsvType.TimeTableSite
        }

        Dim result As CsvImportResultOutputDto
        result = _viewController.CsvImport(param)
        CsvImportResultDisplay(result, ctlSiteTimeTable)

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' クラス時間割[取込]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlClassTimeTable_ImportButtonClick(sender As Object, e As EventArgs) Handles ctlClassTimeTable.ImportButtonClick
        MouseCursor.WaitCursor(Me)

        Dim param As New CsvImportParameterDto With {
          .FilePath = ctlClassTimeTable.FilePath,
          .CsvType = ImportCsvType.TimeTableClass
        }

        Dim result As CsvImportResultOutputDto
        result = _viewController.CsvImport(param)
        CsvImportResultDisplay(result, ctlClassTimeTable)

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' 取込結果表示
    ''' </summary>
    ''' <param name="result"></param>
    Private Sub CsvImportResultDisplay(result As CsvImportResultOutputDto, uctrl As ImportCheckControl)
        uctrl.SetCurrentImportResult(result.ProcessedAt, result.ProcessCount, result.ProcessMessage)
    End Sub

#End Region

#Region "[データ確認]ボタン押下イベント"

    ''' <summary>
    ''' [時間パターンデータ確認]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlTimePattern_ViewButtonClick(sender As Object, e As EventArgs) Handles ctlTimePattern.ViewButtonClick
        MouseCursor.WaitCursor(Me)

        Dim frm As Form = New FrmCheckTimePattern(AppState.TargetYearMonth, AppState.TargetYearMonth)
        frm.StartPosition = FormStartPosition.CenterParent
        frm.ShowDialog(Me)

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' [教室時間割データ確認]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlSiteTimeTable_ViewButtonClick(sender As Object, e As EventArgs) Handles ctlSiteTimeTable.ViewButtonClick
        MouseCursor.WaitCursor(Me)

        Dim frm As Form = New FrmCheckTimeTableSite
        frm.StartPosition = FormStartPosition.CenterParent
        frm.ShowDialog()

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' [クラス時間割データ確認]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ctlClassTimeTable_ViewButtonClick(sender As Object, e As EventArgs) Handles ctlClassTimeTable.ViewButtonClick
        MouseCursor.WaitCursor(Me)

        Dim frm As Form = New FrmCheckTimeTableClass
        frm.StartPosition = FormStartPosition.CenterParent
        frm.ShowDialog()

        MouseCursor.DefaultCursor(Me)
    End Sub

#End Region

    ''' <summary>
    ''' 履歴情報の初期表示
    ''' </summary>
    Private Sub DisplayHistory()

        ' 前回のCSV取込結果情報の取得
        Dim model As ImportTimetableOutputDto
        model = _viewController.InitialDisplayData()

        Dim lastDate As String
        Dim lastCount As String
        Dim lastStatus As String
        Dim info As ProcessResultInfoDto

        ' [時間パターン]
        '  取込最終件数、取込最終日時
        info = model.TimePatternInfo
        lastDate = DateUtil.EmptyDateToDefaultLong(info.ExecDate)
        lastCount = NumberUtil.DigitComma(info.Count)
        lastStatus = info.StatusStr
        ctlTimePattern.SetLastImportResult(lastDate, lastCount, lastStatus)

        ' [教室時間割]
        '  取込最終件数、取込最終日時
        info = model.TimetableSiteInfo
        lastDate = DateUtil.EmptyDateToDefaultLong(info.ExecDate)
        lastCount = NumberUtil.DigitComma(info.Count)
        lastStatus = info.StatusStr
        ctlSiteTimeTable.SetLastImportResult(lastDate, lastCount, lastStatus)

        ' [クラス別時間割]
        '  取込最終件数、取込最終日時
        info = model.TimetableSiteInfo
        lastDate = DateUtil.EmptyDateToDefaultLong(info.ExecDate)
        lastCount = NumberUtil.DigitComma(info.Count)
        lastStatus = info.StatusStr
        ctlClassTimeTable.SetLastImportResult(lastDate, lastCount, lastStatus)
    End Sub

End Class