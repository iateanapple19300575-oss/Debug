﻿Public Class FrmCheckTimePattern
    Inherits BaseForm

    ' 画面名
    Private Const SCREEN_NAME As String = "時刻パターンデータ確認"

    ' CSV出力ファイル名接頭辞
    Private Const EXPORT_FILE_NAME_PREFIX = "時刻パターン"

#Region "画面変数関連"

    ''' <summary>
    ''' 時間割画面サービス
    ''' </summary>
    Private service As New TimeScheduleService()

    ''' <summary>
    ''' アプリ対象年月度
    ''' </summary>
    ''' <returns></returns>
    Private Property TargetMonth As Date

    ''' <summary>
    ''' 画面表示対象の月
    ''' </summary>
    ''' <returns></returns>
    Private Property DisplayMonth As Date

#End Region

#Region "画面クラス初期化"

    Public Sub New()
        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後で初期化を追加します。
        Me.TargetMonth = Nothing
        Me.DisplayMonth = Nothing
    End Sub

    Public Sub New(ByVal targetMonth As Date, ByVal yearMonth As Date)
        MyBase.New("時間パターンデータ確認")

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後で初期化を追加します。
        Me.TargetMonth = targetMonth
        Me.DisplayMonth = yearMonth
    End Sub

#End Region

#Region "Windowsイベント"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmTimePattern_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitDisplay()

        ' モニタ中央に表示する設定
        Me.StartPosition = FormStartPosition.CenterScreen

    End Sub

    ''' <summary>
    ''' 表示対象年月のスピンボタン押下イベント(値変更イベント)
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub dtpYearMonth_ValueChanged(sender As Object, e As EventArgs) Handles dtpYearMonth.ValueChanged
        DisplayMonth = dtpYearMonth.Value
        DisplaySchedule()
    End Sub

#End Region

#Region "内部共通処理"

    ''' <summary>
    ''' 初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        ' 画面部品初期化
        Initialize()

        ' 時間一覧データ取得
        DisplaySchedule()
    End Sub

    ''' <summary>
    ''' 初期化処理
    ''' </summary>
    Private Sub Initialize()
        ' 年月表示
        dtpYearMonth.Value = DisplayMonth
    End Sub

    ''' <summary>
    ''' 時間割情報取得設定処理
    ''' </summary>
    Private Sub DisplaySchedule()
        Dim result As ResultData = service.LoadTimePatternData(DisplayMonth)
        If result.Success Then
            Dim dtTable As DataTable = result.ResDataTable

            With dgvDataList
                .DataSource = dtTable

                ' 表示幅設定
                .Columns(.Columns("日付").Index).Width = 90
                .Columns(.Columns("曜日").Index).Width = 40
                .Columns(.Columns("曜日区分").Index).Width = 200
                .Columns(.Columns("日付").Index).SortMode = DataGridViewColumnSortMode.NotSortable
                .Columns(.Columns("曜日").Index).SortMode = DataGridViewColumnSortMode.NotSortable
                .Columns(.Columns("曜日区分").Index).SortMode = DataGridViewColumnSortMode.NotSortable

                ' 非表示設定
                .Columns(.Columns("年度").Index).Visible = False

                If .Rows.Count > 0 Then
                    .Rows(0).Selected = True
                End If
            End With
        End If
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub CsvOut_Click(sender As Object, e As EventArgs) Handles CsvOut.Click
        Dim defaultFileName As String = EXPORT_FILE_NAME_PREFIX & "_" & dtpYearMonth.Value.ToString("yyyy年MM月") & ".csv"

        If GridCsvHelper.ExportCsv(defaultFileName, dgvDataList) Then
            MessageBox.Show(Me, EXPORT_FILE_NAME_PREFIX & "データを出力しました")
        End If
    End Sub

#End Region

End Class