﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSystemEnvSettings
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.TxtBBasicUnitPrice = New System.Windows.Forms.TextBox()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.BtnColorDefault = New System.Windows.Forms.Button()
		Me.BtnPreview = New System.Windows.Forms.Button()
		Me.CmbNoStamp = New System.Windows.Forms.ComboBox()
		Me.CmbClockOutEarly = New System.Windows.Forms.ComboBox()
		Me.CmbClockOutLate = New System.Windows.Forms.ComboBox()
		Me.CmbClockInLate = New System.Windows.Forms.ComboBox()
		Me.CmbClockInEarly = New System.Windows.Forms.ComboBox()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.BtnClose = New System.Windows.Forms.Button()
		Me.BtnSave = New System.Windows.Forms.Button()
		Me.GroupBox2 = New System.Windows.Forms.GroupBox()
		Me.BtnSystemDefault = New System.Windows.Forms.Button()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.TxtBTimeSpan = New System.Windows.Forms.TextBox()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.DGVPreview = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
		Me.GroupBox1.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		CType(Me.DGVPreview, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(21, 35)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(79, 15)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "基本報酬単価"
		'
		'TxtBBasicUnitPrice
		'
		Me.TxtBBasicUnitPrice.Location = New System.Drawing.Point(141, 29)
		Me.TxtBBasicUnitPrice.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.TxtBBasicUnitPrice.Name = "TxtBBasicUnitPrice"
		Me.TxtBBasicUnitPrice.Size = New System.Drawing.Size(69, 23)
		Me.TxtBBasicUnitPrice.TabIndex = 1
		Me.TxtBBasicUnitPrice.Text = "0"
		Me.TxtBBasicUnitPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label2.Location = New System.Drawing.Point(27, 40)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(50, 15)
		Me.Label2.TabIndex = 0
		Me.Label2.Text = "打刻なし"
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.Add(Me.BtnColorDefault)
		Me.GroupBox1.Controls.Add(Me.BtnPreview)
		Me.GroupBox1.Controls.Add(Me.CmbNoStamp)
		Me.GroupBox1.Controls.Add(Me.CmbClockOutEarly)
		Me.GroupBox1.Controls.Add(Me.CmbClockOutLate)
		Me.GroupBox1.Controls.Add(Me.CmbClockInLate)
		Me.GroupBox1.Controls.Add(Me.CmbClockInEarly)
		Me.GroupBox1.Controls.Add(Me.Label6)
		Me.GroupBox1.Controls.Add(Me.Label5)
		Me.GroupBox1.Controls.Add(Me.Label4)
		Me.GroupBox1.Controls.Add(Me.Label3)
		Me.GroupBox1.Controls.Add(Me.Label2)
		Me.GroupBox1.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.GroupBox1.Location = New System.Drawing.Point(470, 75)
		Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.GroupBox1.Size = New System.Drawing.Size(420, 299)
		Me.GroupBox1.TabIndex = 1
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "打刻エラー背景色設定"
		'
		'BtnColorDefault
		'
		Me.BtnColorDefault.Location = New System.Drawing.Point(183, 257)
		Me.BtnColorDefault.Name = "BtnColorDefault"
		Me.BtnColorDefault.Size = New System.Drawing.Size(100, 26)
		Me.BtnColorDefault.TabIndex = 11
		Me.BtnColorDefault.Text = "元に戻す"
		Me.BtnColorDefault.UseVisualStyleBackColor = True
		'
		'BtnPreview
		'
		Me.BtnPreview.Location = New System.Drawing.Point(300, 257)
		Me.BtnPreview.Name = "BtnPreview"
		Me.BtnPreview.Size = New System.Drawing.Size(100, 26)
		Me.BtnPreview.TabIndex = 10
		Me.BtnPreview.Text = "プレビュー"
		Me.BtnPreview.UseVisualStyleBackColor = True
		'
		'CmbNoStamp
		'
		Me.CmbNoStamp.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable
		Me.CmbNoStamp.DropDownHeight = 15
		Me.CmbNoStamp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbNoStamp.FormattingEnabled = True
		Me.CmbNoStamp.IntegralHeight = False
		Me.CmbNoStamp.ItemHeight = 20
		Me.CmbNoStamp.Location = New System.Drawing.Point(210, 34)
		Me.CmbNoStamp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.CmbNoStamp.Name = "CmbNoStamp"
		Me.CmbNoStamp.Size = New System.Drawing.Size(190, 26)
		Me.CmbNoStamp.TabIndex = 1
		'
		'CmbClockOutEarly
		'
		Me.CmbClockOutEarly.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable
		Me.CmbClockOutEarly.DropDownHeight = 15
		Me.CmbClockOutEarly.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbClockOutEarly.FormattingEnabled = True
		Me.CmbClockOutEarly.IntegralHeight = False
		Me.CmbClockOutEarly.ItemHeight = 20
		Me.CmbClockOutEarly.Location = New System.Drawing.Point(210, 194)
		Me.CmbClockOutEarly.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.CmbClockOutEarly.Name = "CmbClockOutEarly"
		Me.CmbClockOutEarly.Size = New System.Drawing.Size(190, 26)
		Me.CmbClockOutEarly.TabIndex = 9
		'
		'CmbClockOutLate
		'
		Me.CmbClockOutLate.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable
		Me.CmbClockOutLate.DropDownHeight = 15
		Me.CmbClockOutLate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbClockOutLate.FormattingEnabled = True
		Me.CmbClockOutLate.IntegralHeight = False
		Me.CmbClockOutLate.ItemHeight = 20
		Me.CmbClockOutLate.Location = New System.Drawing.Point(210, 154)
		Me.CmbClockOutLate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.CmbClockOutLate.Name = "CmbClockOutLate"
		Me.CmbClockOutLate.Size = New System.Drawing.Size(190, 26)
		Me.CmbClockOutLate.TabIndex = 7
		'
		'CmbClockInLate
		'
		Me.CmbClockInLate.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable
		Me.CmbClockInLate.DropDownHeight = 15
		Me.CmbClockInLate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbClockInLate.DropDownWidth = 140
		Me.CmbClockInLate.FormattingEnabled = True
		Me.CmbClockInLate.IntegralHeight = False
		Me.CmbClockInLate.ItemHeight = 20
		Me.CmbClockInLate.Location = New System.Drawing.Point(210, 114)
		Me.CmbClockInLate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.CmbClockInLate.Name = "CmbClockInLate"
		Me.CmbClockInLate.Size = New System.Drawing.Size(190, 26)
		Me.CmbClockInLate.TabIndex = 5
		'
		'CmbClockInEarly
		'
		Me.CmbClockInEarly.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable
		Me.CmbClockInEarly.DropDownHeight = 15
		Me.CmbClockInEarly.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.CmbClockInEarly.FormattingEnabled = True
		Me.CmbClockInEarly.IntegralHeight = False
		Me.CmbClockInEarly.ItemHeight = 20
		Me.CmbClockInEarly.Location = New System.Drawing.Point(210, 74)
		Me.CmbClockInEarly.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.CmbClockInEarly.Name = "CmbClockInEarly"
		Me.CmbClockInEarly.Size = New System.Drawing.Size(190, 26)
		Me.CmbClockInEarly.TabIndex = 3
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label6.Location = New System.Drawing.Point(27, 200)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(144, 15)
		Me.Label6.TabIndex = 8
		Me.Label6.Text = "退勤打刻：実績終了より前"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label5.Location = New System.Drawing.Point(27, 160)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(144, 15)
		Me.Label5.TabIndex = 6
		Me.Label5.Text = "退勤打刻：退勤時刻より後"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label4.Location = New System.Drawing.Point(27, 120)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(144, 15)
		Me.Label4.TabIndex = 4
		Me.Label4.Text = "出勤打刻：実績開始より後"
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label3.Location = New System.Drawing.Point(27, 80)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(144, 15)
		Me.Label3.TabIndex = 2
		Me.Label3.Text = "出勤打刻：出勤時刻より前"
		'
		'BtnClose
		'
		Me.BtnClose.Location = New System.Drawing.Point(832, 15)
		Me.BtnClose.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.BtnClose.Name = "BtnClose"
		Me.BtnClose.Size = New System.Drawing.Size(93, 31)
		Me.BtnClose.TabIndex = 3
		Me.BtnClose.Text = "閉じる"
		Me.BtnClose.UseVisualStyleBackColor = True
		'
		'BtnSave
		'
		Me.BtnSave.Location = New System.Drawing.Point(703, 15)
		Me.BtnSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.BtnSave.Name = "BtnSave"
		Me.BtnSave.Size = New System.Drawing.Size(93, 31)
		Me.BtnSave.TabIndex = 2
		Me.BtnSave.Text = "保存"
		Me.BtnSave.UseVisualStyleBackColor = True
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.Add(Me.BtnSystemDefault)
		Me.GroupBox2.Controls.Add(Me.Label10)
		Me.GroupBox2.Controls.Add(Me.Label9)
		Me.GroupBox2.Controls.Add(Me.Label8)
		Me.GroupBox2.Controls.Add(Me.TxtBTimeSpan)
		Me.GroupBox2.Controls.Add(Me.Label7)
		Me.GroupBox2.Controls.Add(Me.TxtBBasicUnitPrice)
		Me.GroupBox2.Controls.Add(Me.Label1)
		Me.GroupBox2.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.GroupBox2.Location = New System.Drawing.Point(24, 75)
		Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.GroupBox2.Size = New System.Drawing.Size(420, 299)
		Me.GroupBox2.TabIndex = 0
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "システム設定"
		'
		'BtnSystemDefault
		'
		Me.BtnSystemDefault.Location = New System.Drawing.Point(300, 257)
		Me.BtnSystemDefault.Name = "BtnSystemDefault"
		Me.BtnSystemDefault.Size = New System.Drawing.Size(100, 26)
		Me.BtnSystemDefault.TabIndex = 12
		Me.BtnSystemDefault.Text = "元に戻す"
		Me.BtnSystemDefault.UseVisualStyleBackColor = True
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Font = New System.Drawing.Font("游ゴシック", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label10.Location = New System.Drawing.Point(26, 99)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(260, 14)
		Me.Label10.TabIndex = 6
		Me.Label10.Text = "※実績開始の前、事績終了の後のみなし考慮時間。"
		'
		'Label9
		'
		Me.Label9.AutoSize = True
		Me.Label9.Location = New System.Drawing.Point(216, 77)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(19, 15)
		Me.Label9.TabIndex = 5
		Me.Label9.Text = "分"
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Location = New System.Drawing.Point(216, 32)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(19, 15)
		Me.Label8.TabIndex = 4
		Me.Label8.Text = "円"
		'
		'TxtBTimeSpan
		'
		Me.TxtBTimeSpan.Location = New System.Drawing.Point(141, 72)
		Me.TxtBTimeSpan.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.TxtBTimeSpan.Name = "TxtBTimeSpan"
		Me.TxtBTimeSpan.Size = New System.Drawing.Size(69, 23)
		Me.TxtBTimeSpan.TabIndex = 3
		Me.TxtBTimeSpan.Text = "0"
		Me.TxtBTimeSpan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Location = New System.Drawing.Point(21, 74)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(61, 15)
		Me.Label7.TabIndex = 2
		Me.Label7.Text = "みなし時間"
		'
		'DGVPreview
		'
		Me.DGVPreview.AllowUserToAddRows = False
		Me.DGVPreview.AllowUserToDeleteRows = False
		Me.DGVPreview.AllowUserToResizeColumns = False
		Me.DGVPreview.AllowUserToResizeRows = False
		Me.DGVPreview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.DGVPreview.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9})
		Me.DGVPreview.Location = New System.Drawing.Point(24, 400)
		Me.DGVPreview.Name = "DGVPreview"
		Me.DGVPreview.RowTemplate.Height = 21
		Me.DGVPreview.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.DGVPreview.Size = New System.Drawing.Size(865, 214)
		Me.DGVPreview.TabIndex = 4
		'
		'Column1
		'
		Me.Column1.HeaderText = "講師ｺｰﾄﾞ"
		Me.Column1.Name = "Column1"
		'
		'Column2
		'
		Me.Column2.HeaderText = "講師名"
		Me.Column2.Name = "Column2"
		'
		'Column3
		'
		Me.Column3.HeaderText = "日付"
		Me.Column3.Name = "Column3"
		'
		'Column4
		'
		Me.Column4.HeaderText = "状態"
		Me.Column4.Name = "Column4"
		'
		'Column5
		'
		Me.Column5.HeaderText = "出勤(打刻)"
		Me.Column5.Name = "Column5"
		'
		'Column6
		'
		Me.Column6.HeaderText = "退勤(打刻)"
		Me.Column6.Name = "Column6"
		'
		'Column7
		'
		Me.Column7.HeaderText = "出勤(みなし)"
		Me.Column7.Name = "Column7"
		'
		'Column8
		'
		Me.Column8.HeaderText = "退勤(みなし)"
		Me.Column8.Name = "Column8"
		'
		'Column9
		'
		Me.Column9.HeaderText = "・・・"
		Me.Column9.Name = "Column9"
		'
		'FrmSystemEnvSettings
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(939, 631)
		Me.Controls.Add(Me.DGVPreview)
		Me.Controls.Add(Me.GroupBox2)
		Me.Controls.Add(Me.BtnSave)
		Me.Controls.Add(Me.BtnClose)
		Me.Controls.Add(Me.GroupBox1)
		Me.Font = New System.Drawing.Font("Meiryo UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.KeyPreview = True
		Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
		Me.Name = "FrmSystemEnvSettings"
		Me.Text = "環境設定"
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox1.PerformLayout()
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox2.PerformLayout()
		CType(Me.DGVPreview, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub

	Friend WithEvents Label1 As Label
    Friend WithEvents TxtBBasicUnitPrice As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CmbClockOutEarly As ComboBox
    Friend WithEvents CmbClockOutLate As ComboBox
    Friend WithEvents CmbClockInLate As ComboBox
    Friend WithEvents CmbClockInEarly As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents CmbNoStamp As ComboBox
    Friend WithEvents BtnClose As Button
    Friend WithEvents BtnSave As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents TxtBTimeSpan As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents BtnPreview As Button
    Friend WithEvents DGVPreview As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents BtnColorDefault As Button
    Friend WithEvents BtnSystemDefault As Button
End Class
