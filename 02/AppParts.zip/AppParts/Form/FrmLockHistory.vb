﻿''' <summary>
''' ロック状況確認画面
''' </summary>
Public Class FrmLockHistory
    Inherits BaseForm

    ''' <summary>
    ''' ログ：機能名
    ''' </summary>
    Private Const LOG_FUNCTUON_NAME As String = "出講料計算:ロック状況確認"

    '''' <summary>
    '''' ロガー
    '''' </summary>
    'Private logger As New Logger

    ''' <summary>
    ''' 対象年月度ロックサービス
    ''' </summary>
    Private lockService As New YearMonthLockService


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("ロック状況確認")
        InitializeComponent()
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub LockHistory_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' 初期表示処理
        InitDisplay()
    End Sub

    ''' <summary>
    ''' 初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        Dim lockHistoryLoader = New LockHistoryService()
        Dim dt As New DataTable()
        lockHistoryLoader.LoadAndBind(dgvLockList, dt)

        'Dim def As New GridLockHistoryStyle()
        'def.Apply(dgvLockList)
        'Dim style As New GridStyleDefinitionDefault()
        'style.Apply(dgvLockList)
    End Sub

    ''' <summary>
    ''' ロック状況一覧ダブルクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub dgvLockList_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvLockList.CellDoubleClick

        ' データセル以外は処理しない
        If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then
            Return
        End If

        ' ロック状態(L:ロック中)以外は、処理しない
        Dim lockState As String = dgvLockList.Rows(e.RowIndex).Cells(1).Value
        If Not "L".Equals(lockState) Then
            'dgvLockList.ClearSelection()
            'dgvLockList.CurrentCell = Nothing
            Return
        End If

        ' 強制ロック解除
        Force_Unlock(sender, e)
    End Sub

    ''' <summary>
    ''' 対象年月のロックを強制解除する
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Force_Unlock(sender As Object, e As DataGridViewCellEventArgs)
        ' 事前に対象年月、、ロックユーザ、ロックPCの情報を取得
        Dim yearMonth As String = dgvLockList.Rows(e.RowIndex).Cells(0).Value
        Dim lockUser As String = dgvLockList.Rows(e.RowIndex).Cells(2).Value
        Dim lockPc As String = dgvLockList.Rows(e.RowIndex).Cells(3).Value

        ' ロック解除対象が自分以外の時は、確認メッセージを表示
        If Not (Environment.UserName.Equals(lockUser) AndAlso Environment.MachineName.Equals(lockPc)) Then
            ' 警告
            If MsgBox(MessageIdConst.MSGID_W1001, MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo, "警告") = MsgBoxResult.No Then
                Exit Sub
            End If

            ' 最終確認
            If MsgBox(MessageIdConst.MSGID_W1002, MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo, "最終確認") = MsgBoxResult.No Then
                Exit Sub
            End If
        End If

        Dim result As New ResultData

        Try
            ' 現在の対象年月度ロック状態取得
            Dim targetYearMonth As Date = DateUtil.NoFormatYearMonthStrToDate(yearMonth)
            result = lockService.UnLockedTargetYearMonth(targetYearMonth)

            If result.Success Then
                'Dim yearMonthKanji As String = makeYearMonthKanji(year, month)
                'Logger.WriteProcessLog(LOG_FUNCTUON_NAME, "【重要】ExamDate=" & targetYearMonth.ToString("yyyy年MM月") & "のロック強制解除が実行されました")
                MsgBox("" & targetYearMonth.ToString("yyyy年MM月") & "の強制解除を実行しました")
                'GlobalValues.LockStatus = False
                'GlobalValues.TargetYearMonth = Nothing
            Else
                MsgBox(MessageIdConst.MSGID_E2010)
            End If

        Catch ex As Exception
            'Logger.WriteErrorLog(LOG_FUNCTUON_NAME, Me.GetType().Name & ":" & System.Reflection.MethodBase.GetCurrentMethod.Name & ":" & result.ErrorNumber & ":" & result.ErrorDescription)
            MsgBox(MessageIdConst.MSGID_E9001)
            result.Success = False

        Finally
            InitDisplay()

        End Try

    End Sub
End Class