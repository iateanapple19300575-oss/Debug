﻿Public Class LockHistoryService
  Inherits DataGriViewLoader

  Protected Overrides ReadOnly Property SqlQuery As String
    Get
      Return GetSqlQuery()
    End Get
  End Property

  Private Function GetSqlQuery() As String
    Dim sqlString As New System.Text.StringBuilder
    sqlString.Length = 0
    sqlString.Append("SELECT").Append(" ")
    sqlString.Append("    " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成日)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成者)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" ")
    sqlString.Append("FROM").Append(" ")
    sqlString.Append("  " & DbMapper.GetTableName(Of T_Year_Month_LockEnum)).Append(" ")
    sqlString.Append("ORDER BY").Append(" ")
    sqlString.Append("  " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" DESC ")
    sqlString.Append(";")

    Return sqlString.ToString()
  End Function


  Protected Overrides Sub BindToGrid(ByRef grid As Windows.Forms.DataGridView, ByRef dtTable As DataTable)
    grid.DataSource = dtTable
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).HeaderText = "日付"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).HeaderText = "状態"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).HeaderText = "ロックユーザ"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).HeaderText = "ロックＰＣ"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).HeaderText = "ロック日時"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).HeaderText = "解除ユーザ"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).HeaderText = "解除ＰＣ"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).HeaderText = "解除時間"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成日)).HeaderText = "作成日時"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成者)).HeaderText = "作成者"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).HeaderText = "更新日時"
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).HeaderText = "更新者"

    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Width = 70
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Width = 60
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Width = 120
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).Width = 100
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).Width = 120
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Width = 120
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Width = 100
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).Width = 120
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成日)).Width = 120
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成者)).Width = 120
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).Width = 120
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Width = 120

    grid.ReadOnly = True
    grid.AllowUserToAddRows = False
    grid.AllowUserToDeleteRows = False
    grid.AllowUserToResizeRows = False
    grid.AllowUserToOrderColumns = False
    grid.AllowUserToResizeColumns = False
    grid.AllowUserToResizeRows = False
    grid.RowHeadersWidth = 20
    For Each column As DataGridViewColumn In grid.Columns
      column.SortMode = DataGridViewColumnSortMode.NotSortable
    Next

    Dim totalWidth As Integer = grid.RowHeadersWidth
    For Each column As DataGridViewColumn In grid.Columns
      totalWidth += column.Width
    Next
    'grid.Width = totalWidth + 2
    grid.BackgroundColor = Color.White
    grid.ScrollBars = ScrollBars.Vertical

    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成日)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成者)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter

    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成日)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成者)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

  End Sub

End Class
