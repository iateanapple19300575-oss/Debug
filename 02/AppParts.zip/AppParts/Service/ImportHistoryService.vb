﻿Public Class ImportHistoryService
  Inherits DataGriViewLoader

  Protected Overrides ReadOnly Property SqlQuery As String
    Get
      Return GetSqlQuery()
    End Get
  End Property

  Private Function GetSqlQuery() As String
    Dim sqlString As New System.Text.StringBuilder
    sqlString.Length = 0
    sqlString.Append("SELECT").Append(" ")
    sqlString.Append("    " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.CSV種別)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ分類)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ名)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.ファイル名)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.対象年月)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ件数)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行PC)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行ユーザ)).Append(" ")
    sqlString.Append("  , " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行日)).Append(" ")
    sqlString.Append("FROM").Append(" ")
    sqlString.Append("  " & DbMapper.GetTableName(Of T_History_ImportEnum)).Append(" ")
    sqlString.Append("ORDER BY").Append(" ")
    sqlString.Append("  " & DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行日)).Append(" ASC ")
    sqlString.Append(";")

    Return sqlString.ToString()
  End Function


  Protected Overrides Sub BindToGrid(ByRef grid As Windows.Forms.DataGridView, ByRef dtTable As DataTable)
    grid.DataSource = dtTable
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.CSV種別)).HeaderText = "タイプ"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ分類)).HeaderText = "カテゴリ"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ名)).HeaderText = "データ名"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.ファイル名)).HeaderText = "ファイル名"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.対象年月)).HeaderText = "対象年度"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ件数)).HeaderText = "データ件数"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行PC)).HeaderText = "実行PC"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行ユーザ)).HeaderText = "実行ユーザー"
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行日)).HeaderText = "実行日"

    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.CSV種別)).Width = 70
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ分類)).Width = 130
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ名)).Width = 200
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.ファイル名)).Width = 300
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.対象年月)).Width = 600
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ件数)).Width = 70
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行PC)).Width = 90
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行ユーザ)).Width = 70
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行日)).Width = 130

    grid.ReadOnly = True
    grid.AllowUserToAddRows = False
    grid.AllowUserToDeleteRows = False
    grid.AllowUserToOrderColumns = False
    grid.AllowUserToResizeColumns = False
    grid.AllowUserToResizeRows = False
    grid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing
    grid.RowHeadersWidth = 20
    For Each column As DataGridViewColumn In grid.Columns
      column.SortMode = DataGridViewColumnSortMode.NotSortable
    Next

    Dim totalWidth As Integer = grid.RowHeadersWidth
    For Each column As DataGridViewColumn In grid.Columns
      totalWidth += column.Width
    Next
    'totalWidth -= 70
    grid.Width = totalWidth
    grid.Width = totalWidth + 2
    grid.BackgroundColor = Color.White
    grid.ScrollBars = ScrollBars.Vertical

    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.CSV種別)).Visible = False

    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.CSV種別)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ分類)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ名)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.ファイル名)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.対象年月)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ件数)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行PC)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行ユーザ)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行日)).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter

    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.CSV種別)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ分類)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ名)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.ファイル名)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.対象年月)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.データ件数)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行PC)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行ユーザ)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
    grid.Columns(DbMapper.GetColumnName(Of T_History_ImportEnum)(T_History_ImportEnum.実行日)).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

  End Sub

End Class
