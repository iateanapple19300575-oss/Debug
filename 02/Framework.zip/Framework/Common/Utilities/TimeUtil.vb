﻿Imports Nts.Freamwork.Common.Utilities

Public Class TimeUtil

  Public Shared Function DiffTimeSpan(ByVal stTime As String, ByVal edTime As String) As Integer
    If StringUtil.IsNullOrWhiteSpace(stTime) OrElse StringUtil.IsNullOrWhiteSpace(stTime) Then
      Return 0
    End If
    Dim ts1 As New TimeSpan(Integer.Parse(stTime.Substring(0, 2)), Integer.Parse(stTime.Substring(3, 2)), 0)
    Dim ts2 As New TimeSpan(Integer.Parse(edTime.Substring(0, 2)), Integer.Parse(edTime.Substring(3, 2)), 0)
    Return (ts2 - ts1).TotalMinutes
  End Function

  Public Shared Function AddTime(ByVal stTime As String, ByVal minutes As Integer) As String
    If StringUtil.IsNullOrEmpty(stTime) Then
      Return stTime
    End If

    Dim hour As String = stTime.Substring(0, 2)
    Dim minute As String = stTime.Substring(3, 2)
    Dim dt1 As DateTime = DateTime.Parse(String.Format("{0}/{1}/{2} {3}:{4}:00", DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, hour, minute))
    Dim addDate As DateTime = dt1.AddMinutes(minutes)
    Return String.Format("{0}:{1}", addDate.Hour.ToString("00"), addDate.Minute.ToString("00"))
  End Function

  Public Shared Function TimeFormat(ByVal value As Date?) As String
    If IsNothing(value) Then
      Return ""
    End If

    Dim timeValue As Date = value

    Return timeValue.ToShortTimeString()
  End Function


    Public Shared Function TimeStringToTimeSpan(ByVal value As String) As TimeSpan?
        If StringUtil.IsNullOrWhiteSpace(value) Then
            Return Nothing
        End If

        Dim wkInt As Integer = CInt(value)
        Dim ts As TimeSpan = TimeSpan.FromMinutes(wkInt)

        Return New TimeSpan(ts.Hours, ts.Minutes, 0)
    End Function


End Class
