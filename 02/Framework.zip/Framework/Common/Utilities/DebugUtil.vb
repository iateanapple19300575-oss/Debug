﻿Imports Nts.Freamwork.Common.Utilities

Public Class DebugUtil

  Private _Stopwatch As New System.Diagnostics.Stopwatch

  <Conditional("DEBUG")>
  Public Sub StopwatchStart(Optional ByVal title As String = "")
    _Stopwatch.Start()
    Dim condition As Boolean = True
    Dim message As String = IIf(StringUtil.IsNullOrWhiteSpace(title), "", title & " ") & "START: " & "{0}" & " "
    DisplayMessage(condition, message)
  End Sub

  <Conditional("DEBUG")>
  Public Sub StopwatchStop(Optional ByVal title As String = "")
    _Stopwatch.Stop()
    Dim condition As Boolean = True
    Dim message As String = IIf(StringUtil.IsNullOrWhiteSpace(title), "", title & " ") & "END: " & "{0}" & " "
    DisplayMessage(condition, message)
  End Sub

  Private Sub DisplayMessage(ByVal condition As Boolean, Optional ByVal message As String = "")
    Debug.WriteLineIf(condition, String.Format(message, _Stopwatch.Elapsed.ToString()))
  End Sub

End Class
