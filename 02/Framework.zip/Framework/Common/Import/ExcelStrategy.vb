﻿Imports System.Runtime.InteropServices
Imports Microsoft.Office.Interop.Excel

''' <summary>
''' EXCELデータ入出力
''' </summary>
Public Class ExcelStrategy
	Implements IDataSourceStrategy

	''' <summary>
	''' データロード(EXCEL版)
	''' </summary>
	''' <param name="sourcePath"></param>
	''' <returns></returns>
	Public Function LoadData(ByVal sourcePath As String) As System.Data.DataTable Implements IDataSourceStrategy.LoadData
		Dim excelApp As Application = Nothing
		Dim workbook As Workbook = Nothing
		Dim worksheet As Worksheet = Nothing
		Dim dt As System.Data.DataTable = New System.Data.DataTable()

		Try
			' EXCELオープン
			excelApp = New Application()
			workbook = excelApp.Workbooks.Open(sourcePath)
			worksheet = CType(workbook.Sheets(1), Worksheet)

			' 取込データ範囲取得
			Dim rowCount = worksheet.UsedRange.Rows.Count
			Dim colCount = worksheet.UsedRange.Columns.Count

			' ヘッダ行データの取得
			For col = 1 To colCount
				dt.Columns.Add(worksheet.Cells(1, col).Text)
			Next
			' データ行データの取得
			For row = 2 To rowCount
				Dim values(colCount - 1) As Object
				For col = 1 To colCount
					values(col - 1) = worksheet.Cells(row, col).Text
				Next
				dt.Rows.Add(values)
			Next

		Catch ex As Exception
			Throw
		Finally
			If worksheet IsNot Nothing Then
				Marshal.ReleaseComObject(worksheet)
			End If
			If workbook IsNot Nothing Then
				Marshal.ReleaseComObject(workbook)
			End If
			If excelApp IsNot Nothing Then
				Marshal.ReleaseComObject(excelApp)
			End If
			GC.Collect()
			GC.WaitForPendingFinalizers()
		End Try

		Return dt
	End Function
End Class
