﻿Imports System.Data.OleDb
Imports System.Windows.Forms

Public Class AccessStrategy
	Implements IDataSourceStrategy

	Public Function LoadData(ByVal sourcePath As String) As System.Data.DataTable Implements IDataSourceStrategy.LoadData
		Dim dt As System.Data.DataTable = New System.Data.DataTable()
		Dim connStr As String = ""
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("SELECT ")
		sqlString.Append("  " & " * ")
		sqlString.Append("FROM ")
		sqlString.Append("WHERE 1=1 ")
		sqlString.Append("  " & " ")

		Try
			Using conn As New OleDbConnection(connStr)
				conn.Open()
				Using cmd As New OleDbCommand(sqlString.ToString(), conn)
					Using adapter As New OleDbDataAdapter(cmd)
						adapter.Fill(dt)
					End Using
				End Using
			End Using

		Catch ex As Exception
			Throw
		Finally
		End Try

		Return dt
	End Function
End Class
