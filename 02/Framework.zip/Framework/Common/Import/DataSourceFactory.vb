﻿Public Class DataSourceFactory

	''' <summary>
	''' データソースの列挙体
	''' </summary>
	Public Enum DataSourceType
		Csv
		SqlServer
		Excel
		Access
	End Enum

	''' <summary>
	''' データソースに応じインスタンスを生成する。
	''' </summary>
	''' <param name="sourceType"></param>
	''' <returns></returns>
	Public Shared Function CreateStrategy(ByVal sourceType As DataSourceType) As IDataSourceStrategy
		Select Case sourceType
			Case DataSourceType.Csv
				Return New CsvStrategy()
			Case DataSourceType.Excel
				Return New ExcelStrategy()
			Case DataSourceType.Access
				Return New AccessStrategy()
			Case DataSourceType.SqlServer
				Return New SqlServerStrategy()
			Case Else
				Throw New NotSupportedException("未対応のデータソース")
		End Select
	End Function
End Class
