﻿Imports System.Drawing
Imports System.Windows.Forms

''' <summary>
''' DataGridView のヘッダを2行表示するためのクラス
''' </summary>
Public Class DataGridViewCustomHeader

	''' <summary>
	''' 単一列結合ヘッダクラス
	''' </summary>
	Private Class SingleHeader
		Public Property StartColumIndex As Integer
		Public Property ColumSpan As Integer
		Public Property StartRowIndex As Integer
		Public Property RowSpan As Integer
		Public Property Title As String
		Public Property TextAlign As Integer
	End Class

	''' <summary>
	''' 複数列結合ヘッダクラス
	''' </summary>
	Private Class HeaderGroup
		Public Property StartColumIndex As Integer
		Public Property ColumSpan As Integer
		Public Property StartRowIndex As Integer
		Public Property RowSpan As Integer
		Public Property Title As String
		Public Property TextAlign As Integer
	End Class

	''' <summary>
	''' 単一結合列ヘッダグループ
	''' </summary>
	Private SingleHeaders As New List(Of SingleHeader)

	''' <summary>
	''' 複数列結合ヘッダグループ
	''' </summary>
	Private HeaderGroups As New List(Of HeaderGroup)

	''' <summary>
	''' DataGridVuew
	''' </summary>
	Public Property DataGridView As DataGridView

	''' <summary>
	''' コンストラクタ
	''' </summary>
	Public Sub New()

	End Sub

	''' <summary>
	''' コンストラクタ
	''' </summary>
	''' <param name="dgv">DataGridViewインスタンス</param>
	Public Sub New(dgv As DataGridView)
		Me.DataGridView = dgv
		InitializeHeader()
	End Sub

	''' <summary>
	''' カスタムヘッダ初期化
	''' </summary>
	Private Sub InitializeHeader()
		DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing
		DataGridView.ColumnHeadersHeight = DataGridView.ColumnHeadersHeight * 2
		DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
	End Sub

	''' <summary>
	''' 単独結合ヘッダ定義追加
	''' </summary>
	''' <param name="startIndex"></param>
	''' <param name="title"></param>
	Public Sub SingleHeaderAdd(ByVal startIndex As Integer, ByVal columnSpan As Integer, ByVal title As String)
		SingleHeaders.Add(New SingleHeader With {.StartColumIndex = startIndex, .ColumSpan = columnSpan, .Title = title})
	End Sub

	''' <summary>
	''' 複数列連結ヘッダ定義追加
	''' </summary>
	''' <param name="startIndex">結合開始カラム番号（0～）</param>
	''' <param name="columnSpan">結合カラム数</param>
	''' <param name="title">表示タイトル</param>
	Public Sub HeaderGroupAdd(ByVal startIndex As Integer, ByVal columnSpan As Integer, ByVal title As String)
		HeaderGroups.Add(New HeaderGroup With {.StartColumIndex = startIndex, .ColumSpan = columnSpan, .Title = title})
	End Sub

	''' <summary>
	''' 明細セルタイトル定義
	''' </summary>
	''' <param name="index"></param>
	''' <param name="title"></param>
	Public Sub HeaderColumnAdd(ByVal index As Integer, ByVal title As String)
		DataGridView.Columns(index).HeaderText = title
	End Sub

	''' <summary>
	''' DataGridViewのCellPaintingイベントの処理
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Public Sub CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs)
		Dim g As Graphics = e.Graphics
		Dim sf As New StringFormat With {.Alignment = StringAlignment.Center}
		Dim headerBackColor As Color = Color.LightGray

		' 左上隅セル
		If e.RowIndex = -1 AndAlso e.ColumnIndex = -1 Then
			g.FillRectangle(New SolidBrush(headerBackColor), e.CellBounds)
			DrawThinBorder(g, e.CellBounds)
			Using pen As New Pen(SystemColors.ControlDark)
				g.DrawLine(pen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1)
			End Using
			e.Handled = True
			Return
		End If

		' ヘッダ行
		If e.RowIndex = -1 Then
			' 上段
			Dim r1 As Rectangle = e.CellBounds
			Dim rTop As Rectangle = r1
			rTop.Height = rTop.Height / 2
			' 下段
			Dim rBottom As Rectangle = e.CellBounds
			rBottom.Y += rBottom.Height / 2
			rBottom.Height = rBottom.Height / 2

			Dim head1Rectangle As Rectangle = rTop

			' １列結合セル
			Dim singleCol = SingleHeaders.FirstOrDefault(Function(sh) sh.StartColumIndex = e.ColumnIndex)
			If singleCol IsNot Nothing Then
				g.FillRectangle(New SolidBrush(headerBackColor), r1)
				DrawThinBorder(g, r1)
				head1Rectangle = rTop
				head1Rectangle.Y = (rTop.Height - DataGridView.ColumnHeadersDefaultCellStyle.Font.Size) / 2
				g.DrawString(singleCol.Title, DataGridView.Font, Brushes.Black, head1Rectangle, sf)
				Using pen As New Pen(SystemColors.ControlDark)
					g.DrawLine(pen, r1.Left, r1.Bottom - 1, r1.Right - 1, r1.Bottom - 1)
				End Using
				e.Handled = True
				Return
			End If

			' 複数列結合セル
			Dim head2Rectangle As Rectangle = rBottom
			head2Rectangle.Y = rTop.Height + ((rBottom.Height - DataGridView.ColumnHeadersDefaultCellStyle.Font.Size) / 2)

			Dim group = HeaderGroups.FirstOrDefault(Function(gp) gp.StartColumIndex = e.ColumnIndex)
			If group IsNot Nothing Then
				Dim rSpan As Rectangle = r1
				For i = 1 To group.ColumSpan - 1
					If e.ColumnIndex + 1 < DataGridView.Columns.Count Then
						rSpan.Width += DataGridView.Columns(e.ColumnIndex + i).HeaderCell.Size.Width
					End If
				Next
				rSpan.Height = rSpan.Height / 2

				head1Rectangle = rSpan
				head1Rectangle.Y = (rTop.Height - DataGridView.ColumnHeadersDefaultCellStyle.Font.Size) / 2

				' 先頭列：１行目
				g.FillRectangle(New SolidBrush(headerBackColor), rSpan)
				DrawThinBorder(g, rSpan)
				g.DrawString(group.Title, DataGridView.Font, Brushes.Black, head1Rectangle, sf)

				' 先頭列：２行目
				g.FillRectangle(New SolidBrush(headerBackColor), rBottom)
				DrawThinBorder(g, rBottom)
				g.DrawString(e.Value.ToString(), DataGridView.Font, Brushes.Black, head2Rectangle, sf)
				Using pen As New Pen(SystemColors.ControlDark)
					g.DrawLine(pen, rBottom.Left, rBottom.Bottom - 1, rBottom.Right - 1, rBottom.Bottom - 1)
				End Using
				e.Handled = True
				Return
			End If

			' ２列目以降
			g.FillRectangle(New SolidBrush(headerBackColor), rBottom)
			DrawThinBorder(g, rBottom)
			g.DrawString(e.Value.ToString(), DataGridView.Font, Brushes.Black, head2Rectangle, sf)
			Using pen As New Pen(SystemColors.ControlDark)
				g.DrawLine(pen, rBottom.Left, rBottom.Bottom - 1, rBottom.Right - 1, rBottom.Bottom - 1)
			End Using
			e.Handled = True
		End If
	End Sub

	''' <summary>
	''' 枠線描画処理
	''' </summary>
	''' <param name="g"></param>
	''' <param name="r"></param>
	Private Sub DrawThinBorder(g As Graphics, r As Rectangle)
		Using pen As New Pen(SystemColors.ControlDark)
			g.DrawLine(pen, r.Left, r.Top, r.Right - 1, r.Top)
			g.DrawLine(pen, r.Left, r.Bottom - 1, r.Right - 1, r.Bottom - 1)
			g.DrawLine(pen, r.Left, r.Top, r.Left, r.Bottom - 1)
			g.DrawLine(pen, r.Right - 1, r.Top - 1, r.Right - 1, r.Bottom - 1)
		End Using
	End Sub
End Class