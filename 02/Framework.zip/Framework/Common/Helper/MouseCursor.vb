﻿Imports System.Windows.Forms


Namespace Freamwork.Common.Helper

  ''' <summary>
  ''' カーソルクラス
  ''' </summary>
  Public Class MouseCursor
    ''' <summary>
    ''' 砂時計カーソル表示
    ''' </summary>
    ''' <param name="Frm"></param>
    ''' <returns></returns>
    Public Shared Function WaitCursor(ByVal Frm As Windows.Forms.Form) As Boolean
      If (Not Frm Is Nothing) Then
        Frm.Cursor = Cursors.WaitCursor
      Else
        Cursor.Current = Cursors.WaitCursor
      End If

      Return True
    End Function

    ''' <summary>
    ''' 通常カーソル表示
    ''' </summary>
    ''' <param name="Frm"></param>
    ''' <returns></returns>
    Public Shared Function DefaultCursor(ByVal Frm As Windows.Forms.Form) As Boolean
      Frm.Cursor = Cursors.Default
      Return True
    End Function

  End Class
End Namespace