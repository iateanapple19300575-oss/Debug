﻿Public Class ParameterBuilder

  Private _conditions As New Dictionary(Of String, Object)

  Public Sub Add(ByVal key As String, value As Object)
    _conditions.Add(key, value)
  End Sub

  Public Function Value(ByVal key As String) As Object
    Return _conditions(key)
  End Function

End Class
