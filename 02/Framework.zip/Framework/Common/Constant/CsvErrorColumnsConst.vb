﻿
''' <summary>
''' 打刻データ
''' </summary>
Public Enum CsvErrorColumnStamp
    行番号
    日付
    姓
    名
    姓名
    スタッフコード
    スタッフ種別
    所属グループコード
    所属グループ名
    打刻場所
    出勤時刻
    退勤時刻
    出勤実時刻
    退勤実時刻
    休憩時間
End Enum

''' <summary>
''' 出講予定データ
''' </summary>
Public Enum CsvErrorColumnPlan
    行番号
    日付
    曜日
    コマ
    教室
    クラス
    科目
    担当
    出講名
    テキスト回
End Enum

''' <summary>
''' 出講予定データ
''' </summary>
Public Enum CsvErrorColumnRequest
    行番号
    教室
    科目
    講師名
    日付
    業務名
    開始
    終了
    対象
    内容
    コード
    区分
    実時間
    単価＠
    乗数
    みなし回数
    金額
    担当者
    リーダー
    教務室
End Enum

Public Enum CsvErrorColumnPinchActual
    行番号
    日付
    曜日
    コマ
    教室
    クラス
    講師コード
    出講名
    科目
    テキスト回
    ピンチ区分
    入力日
End Enum


''' <summary>
''' 時間パターンCSV
''' </summary>
Public Enum CsvErrorColumnTimePattern
    行番号
    年度
    年月日
    曜日
    日程パターン
End Enum

''' <summary>
''' 教室時間割CSV
''' </summary>
Public Enum CsvErrorColumnTimeTable
    行番号
    教室
    日程パターン
    コマ
    開始時間
    終了時間
End Enum

''' <summary>
''' コマ単価CSV
''' </summary>
Public Enum TblErrorColumnUnitPrice
    講師コード
    適用年月
    科目
    状態
    ピンチレベル
    教科知識力
    教授能力
    学習観察力
    コマ単価
    クラス手
    当変化理由
    更新日
End Enum
