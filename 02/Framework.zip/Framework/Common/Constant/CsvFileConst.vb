﻿Public Class CsvFileConst
	Class CsvExportFileName
    Public Const EXP_TIME_PATTERN As String = "TimePattern.csv"
    Public Const EXP_TIMETABLE_SITE As String = "TimetableSite.csv"
    Public Const EXP_TIMETABLE_CLASS As String = "TimetableClass.csv"
	End Class


End Class
