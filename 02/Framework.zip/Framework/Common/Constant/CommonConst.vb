﻿Public Class CommonConst
    Class BulkCopyConst
        Public Const BULK_COPY_BATCH_SIZE As Integer = 1000
        Public Const BULK_COPY_TIMEOUT_MINUTE As Integer = 60
    End Class

End Class
