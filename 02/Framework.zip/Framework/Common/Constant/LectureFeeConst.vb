﻿Public Class LectureFeeConst


  ' --- フェーズ ---
  ' 打刻
  Public Const PHASE_PUNCHING As Integer = 0
  ' 予定
  Public Const PHASE_PLAN As Integer = 1
	' 実績
	Public Const PHASE_ACTUAL As Integer = 2

  ' --- データタイプ ---
  ' 打刻
  Public Const DATA_PUNCHING As Integer = 0
  ' 出講データ
  Public Const DATA_CLASSWORK As Integer = 1
	' 業務依頼
	Public Const DATA_REQUEST As Integer = 2


    '' 代行実績
    'Public Const DATA_PINCH As Integer = 2
    '' 出講実績
    'Public Const DATA_ACTUAL As Integer = 4


End Class
