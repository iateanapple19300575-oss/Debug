﻿Public Class MessageIdConst
    ' 情報
    ' 警告
    ' エラー
    ' クリティカル
    ' パラメタエラー
    ' データエラー
    ' 実行環境エラー
    Public Const MSGID_I1001 As String = "{0}取込ファイルを指定してください"
    Public Const MSGID_I1002 As String = "{0}処理が完了しました"
	Public Const MSGID_I1003 As String = "CSVファイルのフォーマットが不正です。指定ファイルが正しいか確認してください"
	Public Const MSGID_I1004 As String = "保存処理に失敗しました。"

    Public Const MSGID_I1005 As String = "マスタデータの取り込みが完了していません。取込後に実行してください"

    Public Const MSGID_I2001 As String = "EXCEL出力が完了しました"
    Public Const MSGID_I2002 As String = "取込が終了しました"
    Public Const MSGID_I2003 As String = "保存しました"
	Public Const MSGID_I2004 As String = "交通費の登録が完了しました"


	Public Const MSGID_W1001 As String = "指定している出講料対象年月の使用フラグを『強制解除』し、未使用状態にします。" & vbCrLf & "この機能を使用する場合は、解除しようとする出講料対象年月を他の人が確実に使用していないことを確認した上でご利用ください。" & vbCrLf & vbCrLf & "続けますか？"
	Public Const MSGID_W1002 As String = "最終確認です。本当によろしいですか？" & vbCrLf & "「はい」を押下後、強制解除を行います。この操作を元に戻すことが出来ません。" & vbCrLf & vbCrLf & "続けますか？"




	Public Const MSGID_E2001 As String = "EXCELのファイル出力に失敗しました"

    Public Const MSGID_I9001 As String = "他ユーザ処理中のため実行できませんでした。時間を置いて再度、実行してください"

    Public Const MSGID_I9002 As String = "内部処理でエラーが発生しました。"









	Public Const MSGID_E2002 As String = "CSVファイルのフォーマットが不正です。指定ファイルが正しいか確認してください"

	' データ取込画面
	Public Const MSGID_E2003 As String = "画面初期表示データの取得に失敗しました"
    Public Const MSGID_E2004 As String = "対象年月度データの取得に失敗しました"



	Public Const MSGID_E2005 As String = "交通費の登録に失敗しました"
	Public Const MSGID_E2006 As String = "交通費が未入力です"
	Public Const MSGID_E2007 As String = "交通費の値が不正です。半角数字で未入力してください"




	Public Const MSGID_E2008 As String = "処理中にエラーが発生しました"


	Public Const MSGID_E2009 As String = "対象年月のロックに失敗しました"
	Public Const MSGID_E2010 As String = "対象年月の強制ロック解除に失敗しました"
	Public Const MSGID_E2011 As String = "対象年月のロック解除に失敗しました"



	Public Const MSGID_E9001 As String = "予期しない例外エラーが発生しました"
	Public Const MSGID_E9002 As String = "多重起動はできません。処理を終了します。"


    Public Const MSGID_E3001 As String = "データがありません。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3002 As String = "フォーマットエラー" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3003 As String = "重複エラー" & vbCrLf & "重複データが存在します。CSVファイルの内容を確認してください"

    ' マスタデータ取込
    Public Const MSGID_E3101 As String = "対象年度以外のデータが含まれています。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3102 As String = "対象年度のデータがありません。" & vbCrLf & "CSVファイルの内容を確認してください"

    ' 勤怠データ取込
    Public Const MSGID_E3201 As String = "対象年月度以外のデータが含まれています。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3202 As String = "対象年月度のデータがありません。" & vbCrLf & "CSVファイルの内容を確認してください"

End Class
