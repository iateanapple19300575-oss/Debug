﻿Imports System.Windows.Forms

Public Class KeyDestinationSelector
    Private m_Observer As New List(Of IObserber)

    Public Sub Add(ByVal observer As IObserber)
        m_Observer.Add(observer)
    End Sub

    Public Sub Remove(ByVal observer As IObserber)
        m_Observer.Add(observer)
    End Sub

    Public Sub Notify(ByVal key As Date)
        For Each observer As IObserber In m_Observer
            If TypeOf observer Is Form AndAlso DirectCast(observer, Form).IsDisposed = False Then
                observer.Notify(key)
            End If
        Next
    End Sub

    Public Sub TeacherSelectNotify(ByVal keyCode As String)
        For Each observer As IObserber In m_Observer
            If TypeOf observer Is Form AndAlso DirectCast(observer, Form).IsDisposed = False Then
                observer.TeacherSelectNotify(keyCode)
            End If
        Next
    End Sub

	Public Sub WindowCloseNotify()
		For Each observer As IObserber In m_Observer
			If TypeOf observer Is Form AndAlso DirectCast(observer, Form).IsDisposed = False Then
				observer.WindowCloseNotify()
			End If
		Next
	End Sub

	Public Function IsWindowsExist(ByVal name As String) As Boolean
		For Each observer As IObserber In m_Observer
			If name.Equals(CType(m_Observer(0), System.Windows.Forms.Control).Name) Then
				Return True
			End If
		Next
		Return False
	End Function

End Class
