﻿Imports AdvanceSoftware.VBReport8

Public MustInherit Class VBReportPage
  Implements IVBReportPage

  ''' <summary>
  ''' ページタイトルセル変数
  ''' </summary>
  ''' <returns></returns>
  Protected MustOverride ReadOnly Property PageTitleCell As String

  ''' <summary>
  ''' ページタイトル
  ''' </summary>
  ''' <returns></returns>
  Protected MustOverride ReadOnly Property PageTitleName As String

  ''' <summary>
  ''' シート名
  ''' </summary>
  ''' <returns></returns>
  Protected MustOverride ReadOnly Property PageSheetName As String

  ''' <summary>
  ''' ページ名
  ''' </summary>
  Protected m_PageName As String = ""

  ''' <summary>
  ''' シート名
  ''' </summary>
  Protected m_SheetName As String = ""

  ''' <summary>
  ''' DataBse接続文字列
  ''' </summary>
  Private m_ConnectString As String = SqlDataBaseUtil.GetConnectionString()

  ''' <summary>
  ''' VB-Reports CellReportオブジェクト
  ''' </summary>
  Protected m_CellReport As CellReport

  ''' <summary>
  ''' 対象年月度
  ''' </summary>
  Protected Property TargetDate As Date

  ''' <summary>
  ''' 出力データ
  ''' </summary>
  Protected Property ReportSourceDataTable As DataTable

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="targetDate"></param>
  Public Sub New(ByVal targetDate As Date)
    Me.TargetDate = targetDate
  End Sub

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="targetDate"></param>
  Public Sub New(ByVal targetDate As Date, ByVal reportDataSource As DataTable)
    Me.TargetDate = targetDate
    Me.ReportSourceDataTable = reportDataSource
  End Sub

  ''' <summary>
  ''' 環境設定
  ''' </summary>
  ''' <param name="report"></param>
  ''' <param name="tagetDate"></param>
  Private Sub VbReportsEnvSetting(ByVal report As CellReport, ByVal tagetDate As Date) Implements IVBReportPage.VbReportsEnvSetting
    m_CellReport = report
    Me.TargetDate = tagetDate
  End Sub

  ''' <summary>
  ''' 初期設定
  ''' </summary>
  Public Overridable Sub InitialSetup() Implements IVBReportPage.InitialSetup
    m_PageName = String.Format(PageTitleName, Year(Me.TargetDate), Month(Me.TargetDate))
    m_SheetName = PageSheetName
  End Sub

  ''' <summary>
  ''' ページ処出力理開始
  ''' </summary>
  Private Sub PageStart() Implements IVBReportPage.PageStart
    Dim outPageCount As String = "1-999999"
    m_CellReport.Page.Start(m_SheetName, outPageCount)
    m_CellReport.Page.Name = m_PageName
  End Sub

  ''' <summary>
  ''' ページ出力処理終了
  ''' </summary>
  Private Sub PageEnd() Implements IVBReportPage.PageEnd
    m_CellReport.Page.End()
  End Sub

  Private Sub PageTitle() Implements IVBReportPage.PageTitle
    m_CellReport.Cell(PageTitleCell, 0, 0).Value = m_PageName
  End Sub

  Private Sub PageTitle(ByVal cell As String) Implements IVBReportPage.PageTitle
    m_CellReport.Cell(cell, 0, 0).Value = m_PageName
  End Sub

  Private Sub PageTitle(ByVal x As Integer, ByVal y As Integer, Optional ByVal offset As Integer = 0) Implements IVBReportPage.PageTitle
    m_CellReport.Cell(x, y, offset).Value = m_PageName
  End Sub

  ''' <summary>
  ''' ページ出力
  ''' </summary>
  Public Overridable Sub PageReport() Implements IVBReportPage.PageReport

    ' 初期設定
    InitialSetup()

    ' ページ出力開始
    PageStart()

    ' ページタイトル出力
    PageTitle()

    ' ページデータ出力
    PageOutput()

    ' ページ出力終了
    PageEnd()

  End Sub

  Protected Shared Function GetValue(ByVal value As Object) As Object
    If Not IsDBNull(value) Then
      Return value
    Else
      Return ""
    End If
  End Function

  ''' <summary>
  ''' 出力データ取得クエリ
  ''' </summary>
  ''' <returns></returns>
  Public MustOverride Function ReportQuery() As String Implements IVBReportPage.ReportQuery

  ''' <summary>
  ''' レポートページデータ出力
  ''' </summary>
  Public MustOverride Sub PageOutput() Implements IVBReportPage.PageOutput

  ''' <summary>
  ''' 明細出力
  ''' </summary>
  ''' <param name="reader"></param>
  Public MustOverride Sub OutputDetail(ByVal reader As DataTable) Implements IVBReportPage.OutputDetail

End Class
