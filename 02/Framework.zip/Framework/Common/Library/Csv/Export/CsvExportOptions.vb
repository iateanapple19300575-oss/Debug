﻿Imports System.Text

''' <summary>
''' CSV出力オプション
''' </summary>
Public Class CsvExportOptions

	''' <summary>
	''' エンコーディング
	''' </summary>
	''' <returns></returns>
	Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

	''' <summary>
	''' BOM有無
	''' </summary>
	''' <returns></returns>
	Property WithBom As Boolean = False

	''' <summary>
	''' ヘッダー行有無
	''' </summary>
	''' <returns></returns>
	Property IncludeHeader As Boolean = True

	''' <summary>
	''' 区切り文字
	''' </summary>
	''' <returns></returns>
	Property Demiliter As String = ","

	''' <summary>
	''' 囲み文字
	''' </summary>
	''' <returns></returns>
	Property QuoteChar As Char = """"

	''' <summary>
	''' 囲み文字有無：値なし
	''' </summary>
	''' <returns></returns>
	Property QuoteEmpty As Boolean = True

	''' <summary>
	''' 囲み文字有無：文字列項目
	''' </summary>
	''' <returns></returns>
	Property QuoteStringOnly As Boolean = True

	''' <summary>
	''' 囲み文字有無：日付、時間項目
	''' </summary>
	''' <returns></returns>
	Property QuoteDateTime As Boolean = True

	''' <summary>
	''' 囲み文字有無：数値項目
	''' </summary>
	''' <returns></returns>
	Property QuoteNumeric As Boolean = False

	''' <summary>
	''' 改行コード
	''' </summary>
	''' <returns></returns>
	Property NewLine As String = vbCrLf

	''' <summary>
	''' 追加書き込みモード
	''' </summary>
	''' <returns></returns>
	Property AppendMode As Boolean = False
End Class
