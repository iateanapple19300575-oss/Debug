﻿Public Class ImportResultInfo

    ''' <summary>
    ''' 処理日
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecutDate As Date = Nothing

    ''' <summary>
    ''' 処理日（文字列）
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecutDateStr As String

    ''' <summary>
    ''' 処理日
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecutCount As Integer = 0

    ''' <summary>
    ''' 実行結果
    ''' </summary>
    Public Property Success As Boolean = True

    ''' <summary>
    ''' 実行結果(メッセージ文言)
    ''' </summary>
    Public Property StatusString As String

    ''' <summary>
    ''' データタイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property DataType As Integer = 0

    ''' <summary>
    ''' エラー件数
    ''' </summary>
    Public Property ErrorCount As Integer = 0

    ''' <summary>
    ''' エラー発生有無（True：発生／False：未発生）
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property HasError As Boolean
        Get
            Return Success = False
        End Get
    End Property

    ''' <summary>
    ''' データフォーマットエラー
    ''' </summary>
    ''' <returns></returns>
    Public Property FormarError As Boolean = False

    ''' <summary>
    ''' データエラータイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorType As Integer = 0

    ''' <summary>
    ''' CSVバリデーションエラー情報
    ''' </summary>
    ''' <returns></returns>
    Public Property ValidationResultList As New Dictionary(Of Integer, List(Of ValidationResult))

End Class
