﻿Imports System.Windows.Forms

''' <summary>
''' DataGridView に対してスタイル（外観設定）を適用するためのインターフェース。
''' 実装クラスごとに異なるテーマやデザインを提供できるようにし、
''' グリッドの見た目に関する責務を明確に分離する。
''' </summary>
Public Interface IGridStyleDefinition

	''' <summary>
	''' 指定された DataGridView にスタイルを適用する。
	''' フォント、色、行高さ、ヘッダ設定などの外観調整を実装側で行う。
	''' </summary>
	''' <param name="grid">スタイルを適用する対象の DataGridView。</param>
	Sub Apply(grid As DataGridView)

    ''' <summary>
    ''' 指定された DataGridView にスタイルを適用する。
    ''' フォント、色、行高さ、ヘッダ設定などの外観調整を実装側で行う。
    ''' </summary>
    ''' <param name="grid">スタイルを適用する対象の DataGridView。</param>
    Sub ApplyCustom(grid As DataGridView)

End Interface