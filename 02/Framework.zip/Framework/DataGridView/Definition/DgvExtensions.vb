﻿Imports System.Reflection
Imports System.Windows.Forms

Module DgvExtensions
	<System.Runtime.CompilerServices.Extension()>
	Public Sub SetDoubleBuffered(dgv As DataGridView)
		Dim dgvType = dgv.GetType()
		Dim prop = dgvType.GetProperty("DoubleBuffered",
			BindingFlags.Instance Or BindingFlags.NonPublic)
		prop.SetValue(dgv, True, Nothing)
	End Sub
End Module