﻿''' <summary>
''' バリデーションインターフェース
''' </summary>
Public Interface IValidation
    Function Validate(ByVal value As String) As ValidationResult
End Interface
