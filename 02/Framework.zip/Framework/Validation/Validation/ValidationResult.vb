﻿Imports System.Drawing

''' <summary>
''' バリデーション結果クラス
''' </summary>
Public Class ValidationResult
    'Inherits ResultInfoData

    '''' <summary>
    '''' 処理結果（True：正常／False：異常）
    '''' </summary>
    '''' <returns></returns>
    'Public Property Success As Boolean = True

    ''' <summary>
    ''' 対象値
    ''' </summary>
    ''' <returns></returns>
    Public Property Value As String = ""

    ''' <summary>
    ''' バリデーション結果（True：正常／False：エラー）
    ''' </summary>
    ''' <returns>バリデーション結果</returns>
    Public Property IsValid As Boolean = True

    ''' <summary>
    ''' データフォーマットエラー
    ''' </summary>
    ''' <returns></returns>
    Public Property FormarError As Boolean = False

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property SummaryMessage As String = String.Empty

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorMessage As String = String.Empty

    ''' <summary>
    ''' エラーカラー
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorColor As Color = Color.White

    '''' <summary>
    '''' エラー件数
    '''' </summary>
    '''' <returns></returns>
    'Public Property ErrorCount As Integer = 0

    '' ヘッダ名リスト
    'Public Property HeaderColumns As New List(Of String)

    '' ヘッダ名リスト
    'Public Property CsvDataValue As String


    '' エラー情報取得
    'Public Property ErrorDataTable As New DataTable


    '' バリデーションエラー情報
    'Public Property ValidationResults As New Dictionary(Of Integer, List(Of ValidationResult))


End Class
