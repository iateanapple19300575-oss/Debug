﻿Public Interface ICsvValidationFactory
	'Function Headers() As List(Of String)
	Function CreateValidator(ByVal columnName As String) As IValidation
End Interface