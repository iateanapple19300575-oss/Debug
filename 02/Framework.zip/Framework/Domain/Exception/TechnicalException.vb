﻿''' <summary>
''' 技術的例外
''' </summary>
Public Class TechnicalException
    Inherits BaseException

    ''' <summary>
    ''' TechnicalException を生成します。
    ''' </summary>
    ''' <param name="message">ユースケースエラーの内容。</param>
    Public Sub New(ByVal message As String)
        MyBase.New(message)
        Me.DeveloperMessage = message
    End Sub

    Public Sub New(ByVal userMessage As String, ByVal innerException As Exception)
        MyBase.New(userMessage, innerException)
        Me.DeveloperMessage = userMessage
    End Sub

    Public Sub New(ByVal userMessage As String, ByVal developerMessage As String, ByVal inner As Exception)
        MyBase.New(userMessage, inner)
        Me.DeveloperMessage = developerMessage
    End Sub

End Class