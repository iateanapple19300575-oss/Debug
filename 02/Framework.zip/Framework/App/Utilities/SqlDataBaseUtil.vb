﻿Public Class SqlDataBaseUtil

    Public Shared Function GetConnectionString() As String

        'Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=GH2000_DEV;Integrated Security=True;"
        Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=LECTPAY;User ID=LECTUSER;Password=ntsLect0302_dev"

        'TODO:要注意ビルド注意
        '#If NTS_DEBUG Then
        '		'Return "Server=NTSSQLDE2.site.int.nichinoken.net;UID=GHMente;PWD=GHMente2008;DATABASE=GH2000_DEV;APP=XXTEST01"
        '		Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=GH2000_DEV;Integrated Security=True;"
        '#Else
        '    Return "Server=NTSSQLDE2.site.int.nichinoken.net;UID=GHMente;PWD=GHMente2008;DATABASE=GH2000;APP=XXTEST01"
        '#End If

    End Function


    Public Shared Function GetViewConnectionString() As String

        Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=LECTPAY;Integrated Security=True;"
        'TODO:要注意ビルド注意
        '#If NTS_DEBUG Then
        '		Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=LECTPAY;Integrated Security=True;"
        '#End If

    End Function

End Class
