﻿Imports System.IO
Imports System.Text
Imports System.Windows.Forms

Public Class GridCsvHelper

  ''' <summary>
  ''' DataGriViewに表示中のデータをCSVファイルに出力する。
  ''' </summary>
  ''' <param name="fileName"></param>
  ''' <param name="dgv"></param>
  ''' <returns></returns>
  Public Shared Function ExportCsv(fileName As String, dgv As DataGridView) As Boolean
    Dim result As Boolean = False

    ' 保存先を選択
    Dim sfd As New SaveFileDialog()
    sfd.Filter = "CSVファイル (*.csv)|*.csv"
    sfd.FileName = fileName

    If sfd.ShowDialog() = DialogResult.OK Then
      result = True
      Try
        Dim enc As Encoding = Encoding.GetEncoding("Shift_JIS")

        ' UTF-8 の場合、以下
        '------------------------------------------------------------------- 
        'Using sw As New StreamWriter(sfd.FileName, False, Encoding.UTF8)
        '------------------------------------------------------------------- 
        Using sw As New StreamWriter(sfd.FileName, False, enc)
          ' --- ヘッダー行 ---
          Dim header As New List(Of String)
          For Each col As DataGridViewColumn In dgv.Columns
            header.Add(EscapeCsv(col.HeaderText))
          Next
          sw.WriteLine(String.Join(",", header.ToArray()))

          ' --- データ行 ---
          For Each row As DataGridViewRow In dgv.Rows
            If Not row.IsNewRow Then ' 新規入力行は除外
              Dim fields As New List(Of String)
              For Each cell As DataGridViewCell In row.Cells
                fields.Add(EscapeCsv(If(cell.Value, "").ToString()))
              Next
              sw.WriteLine(String.Join(",", fields.ToArray()))
            End If
          Next
        End Using
      Catch ex As Exception
        'MessageBox.Show("エクスポート中にエラーが発生しました: " & ex.Message)
      End Try
    End If

    Return result
  End Function

  ' CSV用に値をエスケープ（カンマやダブルクォート対応）
  Private Shared Function EscapeCsv(value As String) As String

    'If value.Contains("""") Then
    '  value = value.Replace("""", """""") ' ダブルクォートを2つに
    'End If
    'If value.Contains(",") OrElse value.Contains("""") OrElse value.Contains(vbCr) OrElse value.Contains(vbLf) Then
    '  value = $"""{value}""" ' ダブルクォートで囲む
    'End If
    Return value
  End Function

End Class
