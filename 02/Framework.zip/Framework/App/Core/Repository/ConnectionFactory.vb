﻿Imports System.Data.SqlClient

Public Class ConnectionFactory
    Public Shared Function Create() As SqlConnection
    Dim cn As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
    cn.Open()
        Return cn
    End Function
End Class