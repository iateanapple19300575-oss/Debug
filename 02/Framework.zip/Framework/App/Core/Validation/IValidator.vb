﻿Public Interface IValidator(Of T)
    'Sub Validate(target As T)
    Function Validate(dto As T) As List(Of String)
End Interface