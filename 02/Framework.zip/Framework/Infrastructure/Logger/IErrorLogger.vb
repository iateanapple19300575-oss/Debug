﻿''' <summary>
''' エラーログ用ロガー。
''' </summary>
Public Interface IErrorLogger
    Inherits ILogger
End Interface
