﻿''' <summary>
''' エラーログ専用ロガー。
''' </summary>
Public Class ErrorLogger
    Implements IErrorLogger

    Private ReadOnly _inner As ILogger

    ''' <summary>
    ''' ErrorLogger を初期化します。
    ''' </summary>
    Public Sub New(inner As ILogger)
        _inner = inner
    End Sub

    Public Sub Debug(message As String) Implements ILogger.Debug
        ' エラーログでは使用しない
    End Sub

    Public Sub Info(message As String) Implements ILogger.Info
        ' 使用しない
    End Sub

    Public Sub Warn(message As String) Implements ILogger.Warn
        _inner.Warn(message)
    End Sub

    Public Sub [Error](message As String, ex As Exception) Implements ILogger.Error
        _inner.Error(message, ex)
    End Sub

End Class