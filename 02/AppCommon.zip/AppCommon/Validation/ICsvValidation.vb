﻿''' <summary>
''' CSVバリデーションインターフェース
''' </summary>
Public Interface ICsvValidation
    Function Validate(ByVal importRows As List(Of Dictionary(Of String, String))) As ImportResultInfo
End Interface
