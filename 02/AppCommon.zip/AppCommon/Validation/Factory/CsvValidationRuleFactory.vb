﻿Public Class CsvValidationRuleFactory

  ''' <summary>
  ''' データタイプ
  ''' </summary>
  ''' <returns></returns>
  Private Property DataType As Integer = 0

  ''' <summary>
  ''' CSVファイル名
  ''' </summary>
  ''' <returns></returns>
  Private Property FileName As String

  ''' <summary>
  ''' 対象年月度
  ''' </summary>
  ''' <returns></returns>
  Private Property YearMonth As Date


  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New(ByVal dataType As Integer, ByVal yearMonth As Date)
    Me.DataType = dataType
    Me.YearMonth = yearMonth
  End Sub

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New(ByVal dataType As Integer, ByVal fileName As String, ByVal yearMonth As Date)
    Me.DataType = dataType
    Me.FileName = fileName
    Me.YearMonth = yearMonth
  End Sub

  ''' <summary>
  ''' バリデーションルールのインスタンス
  ''' </summary>
  ''' <returns></returns>
  Public Function CreateValidationRule() As ICsvValidation
    Select Case DataType
      Case TableImportHistoryConst.TYPE_TIME_PATTERN
        Return New CsvValidationTimePatternRule()
      Case TableImportHistoryConst.TYPE_TIME_TABLE_SITE
        Return New CsvValidationTimeTableSiteRule()
      Case TableImportHistoryConst.TYPE_TIME_TABLE_CLASS
        Return New CsvValidationTimeTableClassRule()
      Case TableImportHistoryConst.TYPE_T_STAMP
        Return New CsvValidationStampRule()
      Case TableImportHistoryConst.TYPE_LECTURE_REGULAR
        Return New CsvValidationPlanRule()
      Case TableImportHistoryConst.TYPE_BUSINESS_PUNCH
        Return New CsvValidationRequestRule()
      Case TableImportHistoryConst.TYPE_T_DELEGATION
        Return New CsvValidationDelegationRule()
      Case Else
        Return Nothing
    End Select
  End Function
End Class
