﻿Public Class CsvValidationTimeTableSiteRule
    Implements ICsvValidationFactory

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
        Select Case columnName
            Case "Year"
                Return New YearValidator(columnName, True)
                'Return Nothing
            Case "Site_Code"
                Return New RoomValidator(columnName, True)
            Case "Schedule_Pattern"
                Return New DayOfWeekPatternValidator(columnName, True)
            Case "Koma_Seq"
                Return New KomaValidator(columnName, True)
            Case "Start_Time"
                Return New ShortTimeValidator(columnName, True)
            Case "End_Time"
                Return New ShortTimeValidator(columnName, True)
            Case Else
                Return Nothing
        End Select
    End Function
End Class
