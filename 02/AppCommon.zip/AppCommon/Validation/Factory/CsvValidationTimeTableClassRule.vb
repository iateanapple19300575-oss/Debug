﻿Public Class CsvValidationTimeTableClassRule
  Implements ICsvValidationFactory

  ''' <summary>
  ''' 項目毎にチェック
  ''' </summary>
  ''' <param name="columnName"></param>
  ''' <returns></returns>
  Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
    Select Case columnName
      Case "Setting_Category"
        'Return New YearValidator(columnName, True)
        Return Nothing
      Case "Site_Code"
        Return New RoomValidator(columnName, True)
      Case "Target_Period"
        'Return New DayOfWeekPatternValidator(columnName, True)
        Return Nothing
      Case "Grade"
        Return New GradeValidator(columnName, True)
      Case "Class_Code"
        Return New ClassValidator(columnName, True)
      Case "Koma_Seq"
        Return New KomaValidator(columnName, True)
      Case "Start_Time"
        Return New ShortTimeValidator(columnName, True)
      Case "End_Time"
        Return New ShortTimeValidator(columnName, True)
      Case Else
        Return Nothing
    End Select
  End Function
End Class
