﻿''' <summary>
''' 教室時間割CSVバリデーションクラス
''' </summary>
Public Class TimeTableSiteCsvValidation
    Inherits CsvValidationAbstract

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationTimeTableSiteRule()
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
        Select Case columnName
            Case "Site_Code"
                Return New RoomValidator(columnName, True)
            Case "Day_Pattern"
                Return New DayOfWeekPatternValidator(columnName, True)
            Case "Koma"
                Return New KomaValidator(columnName, True)
            Case "Start_Time"
                Return New TimeValidator(columnName, True)
            Case "End_Time"
                Return New TimeValidator(columnName, True)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
