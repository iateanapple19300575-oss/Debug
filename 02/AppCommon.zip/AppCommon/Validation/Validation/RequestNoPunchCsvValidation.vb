﻿''' <summary>
''' 打刻外業務依頼CSVバリデーションクラス
''' </summary>
Public Class RequestNoPunchCsvValidation
    Inherits CsvValidationAbstract

    '''' <summary>
    '''' CSV項目名リスト
    '''' </summary>
    'Public Shared ReadOnly csvColumns As New List(Of String) _
    '            ({
    '                "教室", "科目", "講師名", "日付", "業務名", "開始", "終了", "対象", "内容", "コード",
    '                "区分", "実時間", "＠", "乗数", "みなし回数", "金額", "担当者", "リーダー", "教務室"
    '            })

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csv As ICsv)
        MyBase.New(csv)
        ValidatorFactory = New CsvValidationRequestNoPunchRule()
    End Sub

    '''' <summary>
    '''' CSV項目名リスト
    '''' </summary>
    'Public Overrides Function Headers() As List(Of String)
    '    Return New List(Of String) _
    '            ({
    '                "教室", "科目", "講師名", "日付", "業務名", "開始", "終了", "対象", "内容", "コード",
    '                "区分", "実時間", "＠", "乗数", "みなし回数", "金額", "担当者", "リーダー", "教務室"
    '            })
    'End Function

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Overrides Function CreateValidator(ByVal columnName As String) As IValidation
        Select Case columnName
            Case "勤務日"
                Return New DateValidator(columnName, True)
            Case "講師コード"
                Return New TeacherCodeValidator(columnName, True)
            Case "教室コード"
                Return New RoomValidator(columnName, True)
            Case "開始時間"
                Return New TimeValidator(columnName, True)
            Case "終了時間"
                Return New TimeValidator(columnName, True)
            Case "交通費支給対象"
                Return New IntegerValidator(columnName, False)
            Case Else
                Return Nothing
        End Select
    End Function
End Class
