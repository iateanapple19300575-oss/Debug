﻿''' <summary>
''' 年バリデータ
''' </summary>
Public Class YearValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 年データ長
    ''' </summary>
    Private Const YEAR_LENGTH As Integer = 4

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format(" yyyy 形式の半角文字({0}桁)で入力してください", YEAR_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, YEAR_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", YEAR_LENGTH))
        End If

        ' 年(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(0, 4)) Then
            Return NewInvalidResult(value, "年に半角数字以外の値があります")
        End If

        Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
