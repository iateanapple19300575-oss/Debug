﻿Imports System.Drawing

''' <summary>
''' 学年＋クラスコードバリデータ
''' </summary>
Public Class GradeAndClasseValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 学年長
    ''' </summary>
    Private Const GRADE_CODE_LENGTH As Integer = 1

	''' <summary>
	''' クラスコード最小桁数
	''' </summary>
	Private Const CLASS_CODE_MIN_LENGTH As Integer = 1

	''' <summary>
	''' クラスコード最大桁数
	''' </summary>
	Private Const CLASS_CODE_MAX_LENGTH As Integer = 4

	''' <summary>
	''' 学年+クラスコードの最小桁数
	''' </summary>
	Private Const GRADE_CLASS_MIN_LENGTH As Integer = GRADE_CODE_LENGTH + CLASS_CODE_MIN_LENGTH

	''' <summary>
	''' 学年+クラスコードの最大桁数
	''' </summary>
	Private Const GRADE_CLASS_MAX_LENGTH As Integer = GRADE_CODE_LENGTH + CLASS_CODE_MAX_LENGTH

	''' <summary>
	''' 概要メッセージ
	''' </summary>
	''' <returns></returns>
	Protected Overrides Property SummaryMessage As String =
		String.Format("学年(半角数字{0}桁) + クラスコード({0}～{1}文字)で入力してください",
					  GRADE_CODE_LENGTH, CLASS_CODE_MIN_LENGTH, CLASS_CODE_MAX_LENGTH)


	''' <summary>
	''' コンストラクタ
	''' </summary>
	''' <param name="columnName"></param>
	''' <param name="isRequired"></param>
	Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

#If 0 Then

        ' 桁数
        If Not ValidateChecker.IsRangeByteLength(value, GRADE_CLASS_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", GRADE_CLASS_LENGTH))

            Return New ValidationResult With {
                .IsValid = False,
                .SummaryMessage = GetMessage(),
                .ErrorMessage = String.Concat(DETAIL_PREFIX, String.Format("半角{0}桁以外です", GRADE_CLASS_LENGTH), DETAIL_SUFFIX),
                .ErrorColor = Color.Red
            }
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")

        Return New ValidationResult With {
                .IsValid = False,
                .SummaryMessage = GetMessage(),
                .ErrorMessage = String.Concat(DETAIL_PREFIX, "全角文字の値があります", DETAIL_SUFFIX),
                .ErrorColor = Color.Red
            }
        End If

        ' 1桁目(半角数字)
        If Not ValidateChecker.IsHalfWidthNumberOnlySubstring(value, 0, GRADE_CODE_LENGTH) Then
            Return NewInvalidResult(value, "1桁目が半角数字以外です")

        Return New ValidationResult With {
                .IsValid = False,
                .SummaryMessage = GetMessage(),
                .ErrorMessage = String.Concat(DETAIL_PREFIX, String.Format("1桁目が半角数字以外です"), DETAIL_SUFFIX),
                .ErrorColor = Color.Red
            }
        End If

        ' 2桁目(半角英字)
        If Not ValidateChecker.IsHalfWidthAlphabetOnlySubstring(value, 1, 1) Then
            Return NewInvalidResult(value, "2桁目が半角英字以外です")

        Return New ValidationResult With {
                .IsValid = False,
                .SummaryMessage = GetMessage(),
                .ErrorMessage = String.Concat(DETAIL_PREFIX, String.Format("2桁目が半角英字以外です"), DETAIL_SUFFIX),
                .ErrorColor = Color.Red
            }
        End If

        ' 3桁目(半角英数字)
        If Not ValidateChecker.IsHalfWidthAlphabetOrNumberOnlySubstring(value, 2, 1) Then
            Return NewInvalidResult(value, "3桁目が半角英数字以外です")

        Return New ValidationResult With {
                .IsValid = False,
                .SummaryMessage = GetMessage(),
                .ErrorMessage = String.Concat(DETAIL_PREFIX, String.Format("3桁目が半角英数字以外です"), DETAIL_SUFFIX),
                .ErrorColor = Color.Red
            }
        End If

#Else

		' 学年(1桁)+クラス(1桁～4桁)
		If Not ValidateChecker.IsVariableCharacterLengthRange(value, GRADE_CLASS_MIN_LENGTH, GRADE_CLASS_MAX_LENGTH) Then
			Return NewInvalidResult(value, String.Format("最大文字数{0}を超えています", GRADE_CLASS_MAX_LENGTH))
		End If

		' 1桁目(半角数字)
		If Not ValidateChecker.IsHalfWidthNumberOnlySubstring(value, 0, GRADE_CODE_LENGTH) Then
			Return NewInvalidResult(value, String.Format("{0}桁目が半角数字以外です", 0 + GRADE_CODE_LENGTH))
		End If

#End If

		Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
