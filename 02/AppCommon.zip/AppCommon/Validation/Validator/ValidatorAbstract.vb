﻿Imports System.Drawing

''' <summary>
''' バリデータ抽象クラス
''' </summary>
Public MustInherit Class ValidatorAbstract
    Implements IValidation

    ''' <summary>
    ''' 対象CSVカラム名
    ''' </summary>
    ''' <returns></returns>
    Protected Property ColumnName As String = ""

    ''' <summary>
    ''' 必須項目
    ''' </summary>
    ''' <returns></returns>
    Protected Property IsRequired As Boolean = False

    ''' <summary>
    ''' 対象年月度
    ''' Date型の年、月のみ使用する。
    ''' </summary>
    ''' <returns></returns>
    Protected Property TargetMonth As Date

    ''' <summary>
    ''' 概要メッセージ(基礎)
    ''' </summary>
    ''' <returns></returns>
    Protected Overridable Property SummaryMessage As String


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        Me.ColumnName = columnName
        Me.IsRequired = isRequired
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, ByVal targeMonth As Date, Optional ByVal isRequired As Boolean = False)
        Me.ColumnName = columnName
        Me.TargetMonth = targeMonth
        Me.IsRequired = isRequired
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public MustOverride Function Validate(ByVal value As String) As ValidationResult Implements IValidation.Validate

    ''' <summary>
    ''' バリデーション結果作成
    ''' </summary>
    ''' <param name="errorMessage"></param>
    ''' <returns></returns>
    Public Function NewInvalidResult(ByVal value As String, ByVal errorMessage As String) As ValidationResult
        Return New ValidationResult With {
                .Value = value,
                .IsValid = False,
                .SummaryMessage = String.Concat("【", Me.ColumnName, "】", "は、", SummaryMessage, ""),
                .ErrorMessage = String.Concat("　・", errorMessage, ""),
                .ErrorColor = Color.Red
            }
    End Function
End Class
