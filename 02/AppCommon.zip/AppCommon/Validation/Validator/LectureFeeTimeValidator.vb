﻿Imports System.Drawing

Public Class LectureFeeTimeValidator

    Private Shared m_ErrorColor As New List(Of Color)

    Private Shared m_Message As String


	''' <summary>
	''' バリデーション
	''' </summary>
	''' <param name="jobStTime">打刻出勤時間</param>
	''' <param name="jobEdTime">打刻退勤時間</param>
	''' <param name="actStTime">授業開始時間</param>
	''' <param name="actEdTime">授業終了時間</param>
	''' <param name="reqStTime">業務開始時間</param>
	''' <param name="reqEdTime">業務終了時間</param>
	''' <param name="dmdStTime">みなし開始時間</param>
	''' <param name="dmdEdTime">みなし終了時間</param>
	''' <param name="plnStTime">予定開始時間</param>
	''' <returns></returns>
	Public Shared Function Validate(
								ByVal jobStTime As String, ByVal jobEdTime As String,
								ByVal actStTime As String, ByVal actEdTime As String,
								ByVal reqStTime As String, ByVal reqEdTime As String,
								ByVal dmdStTime As String, ByVal dmdEdTime As String,
								ByVal plnStTime As String, ByVal systemEnvData As SystemEnvData
							) As Boolean

		' 戻り値の初期化
		Dim result As Boolean = True
		m_Message = ""
		m_ErrorColor.Clear()
		m_ErrorColor.Add(Color.White)
		m_ErrorColor.Add(Color.White)
		m_ErrorColor.Add(Color.White)
		m_ErrorColor.Add(Color.White)


		' 出勤打刻なし または 退勤打刻なし
		If (String.IsNullOrEmpty(jobStTime) OrElse String.IsNullOrEmpty(jobEdTime)) Then
			If (String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻なし 且つ 退勤打刻なし

				'' 出勤、退勤、実績、業務届なし
				'If String.IsNullOrEmpty(actStTime) AndAlso String.IsNullOrEmpty(reqStTime) Then
				'	result = True
				'	Return True
				'End If

				m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻なし", m_Message)
				'm_ErrorColor(0) = Color.LightPink
				'm_ErrorColor(1) = Color.LightPink
				m_ErrorColor(0) = systemEnvData.PunchingInOutColor()
				m_ErrorColor(1) = systemEnvData.PunchingInOutColor()

				m_ErrorColor(2) = Color.White
				m_ErrorColor(3) = Color.White
				result = False
				Return False

			ElseIf (String.IsNullOrEmpty(jobStTime) AndAlso Not String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻なし　且つ　退勤打刻あり
				m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻忘れ（出勤）", m_Message)
				'm_ErrorColor(0) = Color.LightPink
				m_ErrorColor(0) = systemEnvData.PunchingInOutColor()
				m_ErrorColor(1) = Color.White
				m_ErrorColor(2) = Color.White
				m_ErrorColor(3) = Color.White
				result = False
			ElseIf (Not String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻あり　且つ　退勤打刻なし
				m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻忘れ（退勤）", m_Message)
				m_ErrorColor(0) = Color.White
				'm_ErrorColor(1) = Color.LightPink
				m_ErrorColor(1) = systemEnvData.PunchingInOutColor()
				m_ErrorColor(2) = Color.White
				m_ErrorColor(3) = Color.White
				result = False
				'End If
			End If
		End If


		'' 出勤打刻あり　且つ　みなし出勤あり
		'If (Not String.IsNullOrEmpty(jobStTime) AndAlso Not String.IsNullOrEmpty(dmdStTime)) Then
		'	If (jobStTime < dmdStTime) Then
		'		Dim diffTime As String = TimeUtil.DiffTimeSpan(jobStTime, dmdStTime)
		'		Dim messageStr As String = String.Format("異常：出勤早（みなし出勤の{0}分前）", diffTime)
		'		m_Message = IIf(String.IsNullOrEmpty(m_Message), messageStr, m_Message)
		'		' 出勤早
		'		'm_ErrorColor(0) = Color.LightSkyBlue
		'		m_ErrorColor(0) = systemEnvData.PunchingInEarlyColor()
		'		'm_errorColor(1) = Color.White
		'		'm_errorColor(2) = Color.White
		'		'm_errorColor(3) = Color.White
		'		result = False
		'	End If

		'	If (jobStTime > actStTime) Then
		'		Dim diffTime As String = TimeUtil.DiffTimeSpan(actStTime, jobStTime)
		'		Dim messageStr As String = String.Format("異常：出勤遅（実績の{0}分後）", diffTime)
		'		m_Message = IIf(String.IsNullOrEmpty(m_Message), messageStr, m_Message)
		'		' 出勤遅
		'		'm_ErrorColor(0) = Color.Yellow
		'		m_ErrorColor(0) = systemEnvData.PunchingInLateColor()
		'		'm_errorColor(1) = Color.White
		'		'm_ErrorColor(2) = Color.Yellow
		'		m_ErrorColor(2) = systemEnvData.PunchingInLateColor()
		'		'm_errorColor(3) = Color.White
		'		result = False
		'	End If
		'	'ElseIf (Not String.IsNullOrEmpty(jobStTime) AndAlso Not String.IsNullOrEmpty(actStTime) AndAlso String.IsNullOrEmpty(plnStTime)) Then
		'	'    ' 出勤打刻あり　且つ　実績開始あり　且つ　予定開始なし
		'	'    m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：予定なし", m_Message)
		'	'    m_ErrorColor(0) = Color.White
		'	'    m_ErrorColor(1) = Color.White
		'	'    m_ErrorColor(2) = Color.White
		'	'    m_ErrorColor(3) = Color.White
		'	'    result = False
		'ElseIf (Not String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(actStTime) AndAlso Not String.IsNullOrEmpty(plnStTime)) Then
		'	' 出勤打刻あり　且つ　実績開始なし　且つ　予定開始あり
		'	m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：実績なし", m_Message)
		'	m_ErrorColor(0) = Color.White
		'	m_ErrorColor(1) = Color.White
		'	m_ErrorColor(2) = Color.White
		'	m_ErrorColor(3) = Color.White
		'	result = False
		'ElseIf (Not String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(actStTime) AndAlso String.IsNullOrEmpty(plnStTime)) Then
		'	' 出勤打刻あり　且つ　実績開始なし　且つ　予定開始なし
		'	m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：予定・実績なし", m_Message)
		'	m_ErrorColor(0) = Color.White
		'	m_ErrorColor(1) = Color.White
		'	m_ErrorColor(2) = Color.White
		'	m_ErrorColor(3) = Color.White
		'	result = False
		'End If

		'If (Not String.IsNullOrEmpty(jobEdTime) AndAlso Not String.IsNullOrEmpty(dmdEdTime)) Then
		'	' 退勤打刻あり　且つ　みなし退勤あり
		'	If (jobEdTime > dmdEdTime) Then
		'		' 退勤打刻　＞　みなし退勤
		'		Dim diffTime As String = TimeUtil.DiffTimeSpan(dmdEdTime, jobEdTime)
		'		Dim messageStr As String = String.Format("異常：退勤遅（みなしの{0}分後）", diffTime)
		'		m_Message = IIf(String.IsNullOrEmpty(m_Message), messageStr, m_Message)
		'		' 退勤遅
		'		'm_errorColor(0) = Color.White
		'		'm_ErrorColor(1) = Color.LightSkyBlue
		'		m_ErrorColor(1) = systemEnvData.PunchingOutLateColor()
		'		'm_errorColor(2) = Color.White
		'		'm_errorColor(3) = Color.White
		'		' 出勤早 & 退勤遅
		'		'm_errorColor(0) = Color.LightSkyBlue
		'		'm_errorColor(1) = Color.LightSkyBlue
		'		'm_errorColor(2) = Color.White
		'		'm_errorColor(3) = Color.White
		'		result = False
		'	End If

		'	If (jobEdTime < actEdTime) Then
		'		' 退勤打刻　＜　実績終了
		'		Dim diffTime As String = TimeUtil.DiffTimeSpan(jobEdTime, actEdTime)
		'		Dim messageStr As String = String.Format("異常：退勤早（実績の{0}分前）", diffTime)
		'		m_Message = IIf(String.IsNullOrEmpty(m_Message), messageStr, m_Message)
		'		' 退勤早
		'		'm_errorColor(0) = Color.White
		'		'm_ErrorColor(1) = Color.Yellow
		'		m_ErrorColor(1) = systemEnvData.PunchingOutEarlyColor()
		'		'm_errorColor(2) = Color.White
		'		'm_ErrorColor(3) = Color.Yellow
		'		m_ErrorColor(3) = systemEnvData.PunchingOutEarlyColor()
		'		' 出勤遅 & 退勤早
		'		'm_errorColor(0) = Color.Yellow
		'		'm_errorColor(1) = Color.Yellow
		'		'm_errorColor(2) = Color.Yellow
		'		'm_errorColor(3) = Color.Yellow
		'		result = False
		'	End If
		'End If

		'' 正常
		'If result Then
		'	m_Message = IIf(String.IsNullOrEmpty(m_Message), "正常", m_Message)
		'	' ここまで正常判断で、打刻なしなら未出勤なのでステータスは未設定("")
		'	If (String.IsNullOrEmpty(jobStTime) OrElse String.IsNullOrEmpty(jobEdTime)) Then
		'		m_Message = ""
		'	End If
		'End If

		Return result
	End Function


#If 0 Then

	''' <summary>
	''' 日時打刻バリデーション
	''' </summary>
	''' <param name="jobStTime">打刻出勤時間</param>
	''' <param name="jobEdTime">打刻退勤時間</param>
	''' <param name="actStTime">授業開始時間</param>
	''' <param name="actEdTime">授業終了時間</param>
	''' <param name="reqStTime">業務開始時間</param>
	''' <param name="reqEdTime">業務終了時間</param>
	''' <returns></returns>
	Public Shared Function Validate(
								ByVal jobStTime As String, ByVal jobEdTime As String,
								ByVal actStTime As String, ByVal actEdTime As String,
								ByVal reqStTime As String, ByVal reqEdTime As String,
								ByVal systemEnvData As SystemEnvData
							) As Boolean

		' 戻り値の初期化
		Dim result As Boolean = True
		m_Message = ""
		m_ErrorColor.Clear()
		m_ErrorColor.Add(Color.White)
		m_ErrorColor.Add(Color.White)
		m_ErrorColor.Add(Color.White)
		m_ErrorColor.Add(Color.White)


		' 授業開始あり 又は、業務開始あり
		If Not String.IsNullOrEmpty(actStTime) OrElse Not String.IsNullOrEmpty(reqStTime) Then
			' --- 稼働実績ありの勤怠打刻チェック ---
			If (String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻なし 且つ 退勤打刻なし
				m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻なし", m_Message)
				m_ErrorColor(0) = systemEnvData.PunchingInOutColor()
				m_ErrorColor(1) = systemEnvData.PunchingInOutColor()
				Return False
			ElseIf (String.IsNullOrEmpty(jobStTime) AndAlso Not String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻なし　且つ　退勤打刻あり
				m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻忘れ（出勤）", m_Message)
				m_ErrorColor(0) = systemEnvData.PunchingInOutColor()
				m_ErrorColor(1) = Color.White
				Return False
			ElseIf (Not String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻あり　且つ　退勤打刻なし
				m_Message = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻忘れ（退勤）", m_Message)
				m_ErrorColor(0) = Color.White
				m_ErrorColor(1) = systemEnvData.PunchingInOutColor()
				Return False
			End If
		End If

		'' 正常
		'If result Then
		'	m_Message = IIf(String.IsNullOrEmpty(m_Message), "正常", m_Message)
		'	' ここまで正常判断で、打刻なしなら未出勤なのでステータスは未設定("")
		'	If (String.IsNullOrEmpty(jobStTime) OrElse String.IsNullOrEmpty(jobEdTime)) Then
		'		m_Message = ""
		'	End If
		'End If

		Return result
	End Function

	''' <summary>
	''' 打刻チェック
	''' </summary>
	''' <param name="jobStTime">打刻出勤時間</param>
	''' <param name="jobEdTime">打刻退勤時間</param>
	''' <param name="actStTime">授業開始時間</param>
	''' <param name="actEdTime">授業終了時間</param>
	''' <param name="reqStTime">業務開始時間</param>
	''' <param name="reqEdTime">業務終了時間</param>
	''' <returns></returns>
	Public Shared Function Validate(
								ByVal jobStTime As String, ByVal jobEdTime As String,
								ByVal actStTime As String, ByVal actEdTime As String,
								ByVal reqStTime As String, ByVal reqEdTime As String
							) As String
		Dim status As String = ""

		' 勤怠打刻のチェック
		If (String.IsNullOrEmpty(jobStTime) OrElse String.IsNullOrEmpty(jobEdTime)) Then
			If (String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻なし 且つ 退勤打刻なし
				status = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻なし", m_Message)
			ElseIf (String.IsNullOrEmpty(jobStTime) AndAlso Not String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻なし　且つ　退勤打刻あり
				status = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻忘れ（出勤）", m_Message)
			ElseIf (Not String.IsNullOrEmpty(jobStTime) AndAlso String.IsNullOrEmpty(jobEdTime)) Then
				' 出勤打刻あり　且つ　退勤打刻なし
				status = IIf(String.IsNullOrEmpty(m_Message), "異常：打刻忘れ（退勤）", m_Message)
			End If
		End If

		Return status
	End Function

#End If
















	''' <summary>
	''' エラーカラー取得
	''' </summary>
	''' <returns></returns>
	Public Shared Function GetErrorColor() As List(Of Color)
        Return m_ErrorColor
    End Function

    ''' <summary>
    ''' エラーメッセージ取得
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetErrorMessage() As String
        Return m_Message
    End Function

End Class
