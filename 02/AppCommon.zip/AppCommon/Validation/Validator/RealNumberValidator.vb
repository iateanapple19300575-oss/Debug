﻿Imports System.Drawing

''' <summary>
''' 数字(実数)バリデータ
''' </summary>
Public Class RealNumberValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = "半角数字で入力してください"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>

    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 半角数字、ドット(.)
        If Not ValidateChecker.IsHalfWidthNumberOrDotOnly(value) Then
            Return NewInvalidResult(value, "半角数字および、"".""以外の値があります")
        End If

        Dim realValue() As String = value.Split(".")

        ' 整数部なし、小数部なし(".")
        If (realValue.Length = 2 AndAlso realValue(0).Length = 0 AndAlso realValue(1).Length = 0) Then
            Return NewInvalidResult(value, "整数部と小数部の値がありません")
        End If

        ' 整数部なし(".0")
        If (realValue.Length = 2 AndAlso realValue(0).Length = 0) Then
            Return NewInvalidResult(value, "整数部の値がありません")
        End If

        ' 小数部なし("1.")
        If (realValue.Length = 2 AndAlso realValue(1).Length = 0) Then
            Return NewInvalidResult(value, "小数部の値がありません")
        End If

        ' その他フォーマットエラー
        If (realValue.Length < 1 OrElse realValue.Length > 2) Then
            Return NewInvalidResult(value, "フォーマットに誤りがあります")
        End If

        ' TODO:要検討(ざっくり数値チェック)
        ' 小数点値
        'If Not ValidateChecker.IsRealNumber(value) Then
        '    Return NewInvalidResult(value, "小数値以外の値があります")
        '    Return New ValidationResult With {
        '        .IsValid = False,
        '        .SummaryMessage = GetMessage(),
        '        .ErrorMessage = String.Concat(DETAIL_PREFIX, "小数値以外の値があります", DETAIL_SUFFIX),
        '        .ErrorColor = Color.Red
        '    }
        'End If

        Return New ValidationResult With {.IsValid = True, .Value = value}
    End Function

End Class
