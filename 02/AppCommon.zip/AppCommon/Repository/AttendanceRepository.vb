﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto

''' <summary>
''' 勤怠情報リポジトリクラス
''' </summary>
Public Class AttendanceRepository
    Private _uow As DbTransactionScope

    Public Sub New()

    End Sub

    Public Sub New(ByVal uow As DbTransactionScope)
        _uow = uow
    End Sub


    ''' <summary>
    ''' 月間（範囲期間）の勤怠情報取得
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoadByMonthly(ByVal param As RepositoryFindParameterDto) As DataTable
        Dim firstDay As String = DateUtil.FirstDayOfMonth(param.TargetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(param.TargetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT *").Append(" ")
        sqlString.Append("  , '' As 日付").Append(" ")
        sqlString.Append("  , '' As 日付KEY").Append(" ")
        sqlString.Append("  , '' As 日付色").Append(" ")
        sqlString.Append("FROM VL_Lecture_Details LD").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1")
        sqlString.Append("  AND LD.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND LD.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("ORDER BY ")
        sqlString.Append("   LD.Lecture_Date ")
        sqlString.Append("   , LD.Teacher_Code ")

        Return SqlCommandExecutor.ExecuteDataTable(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
          )
    End Function

    ''' <summary>
    ''' １日の勤怠情報取得
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoadByDays(ByVal param As RepositoryFindParameterDto) As DataTable
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT *").Append(" ")
        sqlString.Append("  , '' As 日付").Append(" ")
        sqlString.Append("  , '' As 日付KEY").Append(" ")
        sqlString.Append("  , '' As 日付色").Append(" ")
        sqlString.Append("FROM VL_Lecture_Details LD").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1")
        sqlString.Append("  AND LD.Lecture_Date = @対象日").Append(" ")
        sqlString.Append("  AND LD.Teacher_Code = @講師").Append(" ")

        Return SqlCommandExecutor.ExecuteDataTable(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@対象日", .Value = param.TargetDate},
            New SqlParameter() With {.ParameterName = "@講師", .Value = param.TeacherCode}
          )
    End Function

    ''' <summary>
    ''' １日の勤怠詳細情報取得
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoadByDayDetails(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  LBA.Lecture_Date").Append(" ")
        sqlString.Append("  , LBA.Teacher_Code").Append(" ")
        sqlString.Append("  , LBA.Data_Type").Append(" ")
        sqlString.Append("  , LBA.Site_Code").Append(" ")
        sqlString.Append("  , LBA.Grade").Append(" ")
        sqlString.Append("  , LBA.Class_Code").Append(" ")
        sqlString.Append("  , LBA.Koma_Seq").Append(" ")
        sqlString.Append("  , LBA.Business_Name").Append(" ")
        sqlString.Append("  , LBA.Contents").Append(" ")
        sqlString.Append("  , LBA.Start_Time").Append(" ")
        sqlString.Append("  , LBA.End_Time").Append(" ")
        sqlString.Append("  , VS.Site_Name").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  ( ").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      Lecture_Date").Append(" ")
        sqlString.Append("      , Teacher_Code").Append(" ")
        sqlString.Append("      , 1 As Data_Type").Append(" ")
        sqlString.Append("      , Site_Code").Append(" ")
        sqlString.Append("      , Grade").Append(" ")
        sqlString.Append("      , Class_Code").Append(" ")
        sqlString.Append("      , Koma_Seq").Append(" ")
        sqlString.Append("      , '' AS Business_Name").Append(" ")
        sqlString.Append("      , '' AS Contents").Append(" ")
        sqlString.Append("      , Start_Time").Append(" ")
        sqlString.Append("      , End_Time ").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      W_Lecture_Actual ").Append(" ")
        sqlString.Append("    UNION ").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      Lecture_Date").Append(" ")
        sqlString.Append("      , Teacher_Code").Append(" ")
        sqlString.Append("      , 2 as Data_Type").Append(" ")
        sqlString.Append("      , Site_Code").Append(" ")
        sqlString.Append("      , '' As Grade").Append(" ")
        sqlString.Append("      , '' As Class_Code").Append(" ")
        sqlString.Append("      , '' As Koma_Seq").Append(" ")
        sqlString.Append("      , Business_Name").Append(" ")
        sqlString.Append("      , Contents").Append(" ")
        sqlString.Append("      , Start_Time").Append(" ")
        sqlString.Append("      , End_Time ").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      W_Business_Actual").Append(" ")
        sqlString.Append("  ) As LBA").Append(" ")
        sqlString.Append("  LEFT JOIN VM_Site VS").Append(" ")
        sqlString.Append("    ON VS. Site_Code = LBA.Site_Code").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1 ").Append(" ")
        sqlString.Append("  AND Lecture_Date = @対象日").Append(" ")
        sqlString.Append("  AND Teacher_Code = @講師").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Lecture_Date").Append(" ")
        sqlString.Append("  , Teacher_Code").Append(" ")
        sqlString.Append("  , Start_Time").Append(" ")
        sqlString.Append(";").Append(" ")

        Return SqlCommandExecutor.ExecuteDataTable(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@対象日", .Value = param.LectureDate},
            New SqlParameter() With {.ParameterName = "@講師", .Value = param.TeacherCode}
          )
    End Function


    Public Function LoadDataExecute(ByVal uow As DbTransactionScope, ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As List(Of LectureDetailsDto)
        Dim dataList As New List(Of LectureDetailsDto)

        Try
            Using cmd As New SqlCommand(sql, uow.Connection)
                cmd.Transaction = uow.Transaction
                cmd.Parameters.AddRange(parameters)
                Dim reader As SqlDataReader = cmd.ExecuteReader()
                While reader.Read()
                    Dim item As New LectureDetailsDto
                    item.LectureDate = GetDateSafe(reader, "Lecture_Date")
                    item.TeacherCode = GetStringSafe(reader, "Teacher_Code")
                    item.TeacherName = GetStringSafe(reader, "Teacher_Name")
                    item.PunchStartTime = GetTimeSpanSafe(reader, "Punch_Start_Time")
                    item.PunchEndTime = GetTimeSpanSafe(reader, "Punch_End_Time")
                    item.LectureStartTimeMin = GetTimeSpanSafe(reader, "Lecture_Start_Time_Min")
                    item.LectureEndTimeMax = GetTimeSpanSafe(reader, "Lecture_End_Time_Max")
                    item.TaskStartTimeMin = GetTimeSpanSafe(reader, "Task_Start_Time_Min")
                    item.TaskEndTimeMax = GetTimeSpanSafe(reader, "Task_End_Time_Max")
                    item.OthersStartTimeMin = GetTimeSpanSafe(reader, "Others_Start_Time_Min")
                    item.OthersEndTimeMax = GetTimeSpanSafe(reader, "Others_End_Time_Max")
                    item.WorkStartTimeMin = GetTimeSpanSafe(reader, "Work_Start_Time_Min")
                    item.WorkEndTimeMax = GetTimeSpanSafe(reader, "Work_End_Time_Max")
                    item.DeemedStartTime = GetTimeSpanSafe(reader, "Deemed_Start_Time")
                    item.DeemedEndTime = GetTimeSpanSafe(reader, "Deemed_End_Time")
                    item.DeemedTimeBefore = GetTimeSpanSafe(reader, "Deemed_Time_Before")
                    item.DeemedTimeAfter = GetTimeSpanSafe(reader, "Deemed_Time_After")
                    item.TaskBaseUnitPrice = GetIntSafe(reader, "Task_Base_Unit_Price")
                    item.TaskUnitPrice = GetIntSafe(reader, "Task_Unit_Price")
                    item.LectureUnitPrice = GetIntSafe(reader, "Lecture_Unit_Price")
                    item.NumberOfPunched = GetByteSafe(reader, "Punch_Count")

                    item.LectureWorkItems = New List(Of LectureWorkItem)
                    For i As Integer = 1 To 6
                        Dim lwItem As New LectureWorkItem
                        lwItem.SiteCode = GetStringSafe(reader, "Site_Code" & i.ToString())
                        lwItem.Grade = GetStringSafe(reader, "Grade" & i.ToString())
                        lwItem.ClassCode = GetStringSafe(reader, "Class_Code" & i.ToString())
                        Dim koma As String = ""
                        If Not GetByteSafe(reader, "Koma_Seq" & i.ToString()) Is Nothing Then
                            koma = GetByteSafe(reader, "Koma_Seq" & i.ToString()).ToString()
                        End If
                        lwItem.KomaSeq = koma
                        lwItem.PinchType = GetStringSafe(reader, "Pinch_Type" & i.ToString())
                        lwItem.StartTime = GetTimeSpanSafe(reader, "Start_Time" & i.ToString())
                        lwItem.EndTime = GetTimeSpanSafe(reader, "End_Time" & i.ToString())
                        lwItem.LectureCoefficient = GetDecimalSafe(reader, "Lecture_Coefficient" & i.ToString())
                        lwItem.Amount = GetDecimalSafe(reader, "Amount" & i.ToString())
                        item.LectureWorkItems.Add(lwItem)
                    Next

                    item.TaskWorkItems = New List(Of TaskWorkItem)
                    For i As Integer = 1 To 6
                        Dim twItem As New TaskWorkItem
                        twItem.SiteCode = GetStringSafe(reader, "Task_Site_Code" & i.ToString())
                        twItem.StartTime = GetTimeSpanSafe(reader, "Task_Start_Time" & i.ToString())
                        twItem.EndTime = GetTimeSpanSafe(reader, "Task_End_Time" & i.ToString())
                        item.TaskWorkItems.Add(twItem)
                    Next

                    item.OthersWorkItems = New List(Of OthersWorkItem)
                    For i As Integer = 1 To 6
                        Dim owItem As New OthersWorkItem
                        owItem.SiteCode = GetStringSafe(reader, "Others_Site_Code" & i.ToString())
                        owItem.StartTime = GetTimeSpanSafe(reader, "Others_Start_Time" & i.ToString())
                        owItem.EndTime = GetTimeSpanSafe(reader, "Others_End_Time" & i.ToString())
                        'owItem.Amount = GetDecimalSafe(reader, "Others_Amount" & i.ToString())
                        item.OthersWorkItems.Add(owItem)
                    Next
                    dataList.Add(item)
                End While
            End Using

        Catch ex As Exception
            Throw
        Finally

        End Try

        Return dataList
    End Function

End Class
