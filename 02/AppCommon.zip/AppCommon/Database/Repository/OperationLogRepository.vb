﻿Imports System.Data.SqlClient

Public Class OperationLogRepository

	''' <summary>
	''' ログ保存
	''' </summary>
	''' <param name="winName">画面名</param>
	''' <param name="content">操作内容</param>
	''' <param name="detail">詳細内容</param>
	Protected Shared Sub LogEvent(ByVal winName As String, ByVal content As String, Optional detail As String = "")

		' ログ登録用SQL文
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("INSERT INTO ")
		sqlString.Append("  " & T_Operation_LogEnum.イベントID.Table).Append(" ")
		sqlString.Append("  (")
		sqlString.Append("      " & T_Operation_LogEnum.イベント発生日時.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.画面名.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.操作内容.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.操作詳細情報.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.対象年月度.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.実行ファイル名.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.実行ユーザー.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.実行PC.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.実行日.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.作成日.Column).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.作成者.Column).Append(" ")
		sqlString.Append("  ) VALUES ( ")
		sqlString.Append("      " & T_Operation_LogEnum.イベント発生日時.Param).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.画面名.Param).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.操作内容.Param).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.操作詳細情報.Param).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.対象年月度.Param).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.実行ファイル名.Param).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.実行ユーザー.Param).Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.実行PC.Param).Append(" ")
		sqlString.Append("    , GETDATE()").Append(" ")
		sqlString.Append("    , GETDATE()").Append(" ")
		sqlString.Append("    , " & T_Operation_LogEnum.作成者.Param).Append(" ")
		sqlString.Append("  )")
		sqlString.Append(";")


		' ログ出力項目の整理
		Dim assemblyName As String = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name
		Dim exeName As String = System.IO.Path.GetFileName(System.Windows.Forms.Application.ExecutablePath)
		Dim targetDateW As Object = DBNull.Value
		If Not DateUtil.IsNullOrEmpty(AppState.TargetYearMonth) Then
			targetDateW = String.Format("{0}/{1}",
								AppState.TargetYearMonth.Year.ToString("0000;[0000]"),
								AppState.TargetYearMonth.Month.ToString("00;[00]"))
		End If

        Try
            Dim exec As New SqlExecutor()
            exec.ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.イベント発生日時.Param, .Value = DateTime.Now},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.画面名.Param, .Value = LogScreenName(winName)},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.操作内容.Param, .Value = content},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.操作詳細情報.Param, .Value = detail},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.対象年月度.Param, .Value = targetDateW},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行ファイル名.Param, .Value = exeName},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行ユーザー.Param, .Value = AppState.CurrentUserName},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行PC.Param, .Value = AppState.CurrentPcName},
                New SqlParameter() With {.ParameterName = T_Operation_LogEnum.作成者.Param, .Value = AppState.CurrentUserName}
            )

        Catch ex As Exception

        End Try

	End Sub

	''' <summary>
	''' ログ出力用画面名取得
	''' </summary>
	''' <param name="name"></param>
	''' <returns></returns>
	Private Shared Function LogScreenName(ByVal name As String) As String
		Return name & "画面"
	End Function

End Class
