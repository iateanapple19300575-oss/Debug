﻿Public Class BusinessActualDef
  Public ReadOnly TableName As String = "W_Business_Actual"

  Public ReadOnly Lecture_Date As String = "Lecture_Date"
  Public ReadOnly Site_Code As String = "Site_Code"
  Public ReadOnly Teacher_Code As String = "Teacher_Code"
  Public ReadOnly Subject As String = "Subject"
  Public ReadOnly Business_Name As String = "Business_Name"
  Public ReadOnly Target As String = "Target"
  Public ReadOnly Contents As String = "Contents"
  Public ReadOnly Start_Time As String = "Start_Time"
  Public ReadOnly End_Time As String = "End_Time"
  Public ReadOnly Category As String = "Category"
  Public ReadOnly Working_Time As String = "Working_Time"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
