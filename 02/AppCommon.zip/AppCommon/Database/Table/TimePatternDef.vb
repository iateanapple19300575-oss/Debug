﻿Public Class TimePatternDef
  Public ReadOnly TableName As String = "M_Time_Pattern"

  Public ReadOnly Fiscal_Year As String = "Fiscal_Year"
  Public ReadOnly Lecture_Date As String = "Lecture_Date"
  Public ReadOnly Youbi As String = "Youbi"
  Public ReadOnly Schedule_Pattern As String = "Schedule_Pattern"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
