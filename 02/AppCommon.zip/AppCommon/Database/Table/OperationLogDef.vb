﻿Public Class OperationLogDef
  Public ReadOnly TableName As String = "T_Operation_Log"

  Public ReadOnly Id As String = "Id"
  Public ReadOnly Event_Date_Time As String = "Event_Date_Time"
  Public ReadOnly Window_Name As String = "Window_Name"
  Public ReadOnly Event_Content As String = "Event_Content"
  Public ReadOnly Event_Details As String = "Event_Details"
  Public ReadOnly Target_Date As String = "Target_Date"
  Public ReadOnly Exe_Name As String = "Exe_Name"
  Public ReadOnly User_Id As String = "User_Id"
  Public ReadOnly Pc_Id As String = "Pc_Id"
  Public ReadOnly Execution_Date As String = "Execution_Date"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
