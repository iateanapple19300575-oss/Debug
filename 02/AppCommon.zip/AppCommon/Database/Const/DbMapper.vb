﻿Imports System.Runtime.CompilerServices

Public Enum SiteGroupListEnum
	ID
	地区名
End Enum

Public Enum SiteEnum
	教室コード
	教室名
	教室区分
	本校教室コード
End Enum

Public Enum TeacherRegistryEnum
	姓
	名
	性別
	カナ姓
	カナ名
	姓ふりがな
	講師コード
	科目
	専任
	職員番号
	生年月日
	講師名
	ペンネーム
	ペンネームふりがな
	読み
	兼職
	年収制限額
	状態
	スタッフ講師区分
	登録区分
	経理登録区分
	登録日
	退社日
	更新日
End Enum

Public Enum T_History_ImportEnum
    CSV種別
    データ分類
    データ名
    ファイル名
    対象年月
    データ件数
    実行PC
    実行ユーザ
    実行日
    作成日
    作成者
    更新日
    更新者
End Enum


Public Enum M_Time_PatternEnum
    年度
    年月日
    曜日
    日程パターン名
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum M_Timetable_SiteEnum
    年
    教室コード
    日程パターン名
    コマ
    開始時間
    終了時間
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum M_Timetable_ClassEnum
    設定区分
    教室コード
    対象期間
    学年
    クラスコード
    コマ
    開始時間
    終了時間
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum M_Hourly_WageEnum
    適用開始日
    業務給標準単価
    みなし勤務時間_事前分
    みなし勤務時間_事後分
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum M_Teacher_WageEnum
    講師コード
    適用年月日
    授業給コマ単価
    業務給単価
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum M_Lecture_Wage_PercentageEnum
    年
    期
    教室コード
    学年
    クラスコード
    授業給係数
    備考
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum W_Stamp_DataEnum
    日付
    姓
    名
    姓名
    スタッフコード
    スタッフ種別
    所属グループコード
    所属グループ名
    打刻場所
    出勤時刻_丸め
    退勤時刻_丸め
    出勤時間
    退勤時間
    休憩時間
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum W_Lecture_PlanEnum
    日付
    コマ
    教室コード
    学年
    クラスコード
    科目
    講師コード
    出講名
    テキスト回
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum W_Request_ActualEnum
    教室コード
    科目
    講師名
    日付
    業務名
    開始時間
    終了時間
    対象
    内容
    講師コード
    区分
    実時間
    単価
    乗数
    みなし回数
    金額
    担当者
    リーダー
    教務室
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum W_Pinch_ActualEnum
    日付
    曜日
    コマ
    教室コード
    クラスコード
    講師コード
    出講名
    科目
    テキスト回
    ピンチ区分
    入力日
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum W_Lecture_ActualEnum
    フェーズ
    データ種別
    日付
    コマ
    教室コード
    学年
    クラスコード
    科目
    講師コード
    テキスト回
    開始時間
    終了時間
    ピンチ種別
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum W_Hourly_Wage_Manual_EntryEnum
    講師コード
    勤務日
    教室コード
    開始時間
    終了時間
    備考
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum T_Operation_LogEnum
    イベントID
    イベント発生日時
    画面名
    操作内容
    操作詳細情報
    対象年月度
    実行ファイル名
    実行ユーザー
    実行PC
    実行日
    作成日
    作成者
    更新日
    更新者
End Enum

Public Enum T_Year_Month_LockEnum
    対象年月度
    ロック状態
    ロック開始ユーザー
    ロック開始PC
    ロック開始時間
    ロック解除ユーザー
    ロック解除PC
    ロック解除時間
    作成日
    作成者
    更新日
    更新者
End Enum

' 2025/12/23 -
Public Enum MNSPM10Enum
    Corporate_KND
    Division_KND
    Division_Name
End Enum

Public Enum MNSPM11Enum
    Corporate_KND
    Division_KND
    Site_Code
    Site_Name
End Enum

Public Enum M_Transpo_ExpensesEnum
    講師コード
    教室コード
    適用開始日
    金額
    備考
    作成日
    作成者
    更新日
    更新者
End Enum








''' <summary>
''' 講師マスタ？（既存TBL）
''' </summary>
Public Enum ntb_SiteEnum
    教室コード
    教室名
    教室区分
    電話番号
    FAX番号
    郵便番号
    住所コード
    番地
    住所
    部門番号
    教室番号
    連番１
    連番２
    連番３
    連番４
    連番５
    状態
    更新日時
End Enum




Public Class TableInfo
    Public Property TableName As String
    Public Property Columns As Dictionary(Of [Enum], String)
End Class

Public Class DbMapper

    Private Shared ReadOnly Map As New Dictionary(Of Type, TableInfo) From {
    {
      GetType(SiteGroupListEnum),
      New TableInfo With {
        .TableName = "SiteGroupList",
        .Columns = New Dictionary(Of [Enum], String) From {
          {SiteGroupListEnum.ID, "ID"},
          {SiteGroupListEnum.地区名, "地区名"}
        }
      }
    },
    {
      GetType(SiteEnum),
      New TableInfo With {
        .TableName = "Site",
        .Columns = New Dictionary(Of [Enum], String) From {
          {SiteEnum.教室コード, "教室コード"},
          {SiteEnum.教室名, "教室名"},
          {SiteEnum.教室区分, "教室区分"},
          {SiteEnum.本校教室コード, "本校教室コード"}
        }
      }
    },
    {
      GetType(TeacherRegistryEnum),
      New TableInfo With {
        .TableName = "TeacherRegistry",
        .Columns = New Dictionary(Of [Enum], String) From {
          {TeacherRegistryEnum.姓, "姓"},
          {TeacherRegistryEnum.名, "名"},
          {TeacherRegistryEnum.性別, "性別"},
          {TeacherRegistryEnum.カナ姓, "カナ姓"},
          {TeacherRegistryEnum.カナ名, "カナ名"},
          {TeacherRegistryEnum.姓ふりがな, "姓ふりがな"},
          {TeacherRegistryEnum.講師コード, "講師コード"},
          {TeacherRegistryEnum.科目, "科目"},
          {TeacherRegistryEnum.専任, "専任"},
          {TeacherRegistryEnum.職員番号, "職員番号"},
          {TeacherRegistryEnum.生年月日, "生年月日"},
          {TeacherRegistryEnum.講師名, "講師名"},
          {TeacherRegistryEnum.ペンネーム, "ペンネーム"},
          {TeacherRegistryEnum.ペンネームふりがな, "ペンネームふりがな"},
          {TeacherRegistryEnum.読み, "読み"},
          {TeacherRegistryEnum.兼職, "兼職"},
          {TeacherRegistryEnum.年収制限額, "年収制限額"},
          {TeacherRegistryEnum.状態, "状態"},
          {TeacherRegistryEnum.スタッフ講師区分, "スタッフ講師区分"},
          {TeacherRegistryEnum.登録区分, "登録区分"},
          {TeacherRegistryEnum.経理登録区分, "経理登録区分"},
          {TeacherRegistryEnum.登録日, "登録日"},
          {TeacherRegistryEnum.退社日, "退社日"},
          {TeacherRegistryEnum.更新日, "更新日"}
        }
      }
    },
    {
      GetType(T_History_ImportEnum),
      New TableInfo With {
        .TableName = "T_History_Import",
        .Columns = New Dictionary(Of [Enum], String) From {
          {T_History_ImportEnum.CSV種別, "Csv_Type"},
          {T_History_ImportEnum.データ分類, "Category"},
          {T_History_ImportEnum.データ名, "Data_Name"},
          {T_History_ImportEnum.ファイル名, "File_Name"},
          {T_History_ImportEnum.対象年月, "Fiscal_Year_Month"},
          {T_History_ImportEnum.データ件数, "Execution_Count"},
          {T_History_ImportEnum.実行PC, "Execution_Pc"},
          {T_History_ImportEnum.実行ユーザ, "Execution_User"},
          {T_History_ImportEnum.実行日, "Execution_Date"},
          {T_History_ImportEnum.作成日, "Create_Date"},
          {T_History_ImportEnum.作成者, "Create_User"},
          {T_History_ImportEnum.更新日, "Update_Date"},
          {T_History_ImportEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(M_Time_PatternEnum),
      New TableInfo With {
        .TableName = "M_Time_Pattern",
        .Columns = New Dictionary(Of [Enum], String) From {
          {M_Time_PatternEnum.年度, "Fiscal_Year"},
          {M_Time_PatternEnum.年月日, "Lecture_Date"},
          {M_Time_PatternEnum.曜日, "Youbi"},
          {M_Time_PatternEnum.日程パターン名, "Schedule_Pattern"},
          {M_Time_PatternEnum.作成日, "Create_Date"},
          {M_Time_PatternEnum.作成者, "Create_User"},
          {M_Time_PatternEnum.更新日, "Update_Date"},
          {M_Time_PatternEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(M_Timetable_SiteEnum),
      New TableInfo With {
        .TableName = "M_Timetable_Site",
        .Columns = New Dictionary(Of [Enum], String) From {
          {M_Timetable_SiteEnum.年, "Year"},
          {M_Timetable_SiteEnum.教室コード, "Site_Code"},
          {M_Timetable_SiteEnum.日程パターン名, "Schedule_Pattern"},
          {M_Timetable_SiteEnum.コマ, "Koma_Seq"},
          {M_Timetable_SiteEnum.開始時間, "Start_Time"},
          {M_Timetable_SiteEnum.終了時間, "End_Time"},
          {M_Timetable_SiteEnum.作成日, "Create_Date"},
          {M_Timetable_SiteEnum.作成者, "Create_User"},
          {M_Timetable_SiteEnum.更新日, "Update_Date"},
          {M_Timetable_SiteEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(M_Timetable_ClassEnum),
      New TableInfo With {
        .TableName = "M_Timetable_Class",
        .Columns = New Dictionary(Of [Enum], String) From {
          {M_Timetable_ClassEnum.設定区分, "Setting_Category"},
          {M_Timetable_ClassEnum.教室コード, "Site_Code"},
          {M_Timetable_ClassEnum.対象期間, "Target_Period"},
          {M_Timetable_ClassEnum.学年, "Grade"},
          {M_Timetable_ClassEnum.クラスコード, "Class_Code"},
          {M_Timetable_ClassEnum.コマ, "Koma_Seq"},
          {M_Timetable_ClassEnum.開始時間, "Start_Time"},
          {M_Timetable_ClassEnum.終了時間, "End_Time"},
          {M_Timetable_ClassEnum.作成日, "Create_Date"},
          {M_Timetable_ClassEnum.作成者, "Create_User"},
          {M_Timetable_ClassEnum.更新日, "Update_Date"},
          {M_Timetable_ClassEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(M_Hourly_WageEnum),
      New TableInfo With {
        .TableName = "M_Hourly_Wage",
        .Columns = New Dictionary(Of [Enum], String) From {
          {M_Hourly_WageEnum.適用開始日, "Effective_Date"},
          {M_Hourly_WageEnum.業務給標準単価, "Task_Base_Unit_Price"},
          {M_Hourly_WageEnum.みなし勤務時間_事前分, "Deemed_Time_Before"},
          {M_Hourly_WageEnum.みなし勤務時間_事後分, "Deemed_Time_After"},
          {M_Hourly_WageEnum.作成日, "Create_Date"},
          {M_Hourly_WageEnum.作成者, "Create_User"},
          {M_Hourly_WageEnum.更新日, "Update_Date"},
          {M_Hourly_WageEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(M_Teacher_WageEnum),
      New TableInfo With {
        .TableName = "M_Teacher_Wage",
        .Columns = New Dictionary(Of [Enum], String) From {
          {M_Teacher_WageEnum.講師コード, "Teacher_Code"},
          {M_Teacher_WageEnum.適用年月日, "Effective_Date"},
          {M_Teacher_WageEnum.授業給コマ単価, "Lecture_Unit_Price"},
          {M_Teacher_WageEnum.業務給単価, "Task_Unit_Price"},
          {M_Teacher_WageEnum.作成日, "Create_Date"},
          {M_Teacher_WageEnum.作成者, "Create_User"},
          {M_Teacher_WageEnum.更新日, "Update_Date"},
          {M_Teacher_WageEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(M_Lecture_Wage_PercentageEnum),
      New TableInfo With {
        .TableName = "M_Lecture_Wage_Percentage",
        .Columns = New Dictionary(Of [Enum], String) From {
          {M_Lecture_Wage_PercentageEnum.年, "Year"},
          {M_Lecture_Wage_PercentageEnum.期, "Half_Year"},
          {M_Lecture_Wage_PercentageEnum.教室コード, "Site_Code"},
          {M_Lecture_Wage_PercentageEnum.学年, "Grade"},
          {M_Lecture_Wage_PercentageEnum.クラスコード, "Class_Code"},
          {M_Lecture_Wage_PercentageEnum.授業給係数, "Lecture_Coefficient"},
          {M_Lecture_Wage_PercentageEnum.備考, "Remarks"},
          {M_Lecture_Wage_PercentageEnum.作成日, "Create_Date"},
          {M_Lecture_Wage_PercentageEnum.作成者, "Create_User"},
          {M_Lecture_Wage_PercentageEnum.更新日, "Update_Date"},
          {M_Lecture_Wage_PercentageEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(W_Stamp_DataEnum),
      New TableInfo With {
        .TableName = "W_Stamp_Data",
        .Columns = New Dictionary(Of [Enum], String) From {
          {W_Stamp_DataEnum.日付, "Lecture_Date"},
          {W_Stamp_DataEnum.姓, "Last_Name"},
          {W_Stamp_DataEnum.名, "First_Name"},
          {W_Stamp_DataEnum.姓名, "Full_Name"},
          {W_Stamp_DataEnum.スタッフコード, "Staff_Code"},
          {W_Stamp_DataEnum.スタッフ種別, "Staff_Type"},
          {W_Stamp_DataEnum.所属グループコード, "Group_Code"},
          {W_Stamp_DataEnum.所属グループ名, "Group_Name"},
          {W_Stamp_DataEnum.打刻場所, "Clock_In_Out_Location"},
          {W_Stamp_DataEnum.出勤時刻_丸め, "Arrival_Time_Round"},
          {W_Stamp_DataEnum.退勤時刻_丸め, "Leave_Time_Round"},
          {W_Stamp_DataEnum.出勤時間, "Arrival_Time"},
          {W_Stamp_DataEnum.退勤時間, "Leave_Time"},
          {W_Stamp_DataEnum.休憩時間, "Break_Time"},
          {W_Stamp_DataEnum.作成日, "Create_Date"},
          {W_Stamp_DataEnum.作成者, "Create_User"},
          {W_Stamp_DataEnum.更新日, "Update_Date"},
          {W_Stamp_DataEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(W_Lecture_PlanEnum),
      New TableInfo With {
        .TableName = "W_Lecture_Plan",
        .Columns = New Dictionary(Of [Enum], String) From {
          {W_Lecture_PlanEnum.日付, "Lecture_Date"},
          {W_Lecture_PlanEnum.コマ, "Koma_Seq"},
          {W_Lecture_PlanEnum.教室コード, "Site_Code"},
          {W_Lecture_PlanEnum.学年, "Grade"},
          {W_Lecture_PlanEnum.クラスコード, "Class_Code"},
          {W_Lecture_PlanEnum.科目, "Subject"},
          {W_Lecture_PlanEnum.講師コード, "Teacher_Code"},
          {W_Lecture_PlanEnum.出講名, "Lecture_Name"},
          {W_Lecture_PlanEnum.テキスト回, "Number_Of_Text"},
          {W_Lecture_PlanEnum.作成日, "Create_Date"},
          {W_Lecture_PlanEnum.作成者, "Create_User"},
          {W_Lecture_PlanEnum.更新日, "Update_Date"},
          {W_Lecture_PlanEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(W_Request_ActualEnum),
      New TableInfo With {
        .TableName = "W_Request_Actual",
        .Columns = New Dictionary(Of [Enum], String) From {
          {W_Request_ActualEnum.教室コード, "Site_Code"},
          {W_Request_ActualEnum.科目, "Subject"},
          {W_Request_ActualEnum.講師名, "Teacher_Name"},
          {W_Request_ActualEnum.日付, "Lecture_Date"},
          {W_Request_ActualEnum.業務名, "Business_Name"},
          {W_Request_ActualEnum.開始時間, "Start_Time"},
          {W_Request_ActualEnum.終了時間, "End_Time"},
          {W_Request_ActualEnum.対象, "Target"},
          {W_Request_ActualEnum.内容, "Contents"},
          {W_Request_ActualEnum.講師コード, "Teacher_Code"},
          {W_Request_ActualEnum.区分, "Category"},
          {W_Request_ActualEnum.実時間, "Working_Time"},
          {W_Request_ActualEnum.単価, "Unit_Pice"},
          {W_Request_ActualEnum.乗数, "Multiplier"},
          {W_Request_ActualEnum.みなし回数, "Deemed_Count"},
          {W_Request_ActualEnum.金額, "Amount"},
          {W_Request_ActualEnum.担当者, "PersonIn_In_Charge"},
          {W_Request_ActualEnum.リーダー, "Leader"},
          {W_Request_ActualEnum.教務室, "Academic_Affairs_Office"},
          {W_Request_ActualEnum.作成日, "Create_Date"},
          {W_Request_ActualEnum.作成者, "Create_User"},
          {W_Request_ActualEnum.更新日, "Update_Date"},
          {W_Request_ActualEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(W_Pinch_ActualEnum),
      New TableInfo With {
        .TableName = "W_Pinch_Actual",
        .Columns = New Dictionary(Of [Enum], String) From {
          {W_Pinch_ActualEnum.日付, "Lecture_Date"},
          {W_Pinch_ActualEnum.曜日, "Youbi"},
          {W_Pinch_ActualEnum.コマ, "Koma_Seq"},
          {W_Pinch_ActualEnum.教室コード, "Site_Code"},
          {W_Pinch_ActualEnum.クラスコード, "Class_Code"},
          {W_Pinch_ActualEnum.講師コード, "Teacher_Code"},
          {W_Pinch_ActualEnum.出講名, "Lecture_Name"},
          {W_Pinch_ActualEnum.科目, "Subject"},
          {W_Pinch_ActualEnum.テキスト回, "Number_Of_Text"},
          {W_Pinch_ActualEnum.ピンチ区分, "Pinch_Type"},
          {W_Pinch_ActualEnum.入力日, "Input_Date"},
          {W_Pinch_ActualEnum.作成日, "Create_Date"},
          {W_Pinch_ActualEnum.作成者, "Create_User"},
          {W_Pinch_ActualEnum.更新日, "Update_Date"},
          {W_Pinch_ActualEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(W_Lecture_ActualEnum),
      New TableInfo With {
        .TableName = "W_Lecture_Actual",
        .Columns = New Dictionary(Of [Enum], String) From {
          {W_Lecture_ActualEnum.フェーズ, "Phase"},
          {W_Lecture_ActualEnum.データ種別, "Data_Type"},
          {W_Lecture_ActualEnum.日付, "Lecture_Date"},
          {W_Lecture_ActualEnum.コマ, "Koma_Seq"},
          {W_Lecture_ActualEnum.教室コード, "Site_Code"},
          {W_Lecture_ActualEnum.学年, "Grade"},
          {W_Lecture_ActualEnum.クラスコード, "Class_Code"},
          {W_Lecture_ActualEnum.科目, "Subject"},
          {W_Lecture_ActualEnum.講師コード, "Teacher_Code"},
          {W_Lecture_ActualEnum.テキスト回, "Number_Of_Text"},
          {W_Lecture_ActualEnum.開始時間, "Start_Time"},
          {W_Lecture_ActualEnum.終了時間, "End_Time"},
          {W_Lecture_ActualEnum.ピンチ種別, "Pinch_Type"},
          {W_Lecture_ActualEnum.作成日, "Create_Date"},
          {W_Lecture_ActualEnum.作成者, "Create_User"},
          {W_Lecture_ActualEnum.更新日, "Update_Date"},
          {W_Lecture_ActualEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(W_Hourly_Wage_Manual_EntryEnum),
      New TableInfo With {
        .TableName = "W_Hourly_Wage_Manual_Entry",
        .Columns = New Dictionary(Of [Enum], String) From {
          {W_Hourly_Wage_Manual_EntryEnum.講師コード, "Teacher_Code"},
          {W_Hourly_Wage_Manual_EntryEnum.勤務日, "Lecture_Date"},
          {W_Hourly_Wage_Manual_EntryEnum.教室コード, "Site_Code"},
          {W_Hourly_Wage_Manual_EntryEnum.開始時間, "Start_Time"},
          {W_Hourly_Wage_Manual_EntryEnum.終了時間, "End_Time"},
          {W_Hourly_Wage_Manual_EntryEnum.備考, "Remarks"},
          {W_Hourly_Wage_Manual_EntryEnum.作成日, "Create_Date"},
          {W_Hourly_Wage_Manual_EntryEnum.作成者, "Create_User"},
          {W_Hourly_Wage_Manual_EntryEnum.更新日, "Update_Date"},
          {W_Hourly_Wage_Manual_EntryEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(T_Operation_LogEnum),
      New TableInfo With {
        .TableName = "T_Operation_Log",
        .Columns = New Dictionary(Of [Enum], String) From {
          {T_Operation_LogEnum.イベントID, "Id"},
          {T_Operation_LogEnum.イベント発生日時, "Event_Date_Time"},
          {T_Operation_LogEnum.画面名, "Window_Name"},
          {T_Operation_LogEnum.操作内容, "Event_Content"},
          {T_Operation_LogEnum.操作詳細情報, "Event_Details"},
          {T_Operation_LogEnum.対象年月度, "Target_Date"},
          {T_Operation_LogEnum.実行ファイル名, "Exe_Name"},
          {T_Operation_LogEnum.実行ユーザー, "User_Id"},
          {T_Operation_LogEnum.実行PC, "Pc_Id"},
          {T_Operation_LogEnum.実行日, "Execution_Date"},
          {T_Operation_LogEnum.作成日, "Create_Date"},
          {T_Operation_LogEnum.作成者, "Create_User"},
          {T_Operation_LogEnum.更新日, "Update_Date"},
          {T_Operation_LogEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(T_Year_Month_LockEnum),
      New TableInfo With {
        .TableName = "T_Year_Month_Lock",
        .Columns = New Dictionary(Of [Enum], String) From {
          {T_Year_Month_LockEnum.対象年月度, "Year_Month"},
          {T_Year_Month_LockEnum.ロック状態, "Lock_Status"},
          {T_Year_Month_LockEnum.ロック開始ユーザー, "Lock_User"},
          {T_Year_Month_LockEnum.ロック開始PC, "Lock_Pc"},
          {T_Year_Month_LockEnum.ロック開始時間, "Lock_Datetime"},
          {T_Year_Month_LockEnum.ロック解除ユーザー, "Unlock_User"},
          {T_Year_Month_LockEnum.ロック解除PC, "Unlock_Pc"},
          {T_Year_Month_LockEnum.ロック解除時間, "Unlock_Datetime"},
          {T_Year_Month_LockEnum.作成日, "Create_Date"},
          {T_Year_Month_LockEnum.作成者, "Create_User"},
          {T_Year_Month_LockEnum.更新日, "Update_Date"},
          {T_Year_Month_LockEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(MNSPM10Enum),
      New TableInfo With {
        .TableName = "[LECTPAY].[dbo].[MNSPM10]",
        .Columns = New Dictionary(Of [Enum], String) From {
          {MNSPM10Enum.Corporate_KND, "Corporate_KND"},
          {MNSPM10Enum.Division_KND, "Division_KND"},
          {MNSPM10Enum.Division_Name, "Division_Name"}
        }
      }
    },
    {
      GetType(MNSPM11Enum),
      New TableInfo With {
        .TableName = "[LECTPAY].[dbo].[MNSPM11]",
        .Columns = New Dictionary(Of [Enum], String) From {
          {MNSPM11Enum.Corporate_KND, "Corporate_KND"},
          {MNSPM11Enum.Division_KND, "Division_KND"},
          {MNSPM11Enum.Site_Code, "Site_Code"},
          {MNSPM11Enum.Site_Name, "Site_Name"}
        }
      }
    },
    {
      GetType(M_Transpo_ExpensesEnum),
      New TableInfo With {
        .TableName = "M_Transpo_Expenses",
        .Columns = New Dictionary(Of [Enum], String) From {
          {M_Transpo_ExpensesEnum.講師コード, "Teacher_Code"},
          {M_Transpo_ExpensesEnum.教室コード, "Site_Code"},
          {M_Transpo_ExpensesEnum.適用開始日, "Effective_Date"},
          {M_Transpo_ExpensesEnum.金額, "Amount"},
          {M_Transpo_ExpensesEnum.備考, "Remarks"},
          {M_Transpo_ExpensesEnum.作成日, "Create_Date"},
          {M_Transpo_ExpensesEnum.作成者, "Create_User"},
          {M_Transpo_ExpensesEnum.更新日, "Update_Date"},
          {M_Transpo_ExpensesEnum.更新者, "Update_User"}
        }
      }
    },
    {
      GetType(ntb_SiteEnum),
      New TableInfo With {
        .TableName = "[LECTPAY].[dbo].[ntb_Site]",
        .Columns = New Dictionary(Of [Enum], String) From {
          {ntb_SiteEnum.教室コード, "Site_Code"},
          {ntb_SiteEnum.教室名, "Site_Name"},
          {ntb_SiteEnum.教室区分, "Site_KND"},
          {ntb_SiteEnum.電話番号, "TEL"},
          {ntb_SiteEnum.FAX番号, "FAX"},
          {ntb_SiteEnum.郵便番号, "ZIP"},
          {ntb_SiteEnum.住所コード, "Address_Code"},
          {ntb_SiteEnum.番地, "Street"},
          {ntb_SiteEnum.住所, "Location"},
          {ntb_SiteEnum.部門番号, "Division_No"},
          {ntb_SiteEnum.教室番号, "Site_No"},
          {ntb_SiteEnum.連番１, "SEQ_1"},
          {ntb_SiteEnum.連番２, "SEQ_2"},
          {ntb_SiteEnum.連番３, "SEQ_3"},
          {ntb_SiteEnum.連番４, "SEQ_4"},
          {ntb_SiteEnum.連番５, "SEQ_5"},
          {ntb_SiteEnum.状態, "Status"},
          {ntb_SiteEnum.更新日時, "Update_Date"}
        }
      }
    }
  }

    Public Shared Function GetTableName(Of TEnum As Structure)() As String
		Return Map(GetType(TEnum)).TableName
	End Function

	Public Shared Function GetColumnName(Of TEnum As Structure)(col As TEnum) As String
		Dim key As [Enum] = CType(CType(col, Object), [Enum])
		Return Map(GetType(TEnum)).Columns(key)
	End Function
End Class

Public Module DBShort
	<Extension()>
	Public Function Table(Of TEnum As Structure)(col As TEnum) As String
		Return DbMapper.GetTableName(Of TEnum)()
	End Function

	<Extension()>
	Public Function Column(Of TEnum As Structure)(col As TEnum) As String
		Return DbMapper.GetColumnName(col)
	End Function

	<Extension()>
	Public Function Param(Of TEnum As Structure)(col As TEnum) As String
		Return "@" & DbMapper.GetColumnName(col)
	End Function
End Module
