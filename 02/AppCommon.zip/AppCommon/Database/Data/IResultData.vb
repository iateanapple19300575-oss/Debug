﻿''' <summary>
''' 戻り値インターフェース
''' </summary>
Public Interface IResultData

    '''' <summary>
    '''' 処理結果
    '''' </summary>
    '''' <returns></returns>
    'Property Success As Boolean

    '''' <summary>
    '''' 排他エラー
    '''' </summary>
    '''' <returns></returns>
    'Property Exclusive As Boolean

    '''' <summary>
    '''' エラーコード
    '''' </summary>
    '''' <returns></returns>
    'Property ErrorCode As Integer

    '''' <summary>
    '''' エラーナンバー
    '''' </summary>
    '''' <returns></returns>
    'Property ErrorNumber As Integer

    '''' <summary>
    '''' 例外エラー
    '''' </summary>
    '''' <returns></returns>
    'Property ExceptionEx As Exception

    '''' <summary>
    '''' メッセージ
    '''' </summary>
    '''' <returns></returns>
    'Property Message As String

    '''' <summary>
    '''' 件数
    '''' </summary>
    '''' <returns></returns>
    'Property DataCount As Integer

    '''' <summary>
    '''' 処理日時
    '''' </summary>
    '''' <returns></returns>
    'Property ProcessDateTime As DateTime

    ''' <summary>
    ''' 返却データ(List)
    ''' </summary>
    ''' <returns></returns>
    Property ResList As List(Of String)

    ''' <summary>
    ''' 返却データ(DataClass)
    ''' </summary>
    ''' <returns></returns>
    Property ResDataClass As IData

    ''' <summary>
    ''' 返却データ(DataTable)
    ''' </summary>
    ''' <returns></returns>
    Property ResDataTable As DataTable

    ''' <summary>
    ''' 返却データ(Dictionary)
    ''' </summary>
    ''' <returns></returns>
    Property ResDictionary As Dictionary(Of String, String)

    ''' <summary>
    ''' 返却データ(Dictionary)
    ''' </summary>
    ''' <returns></returns>
    Property ResDic As Dictionary(Of String, IData)

End Interface
