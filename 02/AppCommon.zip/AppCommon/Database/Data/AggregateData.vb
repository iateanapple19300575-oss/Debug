﻿Public Class AggregateData
  Implements IData

  ''' <summary>
  ''' 対象年月度リスト
  ''' </summary>
  ''' <returns></returns>
  Public Property LectureYearMonthList As New List(Of String)

  ''' <summary>
  ''' [時間パターン]：最終取込日時
  ''' </summary>
  ''' <returns></returns>
  Public Property TimePatternFinalDate As Date

  ''' <summary>
  ''' [時間パターン]：最終取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property TimePatternDataCount As Integer

  ''' <summary>
  ''' [教室時間割]：最終取込日時
  ''' </summary>
  ''' <returns></returns>
  Public Property TimeTableFinalDate As Date

  ''' <summary>
  ''' [教室時間割]：最終取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property TimeTableDataCount As Integer

  ''' <summary>
  ''' [コマ単価]：最終取込日時
  ''' </summary>
  ''' <returns></returns>
  Public Property UnitPriceFinalDate As Date

  ''' <summary>
  ''' [コマ単価]：最終取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property UnitPriceDataCount As Integer

  ''' <summary>
  ''' [打刻取込]：最終取込日時
  ''' </summary>
  ''' <returns></returns>
  Public Property StampImportFinalDate As Date

  ''' <summary>
  ''' [打刻取込]：最終取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property StampImportDataCount As Integer

  ''' <summary>
  ''' [出講予定]：最終取込日時
  ''' </summary>
  ''' <returns></returns>
  Public Property PlanImportFinalDate As Date

  ''' <summary>
  ''' [出講予定]：最終取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property PlanImportDataCount As Integer

  ''' <summary>
  ''' [業務依頼]：最終取込日時
  ''' </summary>
  ''' <returns></returns>
  Public Property RequestImportFinalDate As Date

  ''' <summary>
  ''' [業務依頼]：最終取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property RequestImportDataCount As Integer

  ''' <summary>
  ''' [代行実績]：最終取込日時
  ''' </summary>
  ''' <returns></returns>
  Public Property AlternateImportFinalDate As Date

  ''' <summary>
  ''' [代行実績]：最終取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property AlternateImportDataCount As Integer

  ''' <summary>
  ''' 最終集計日時
  ''' </summary>
  ''' <returns></returns>
  Public Property LastCountedDateTime As DateTime

End Class
