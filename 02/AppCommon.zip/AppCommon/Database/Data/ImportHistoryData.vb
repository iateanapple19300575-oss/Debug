﻿Public Class ImportHistoryData
  Implements IData

  ''' <summary>
  ''' データ種別
  ''' </summary>
  ''' <returns></returns>
  Public Property DataType As Integer

  ''' <summary>
  ''' カテゴリ
  ''' </summary>
  ''' <returns></returns>
  Public Property Category As String

  ''' <summary>
  ''' データ名
  ''' </summary>
  ''' <returns></returns>
  Public Property DataName As String

  ''' <summary>
  ''' ファイル名
  ''' </summary>
  ''' <returns></returns>
  Public Property FileName As String

  ''' <summary>
  ''' 年月度
  ''' </summary>
  ''' <returns></returns>
  Public Property YearMonth As String

  ''' <summary>
  ''' ファイル内容
  ''' </summary>
  ''' <returns></returns>
  Public Property FileContent As String

  ''' <summary>
  ''' データ件数
  ''' </summary>
  ''' <returns></returns>
  Public Property DataCount As Integer

  ''' <summary>
  ''' 実施PC
  ''' </summary>
  ''' <returns></returns>
  Public Property CreatePc As String

  ''' <summary>
  ''' 実施ユーザ
  ''' </summary>
  ''' <returns></returns>
  Public Property CreateUser As String

  ''' <summary>
  ''' 実施日付
  ''' </summary>
  ''' <returns></returns>
  Public Property CreateDate As Date
End Class
