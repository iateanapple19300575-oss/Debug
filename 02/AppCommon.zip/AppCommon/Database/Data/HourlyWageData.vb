﻿Public Class HourlyWageData
  Inherits DaoParamDataBase

  Public Property Effective_Date As String = ""
  Public Property Task_Base_Unit_Price As String = ""
  Public Property Deemed_Time_Before As String = ""
  Public Property Deemed_Time_After As String = ""
  Public Property Create_Date As String = ""
  Public Property Create_User As String = ""
  Public Property Update_Date As String = ""
  Public Property Update_User As String = ""
End Class
