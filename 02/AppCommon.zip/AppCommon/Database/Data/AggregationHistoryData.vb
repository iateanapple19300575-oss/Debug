﻿''' <summary>
''' 集計実行履歴テーブルデータクラス
''' </summary>
Public Class AggregationHistoryData
    Inherits TableInfoData
    Implements IData

    ''' <summary>
    ''' 集計処理名
    ''' </summary>
    ''' <returns></returns>
    Public Property AGGREGATION_NAME As String

    ''' <summary>
    ''' 集計処理日時
    ''' </summary>
    ''' <returns></returns>
    Public Property AGGREGATION_DATE As DateTime

    ''' <summary>
    ''' 集計処理結果
    ''' </summary>
    ''' <returns></returns>
    Public Property AGGREGATION_STATUS As String

    ''' <summary>
    ''' 集計処理で使用した打刻データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property TIME_STAMP_DATA_VERSION As DateTime

    ''' <summary>
    ''' 集計処理で使用した出講予定データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property SCHEDULE_DATA_VERSION As DateTime

    ''' <summary>
    ''' 集計処理で使用した業務依頼データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property REQUEST_DATA_VERSION As DateTime

    ''' <summary>
    ''' 集計処理で使用した代行実績データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property SUBSTITUTE_DATA_VERSION As DateTime

    ''' <summary>
    ''' 集計処理で使用した時間パターンマスタのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property TIME_PATTERN_MASTER_VERSION As DateTime

    ''' <summary>
    ''' 集計処理で使用した教室時間割マスタのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property TIMETABLE_MASTER_VERSION As DateTime

    ''' <summary>
    ''' 集計処理で使用したコマ単価マスタのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property PRICE_MASTER_VERSION As DateTime

    ''' <summary>
    ''' 集計処理で使用したコマ単価マスタのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property EXECUTOR_DATE As DateTime

    '''' <summary>
    '''' 集計処理実行PC
    '''' </summary>
    '''' <returns></returns>
    'Public Property CREATE_PC As String

    '''' <summary>
    '''' 集計処理実行ユーザー
    '''' </summary>
    '''' <returns></returns>
    'Public Property CREATE_USER As String

    '''' <summary>
    '''' 集計処理実行日時
    '''' </summary>
    '''' <returns></returns>
    'Public Property CREATE_DATE As String

End Class
