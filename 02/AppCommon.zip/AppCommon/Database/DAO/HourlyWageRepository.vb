﻿Imports System.Data.SqlClient

Public Class HourlyWageRepository
  Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Const KEY_EFFECTIVE_DATE As String = "Effective_Date"

  ''' <summary>
  ''' 取得（条件なし）
  ''' </summary>
  ''' <returns></returns>
  Public Function GetAll(ByVal param As DaoParameter) As DataTable
    Dim HW = Tables.HourlyWage

    Dim sqlString As String =
$"SELECT
      {HW.Effective_Date}
    , {HW.Task_Base_Unit_Price}
    , {HW.Deemed_Time_Before}
    , {HW.Deemed_Time_After}
  FROM
    {HW.TableName}
  WHERE
    1=1
  ORDER BY
    {HW.Effective_Date} ASC;
" ' SQL String End

    Return SqlUtil.ExecuteDataTable(sqlString.ToString(), Nothing)
  End Function

  ''' <summary>
  ''' 取得（条件なし）
  ''' </summary>
  ''' <returns></returns>
  Public Function GetData(ByVal param As DaoParameter) As DataTable
    Dim HW = Tables.HourlyWage

    Dim sqlString As New System.Text.StringBuilder
    sqlString.Length = 0
    sqlString.Append(
      $"SELECT
            {HW.Effective_Date}
          , {HW.Task_Base_Unit_Price}
          , {HW.Deemed_Time_Before}
          , {HW.Deemed_Time_After}
        FROM
          {HW.TableName}
        WHERE
      "
    ).Append(" ")

    If param Is Nothing OrElse String.IsNullOrEmpty(param.Value(KEY_EFFECTIVE_DATE)) Then
      sqlString.Append("1=1")
    Else
      sqlString.Append(
      $"{HW.Effective_Date} = @{HW.Effective_Date}")
    End If

    sqlString.Append(" ")
    sqlString.Append(
      $"ORDER BY
          {HW.Effective_Date} ASC;
      "
    )

    Return SqlUtil.ExecuteDataTable(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{HW.Effective_Date}", .Value = param.CurrentUser}
      )
  End Function

  ''' <summary>
  ''' 追加
  ''' </summary>
  ''' <returns></returns>
  Public Function Add(ByVal data As HourlyWageData) As Integer
    Dim HW = Tables.HourlyWage

    Dim sqlString As String =
$"INSERT INTO 
    {HW.TableName}
  (
      {HW.Effective_Date}
    , {HW.Task_Base_Unit_Price}
    , {HW.Deemed_Time_Before}
    , {HW.Deemed_Time_After}
    , {HW.Create_Date}
    , {HW.Create_User}
    , {HW.Update_Date}
    , {HW.Update_User}
  )
  VALUES
  (
      @{HW.Effective_Date}
    , @{HW.Task_Base_Unit_Price}
    , @{HW.Deemed_Time_Before}
    , @{HW.Deemed_Time_After}
    , GETDATE()
    , @{HW.Create_User}
    , NULL
    , NULL
  )
" ' SQL String End

    Return SqlUtil.ExcuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{HW.Effective_Date}", .Value = data.Effective_Date},
        New SqlParameter() With {.ParameterName = $"@{HW.Task_Base_Unit_Price}", .Value = data.Task_Base_Unit_Price},
        New SqlParameter() With {.ParameterName = $"@{HW.Deemed_Time_Before}", .Value = data.Deemed_Time_Before},
        New SqlParameter() With {.ParameterName = $"@{HW.Deemed_Time_After}", .Value = data.Deemed_Time_After},
        New SqlParameter() With {.ParameterName = $"@{HW.Create_User}", .Value = data.CurrentUser}
      )
  End Function

  ''' <summary>
  ''' 更新
  ''' </summary>
  ''' <returns></returns>
  Public Function Update(ByVal param As DaoParameter, ByVal data As HourlyWageData) As Integer
    Dim HW = Tables.HourlyWage

    Dim sqlString As String =
$"UPDATE
    {HW.TableName}
  SET
    {HW.Task_Base_Unit_Price}=@{HW.Task_Base_Unit_Price}
    , {HW.Deemed_Time_Before}=@{HW.Deemed_Time_Before}
    , {HW.Deemed_Time_After}=@{HW.Deemed_Time_After}
    , {HW.Update_Date}=GETDATE() 
    , {HW.Update_User}={HW.Update_User}
  WHERE
    {HW.Effective_Date}=@{HW.Effective_Date}
" ' SQL String End

    Return SqlUtil.ExcuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{HW.Effective_Date}", .Value = data.Effective_Date},
        New SqlParameter() With {.ParameterName = $"@{HW.Task_Base_Unit_Price}", .Value = data.Task_Base_Unit_Price},
        New SqlParameter() With {.ParameterName = $"@{HW.Deemed_Time_Before}", .Value = data.Deemed_Time_Before},
        New SqlParameter() With {.ParameterName = $"@{HW.Deemed_Time_After}", .Value = data.Deemed_Time_After},
        New SqlParameter() With {.ParameterName = $"@{HW.Update_User}", .Value = data.CurrentUser}
      )
  End Function

  ''' <summary>
  ''' 削除
  ''' </summary>
  ''' <returns></returns>
  Public Function Delete(ByVal param As DaoParameter) As Integer
    Dim HW = Tables.HourlyWage

    Dim sqlString As String =
$"DELETE FROM
    {HW.TableName}
  WHERE
    {HW.Effective_Date}=@{HW.Effective_Date}
" ' SQL String End

    Return SqlUtil.ExcuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{HW.Effective_Date}", .Value = param.Value(KEY_EFFECTIVE_DATE)}
      )
  End Function

  ''' <summary>
  ''' 適用データ
  ''' </summary>
  ''' <returns></returns>
  Public Function FindForApplicableData(ByVal param As DaoParameter) As Integer
    Dim HW = Tables.HourlyWage

    Dim sqlString As String =
$"SELECT TOP 1 
      {HW.Effective_Date}, {HW.Task_Base_Unit_Price}, {HW.Deemed_Time_Before}, {HW.Deemed_Time_After} 
    FROM
      {HW.TableName}
  WHERE 1=1
    AND {HW.Effective_Date}<=@{HW.Effective_Date}
  ORDER BY
    
" ' SQL String End

    Return SqlUtil.ExcuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{HW.Effective_Date}", .Value = param.Value(KEY_EFFECTIVE_DATE)}
      )
  End Function

End Class
