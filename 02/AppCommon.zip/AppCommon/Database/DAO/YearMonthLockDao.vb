﻿Imports System.Data.SqlClient
Imports MainApp.Data.Entity

Public Class YearMonthLockDao
  Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 年月度ロック登録(追加版)
    ''' </summary>
    ''' <param name="yearMonth"></param>
    ''' <returns></returns>
    Public Function LockForInsert(ByVal yearMonth As String) As Integer
    Dim Y = Tables.YearMonthLock

    Dim sqlString As String =
    $"INSERT INTO {Y.TableName} 
        (
            {Y.Year_Month}
          , {Y.Lock_Status}
          , {Y.Lock_User}
          , {Y.Lock_Pc}
          , {Y.Lock_Datetime}
          , {Y.Unlock_User}
          , {Y.Unlock_Pc}
          , {Y.Unlock_Datetime}
          , {Y.Create_Date}
          , {Y.Create_User}
          , {Y.Update_Date}
          , {Y.Update_User}
        )
          SELECT 
            @{Y.Year_Month}
            , 'L'
            , @{Y.Lock_User}
            , @{Y.Lock_User}
            , GETDATE()
            , NULL
            , NULL
            , NULL
            , GETDATE()
            , @{Y.Lock_User}
            , NULL
            , NULL
          WHERE Not EXISTS (
            SELECT 1 FROM 
              {Y.TableName}
            WHERE 1=1
            AND {Y.Year_Month} = @{Y.Year_Month}
          )
      " ' SQL String End

    Return ExecuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{Y.Year_Month}", .Value = yearMonth},
        New SqlParameter() With {.ParameterName = $"@{Y.Lock_User}", .Value = AppState.CurrentUserName},
        New SqlParameter() With {.ParameterName = $"@{Y.Lock_Pc}", .Value = AppState.CurrentPcName}
      )
  End Function

  ''' <summary>
  ''' 年月度ロック登録(更新版)
  ''' </summary>
  ''' <param name="yearMonth"></param>
  ''' <returns></returns>
  Public Function LockForUpdate(ByVal yearMonth As String) As Integer
    Dim Y = Tables.YearMonthLock

    Dim sqlString As String =
    $"UPDATE {Y.TableName}
		    SET
		      {Y.Lock_Status} = 'L'
		      , {Y.Lock_User} = @{Y.Lock_User}
		      , {Y.Lock_Pc} = @{Y.Lock_Pc}
		      , {Y.Lock_Datetime} = GETDATE()
		      , {Y.Unlock_User} = NULL
		      , {Y.Unlock_Pc} = NULL
		      , {Y.Unlock_Datetime} = NULL
		      , {Y.Update_Date} = GETDATE()
		      , {Y.Update_User} = @{Y.Update_User}
		    WHERE 1=1
		      AND {Y.Year_Month} = @{Y.Year_Month}
		      AND (
                    {Y.Lock_Status} = 'U'
                OR ({Y.Lock_Status} = 'L' AND {Y.Lock_User} = @{Y.Lock_User} AND {Y.Lock_Pc} = @{Y.Lock_Pc})
			      )
      " ' SQL String End

    Return ExecuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{Y.Year_Month}", .Value = yearMonth},
        New SqlParameter() With {.ParameterName = $"@{Y.Lock_User}", .Value = AppState.CurrentUserName},
        New SqlParameter() With {.ParameterName = $"@{Y.Lock_Pc}", .Value = AppState.CurrentPcName},
        New SqlParameter() With {.ParameterName = $"@{Y.Update_User}", .Value = AppState.CurrentUserName}
      )
  End Function

  ''' <summary>
  ''' ロック解除(自分自身)
  ''' </summary>
  ''' <param name="yearMonth"></param>
  ''' <returns></returns>
  Public Function UnLock(ByVal yearMonth As String) As Integer
    Dim Y = Tables.YearMonthLock

        Dim sqlString As String =
    $"UPDATE {Y.TableName}
		    SET
		      {Y.Lock_Status} = 'U'
		      , {Y.Unlock_User} = @{Y.Unlock_User} 
		      , {Y.Unlock_Pc} = @{Y.Unlock_Pc}
		      , {Y.Unlock_Datetime} = GETDATE()
		      , {Y.Update_Date} = GETDATE()
		      , {Y.Update_User} = @{Y.Update_User}
		    WHERE 1=1
		      AND {Y.Year_Month} = @{Y.Year_Month}
		      AND (
                    {Y.Lock_Status} = 'U'
                OR ({Y.Lock_Status} = 'L' AND {Y.Lock_User} = @{Y.Lock_User} AND {Y.Lock_Pc} = @{Y.Lock_Pc})
			      )
      " ' SQL String End

        Return ExecuteNonQuery(sqlString.ToString(),
        New SqlParameter() With {.ParameterName = $"@{Y.Year_Month}", .Value = yearMonth},
        New SqlParameter() With {.ParameterName = $"@{Y.Lock_User}", .Value = AppState.CurrentUserName},
        New SqlParameter() With {.ParameterName = $"@{Y.Lock_Pc}", .Value = AppState.CurrentPcName},
        New SqlParameter() With {.ParameterName = $"@{Y.Unlock_User}", .Value = AppState.CurrentUserName},
        New SqlParameter() With {.ParameterName = $"@{Y.Unlock_Pc}", .Value = AppState.CurrentPcName},
        New SqlParameter() With {.ParameterName = $"@{Y.Update_User}", .Value = AppState.CurrentUserName}
      )
    End Function

  ''' <summary>
  ''' ロック強制解除
  ''' </summary>
  ''' <param name="yearMonth"></param>
  ''' <returns></returns>
  Public Function ForcedRelease(ByVal yearMonth As String) As Integer
    Dim Y = Tables.YearMonthLock

    Dim sqlString As String =
    $"UPDATE {Y.TableName}
		    SET
		      {Y.Lock_Status} = 'U'
		      , {Y.Unlock_User} = @{Y.Unlock_User} 
		      , {Y.Unlock_Pc} = @{Y.Unlock_Pc}
		      , {Y.Unlock_Datetime} = GETDATE()
		      , {Y.Update_Date} = GETDATE()
		      , {Y.Update_User} = @{Y.Update_User}
		    WHERE 1=1
		      AND {Y.Year_Month} = @{Y.Year_Month}
		      AND {Y.Lock_Status} = 'L'
      " ' SQL String End

    Return ExecuteNonQuery(sqlString.ToString(),
      New SqlParameter() With {.ParameterName = $"@{Y.Year_Month}", .Value = yearMonth},
      New SqlParameter() With {.ParameterName = $"@{Y.Unlock_User}", .Value = AppState.CurrentUserName},
      New SqlParameter() With {.ParameterName = $"@{Y.Unlock_Pc}", .Value = AppState.CurrentPcName},
      New SqlParameter() With {.ParameterName = $"@{Y.Update_User}", .Value = AppState.CurrentUserName}
    )
  End Function

  ''' <summary>
  ''' 指定対象年度ロック中状態取得
  ''' </summary>
  ''' <param name="yearMonth"></param>
  ''' <returns></returns>
  Public Function GetTargetDateInUse(ByVal yearMonth As String) As List(Of YearMonthLockEntity)
    Dim Y = Tables.YearMonthLock

    Dim sqlString As String =
    $"SELECT
          {Y.Year_Month}
        , {Y.Lock_Status}
        , {Y.Lock_User}
        , {Y.Lock_Pc}
        , {Y.Lock_Datetime}
        , {Y.Unlock_User}
        , {Y.Unlock_Pc}
        , {Y.Unlock_Datetime}
        , {Y.Create_Date}
        , {Y.Create_User}
        , {Y.Update_Date}
        , {Y.Update_User}
		  FROM
        {Y.TableName}
		  WHERE 1=1
		    AND {Y.Year_Month} = @{Y.Year_Month}
      " ' SQL String End

    Return ExcuteQuery(Of YearMonthLockEntity)(sqlString.ToString(),
      New SqlParameter() With {.ParameterName = $"@{Y.Year_Month}", .Value = yearMonth}
    )
  End Function
End Class
