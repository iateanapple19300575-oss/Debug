﻿Public Class TableUtil

    ''' <summary>
    ''' スカラー変数名取得
    ''' </summary>
    ''' <param name="columnName">カラム名</param>
    ''' <returns>スカラ変数名</returns>
    Public Shared Function ScalarVariable(ByVal columnName As String) As String
        Return String.Concat("@", columnName)
    End Function

End Class
