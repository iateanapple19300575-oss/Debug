﻿Public Class ValidationRuleResult
    Public Property Priority As Integer
    Public Property StatusCode As Integer
    Public Property IsError As Boolean
    Public Property Level As ValidationLevel
    Public Property Message As String
    Public Property RuleId As String
    Public Function LevelString() As String
        Select Case Level
            Case ValidationLevel.ErrorLevel
                Return "エラー"
            Case ValidationLevel.WarningLevel
                Return "警告"
            Case ValidationLevel.InformationLevel
                Return "情報"
            Case Else
                Return "無効なエラーレベル"
        End Select
    End Function
End Class