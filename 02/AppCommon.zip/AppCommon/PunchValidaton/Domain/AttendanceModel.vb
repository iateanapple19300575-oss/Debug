﻿''' <summary>
''' 勤怠データを表すモデル。
''' 勤怠(出勤/退勤)、出講(開始/終了)、業務届(開始/終了)などのバリデーション対象データを保持する。
''' </summary>
Public Class AttendanceModel

#Region "SQL取得結果"

    ''' <summary>
    ''' 日付
    ''' </summary>
    Public Property LectureDate As DateTime?

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property TeacherCode As String

    ''' <summary>
    ''' 講師名
    ''' </summary>
    Public Property TeacherName As String

    ''' <summary>
    ''' 出勤時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property PunchStartTime As TimeSpan?

    ''' <summary>
    ''' 退勤時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property PunchEndTime As TimeSpan?

    ''' <summary>
    ''' 打刻回数。
    ''' </summary>
    Public Property NumberOfPunched As Byte?

    ''' <summary>
    ''' 打刻修正回数。
    ''' </summary>
    Public Property NumberOfPunchedUpDate As Byte?

    ''' <summary>
    ''' 出講開始時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property LectureStart As TimeSpan?

    ''' <summary>
    ''' 出講終了時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property LectureEnd As TimeSpan?

    ''' <summary>
    ''' 業務届開始時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property TaskStart As TimeSpan?

    ''' <summary>
    ''' 業務届終了時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property TaskEnd As TimeSpan?

    ''' <summary>
    ''' 打刻外業務開始時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property OthersStart As TimeSpan?

    ''' <summary>
    ''' 打刻外業務終了時刻。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property OthersEnd As TimeSpan?

    ''' <summary>
    ''' みなし時間(授業前)。
    ''' </summary>
    Public Property DeemedTimeBefore As TimeSpan?

    ''' <summary>
    ''' みなし時間(授業後)。
    ''' </summary>
    Public Property DeemedTimeAfter As TimeSpan?

    ''' <summary>
    ''' 時間重複(打刻・打刻外業務給)。
    ''' </summary>
    Public Property OverlapOther As Integer?

    ''' <summary>
    ''' 時間重複(出講授業時間)。
    ''' </summary>
    Public Property OverlapLecture As Integer?

    ''' <summary>
    ''' 時間重複(出講・業務届)。
    ''' </summary>
    Public Property OverlapLectTask As Integer?

    ''' <summary>
    ''' 授業給コマ単価(講師別)。
    ''' </summary>
    Public Property LectureUnitPrice As Integer?

    ''' <summary>
    ''' 業務給標準単価。
    ''' 業務給単価(講師別)が未設定の場合に使われる。
    ''' </summary>
    Public Property TaskBaseUnitPrice As Integer?

    ''' <summary>
    ''' 業務給単価(講師別)。
    ''' </summary>
    Public Property TaskUnitPrice As Integer?

#End Region

#Region "Validation結果"

    ''' <summary>
    ''' 実務開始時刻（出講および業務届）。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property WorkStartTime As TimeSpan?

    ''' <summary>
    ''' 実務終了時刻（出講および業務届）。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property WorkEndTime As TimeSpan?

    ''' <summary>
    ''' みなし勤務開始時間。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property DeemedStartTime As TimeSpan?

    ''' <summary>
    ''' みなし勤務終了時間。
    ''' 未入力の場合は Nothing。
    ''' </summary>
    Public Property DeemedEndTime As TimeSpan?

    ''' <summary>
    ''' みなし勤務時間
    ''' </summary>
    ''' <returns></returns>
    Public Property DeemedHours As TimeSpan?

    Public ReadOnly Property DeemedHourTime As Decimal
        Get
            'Dim ts As TimeSpan = TimeSpan.Zero
            'If DeemedHours IsNot Nothing Then
            '    ts = DeemedHours
            'End If
            'Dim totalHours As Double = ts.TotalHours
            'Return Math.Round(totalHours, 2, MidpointRounding.AwayFromZero)
            If DeemedHours Is Nothing Then
                Return Nothing
            End If

            Dim ts As TimeSpan = DeemedHours
            Dim totalHours As Double = ts.TotalHours

            Return Math.Round(totalHours, 2, MidpointRounding.AwayFromZero)
        End Get
    End Property





    ''' <summary>
    ''' 出講タスク詳細情報
    ''' </summary>
    ''' <returns></returns>
    Public Property LectureWorkItems As List(Of LectureWorkItem)

    ''' <summary>
    ''' 業務届タスク詳細情報
    ''' </summary>
    ''' <returns></returns>
    Public Property TaskWorkItems As List(Of TaskWorkItem)

    ''' <summary>
    ''' 打刻外業務給タスク詳細情報
    ''' </summary>
    ''' <returns></returns>
    Public Property OthersWorkItems As List(Of OthersWorkItem)

    ''' <summary>
    ''' 休憩時間。
    ''' </summary>
    Public Property TaskUnBreakTime As TimeSpan?

    ''' <summary>
    ''' 深夜勤務。
    ''' </summary>
    Public Property LateNightShift As TimeSpan?

    ''' <summary>
    ''' バリデーション結果
    ''' </summary>
    ''' <returns></returns>
    Public Property StatusList As New List(Of ValidationRuleResult)

#End Region

#Region "計算項目"

    ''' <summary>
    ''' 授業コマ数
    ''' </summary>
    ''' <returns></returns>
    Public Property LectureCount As Integer

    ''' <summary>
    ''' 報酬日額
    ''' </summary>
    ''' <returns></returns>
    Public Property DailyRewards As Decimal?

    ''' <summary>
    ''' 授業給
    ''' </summary>
    ''' <returns></returns>
    Public Property LectureFee As Decimal?

    ''' <summary>
    ''' 業務給
    ''' </summary>
    ''' <returns></returns>
    Public Property WorkSalary As Decimal?

    ''' <summary>
    ''' 学年毎のコマ回数
    ''' </summary>
    ''' <returns></returns>
    Public Property GradeCount As Integer()


    ''' <summary>
    ''' 1年生コマ回数
    ''' </summary>
    ''' <returns></returns>
    Public Property Grade1Count As Integer?

    ''' <summary>
    ''' 2年生コマ回数
    ''' </summary>
    ''' <returns></returns>
    Public Property Grade2Count As Integer?

    ''' <summary>
    ''' 3年生コマ回数
    ''' </summary>
    ''' <returns></returns>
    Public Property Grade3Count As Integer?

    ''' <summary>
    ''' 4年生コマ回数
    ''' </summary>
    ''' <returns></returns>
    Public Property Grade4Count As Integer?

    ''' <summary>
    ''' 5年生コマ回数
    ''' </summary>
    ''' <returns></returns>
    Public Property Grade5Count As Integer?

    ''' <summary>
    ''' 6年生コマ回数
    ''' </summary>
    ''' <returns></returns>
    Public Property Grade6Count As Integer?

#End Region

#Region "内部処理用"

    ''' <summary>
    ''' ルール内部編集用
    ''' </summary>
    ''' <returns></returns>
    Public Property DailySummary As DailyWorkSummary

#End Region

#Region "その他"

    ''' <summary>
    ''' 出講業務（複数）。
    ''' 1 日に複数の出講が存在する場合に使用する。
    ''' </summary>
    Public Property WorkItems As List(Of WorkItem)

    ''' <summary>
    ''' 業務届作業（複数）。
    ''' 1 日に複数の業務届が存在する場合に使用する。
    ''' </summary>
    Public Property ExtraTasks As List(Of WorkItem)

    ''' <summary>
    ''' 出講業務（複数）。
    ''' 1 日に複数の出講が存在する場合に使用する。
    ''' </summary>
    Public Property KomaInfoItems As List(Of KomaInfoItem)

#End Region

#Region "画面表示用編集結果"

    ''' <summary>
    ''' フォーマット変換した日付文字列
    ''' </summary>
    ''' <returns></returns>
    Public Property DateStr As String

    ''' <summary>
    ''' フィルタ条件キー
    ''' </summary>
    ''' <returns></returns>
    Public Property DateKey As String

    ''' <summary>
    ''' 日付文字色
    ''' </summary>
    ''' <returns></returns>
    Public Property DateColor As String

    ''' <summary>
    ''' 状態
    ''' </summary>
    Public Property StatusStr As String

#End Region

    ''' <summary>
    ''' コンストラクタ。
    ''' リストの初期化を行い、NullReferenceException を防止する。
    ''' </summary>
    Public Sub New()
        WorkItems = New List(Of WorkItem)()
        ExtraTasks = New List(Of WorkItem)()
        KomaInfoItems = New List(Of KomaInfoItem)
    End Sub

End Class