﻿'''' <summary>
'''' 1 日分の労働時間を計算するクラス
'''' </summary>
'Public Class DailySummaryCalculator

'    Public Sub Calculate(models As List(Of AttendanceModel))
'        For Each model As AttendanceModel In models
'            Dim summary As New DailyWorkSummary

'            ' みなし勤務の勤務時間
'            summary.WorkingHours = CalcDeemedWorkTime(model)

'            '実働開始時間
'            summary.WorkStart = CalcWorkStartTime(model)

'            '実働終了時間
'            summary.WorkEnd = CalcWorkEndTime(model)

'            model.DailySummary = summary
'        Next
'    End Sub

'    Public Function Calculate(model As AttendanceModel) As DailyWorkSummary
'        Dim summary As New DailyWorkSummary

'        ' みなし勤務の勤務時間
'        summary.WorkingHours = CalcDeemedWorkTime(model)

'        '実働開始時間
'        summary.WorkStart = CalcWorkStartTime(model)

'        '実働終了時間
'        summary.WorkEnd = CalcWorkEndTime(model)

'        model.DailySummary = summary

'        Return summary
'    End Function

'    ''' <summary>
'    ''' みなし勤務時間の算出
'    ''' </summary>
'    ''' <param name="model"></param>
'    ''' <returns></returns>
'    Private Function CalcDeemedWorkTime(ByVal model As AttendanceModel) As TimeSpan?
'        model.WorkingHours = Nothing
'        If model.DeemedStartTime.HasValue AndAlso model.DeemedEndTime.HasValue Then
'            model.WorkingHours = model.DeemedEndTime - model.DeemedStartTime
'        End If
'        Return model.WorkingHours
'    End Function


'    ''' <summary>
'    ''' 実働開始時間算出
'    ''' </summary>
'    ''' <param name="model"></param>
'    ''' <returns></returns>
'    Private Function CalcWorkStartTime(ByVal model As AttendanceModel) As TimeSpan?

'        model.WorkStartTime = Nothing
'        If Not (model.LectureStart.HasValue AndAlso model.LectureEnd.HasValue) _
'            OrElse (model.TaskStart.HasValue AndAlso model.TaskEnd.HasValue) Then
'            Return Nothing
'        End If

'        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
'            model.WorkStartTime = IIf(model.LectureStart < model.TaskStart, model.LectureStart, model.TaskStart)
'        End If

'        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
'            model.WorkStartTime = model.TaskStart
'        End If

'        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
'            model.WorkStartTime = model.LectureStart
'        End If

'        Return model.WorkStartTime
'    End Function

'    ''' <summary>
'    ''' 実働終了時間算出
'    ''' </summary>
'    ''' <param name="model"></param>
'    ''' <returns></returns>
'    Private Function CalcWorkEndTime(ByVal model As AttendanceModel) As TimeSpan?

'        model.WorkEndTime = Nothing
'        If Not (model.LectureStart.HasValue AndAlso model.LectureEnd.HasValue) _
'            OrElse (model.TaskStart.HasValue AndAlso model.TaskEnd.HasValue) Then
'            Return Nothing
'        End If

'        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
'            model.WorkEndTime = IIf(model.LectureEnd > model.TaskEnd, model.LectureEnd, model.TaskEnd)
'        End If

'        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
'            model.WorkEndTime = model.TaskEnd
'        End If

'        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
'            model.WorkEndTime = model.LectureEnd
'        End If

'        Return model.WorkEndTime
'    End Function
















'    '''' <summary>
'    '''' 1 日分の集計を実行する
'    '''' </summary>
'    'Public Function Calculate(targetDate As Date, model As AttendanceModel) As DailyWorkSummary

'    '    Dim summary As New DailyWorkSummary With {
'    '        .TargetDate = targetDate
'    '    }

'    '    summary.PlannedWorkTime = CalculatePlannedWorkTime(model)
'    '    summary.TotalWorkTime = CalculateActualWorkTime(model)
'    '    summary.BreakTime = CalculateBreakTime(model)
'    '    summary.OverTime = CalculateOverTime(summary)
'    '    summary.DeepNightTime = CalculateDeepNightTime(targetDate, model)

'    '    Return summary

'    'End Function

'    '''' <summary>
'    '''' 出講時間を計算する
'    '''' </summary>
'    'Private Function CalculatePlannedWorkTime(model As AttendanceModel) As TimeSpan
'    '    Dim total As Double = 0

'    '    For Each item In model.LectureItems
'    '        If item.StartTime.HasValue AndAlso item.EndTime.HasValue Then
'    '            Dim st = item.StartTime.Value
'    '            Dim ed = item.EndTime.Value
'    '            If ed < st Then ed = ed.AddDays(1)
'    '            total += (ed - st).TotalMinutes
'    '        End If
'    '    Next

'    '    Return TimeSpan.FromMinutes(total)
'    'End Function

'    '''' <summary>
'    '''' 実績労働時間を計算する
'    '''' </summary>
'    'Private Function CalculateActualWorkTime(model As AttendanceModel) As TimeSpan
'    '    Dim total As Double = 0

'    '    For Each item In model.WorkItems
'    '        If item.StartTime.HasValue AndAlso item.EndTime.HasValue Then
'    '            Dim st = item.StartTime.Value
'    '            Dim ed = item.EndTime.Value
'    '            If ed < st Then ed = ed.AddDays(1)
'    '            total += (ed - st).TotalMinutes
'    '        End If
'    '    Next

'    '    Return TimeSpan.FromMinutes(total)
'    'End Function

'    '''' <summary>
'    '''' 休憩時間を計算する
'    '''' </summary>
'    'Private Function CalculateBreakTime(model As AttendanceModel) As TimeSpan
'    '    Dim total As Double = 0

'    '    For Each item In model.ExtraTasks
'    '        If item.StartTime.HasValue AndAlso item.EndTime.HasValue Then
'    '            Dim st = item.StartTime.Value
'    '            Dim et = item.EndTime.Value
'    '            If et < st Then
'    '                et = et.AddDays(1)
'    '            End If
'    '            total += (et - st).TotalMinutes
'    '        End If
'    '    Next

'    '    Return TimeSpan.FromMinutes(total)
'    'End Function

'    '''' <summary>
'    '''' 残業時間を計算する
'    '''' </summary>
'    'Private Function CalculateOverTime(summary As DailyWorkSummary) As TimeSpan
'    '    Dim diff = summary.TotalWorkTime - summary.PlannedWorkTime
'    '    If diff.TotalMinutes > 0 Then
'    '        Return diff
'    '    Else
'    '        Return TimeSpan.Zero
'    '    End If
'    'End Function

'    '''' <summary>
'    '''' 深夜残業（22:00～翌5:00）を計算する
'    '''' </summary>
'    'Private Function CalculateDeepNightTime(targetDate As Date, model As AttendanceModel) As TimeSpan

'    '    Dim total As Double = 0

'    '    Dim nightStart As DateTime = targetDate.Date.AddHours(22)
'    '    Dim nightEnd As DateTime = targetDate.Date.AddDays(1).AddHours(5)

'    '    For Each item In model.WorkItems
'    '        If item.StartTime.HasValue AndAlso item.EndTime.HasValue Then

'    '            Dim st = item.StartTime.Value
'    '            Dim et = item.EndTime.Value
'    '            If et < st Then
'    '                et = et.AddDays(1)
'    '            End If

'    '            Dim overlapStart = If(st > nightStart, st, nightStart)
'    '            Dim overlapEnd = If(et < nightEnd, et, nightEnd)

'    '            If overlapEnd > overlapStart Then
'    '                total += (overlapEnd - overlapStart).TotalMinutes
'    '            End If

'    '        End If
'    '    Next

'    '    Return TimeSpan.FromMinutes(total)

'    'End Function

'End Class