﻿''' <summary>
''' 打刻時間、データ取込の時間を元に各種時間を算出する。
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(1)>
Public Class CalcWorkTimeRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D014"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    ''' <summary>
    ''' 出講（開始・終了）時間、業務届（開始・終了）時間、みなし（授業前後）時間を元に
    ''' 以下の時間を求める。
    ''' 実務の最小開始時間（出講と業務の最小開始時間）
    ''' 実務の最大終了時間（出講と業務の最大終了時間）
    ''' みなし勤務の最小開始時間（出講：みなし時間あり。業務届：みなし時間なし）
    ''' みなし勤務の最大終了時間（出講」みなし時間あり。業務届：みなし時間なし）
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate
        Try
            ' 実務開始時間
            model.WorkStartTime = CalcScheduleStartTime(model)
            ' 実務終了時間
            model.WorkEndTime = CalcScheduleEndTime(model)
            ' みなし開始時間
            model.DeemedStartTime = CalcDeemedTimeStart(model)
            ' みなし開始時間
            model.DeemedEndTime = CalcDeemedTimeEnd(model)
            ' みなし勤務時間
            model.DeemedHours = CalcDeemedWorkTime(model)

        Catch ex As Exception

        End Try

        Return Nothing
    End Function

    ''' <summary>
    ''' 実務開始時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleStartTime(model As AttendanceModel) As TimeSpan?

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.WorkStartTime = model.LectureStart
            Else
                model.WorkStartTime = model.TaskStart
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.WorkStartTime = model.TaskStart
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.WorkStartTime = model.LectureStart
        End If

        Return model.WorkStartTime
    End Function

    ''' <summary>
    ''' 実務終了時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleEndTime(model As AttendanceModel) As TimeSpan?

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.WorkEndTime = model.LectureEnd
            Else
                model.WorkEndTime = model.TaskEnd
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.WorkEndTime = model.TaskEnd
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.WorkEndTime = model.LectureEnd
        End If

        Return model.WorkEndTime
    End Function

    ''' <summary>
    ''' みなし開始時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeStart(model As AttendanceModel) As TimeSpan?

        'If Not model.PunchStartTime.HasValue Then
        '    Return Nothing
        'End If

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.DeemedStartTime = model.LectureStart - model.DeemedTimeBefore
            Else
                model.DeemedStartTime = model.TaskStart
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.DeemedStartTime = model.TaskStart
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.DeemedStartTime = model.LectureStart - model.DeemedTimeBefore
        End If

        Return model.DeemedStartTime
    End Function

    ''' <summary>
    ''' みなし終了時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeEnd(model As AttendanceModel) As TimeSpan?

        'If Not model.PunchEndTime.HasValue Then
        '    Return Nothing
        'End If

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.DeemedEndTime = model.LectureEnd + model.DeemedTimeAfter
            Else
                model.DeemedEndTime = model.TaskEnd
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.TaskEnd
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.LectureEnd + model.DeemedTimeAfter
        End If

        Return model.DeemedEndTime
    End Function

    ''' <summary>
    ''' みなし勤務時間の算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Private Function CalcDeemedWorkTime(model As AttendanceModel) As TimeSpan?
        model.DeemedHours = Nothing
        If model.DeemedStartTime.HasValue AndAlso model.DeemedEndTime.HasValue Then
            model.DeemedHours = model.DeemedEndTime - model.DeemedStartTime
        End If
        Return model.DeemedHours
    End Function

End Class
