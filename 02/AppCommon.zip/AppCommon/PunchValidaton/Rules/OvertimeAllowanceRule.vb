﻿''' <summary>
''' 退勤後に業務が終了している場合の警告
''' </summary>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(7)>
Public Class OvertimeAllowanceRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D3030"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Dim ts As TimeSpan
        Dim overHour As Integer = 0

        If model.PunchStartTime.HasValue AndAlso model.PunchEndTime.HasValue Then
            ts = model.PunchEndTime - model.PunchStartTime
            overHour = IIf(ts.Hours > (140 * 60), ts.Hours - (140 * 60), 0)
            Dim orverTime As TimeSpan = TimeSpan.FromMinutes(overHour)

            If overHour > 0 Then
                Return New ValidationRuleResult With {
                    .Priority = PunchValidatePriority.OvertimeAllowanceRule,
                    .IsError = False,
                    .Level = ValidationLevel.InformationLevel,
                    .Message = "残業手当発生(" & orverTime.Hours & "時間" & orverTime.Minutes & "分)",
                    .RuleId = Me.RuleId
                }
            End If
        End If

        Return Nothing
    End Function

End Class
