﻿
Public Enum PunchValidatePriority As Integer
    ''' <summary>打刻なし(出勤)</summary>
    ClockInRequiredRule = 1010
    ''' <summary>打刻なし(退勤)</summary>
    ClockOutRequiredRule = 1020
    ''' <summary>打刻なし(出勤・退勤)</summary>
    ClockInClockOutRule = 1030
    ''' <summary>時間重複(ジョブカン打刻・打刻外業務給)</summary>
    PunchAndNoPunchTaskOverlapRule = 1040
    ''' <summary>時間重複(複数授業)</summary>
    WorkOverlapRule = 1050
    ''' <summary>講師単価未登録</summary>
    InstructorUnitPriceRule = 1060

    ''' <summary>時間重複(授業時間・業務届)</summary>
    WorkAndTaskOverlapRule = 2010
    ''' <summary>交通費未登録区間あり(AA)</summary>
    TranspExpensesRule = 2020
    ''' <summary>授業遅刻(20分)</summary>
    WorkLeavingEarlyRule = 2030
    ''' <summary>授業早退(20分)</summary>
    WorkBehindTimeRule = 2040
    ''' <summary>出勤早(20分)</summary>
    WorkTooEarlyRule = 2050
    ''' <summary>退勤遅(20分)</summary>
    WorkTooLateRule = 2060
    ''' <summary>出講・業務届なし</summary>
    NoWorkItemsRule = 2070
    ''' <summary>打刻回数3回以上</summary>
    NumberOfPunchedRule = 2080

    ''' <summary>休憩発生(60分)</summary>
    BreakTimeRule = 3010
    ''' <summary>深夜勤務発生(30分)</summary>
    LateNightShiftRule = 3020
    ''' <summary>残業手当発生(1時間10分)</summary>
    OvertimeAllowanceRule = 3030
    ''' <summary>授業給係数発生(1.65倍)EA6年A1クラス</summary>
    LectureCoefficientRule = 3040
End Enum
