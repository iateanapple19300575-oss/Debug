﻿''' <summary>
''' 深夜勤務発生の場合の情報
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(13)>
Public Class LateNightShiftRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D3020"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        model.LateNightShift = Nothing

        ' 打刻が不完全場合はチェックしない
        If Not model.PunchStartTime.HasValue OrElse Not model.PunchEndTime.HasValue Then
            Return Nothing
        End If

        If model.PunchStartTime.HasValue AndAlso model.PunchEndTime.HasValue Then
            Dim startTime As New TimeSpan(22, 0, 0)
            Dim endTime As New TimeSpan(5, 0, 0)
            Dim totalTime As TimeSpan = TimeSpan.Zero
            Dim tsWork As TimeSpan

            ' 深夜時間外（5時～22時）勤務の場合、チェックしない
            If endTime <= model.PunchStartTime AndAlso startTime >= model.PunchEndTime Then
                Return Nothing
            End If

            totalTime = TimeSpan.Zero

            ' 5:00 > 出勤打刻 
            If endTime > model.PunchStartTime Then
                ' 5:00 > 退勤打刻
                If endTime > model.PunchEndTime Then
                    ' 深夜勤務 = 退勤打刻 - 出勤打刻 
                    tsWork = (model.PunchEndTime - model.PunchStartTime)
                    totalTime += tsWork
                Else
                    ' 深夜勤務 = 5:00 - 出勤打刻
                    tsWork = (endTime - model.PunchStartTime)
                    totalTime += tsWork
                End If
            End If

            ' 22:00 < 退勤打刻 
            If startTime <= model.PunchEndTime Then
                ' 22:00 < 出勤打刻 
                If startTime <= model.PunchStartTime Then
                    ' 深夜勤務 = 退勤打刻 - 出勤打刻 
                    tsWork = model.PunchEndTime - model.PunchStartTime
                    totalTime += tsWork
                Else
                    ' 深夜勤務 = 退勤打刻 - 22:00
                    tsWork = model.PunchEndTime - startTime
                    totalTime += tsWork
                End If
            End If

            If totalTime > TimeSpan.Zero Then
                model.LateNightShift = totalTime
            End If

            If model.LateNightShift > TimeSpan.Zero Then
                totalTime = model.LateNightShift
                Return New ValidationRuleResult With {
                            .Priority = PunchValidatePriority.LateNightShiftRule,
                            .IsError = False,
                            .Level = ValidationLevel.InformationLevel,
                            .Message = "深夜勤務発生(" & String.Format("{0:0}", totalTime.TotalMinutes) & "分)",
                            .RuleId = Me.RuleId
                        }
            End If
        End If

        Return Nothing
    End Function

End Class
