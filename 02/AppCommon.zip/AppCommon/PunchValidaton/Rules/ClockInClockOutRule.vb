﻿''' <summary>
''' 出勤時刻と退勤時刻の両方が入力されていない場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(1)>
Public Class ClockInClockOutRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1030"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.PunchStartTime.HasValue AndAlso Not model.PunchEndTime.HasValue AndAlso
            (model.LectureStart.HasValue OrElse model.LectureEnd.HasValue OrElse
             model.TaskStart.HasValue OrElse model.TaskEnd.HasValue) Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.ClockInClockOutRule,
                .IsError = True,
                .Level = ValidationLevel.ErrorLevel,
                .Message = "打刻なし(出勤・退勤)",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

End Class