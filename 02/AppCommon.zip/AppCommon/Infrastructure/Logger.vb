﻿Imports System.Data.SqlClient

Public Class Logger
  Inherits TransactionBase

  Private Const LOG_BUSINESS_CODE As String = "GH"
	Private Const LOG_PROCESS_CODE As String = "GHRUN02"

	' 端末名
	Public Property HostName As String

	' ユーザID
	Public Property UserId As String

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 操作ログ
    ''' </summary>
    ''' <param name="procName"></param>
    ''' <param name="message"></param>
    Public Sub WriteProcessLog(ByRef procName As String, ByRef message As String)
		WriteLog(procName, message)
	End Sub

	''' <summary>
	''' SQLログ
	''' </summary>
	''' <param name="procName"></param>
	''' <param name="cmd"></param>
	Public Sub WriteQueryLog(ByRef procName As String, ByVal cmd As SqlCommand)
		Dim sqlStr As String = SqlUtil.GetCommandTextWithParameters(cmd)
		WriteLog(procName, "SQL:" & sqlStr)
	End Sub

	''' <summary>
	''' 操作ログ（エラー）
	''' </summary>
	''' <param name="procName"></param>
	''' <param name="message"></param>
	Public Sub WriteErrorLog(ByRef procName As String, ByRef message As String)
		WriteLog(procName, "ERROR:" & message)
	End Sub

	''' <summary>
	''' 
	''' </summary>
	''' <param name="procName"></param>
	''' <param name="message"></param>
	''' <remarks></remarks>
	Public Shared Function WriteLog(ByRef procName As String, ByRef message As String) As ResultData

		'' [処理名]桁あふれ対策
		'Dim writeProcName As String
		'writeProcName = Mid(procName, 1, 40)

		'' [内容]桁あふれ対策
		'Dim writeComment As String
		'writeComment = message.Replace(vbCrLf, "")
		'writeComment = writeComment.Replace("'", "''")
		'writeComment = Mid(writeComment, 1, 100)

		'Dim sqlString As New System.Text.StringBuilder
		'sqlString.Length = 0
		'sqlString.Append("INSERT INTO" & " ")
		'sqlString.Append("    " & DBTableConst.TABLE_NAME_LECTURES_CALC_LOG & " ")
		'sqlString.Append("SELECT" & " ")
		'sqlString.Append("    CONVERT(NVARCHAR, GETDATE(), 112)                     As [年月日]" & " ")
		'sqlString.Append("    , REPLACE(CONVERT(varchar(8), GETDATE(), 8), ':', '') As [日時]" & " ")
		'sqlString.Append("    , '" & writeProcName & "'                             As [処理名]" & " ")
		'sqlString.Append("    , '" & writeComment & "'                              As [内容]" & " ")
		'sqlString.Append("    , '" & Environment.UserName & "'                      As [処理実行者]" & " ")
		'sqlString.Append("    , '" & LOG_PROCESS_CODE & "'                          As [処理コード]" & " ")
		'sqlString.Append("    , '" & My.Application.Info.AssemblyName & "'          As [処理プログラム]" & " ")
		'sqlString.Append("    , '" & LOG_BUSINESS_CODE & "'                         As [業務コード]" & " ")
		'sqlString.Append("    , '" & Environment.MachineName & "'                   As [処理PC]" & " ")

		Dim result As New ResultData

		'Try
		'	Dim tran As New TranBase
		'	result = tran.ExcuteNonQuery(sqlString.ToString())

		'Catch ex As SqlException
		'	result.Success = False
		'	result.ErrorCode = ex.Number
		'	result.ErrorDescription = ex.Message
		'	result.ExceptionEx = ex
		'	Throw

		'Catch ex As Exception
		'	result.Success = False
		'	result.ErrorDescription = ex.Message
		'	result.ExceptionEx = ex
		'	Throw

		'Finally

		'End Try

		Return result

	End Function

End Class
