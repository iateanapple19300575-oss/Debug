﻿-----------------------------------------------------------------------
-- グループView
-- 企業種別が１のグループ名称を参照する。
-----------------------------------------------------------------------
CREATE OR ALTER VIEW VM_Group AS 

SELECT
    Corporate_KND COLLATE Japanese_CS_AS_KS_WS As Corporate_KND
    , Division_KND COLLATE Japanese_CS_AS_KS_WS As Division_KND
    , Division_Name COLLATE Japanese_CS_AS_KS_WS As Division_Name
FROM
    [LECTPAY].[dbo].[MNSPM10] 
WHERE
    Corporate_KND = '1'
