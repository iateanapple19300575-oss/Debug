﻿CREATE OR ALTER VIEW [dbo].[MNSPM10]
AS
SELECT
     Corporate_KND COLLATE Japanese_CS_AS_KS_WS As Corporate_KND
    ,Division_KND COLLATE Japanese_CS_AS_KS_WS As Division_KND
    ,Division_Name COLLATE Japanese_CS_AS_KS_WS As Division_Name
FROM MNS.dbo.MNSPM10
GO
