﻿-----------------------------------------------------------------------
-- 教室名称View
-----------------------------------------------------------------------
CREATE OR ALTER VIEW VM_Site AS 

SELECT
    M10.Corporate_KND COLLATE Japanese_CS_AS_KS_WS As Corporate_KND
    , M11.Division_KND COLLATE Japanese_CS_AS_KS_WS As Division_KND
    , M11.Site_Code COLLATE Japanese_CS_AS_KS_WS As Site_Code
	, REPLACE (NS.Site_Name, '　', '') COLLATE Japanese_CS_AS_KS_WS As Site_Name
	, CONCAT(NS.Site_Code, '：', REPLACE (NS.Site_Name, '　', '') COLLATE Japanese_CS_AS_KS_WS) As Site_Name2
FROM
    [LECTPAY].[dbo].[MNSPM10] M10 
    LEFT JOIN [LECTPAY].[dbo].[MNSPM11] M11 
        ON ( 
            M10.Corporate_KND = M11.Corporate_KND 
            AND M10.Division_KND = M11.Division_KND
        ) 
    LEFT JOIN [LECTPAY].[dbo].[ntb_Site] NS 
        ON ( 
            M11.Site_Code = NS.Site_Code COLLATE Japanese_CS_AS_KS_WS
        )
