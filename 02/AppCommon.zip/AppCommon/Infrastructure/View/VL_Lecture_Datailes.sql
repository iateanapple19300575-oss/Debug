﻿CREATE OR ALTER VIEW VL_Lecture_Details AS

WITH StaffDates AS (
    SELECT Lecture_Date, Teacher_Code FROM W_Lecture_Actual
    UNION
    SELECT Lecture_Date, Teacher_Code FROM W_Business_Actual
    UNION
    SELECT Lecture_Date, Teacher_Code FROM W_Business_No_Punch
    UNION
    SELECT Lecture_Date, Staff_Code As Teacher_Code FROM W_Stamp_Data
),

-- A/B/C の行番号付け（開始時間昇順）
ARows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY Lecture_Date, Teacher_Code ORDER BY Start_Time) AS RN
    FROM W_Lecture_Actual WHERE Phase=2 And Data_Type=1
),
BRows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY Lecture_Date, Teacher_Code ORDER BY Start_Time) AS RN
    FROM W_Business_Actual
),
CRows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY Lecture_Date, Teacher_Code ORDER BY Start_Time) AS RN
    FROM W_Business_No_Punch
),

-- A/B/C の最小開始・最大終了
AMinMax AS (
    SELECT Lecture_Date, Teacher_Code, 
           MIN(Start_Time) AS AMinStart,
           MAX(End_Time)   AS AMaxEnd
    FROM W_Lecture_Actual GROUP BY Teacher_Code, Lecture_Date
),
BMinMax AS (
    SELECT Lecture_Date, Teacher_Code, 
           MIN(Start_Time) AS BMinStart,
           MAX(End_Time)   AS BMaxEnd
    FROM W_Business_Actual GROUP BY Teacher_Code, Lecture_Date
),
CMinMax AS (
    SELECT Lecture_Date, Teacher_Code, 
           MIN(Start_Time) AS CMinStart,
           MAX(End_Time)   AS CMaxEnd
    FROM W_Business_No_Punch GROUP BY Teacher_Code, Lecture_Date
),

--
Coefficient AS (
    SELECT
        Year
        , Half_Year
        , Site_Code
        , Grade
        , Class_Code
        , Lecture_Coefficient
        , Remarks
    FROM
        M_Lecture_Wage_Percentage 
    WHERE
        1 = 1 
        AND Year = '2025'
        AND Half_Year = 1
),


-- A/B/C の横展開（最大 10 件）
AExpanded AS (
    SELECT 
        r.Lecture_Date As A_Lecture_Date, 
        r.Teacher_Code As A_Teacher_Code,
        MAX(CASE WHEN RN=1 THEN r.Site_Code END) AS 出講教室1,
        MAX(CASE WHEN RN=1 THEN r.Grade END) AS 出講学年1,
        MAX(CASE WHEN RN=1 THEN r.Class_Code END) AS 出講クラス1,
        MAX(CASE WHEN RN=1 THEN r.Koma_Seq END) AS 出講コマ1,
        MAX(CASE WHEN RN=1 THEN r.Pinch_Type END) AS 出講ピンチ1,
        MAX(CASE WHEN RN=1 THEN r.Start_Time END) AS 出講開始1,
        MAX(CASE WHEN RN=1 THEN r.End_Time END) AS 出講終了1,
        MAX(CASE WHEN RN=1 THEN cf.Lecture_Coefficient END) AS 授業給係数1,
        MAX(CASE WHEN RN=1 THEN te.Amount END) AS 交通費1,
        MAX(CASE WHEN RN=2 THEN r.Site_Code END) AS 出講教室2,
        MAX(CASE WHEN RN=2 THEN r.Grade END) AS 出講学年2,
        MAX(CASE WHEN RN=2 THEN r.Class_Code END) AS 出講クラス2,
        MAX(CASE WHEN RN=2 THEN r.Koma_Seq END) AS 出講コマ2,
        MAX(CASE WHEN RN=2 THEN r.Pinch_Type END) AS 出講ピンチ2,
        MAX(CASE WHEN RN=2 THEN r.Start_Time END) AS 出講開始2,
        MAX(CASE WHEN RN=2 THEN r.End_Time END) AS 出講終了2,
        MAX(CASE WHEN RN=2 THEN cf.Lecture_Coefficient END) AS 授業給係数2,
        MAX(CASE WHEN RN=2 THEN te.Amount END) AS 交通費2,
        MAX(CASE WHEN RN=3 THEN r.Site_Code END) AS 出講教室3,
        MAX(CASE WHEN RN=3 THEN r.Grade END) AS 出講学年3,
        MAX(CASE WHEN RN=3 THEN r.Class_Code END) AS 出講クラス3,
        MAX(CASE WHEN RN=3 THEN r.Koma_Seq END) AS 出講コマ3,
        MAX(CASE WHEN RN=3 THEN r.Pinch_Type END) AS 出講ピンチ3,
        MAX(CASE WHEN RN=3 THEN r.Start_Time END) AS 出講開始3,
        MAX(CASE WHEN RN=3 THEN r.End_Time END) AS 出講終了3,
        MAX(CASE WHEN RN=3 THEN cf.Lecture_Coefficient END) AS 授業給係数3,
        MAX(CASE WHEN RN=3 THEN te.Amount END) AS 交通費3,
        MAX(CASE WHEN RN=4 THEN r.Site_Code END) AS 出講教室4,
        MAX(CASE WHEN RN=4 THEN r.Grade END) AS 出講学年4,
        MAX(CASE WHEN RN=4 THEN r.Class_Code END) AS 出講クラス4,
        MAX(CASE WHEN RN=4 THEN r.Koma_Seq END) AS 出講コマ4,
        MAX(CASE WHEN RN=4 THEN r.Pinch_Type END) AS 出講ピンチ4,
        MAX(CASE WHEN RN=4 THEN r.Start_Time END) AS 出講開始4,
        MAX(CASE WHEN RN=4 THEN r.End_Time END) AS 出講終了4,
        MAX(CASE WHEN RN=4 THEN cf.Lecture_Coefficient END) AS 授業給係数4,
        MAX(CASE WHEN RN=4 THEN te.Amount END) AS 交通費4,
        MAX(CASE WHEN RN=5 THEN r.Site_Code END) AS 出講教室5,
        MAX(CASE WHEN RN=5 THEN r.Grade END) AS 出講学年5,
        MAX(CASE WHEN RN=5 THEN r.Class_Code END) AS 出講クラス5,
        MAX(CASE WHEN RN=5 THEN r.Koma_Seq END) AS 出講コマ5,
        MAX(CASE WHEN RN=5 THEN r.Pinch_Type END) AS 出講ピンチ5,
        MAX(CASE WHEN RN=5 THEN r.Start_Time END) AS 出講開始5,
        MAX(CASE WHEN RN=5 THEN r.End_Time END) AS 出講終了5,
        MAX(CASE WHEN RN=5 THEN cf.Lecture_Coefficient END) AS 授業給係数5,
        MAX(CASE WHEN RN=5 THEN te.Amount END) AS 交通費5,
        MAX(CASE WHEN RN=6 THEN r.Site_Code END) AS 出講教室6,
        MAX(CASE WHEN RN=6 THEN r.Grade END) AS 出講学年6,
        MAX(CASE WHEN RN=6 THEN r.Class_Code END) AS 出講クラス6,
        MAX(CASE WHEN RN=6 THEN r.Koma_Seq END) AS 出講コマ6,
        MAX(CASE WHEN RN=6 THEN r.Pinch_Type END) AS 出講ピンチ6,
        MAX(CASE WHEN RN=6 THEN r.Start_Time END) AS 出講開始6,
        MAX(CASE WHEN RN=6 THEN r.End_Time END) AS 出講終了6,
        MAX(CASE WHEN RN=6 THEN cf.Lecture_Coefficient END) AS 授業給係数6,
        MAX(CASE WHEN RN=6 THEN te.Amount END) AS 交通費6

    FROM ARows r

        OUTER APPLY (
           SELECT
                Year
                , Half_Year
                , Site_Code
                , Grade
                , Class_Code
                , Lecture_Coefficient
                , Remarks
            FROM
                M_Lecture_Wage_Percentage 
            WHERE
                Year = Year(r.Lecture_Date)
                AND Half_Year = (CASE WHEN Month(r.Lecture_Date) < 2 THEN 2 ELSE 1 END)
                AND r.Grade = Grade
                AND SUBSTRING(r.Class_Code, 1, 1) = Class_Code
                AND (
                    (Site_Code != 'ZZ' AND r.Site_Code = Site_Code)
                    OR (Site_Code = 'ZZ')
                )
            ) cf
 
        OUTER APPLY (
            SELECT TOP 1
                Amount
                , Effective_Date
                , Teacher_Code
                , Site_Code
            FROM 
                M_Transpo_Expenses
            WHERE
                Effective_Date <= r.Lecture_Date
                AND Teacher_Code = r.Teacher_Code
                AND Site_Code = r.Site_Code
            ORDER BY
                Effective_Date DESC
        ) te
    GROUP BY r.Lecture_Date, r.Teacher_Code
),
BExpanded AS (
    SELECT 
        Lecture_Date As B_Lecture_Date, 
        Teacher_Code As B_Teacher_Code,
        MAX(CASE WHEN RN=1 THEN Site_Code END) AS 業務教室1,
        MAX(CASE WHEN RN=1 THEN Start_Time END) AS 業務開始1,
        MAX(CASE WHEN RN=1 THEN End_Time END) AS 業務終了1,
        MAX(CASE WHEN RN=2 THEN Site_Code END) AS 業務教室2,
        MAX(CASE WHEN RN=2 THEN Start_Time END) AS 業務開始2,
        MAX(CASE WHEN RN=2 THEN End_Time END) AS 業務終了2,
        MAX(CASE WHEN RN=3 THEN Site_Code END) AS 業務教室3,
        MAX(CASE WHEN RN=3 THEN Start_Time END) AS 業務開始3,
        MAX(CASE WHEN RN=3 THEN End_Time END) AS 業務終了3,
        MAX(CASE WHEN RN=4 THEN Site_Code END) AS 業務教室4,
        MAX(CASE WHEN RN=4 THEN Start_Time END) AS 業務開始4,
        MAX(CASE WHEN RN=4 THEN End_Time END) AS 業務終了4,
        MAX(CASE WHEN RN=5 THEN Site_Code END) AS 業務教室5,
        MAX(CASE WHEN RN=5 THEN Start_Time END) AS 業務開始5,
        MAX(CASE WHEN RN=5 THEN End_Time END) AS 業務終了5,
        MAX(CASE WHEN RN=6 THEN Site_Code END) AS 業務教室6,
        MAX(CASE WHEN RN=6 THEN Start_Time END) AS 業務開始6
    FROM BRows
    GROUP BY Lecture_Date, Teacher_Code
),
CExpanded AS (
    SELECT 
        Lecture_Date As C_Lecture_Date, 
        Teacher_Code As C_Teacher_Code,
        MAX(CASE WHEN RN=1 THEN Site_Code END) AS 打刻外教室1,
        MAX(CASE WHEN RN=1 THEN Start_Time END) AS 打刻外開始1,
        MAX(CASE WHEN RN=1 THEN End_Time END) AS 打刻外終了1,
        MAX(CASE WHEN RN=2 THEN Site_Code END) AS 打刻外教室2,
        MAX(CASE WHEN RN=2 THEN Start_Time END) AS 打刻外開始2,
        MAX(CASE WHEN RN=2 THEN End_Time END) AS 打刻外終了2,
        MAX(CASE WHEN RN=3 THEN Site_Code END) AS 打刻外教室3,
        MAX(CASE WHEN RN=3 THEN Start_Time END) AS 打刻外開始3,
        MAX(CASE WHEN RN=3 THEN End_Time END) AS 打刻外終了3,
        MAX(CASE WHEN RN=4 THEN Site_Code END) AS 打刻外教室4,
        MAX(CASE WHEN RN=4 THEN Start_Time END) AS 打刻外開始4,
        MAX(CASE WHEN RN=4 THEN End_Time END) AS 打刻外終了4,
        MAX(CASE WHEN RN=5 THEN Site_Code END) AS 打刻外教室5,
        MAX(CASE WHEN RN=5 THEN Start_Time END) AS 打刻外開始5,
        MAX(CASE WHEN RN=5 THEN End_Time END) AS 打刻外終了5,
        MAX(CASE WHEN RN=6 THEN Site_Code END) AS 打刻外教室6,
        MAX(CASE WHEN RN=6 THEN Start_Time END) AS 打刻外開始6,
        MAX(CASE WHEN RN=6 THEN End_Time END) AS 打刻外終了6
    FROM CRows
    GROUP BY Lecture_Date, Teacher_Code
),

-- 重複件数＋重複 ID（CSV）
OverlapDetails AS (
    SELECT
        s.Lecture_Date,
        s.Teacher_Code,

        -- A-A
        (SELECT COUNT(*) FROM W_Lecture_Actual a1 JOIN W_Lecture_Actual a2
         ON a1.Teacher_Code=s.Teacher_Code AND a2.Teacher_Code=s.Teacher_Code
        AND a1.Lecture_Date=s.Lecture_Date AND a2.Lecture_Date=s.Lecture_Date
        AND a1.Phase='2' AND a2.Phase='2'
        AND a1.Data_Type=1 AND a2.Data_Type=1
        AND a1.Id<a2.Id AND a1.Start_Time<a2.End_Time AND a1.End_Time>a2.Start_Time) AS CntAA,

        -- B-B
        (SELECT COUNT(*) FROM W_Business_Actual b1 JOIN W_Business_Actual b2
         ON b1.Teacher_Code=s.Teacher_Code AND b2.Teacher_Code=s.Teacher_Code
        AND b1.Lecture_Date=s.Lecture_Date AND b2.Lecture_Date=s.Lecture_Date
        AND b1.Id<b2.Id AND b1.Start_Time<b2.End_Time AND b1.End_Time>b2.Start_Time) AS CntBB,

        -- C-C
        (SELECT COUNT(*) FROM W_Business_No_Punch c1 JOIN W_Business_No_Punch c2
         ON c1.Teacher_Code=s.Teacher_Code AND c2.Teacher_Code=s.Teacher_Code
        AND c1.Lecture_Date=s.Lecture_Date AND c2.Lecture_Date=s.Lecture_Date
        AND c1.Id<c2.Id AND c1.Start_Time<c2.End_Time AND c1.End_Time>c2.Start_Time) AS CntCC,

        -- A-B
        (SELECT COUNT(*) FROM W_Lecture_Actual a JOIN W_Business_Actual b
         ON a.Teacher_Code=s.Teacher_Code AND b.Teacher_Code=s.Teacher_Code
        AND a.Lecture_Date=s.Lecture_Date AND b.Lecture_Date=s.Lecture_Date
        AND a.Start_Time<b.End_Time AND a.End_Time>b.Start_Time) AS CntAB,

        -- A-C
        (SELECT COUNT(*) FROM W_Lecture_Actual a JOIN W_Business_No_Punch c
         ON a.Teacher_Code=s.Teacher_Code AND c.Teacher_Code=s.Teacher_Code
        AND a.Lecture_Date=s.Lecture_Date AND c.Lecture_Date=s.Lecture_Date
        AND a.Start_Time<c.End_Time AND a.End_Time>c.Start_Time) AS CntAC,

        -- B-C
        (SELECT COUNT(*) FROM W_Business_Actual b JOIN W_Business_No_Punch c
         ON b.Teacher_Code=s.Teacher_Code AND c.Teacher_Code=s.Teacher_Code
        AND b.Lecture_Date=s.Lecture_Date AND c.Lecture_Date=s.Lecture_Date
        AND b.Start_Time<c.End_Time AND b.End_Time>c.Start_Time) AS CntBC,

        -- M-C
        (SELECT COUNT(*) FROM W_Stamp_Data m JOIN W_Business_No_Punch c
         ON m.Staff_Code=s.Teacher_Code AND c.Teacher_Code=s.Teacher_Code
        AND m.Lecture_Date=s.Lecture_Date AND c.Lecture_Date=s.Lecture_Date
        AND m.Start_Time<c.End_Time AND m.End_Time>c.Start_Time) AS CntMC

    FROM StaffDates s
),

MainCheck AS (
    SELECT
        s.Lecture_Date,
        s.Teacher_Code,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1   -- 主テーブルが無い日は NG
            WHEN EXISTS (
                SELECT 1 FROM W_Lecture_Actual a
                WHERE a.Lecture_Date = s.Lecture_Date
                  AND a.Teacher_Code = s.Teacher_Code
                  AND a.Start_Time < m.Start_Time
            ) THEN 1 ELSE 0 
        END AS ABeforeStart,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Lecture_Actual a
                WHERE a.Lecture_Date = s.Lecture_Date
                  AND a.Teacher_Code = s.Teacher_Code
                  AND a.End_Time > m.End_Time
            ) THEN 1 ELSE 0 
        END AS AAfterEnd,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_Actual b
                WHERE b.Lecture_Date = s.Lecture_Date
                  AND b.Teacher_Code = s.Teacher_Code
                  AND b.Start_Time < m.Start_Time
            ) THEN 1 ELSE 0 
        END AS BBeforeStart,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_Actual b
                WHERE b.Lecture_Date = s.Lecture_Date
                  AND b.Teacher_Code = s.Teacher_Code
                  AND b.End_Time > m.End_Time
            ) THEN 1 ELSE 0 
        END AS BAfterEnd,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_No_Punch c
                WHERE c.Lecture_Date = s.Lecture_Date
                  AND c.Teacher_Code = s.Teacher_Code
                  AND c.Start_Time < m.Start_Time
            ) THEN 1 ELSE 0 
        END AS CBeforeStart,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_No_Punch c
                WHERE c.Lecture_Date = s.Lecture_Date
                  AND c.Teacher_Code = s.Teacher_Code
                  AND c.End_Time > m.End_Time
            ) THEN 1 ELSE 0 
        END AS CAfterEnd

    FROM StaffDates s
    LEFT JOIN W_Stamp_Data m
        ON m.Staff_Code = s.Teacher_Code
       AND m.Lecture_Date = s.Lecture_Date
),
Teacher AS (
  SELECT
    講師コード As Teacher_Code
    , 講師名 As Teacher_Name
  FROM
    TeacherRegistry
  WHERE
    登録区分 IS NULL
)

SELECT
    s.Lecture_Date As Lecture_Date
    , s.Teacher_Code As Teacher_Code
    , mt.Teacher_Name As Teacher_Name

    -- 主テーブル
    , m.Start_Time AS 出勤時刻
    , m.End_Time   AS 退勤時刻

    -- A/B/C の最小開始・最大終了
    , amin.AMinStart As 出講開始時間
    , amin.AMaxEnd As 出講終了時間
    , bmin.BMinStart As 業務届開始時間
    , bmin.BMaxEnd As 業務届終了時間
    , cmin.CMinStart As 業務給開始時間
    , cmin.CMaxEnd As 業務給終了時間

    , CONVERT(TIME(0), NULL) As 実務開始時間
    , CONVERT(TIME(0), NULL) As 実務終了時間
    , CONVERT(TIME(0), NULL) As 勤務開始時間
    , CONVERT(TIME(0), NULL) As 勤務終了時間

    -- A/B/C 横並び 10 件
    , a.*
    , b.*
    , c.*

    -- 重複件数
    , o.CntAA As 出講授業重複
    , o.CntAB As 出講業務届重複
    , o.CntMC As 打刻外業務重複

    -- 主テーブル整合性
    -- 主テーブル整合性チェック
    , mc.ABeforeStart
    , mc.AAfterEnd
    , mc.BBeforeStart
    , mc.BAfterEnd
    , mc.CBeforeStart
    , mc.CAfterEnd

    , HW.Task_Base_Unit_Price
    , HW.Deemed_Time_Before
    , HW.Deemed_Time_After
    , m.Punch_Count As 打刻回数
    , '' As 状態

FROM StaffDates s
LEFT JOIN W_Stamp_Data m
    ON m.Staff_Code = s.Teacher_Code
   AND m.Lecture_Date = s.Lecture_Date
LEFT JOIN AMinMax amin
    ON amin.Teacher_Code = s.Teacher_Code
   AND amin.Lecture_Date = s.Lecture_Date
LEFT JOIN BMinMax bmin
    ON bmin.Teacher_Code = s.Teacher_Code
   AND bmin.Lecture_Date = s.Lecture_Date
LEFT JOIN CMinMax cmin
    ON cmin.Teacher_Code = s.Teacher_Code
   AND cmin.Lecture_Date = s.Lecture_Date
LEFT JOIN AExpanded a
    ON a.A_Teacher_Code = s.Teacher_Code
   AND a.A_Lecture_Date = s.Lecture_Date
LEFT JOIN BExpanded b
    ON b.B_Teacher_Code = s.Teacher_Code
   AND b.B_Lecture_Date = s.Lecture_Date
LEFT JOIN CExpanded c
    ON c.C_Teacher_Code = s.Teacher_Code
   AND c.C_Lecture_Date = s.Lecture_Date
LEFT JOIN OverlapDetails o
    ON o.Teacher_Code = s.Teacher_Code
   AND o.Lecture_Date = s.Lecture_Date
LEFT JOIN MainCheck mc
    ON mc.Teacher_Code = s.Teacher_Code
   AND mc.Lecture_Date = s.Lecture_Date
LEFT JOIN Teacher mt
    ON mt.Teacher_Code = s.Teacher_Code


-- 標準単価、みなし時間
OUTER APPLY (
  SELECT TOP 1
    Effective_Date
    , Task_Base_Unit_Price
    , Deemed_Time_Before
    , Deemed_Time_After
  FROM 
    M_Hourly_Wage
  WHERE
    Effective_Date <= s.Lecture_Date
  ORDER BY
    Effective_Date DESC
) HW

Where
    1=1
    AND a.A_Teacher_Code IS NOT NULL
-- ORDER BY
--     a.Lecture_Date
--     , a.Teacher_Code
;
