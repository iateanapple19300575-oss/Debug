﻿Imports System.Data.SqlClient
Imports MainApp.Data.Entity
Imports Nts.Freamwork.Common.Utilities

Public Class TimetableSiteRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="targetYears"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetYears As String) As Integer
        'Dim targetYear As String = targetDate.Year.ToString("D4")
        Dim targetYear As String = targetYears

        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("DELETE").Append(" ")
        SqlQuery.Append("  FROM").Append(" ")
        SqlQuery.Append("    ").Append(DBTableConst.TABLE_NAME_TIMETABLE_SITE).Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1=1").Append(" ")
        SqlQuery.Append("  AND Year = " & "@対象年" & " ")
        SqlQuery.Append(";")

        Return ExecuteNonQuery(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@対象年", .Value = targetYear}
        )
    End Function

    ''' <summary>
    ''' 格納しているデータの年履歴を取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetYearHistory() As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  Year").Append(" ")
        SqlQuery.Append("  , CONCAT(Year, '年') As Year_Name").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  M_Timetable_Site ").Append(" ")
        SqlQuery.Append("GROUP BY").Append(" ")
        SqlQuery.Append("  Year").Append(" ")
        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  Year DESC").Append(" ")
        SqlQuery.Append(";").Append(" ")

        Return ExecuteDataTable(SqlQuery.ToString(), Nothing)
    End Function

    ''' <summary>
    ''' 教室時間割テーブル [M_Timetable_Site]
    ''' </summary>
    ''' <returns></returns>
    Public Function SelectPivotMonth(ByVal entity As TimetableSiteEntity) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder

        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  MTS.Year").Append(" ")
        SqlQuery.Append("  , MTS.Site_Code").Append(" ")
        SqlQuery.Append("  , MAX(VS.Site_Name) As Site_Name").Append(" ")
        SqlQuery.Append("  , MTS.Schedule_Pattern").Append(" ")

        For i As Integer = 1 To 9
            SqlQuery.Append("  , CONVERT(VARCHAR (5), MAX(Start_Time_" & i.ToString() & "), 108) As Start_Time_" & i.ToString()).Append(" ")
            SqlQuery.Append("  , CONVERT(VARCHAR (5), MAX(End_Time_" & i.ToString() & "), 108) As End_Time_" & i.ToString()).Append(" ")
        Next

        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  ( ").Append(" ")
        SqlQuery.Append("    SELECT").Append(" ")
        SqlQuery.Append("      Year").Append(" ")
        SqlQuery.Append("      , Site_Code").Append(" ")
        SqlQuery.Append("      , Schedule_Pattern").Append(" ")

        For i As Integer = 1 To 9
            SqlQuery.Append("      , CASE WHEN Koma_Seq = '" & i.ToString() & "' And Start_Time IS NOT NULL").Append(" ")
            SqlQuery.Append("          THEN Start_Time ELSE NULL END As Start_Time_" & i.ToString()).Append(" ")
            SqlQuery.Append("      , CASE WHEN Koma_Seq = '" & i.ToString() & "' And End_Time IS NOT NULL").Append(" ")
            SqlQuery.Append("          THEN End_Time ELSE NULL END As End_Time_" & i.ToString()).Append(" ")
        Next

        SqlQuery.Append("    FROM").Append(" ")
        SqlQuery.Append("      M_Timetable_Site").Append(" ")
        SqlQuery.Append("  ) As MTS ").Append(" ")

        SqlQuery.Append("LEFT JOIN VM_Site VS ").Append(" ")
        SqlQuery.Append("  ON ( ").Append(" ")
        SqlQuery.Append("       MTS.Site_Code = VS.Site_Code COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("     ) ").Append(" ")

        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")
        SqlQuery.Append("  AND MTS.Year = @対象年").Append(" ")

        If StringUtil.IsNotNullOrWhiteSpace(entity.Division_KND) Then
            SqlQuery.Append("  AND VS.Division_KND = @Division_KND").Append(" ")
        End If

        If Not StringUtil.IsNullOrWhiteSpace(entity.Site_Code) Then
            SqlQuery.Append("  AND MTS.Site_Code = @Site_Code").Append(" ")
        End If

        SqlQuery.Append("GROUP BY").Append(" ")
        SqlQuery.Append("  MTS.Year").Append(" ")
        SqlQuery.Append("  , MTS.Site_Code").Append(" ")
        SqlQuery.Append("  , MTS.Schedule_Pattern").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@対象年", .Value = entity.TargetYear})
        If StringUtil.IsNotNullOrWhiteSpace(entity.Division_KND) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Division_KND", .Value = entity.Division_KND})
        End If
        If StringUtil.IsNotNullOrWhiteSpace(entity.Site_Code) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = entity.Site_Code})
        End If

        Return ExecuteDataTable(SqlQuery.ToString(), params.ToArray)

    End Function


End Class
