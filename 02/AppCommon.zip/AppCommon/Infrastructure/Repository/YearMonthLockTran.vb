﻿Imports System.Data.SqlClient

''' <summary>
''' 年月度ロックトラン
''' </summary>
Public Class YearMonthLockTran
  Inherits TransactionBase

  Private Const LOG_FUNCTUON_NAME As String = "年月度設定画面"

    'Private logger As New Logger

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 年月度ロック登録(追加版)
    ''' </summary>
    ''' <param name="yearMonth"></param>
    ''' <returns></returns>
    Public Function LockForInsert(ByVal yearMonth As String) As ResultData
		Dim result As New ResultData
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("INSERT INTO").Append(" ")
		sqlString.Append("  " & DbMapper.GetTableName(Of T_Year_Month_LockEnum)).Append(" ")
		sqlString.Append("( ")
		sqlString.Append("    " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成日)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成者)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" ")
		sqlString.Append(")").Append(" ")
		sqlString.Append("SELECT").Append(" ")
		sqlString.Append("    @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
		sqlString.Append("  , 'L'").Append(" ")
		sqlString.Append("  , @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
		sqlString.Append("  , @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).Append(" ")
		sqlString.Append("  , GETDATE()").Append(" ")
		sqlString.Append("  , NULL").Append(" ")
		sqlString.Append("  , NULL").Append(" ")
		sqlString.Append("  , NULL").Append(" ")
		sqlString.Append("  , GETDATE()").Append(" ")
		sqlString.Append("  , @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
		sqlString.Append("  , NULL").Append(" ")
		sqlString.Append("  , NULL").Append(" ")
		sqlString.Append("WHERE Not EXISTS (").Append(" ")
		sqlString.Append("  SELECT 1 FROM").Append(" ")
		sqlString.Append("  " & DbMapper.GetTableName(Of T_Year_Month_LockEnum)).Append(" ")
		sqlString.Append("  WHERE 1=1").Append(" ")
		sqlString.Append("    AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" = ")
		sqlString.Append("       @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
		sqlString.Append(")")
		sqlString.Append(";")

    Try
      Using dts As New DbTransactionScope()
        Dim cmdInsert As New SqlCommand(sqlString.ToString(), dts.Connection)
        cmdInsert.Transaction = dts.Transaction
        cmdInsert.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度), yearMonth)
        cmdInsert.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー), Environment.UserName)
        cmdInsert.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC), Environment.MachineName)
        result.DataCount = cmdInsert.ExecuteNonQuery()
        result.Success = False
        If result.DataCount > 0 Then
          result.Success = True
        End If
      End Using
    Catch ex As Exception
      result.Success = False
    Finally

    End Try

		Return result
	End Function

	''' <summary>
	''' 年月度ロック登録(更新版)
	''' </summary>
	''' <param name="yearMonth"></param>
	''' <returns></returns>
	Public Function LockForUpdate(ByVal yearMonth As String) As ResultData
		Dim result As New ResultData
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("UPDATE").Append(" ")
		sqlString.Append("  " & DbMapper.GetTableName(Of T_Year_Month_LockEnum)).Append(" ")
		sqlString.Append("SET").Append(" ")
		sqlString.Append("    " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" = 'L'").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" = ").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).Append(" = ").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).Append(" = GETDATE()").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" = NULL").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" = NULL").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).Append(" = NULL").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).Append(" = GETDATE()").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" = ").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" ")
		sqlString.Append("WHERE 1=1").Append(" ")
		sqlString.Append("  AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" = ")
		sqlString.Append("     @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
		sqlString.Append("  AND (" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" = 'U' OR ")
		sqlString.Append("       " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" = ")
		sqlString.Append("      @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
		sqlString.Append("      )").Append(" ")
		sqlString.Append(";")

		Try
      Using dts As New DbTransactionScope()
        Dim cmdUpdate As New SqlCommand(sqlString.ToString(), dts.Connection)
        cmdUpdate.Transaction = dts.Transaction
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度), yearMonth)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー), Environment.UserName)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC), Environment.MachineName)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者), Environment.UserName)
        result.DataCount = cmdUpdate.ExecuteNonQuery()
        result.Success = False
        If result.DataCount > 0 Then
          result.Success = True
        End If
      End Using

    Catch ex As Exception
			result.Success = False
		Finally

		End Try

		Return result
	End Function

	''' <summary>
	''' ロック解除(自分自身)
	''' </summary>
	''' <param name="yearMonth"></param>
	''' <returns></returns>
	Public Function UnLock(ByVal yearMonth As String) As ResultData
		Dim result As New ResultData
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("UPDATE").Append(" ")
		sqlString.Append("  " & DbMapper.GetTableName(Of T_Year_Month_LockEnum)).Append(" ")
		sqlString.Append("SET").Append(" ")
		sqlString.Append("    " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" = 'U'").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" =").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" =").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).Append(" = GETDATE()").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).Append(" = GETDATE()").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" = ").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" ")
		sqlString.Append("WHERE 1=1").Append(" ")
		sqlString.Append("  AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" =").Append(" ")
		sqlString.Append("     @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
		sqlString.Append("  AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" = 'L'").Append(" ")
		sqlString.Append("  AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" = ")
		sqlString.Append("     @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
		sqlString.Append(";")

		Try
      Using dts As New DbTransactionScope()
        Dim cmdUpdate As New SqlCommand(sqlString.ToString(), dts.Connection)
        cmdUpdate.Transaction = dts.Transaction
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度), yearMonth)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー), Environment.UserName)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー), Environment.UserName)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC), Environment.MachineName)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者), Environment.MachineName)
        result.DataCount = cmdUpdate.ExecuteNonQuery()
        result.Success = False
        If result.DataCount > 0 Then
          result.Success = True
        End If
      End Using
    Catch ex As Exception
      result.Success = False
		Finally

		End Try

		Return result
	End Function

	''' <summary>
	''' ロック強制解除
	''' </summary>
	''' <param name="yearMonth"></param>
	''' <returns></returns>
	Public Function ForcedRelease(ByVal yearMonth As String) As ResultData
		Dim result As New ResultData
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("UPDATE").Append(" ")
		sqlString.Append("  " & DbMapper.GetTableName(Of T_Year_Month_LockEnum)).Append(" ")
		sqlString.Append("SET").Append(" ")
		sqlString.Append("  " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" = 'U'").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" =").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" =").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).Append(" = GETDATE()").Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).Append(" = GETDATE()" & " ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" =").Append(" ")
		sqlString.Append("   @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" ")
		sqlString.Append("WHERE 1=1").Append(" ")
		sqlString.Append("  AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" =").Append(" ")
		sqlString.Append("     @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
		sqlString.Append("  AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" = 'L'").Append(" ")
		sqlString.Append(";")

		Try
      Using dts As New DbTransactionScope()
        Dim cmdUpdate As New SqlCommand(sqlString.ToString(), dts.Connection)
        cmdUpdate.Transaction = dts.Transaction
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度), yearMonth)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー), Environment.UserName)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC), Environment.MachineName)
        cmdUpdate.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者), Environment.MachineName)
        result.DataCount = cmdUpdate.ExecuteNonQuery()
        result.Success = False
        If result.DataCount > 0 Then
          result.Success = True
        End If
      End Using
    Catch ex As Exception
      result.Success = False
		Finally

		End Try

		Return result
	End Function

	''' <summary>
	''' 指定対象年度ロック中状態取得
	''' </summary>
	''' <param name="yearMonth"></param>
	''' <returns></returns>
	Public Function GetTargetDateInUse(ByVal yearMonth As String) As ResultData
		Dim result As New ResultData

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("SELECT").Append(" ")
		sqlString.Append("    " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始時間)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除ユーザー)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除PC)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック解除時間)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成日)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.作成者)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新日)).Append(" ")
		sqlString.Append("  , " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.更新者)).Append(" ")
		sqlString.Append("FROM").Append(" ")
		sqlString.Append("  " & DbMapper.GetTableName(Of T_Year_Month_LockEnum)).Append(" ")
		sqlString.Append("WHERE 1=1" & " ")
		sqlString.Append("  AND " & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" =").Append(" ")
		sqlString.Append("     @" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度)).Append(" ")

		Try
      Using dts As New DbTransactionScope()
        Using command As New SqlCommand(sqlString.ToString(), dts.Connection)
          command.Transaction = dts.Transaction
          command.Parameters.AddWithValue("@" & DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.対象年月度), yearMonth)
                    'logger.WriteQueryLog(LOG_FUNCTUON_NAME, command)

                    Dim dic As New Dictionary(Of String, String)
          Dim reader As SqlDataReader = command.ExecuteReader()
          Dim rowCount As Integer = 0
          While reader.Read()
            For i = 0 To reader.FieldCount - 1
              dic.Add(reader.GetName(i), SqlDataReaderUtil.GetValue(reader, reader.GetName(i)))
            Next
            rowCount += 1
          End While
          reader.Close()
          result.ResDicString = dic
          result.DataCount = rowCount
        End Using
      End Using
    Catch ex As SqlException
			result.Success = False
			result.ErrorCode = ex.Number
			result.ErrorDescription = ex.Message
			result.ExceptionEx = ex
			Throw
		Catch ex As Exception
			result.Success = False
			result.ErrorDescription = ex.Message
			result.ExceptionEx = ex
			Throw
		Finally
			If Not result.Success Then
                'logger.WriteErrorLog(LOG_FUNCTUON_NAME, Me.GetType().Name & ":" & System.Reflection.MethodBase.GetCurrentMethod.Name & ":" & result.ErrorNumber & ":" & result.ErrorDescription)
            End If

		End Try

		Return result
	End Function
End Class
