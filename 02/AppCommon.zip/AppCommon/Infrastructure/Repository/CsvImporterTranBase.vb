﻿Imports MainApp.Data.Dto
Imports MainApp.Data.Entity

''' <summary>
''' CSVインポート基底クラス（）
''' </summary>
Public MustInherit Class CsvImporterTranBase
    Implements ICsvImporter

    Private ReadOnly _filePath As String

    Private ReadOnly _targetDate As Date

    Private ReadOnly _csv As ICsv

    Private ReadOnly _reader As ICsvReader

    Private ReadOnly _validation As ICsvValidation

    Private ReadOnly _parameter As CsvImportParameterDto

    Private ReadOnly _sqlConnection As DbTransactionScope

    Private ReadOnly _historyRepo As New HistoryImportRepository

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="param"></param>
    ''' <param name="csv"></param>
    ''' <param name="validation"></param>
    Protected Sub New(param As CsvImportParameterDto, csv As ICsv, validation As ICsvValidation)
        _parameter = param
        _filePath = csv.FileName
        _targetDate = param.TargetDate
        _validation = validation
        _reader = New CsvReader(csv)
        _csv = csv
    End Sub

    ''' <summary>
    ''' CSVインポートトランザクション
    ''' </summary>
    ''' <returns></returns>
    Public Function Execute() As ImportResultInfo Implements ICsvImporter.Execute
        Dim result As New ImportResultInfo
        Dim nowDateTime As DateTime = Now

        result.ExecutDate = nowDateTime

        ' --------------------------------------------------------------------
        ' 1. CSVフォーマット確認
        ' 　ヘッダ項目：カラム数、カラム名で対象CSVであるかの簡単なチェック
        ' --------------------------------------------------------------------
        If Not _reader.FormatValidation(_filePath) Then
            result.Success = False
            result.ErrorType = ImportDataErrorType.FormatError
            Return result
        End If

        ' --------------------------------------------------------------------
        ' 2. CSV 読み込み
        ' --------------------------------------------------------------------
        Dim rows = _reader.Read(_filePath)

        ' --------------------------------------------------------------------
        ' 2-1. 対象データのみチェック
        ' --------------------------------------------------------------------
        If DuplicateValidation(rows) Then
            result.Success = False
            result.ErrorType = ImportDataErrorType.DuplicateError
            Return result
        End If


        Dim delMonths As New List(Of String)
        Dim valid As Integer = ValidationMonthPeriod(delMonths, rows)
        If Not valid = ImportDataErrorType.Success Then
            result.Success = False
            result.ErrorType = valid
            Return result
        End If

        ' --------------------------------------------------------------------
        ' 3. バリデーション
        ' --------------------------------------------------------------------
        result = _validation.Validate(rows)
        If result.HasError Then
            result.ExecutDate = nowDateTime
            Return result
        End If

        ' --------------------------------------------------------------------
        ' 4. CSVインポートのメイン処理
        ' --------------------------------------------------------------------
        Using uow As New DbTransactionScope()

            Try
                '-------------------------------------------------------------
                ' 4-1. 前回実施のデータ削除
                ' 　何もせず、インポートすると重複エラーになるかも知れない。
                ' 　なので、今回対象期間のデータを一旦削除する。
                ' 　処理事態は、サブクラスで実装する。
                '-------------------------------------------------------------
                PreparatoryWork(uow, rows, delMonths)

                '-------------------------------------------------------------
                ' 4-2. CSVデータのインポート
                ' 　BulkCopyによりCSVデータを取込する。
                '-------------------------------------------------------------
                Dim dt As DataTable = Nothing
                dt = ReadWithDataTable(_filePath, _parameter.TargetDate)
                BulkCopyExecutor.ExecuteWithTran(uow.Connection, uow.Transaction, TargetTableName, dt, _csv.BuckCopyMapping())

                '-------------------------------------------------------------
                ' 4-3. 特別処理
                ' 　標準処理以外にインポート後に特別な処理が必要なとき、
                ' 　サブクラスで実装する。
                '-------------------------------------------------------------
                AppendJob(uow)

                '-------------------------------------------------------------
                ' 4-4. 履歴情報の登録（インポート履歴）
                '-------------------------------------------------------------
                Dim dto As HistoryImportDto = CreateHistoryImportDto(_csv)
                dto.ExecutionCount = dt.Rows.Count
                Dim entity As HistoryImportEntity = ImportHistoryHelper.DtoToEntity(dto)
                _historyRepo.Insert(uow, entity)

                '-------------------------------------------------------------
                ' 4-5. コミット
                '-------------------------------------------------------------
                uow.CommitTransaction()

                result.ExecutDate = nowDateTime
                result.ExecutCount = entity.ExecutionCount
                result.Success = True
                Return result

            Catch ex As Exception
                ' ロールバック
                uow.RollbackTransaction()
                result.Success = False
                'result.Message = ex.Message
            End Try

        End Using

        Return result
    End Function

    ''' <summary>
    ''' 画面パラメタ→DTO変換
    ''' </summary>
    ''' <param name="csv"></param>
    ''' <returns></returns>
    Private Function CreateHistoryImportDto(csv As ICsv) As HistoryImportDto
        Dim dto As New HistoryImportDto

        dto.CsvType = csv.CsvType
        dto.Category = csv.Ccategory
        dto.DataName = csv.DataName
        dto.FileName = csv.FileName
        dto.FiscalYearMonth = IIf(DateUtil.IsNullOrEmpty(_targetDate), "", _targetDate.Year & _targetDate.Month.ToString("D2"))
        dto.ExecutionDate = Now
        dto.ExecutionUser = Environment.UserName
        dto.ExecutionPc = Environment.MachineName
        dto.ExecutionStatus = 0
        dto.ExecutionCount = 0
        dto.CreateUser = Environment.UserName
        dto.CreateDate = Now
        Return dto
    End Function

    Protected Overridable Function LoadCsv() As DataTable
        Return CsvParser.Load(_filePath)
    End Function

    Protected Overridable Sub ValidateCommon(dto As Object)
        ' 必須チェックなど共通があればここに
    End Sub

    Protected Overridable Function CreateDataTable() As DataTable
        Return DataTableBuilder.FromDtoType(GetDtoType())
    End Function

    Protected Overridable Sub AddToDataTable(dt As DataTable, dto As Object)
        DataTableBuilder.AddRow(dt, dto)
    End Sub

    Protected Sub LogError(rowIndex As Integer, dto As Object, ex As Exception)
        Dim dtoStr As String = If(dto Is Nothing, "(null)",
            String.Join(",",
                dto.GetType().GetProperties().
                    Select(Function(p) $"{p.Name}={p.GetValue(dto, Nothing)}")))

        Dim log = $"{DateTime.Now} 行:{rowIndex} DTO:{dtoStr} Error:{ex.Message}"
        System.IO.File.AppendAllText("import_error.log", log & Environment.NewLine)
    End Sub

    Public Function ReadWithDataTable(fileName As String, Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Return _reader.ToDataTable(fileName, yearMonth)
    End Function

    Protected Overridable Function AppendJob(ByVal sqlDbConn As DbTransactionScope) As Integer
        Return 0
    End Function

    Protected MustOverride ReadOnly Property TargetTableName As String
    Protected MustOverride ReadOnly Property ImportTypeName As String
    Protected MustOverride ReadOnly Property DataType As String
    Protected MustOverride Function GetDtoType() As Type
    Protected MustOverride Sub PreparatoryWork(ByVal sqlDbConn As DbTransactionScope, impDataDic As List(Of Dictionary(Of String, String)), delMonths As List(Of String))
    Protected MustOverride Function ValidationMonthPeriod(ByRef delKeys As List(Of String), ByVal impDataList As List(Of Dictionary(Of String, String))) As ImportDataErrorType
    Protected MustOverride Sub DeleteSwapData(ByVal sqlDbConn As DbTransactionScope, targetDate As List(Of String))
    Protected MustOverride Function DuplicateValidation(ByVal impDataDic As List(Of Dictionary(Of String, String))) As Boolean
End Class