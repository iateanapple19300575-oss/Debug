﻿Imports System.Data.SqlClient

Public Class TeacherWageWorkRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' WORK講師給与単価データ全削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteSwapData() As Integer
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append("W_Teacher_Wage").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString()
        )
    End Function

End Class
