﻿Imports System.Windows.Forms
''' <summary>
''' MDI 子フォームとして動作する基底フォーム。
''' GlobalState の変更通知を UI スレッドで受け取り、派生フォームで UI 更新を実装。
''' </summary>
Public Class BaseMdiChildForm
	Inherits Form

	Private _subscribed As Boolean = False

	''' <summary>
	''' フォームロード時に StateDispatcher.UiStateChanged を購読する。
	''' </summary>
	Protected Overrides Sub OnLoad(e As EventArgs)
		MyBase.OnLoad(e)

		If Not _subscribed Then
			AddHandler StateDispatcher.UiStateChanged, AddressOf OnUiStateChanged
			_subscribed = True
		End If
	End Sub

	''' <summary>
	''' フォームクローズ時に購読解除（メモリリーク防止）。
	''' </summary>
	Protected Overrides Sub OnFormClosed(e As FormClosedEventArgs)
		RemoveHandler StateDispatcher.UiStateChanged, AddressOf OnUiStateChanged
		MyBase.OnFormClosed(e)
	End Sub

	''' <summary>
	''' GlobalState の変更を UI スレッドで受け取る。
	''' 派生フォームで UI 更新処理を実装する。
	''' </summary>
	Public Overridable Sub OnUiStateChanged(key As String, value As Object)
		' 派生フォームで実装
	End Sub

End Class