﻿Imports System.Windows.Forms
''' <summary>
''' アプリケーション全体の MDI 親フォームとして動作する基底クラス。
''' </summary>
''' <remarks>
''' ・MDI 子フォームの管理（アクティブ化イベントの購読）
''' ・UI スレッドの SynchronizationContext 登録（初回のみ）
''' ・StateDispatcher.Attach による GlobalState → UI スレッド通知の有効化
''' ・ステータスバーの自動同期（UiStateChanged の購読）
''' </remarks>
Public Class BaseMdiParentForm
	Inherits Form

	''' <summary>
	''' UI スレッド登録および StateDispatcher.Attach が実行済みかどうかを示すフラグ。
	''' </summary>
	Private Shared _initialized As Boolean = False

	''' <summary>
	''' フォームロード時に MDI親としての初期化処理を実行する。
	''' </summary>
	''' <param name="e">イベントデータ</param>
	''' <remarks>
	''' ・MDI子フォームのアクティブ化イベントを購読する。
	''' ・アプリ全体で 1回だけ UIスレッド登録と StateDispatcher.Attach を実行
	''' ・MDI親フォームとしての設定（IsMdiContainer）
	''' ・GlobalState の UI スレッド通知（UiStateChanged）を購読し、ステータスバー同期を可能にする
	''' </remarks>
	Protected Overrides Sub OnLoad(e As EventArgs)
		MyBase.OnLoad(e)

		' MDI子アクティブ化イベントを購読
		AddHandler Me.MdiChildActivate, AddressOf OnMdiChildActivated

		If Not _initialized Then
			' UIスレッド登録（アプリ全体で1回）
			StateDispatcher.InitializeForUIThread()

			' GlobalState → UIスレッドへのマーシャリングを有効化（1回）
			StateDispatcher.Attach()

			_initialized = True
		End If

		' MDI親フォームとして動作
		Me.IsMdiContainer = True

		' ステータスバー同期のため、UI スレッドで発火するイベントを購読
		AddHandler StateDispatcher.UiStateChanged, AddressOf OnUiStateChanged
	End Sub

	''' <summary>
	''' フォームクローズ時に購読解除を行う（メモリリーク防止）。
	''' </summary>
	''' <param name="e">イベントデータ</param>
	Protected Overrides Sub OnFormClosed(e As FormClosedEventArgs)
		RemoveHandler StateDispatcher.UiStateChanged, AddressOf OnUiStateChanged
		MyBase.OnFormClosed(e)
	End Sub

	''' <summary>
	''' MDI子フォームがアクティブ化された際に呼び出される。
	''' </summary>
	''' <param name="sender">イベントの送信元</param>
	''' <param name="e">イベントデータ</param>
	''' <remarks>
	''' 派生クラスで、アクティブな MDI子フォームに応じた UI更新や状態反映を行う場合にオーバーライドする。
	''' </remarks>
	Protected Overridable Sub OnMdiChildActivated(sender As Object, e As EventArgs)
		Dim child = Me.ActiveMdiChild
		If child Is Nothing Then
			Return
		End If

		' 子フォーム起動時に何かする場合、ここに処理を実装予定
	End Sub

	''' <summary>
	''' GlobalState の変更をUIスレッドで受け取り、ステータスバーに反映する。
	''' </summary>
	''' <param name="key">変更された状態のキー名</param>
	''' <param name="value">変更後の値</param>
	''' <remarks>
	''' ・StateDispatcher により UIスレッドで発火するため、UI更新が安全に行える。
	''' ・派生クラスでステータスバー以外の UI更新を追加することも可能。
	''' </remarks>
	Protected Overridable Sub OnUiStateChanged(key As String, value As Object)
		Select Case key
			Case "CurrentUserName"
				'lblUserName.Text = $"{value}"
			Case "CurrentStatus"
				'lblStatus.Text = $"{value}"
			Case "ApplicationName"
				'lblApplicationName.Text = $"{value}"
			Case Else
				' 必要に応じて他のキーも追加
		End Select
	End Sub

	''' <summary>
	''' 指定した型の MDI子フォームを表示する。
	''' 既に存在する場合はアクティブ化し、存在しない場合は新規作成して表示する。
	''' </summary>
	''' <typeparam name="T">MDI子フォームの型</typeparam>
	''' <returns>取得または作成されたフォーム</returns>
	Protected Function ShowOrActivateMdiChild(Of T As {Form, New})() As T
		' 既に開いている MDI子フォームを検索
		For Each child As Form In Me.MdiChildren
			If TypeOf child Is T Then
				' 表示中ならば アクティブ化
				child.Activate()
				Return DirectCast(child, T)
			End If
		Next

		' 存在しない場合は新規作成
		Dim newForm As New T()
		newForm.MdiParent = Me
		newForm.Show()
		Return newForm
	End Function
End Class