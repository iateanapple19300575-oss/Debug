﻿Imports System.Windows.Forms

''' <summary>
''' エラー情報格納用データクラス
''' </summary>
Public Class ColumnsStyleInfo
	Public Property Name As String
	Public Property Alignment As DataGridViewContentAlignment
	Public Property Width As Integer
End Class
