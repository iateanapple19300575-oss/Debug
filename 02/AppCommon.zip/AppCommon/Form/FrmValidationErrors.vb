﻿Imports System.Drawing
Imports System.Windows.Forms
Imports Freamwork.Common.Helper

''' <summary>
''' CSVデータ取込エラー画面(基底クラス)
''' </summary>
Public Class FrmValidationErrors

    ''' <summary>
    ''' エラー行番号タイトル
    ''' </summary>
    Protected Const ERROR_LINES_TITLE As String = "行番号"

    ''' <summary>
    ''' DataGridViewデフォルトカラム表示サイズ
    ''' </summary>
    Protected Const COLUMN_DEFAULTS_SIZE As Integer = 100

    ''' <summary>
    ''' カラム幅調整モード（True：自動モード／False：指定モード）
    ''' </summary>
    ''' <returns></returns>
    Protected Property FitColumnSize As Boolean = False

    '' <summary>
    '' DataGridView定義情報(カラム表示設定)
    '' </summary>
    '' <returns></returns>
    Protected Property ColumnStyleInfoList As New List(Of ColumnsStyleInfo)

    ''' <summary>
    ''' エラーデータ情報(実データ)
    ''' </summary>
    ''' <returns></returns>
    Protected Property ValidationResultDic As Dictionary(Of Integer, List(Of ValidationResult))

    ''' <summary>
    ''' CSVデータ情報
    ''' </summary>
    Private csvFileInfo As CsvAbstract

    ''' <summary>
    ''' CSVデータ情報
    ''' </summary>
    Private Const WINDOW_NAME_PREFIX As String = "取込エラー"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        ' デザイナーで必要
        InitializeComponent()
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="errResultDic"></param>
    Public Sub New(ByVal errResultDic As Dictionary(Of Integer, List(Of ValidationResult)), ByVal csvInfo As CsvAbstract)
        ' デザイナーで必要
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後で初期化を追加します。
        Me.ValidationResultDic = errResultDic
        'Me.CsvInfo = CsvInfo
        'Me.ColumnStyleInfoList = alignmentList

        csvFileInfo = csvInfo

    End Sub

    ''' <summary>
    ''' Resizeイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ' DataGridViewのサイズをフォーム全体に合わせる
        dtGridView.Width = Me.ClientSize.Width
        dtGridView.Height = Me.ClientSize.Height
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmImportError_Load(sender As Object, e As EventArgs) Handles Me.Load
        MouseCursor.WaitCursor(Me)

        'Me.MinimizeBox = False
        'Me.MaximizeBox = False
        'Me.FormBorderStyle = FormBorderStyle.FixedDialog

        ' 継承先のサブクラスでデータ毎のカラム情報を設定。

        Me.Font = New Font("游ゴシック", 9, FontStyle.Regular)

        SetupForm()

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' 画面表示準備
    ''' </summary>
    Protected Sub SetupForm()

        ProcessingService.Show(Me, "エラー情報読込中...")

        ' 画面毎のDatGridViewの設定(サブクラスで定義)
        InitializeDataGridView()

        ' InitializeDataGridView()の定義を元に画面フォーム初期化
        InitializeForm()

        ' Windowの初期化
        InitializeWindow()

        ProcessingService.Close()

    End Sub

    ''' <summary>
    ''' エラー情報表示
    ''' </summary>
    Private Sub InitializeForm()

        '' 継承先のサブクラスでデータ毎のカラム情報を設定。
        'SetupColumnInfo()

        With dtGridView
            ' ヘッダ行
            .ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False
            .ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

            ' ヘッダ：エラー行番号表示列
            .ColumnCount = ColumnStyleInfoList.Count + 1
            .Columns(0).HeaderText = ERROR_LINES_TITLE
            .Columns(0).Width = 60
            .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            .Columns(0).SortMode = DataGridViewColumnSortMode.NotSortable

            ' ヘッダ：項目タイトル名
            For colIndex As Integer = 0 To ColumnStyleInfoList.Count - 1
                .Columns(colIndex + 1).HeaderText = ColumnStyleInfoList(colIndex).Name
                .Columns(colIndex + 1).DefaultCellStyle.Alignment = ColumnStyleInfoList(colIndex).Alignment
                .Columns(colIndex + 1).SortMode = DataGridViewColumnSortMode.NotSortable
            Next

            ' 文字列の表示位置とカラム表示幅の設定
            Dim colIdx As Integer = 0
            For Each column As ColumnsStyleInfo In ColumnStyleInfoList
                .Columns(colIdx + 1).DefaultCellStyle.Alignment = column.Alignment
                .Columns(colIdx + 1).Width = column.Width
                colIdx += 1
            Next

            ' CSVの各項目データ
            Dim sortedKeys = ValidationResultDic.Keys.OrderBy(Function(k) k).ToList()
            .Rows.Clear()
            For rowIndex As Integer = 0 To ValidationResultDic.Count - 1
                .Rows.Add()
                .Rows(rowIndex).Cells(0).Value = String.Format("{0:D5}", sortedKeys(rowIndex) + 1)
                For colIndex As Integer = 0 To ValidationResultDic(sortedKeys(rowIndex)).Count - 1
                    .Rows(rowIndex).Cells(colIndex + 1).Value = ValidationResultDic(sortedKeys(rowIndex))(colIndex).Value
                    .Rows(rowIndex).Cells(colIndex + 1).Style.BackColor = ValidationResultDic(sortedKeys(rowIndex))(colIndex).ErrorColor
                    If (Not ValidationResultDic(sortedKeys(rowIndex))(colIndex).IsValid()) Then
                        .Rows(rowIndex).Cells(colIndex + 1).ToolTipText = ToolTipErrorMessage(ValidationResultDic(sortedKeys(rowIndex))(colIndex).SummaryMessage, ValidationResultDic(sortedKeys(rowIndex))(colIndex).ErrorMessage())
                    End If
                Next
            Next

            If FitColumnSize Then
                ' 列幅・行高の自動調整(設定すると両脇の余白がないため各データで表示幅を指定するようにしている)
                .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
                .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells
            End If

            ' 新規行は表示しない
            .AllowUserToAddRows = False
        End With
    End Sub

    ''' <summary>
    ''' Windowの初期化
    ''' </summary>
    Private Sub InitializeWindow()
        Me.Text = WINDOW_NAME_PREFIX & "【" & csvFileInfo.FileName & "】"
    End Sub

    ''' <summary>
    ''' エラーカラム情報追加メソッド（カラムサイズ固定）
    ''' </summary>
    ''' <param name="columnName">カラム名</param>
    ''' <param name="alignment">表示位置</param>
    Public Sub Add(ByVal columnName As String, ByVal alignment As DataGridViewContentAlignment)
        FitColumnSize = True
        Add(columnName, alignment, COLUMN_DEFAULTS_SIZE)
    End Sub

    ''' <summary>
    ''' エラーカラム情報追加メソッド（カラムサイズ指定）
    ''' </summary>
    ''' <param name="columnName">カラム名</param>
    ''' <param name="alignment">表示位置</param>
    Public Sub Add(ByVal columnName As String, ByVal alignment As DataGridViewContentAlignment, ByVal width As Integer)
        Dim columnInfo As New ColumnsStyleInfo With {
            .Name = columnName,
            .Alignment = alignment,
            .Width = width
        }
        ColumnStyleInfoList.Add(columnInfo)
    End Sub

    ''' <summary>
    ''' エラー箇所のツールチップ表示用のメッセージ設定
    ''' </summary>
    ''' <param name="summaryMessage">概要メッセージ</param>
    ''' <param name="detailMessage">詳細メッセージ</param>
    ''' <returns></returns>
    Protected Function ToolTipErrorMessage(ByVal summaryMessage As String, ByVal detailMessage As String) As String
        Return String.Concat(summaryMessage, vbCrLf, detailMessage)
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmValidationErrors_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Me.Width = dtGridView.Width
        Me.Height = dtGridView.Height + 20
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.FormBorderStyle = FormBorderStyle.FixedDialog
    End Sub

    ''' <summary>
    ''' カラム情報設定
    ''' </summary>
    Protected Sub InitializeDataGridView()
        Dim csvColumnNames() As String = csvFileInfo.Headers.ToArray()
        Dim colmunAligns() As Integer = csvFileInfo.ContentAlign.ToArray()
        For i As Integer = 0 To csvColumnNames.Length - 1
            Add(csvColumnNames(i), colmunAligns(i))
        Next
    End Sub
End Class