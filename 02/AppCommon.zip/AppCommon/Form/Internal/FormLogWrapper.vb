﻿Imports System.Reflection
Imports System.Windows.Forms
Imports System.ComponentModel
''' <summary>
''' WinForms のフォームおよびコントロールのイベントを動的にラップし、
''' イベント開始・終了・例外をログとして記録するためのユーティリティクラス。
''' </summary>
Public Class FormLogWrapper

	Private Shared ReadOnly ControlTypeToJapanese As New Dictionary(Of String, String) From {
		{"Form", "画面"},
		{"Button", "ボタン"},
		{"ComboBox", "コンボボックス"},
		{"TextBox", "テキストボックス"},
		{"Label", "ラベル"},
		{"CheckBox", "チェックボックス"},
		{"RadioButton", "ラジオボタン"},
		{"ListBox", "リストボックス"},
		{"DataGridView", "データグリッドビュー"},
		{"TabControl", "タブコントロール"},
		{"Panel", "パネル"},
		{"GroupBox", "グループボックス"}
	}

	''' <summary>
	''' すでにラップ済みのイベントを識別するためのキー集合。
	''' 同じイベントを二重にラップしないようにする。
	''' </summary>
	Private Shared ReadOnly _wrappedEvents As New HashSet(Of String)()

	''' <summary>
	''' 最後に表示されたフォーム名。
	''' フォーム遷移ログ（前画面 → 現在画面）を出力するために使用する。
	''' </summary>
	Private Shared _lastFormName As String = Nothing

	''' <summary>
	''' コントロール型ごとにラップ対象とするイベント名の一覧。
	''' </summary>
	Private Shared ReadOnly TargetEvents As New Dictionary(Of Type, String()) From {
		{GetType(Button), New String() {"Click"}},
		{GetType(ComboBox), New String() {"SelectedIndexChanged"}},
		{GetType(RadioButton), New String() {"CheckedChanged"}},
		{GetType(CheckBox), New String() {"CheckedChanged"}},
		{GetType(TextBox), New String() {"LostFocus"}}
	}

	''' <summary>
	''' フォームのライフサイクルイベント（Load / Shown / FormClosing / FormClosed）をラップし、
	''' 画面遷移や表示状態をログに記録する。
	''' </summary>
	''' <param name="form">対象フォーム</param>
	Public Shared Sub WrapFormLifecycle(form As Form)
		Dim scrnName As String = "[" & form.Text & "]" & " 画面"
		Dim ctrlName As String = "[" & form.Text & "]" & " フォーム"

		' --- Load ---
		AddHandler form.Load,
			Sub(sender, e)
				Try
					'Dim current As String = form.Name
					'Dim previous As String = If(_lastFormName, "初期起動")
					'LogService.Write(scrnName, ctrlName, "Load", previous & " → " & current & " (画面表示)")
					'_lastFormName = current
					LogService.Write(scrnName, ctrlName, "Load", "(画面表示)")
				Catch ex As Exception
					LogService.Write(scrnName, ctrlName, "Load例外", ex.Message)
                    'ErrorFacade.Report(ex, ErrorContext.Manual)
                End Try
			End Sub

		'' --- Shown ---
		'AddHandler form.Shown,
		'	Sub(sender, e)
		'		Try
		'			'LogService.Write(scrnName, ctrlName, "Shown", form.Name & " 表示完了")
		'			LogService.Write(scrnName, ctrlName, "Shown", "(画面表示)")
		'		Catch ex As Exception
		'			LogService.Write(scrnName, ctrlName, "Shown例外", ex.Message)
		'			ErrorFacade.Report(ex, ErrorContext.Manual)
		'		End Try
		'	End Sub

		'' --- FormClosing ---
		'AddHandler form.FormClosing,
		'	Sub(sender, e)
		'		Try
		'			LogService.Write(scrnName, ctrlName, "FormClosing", form.Name & " 終了開始")
		'		Catch ex As Exception
		'			LogService.Write(scrnName, ctrlName, "FormClosing例外", ex.Message)
		'			ErrorFacade.Report(ex, ErrorContext.Manual)
		'		End Try
		'	End Sub

		' --- FormClosed ---
		'AddHandler form.FormClosed,
		'	Sub(sender, e)
		'		Try
		'			'LogService.Write(scrnName, ctrlName, "FormClosed", form.Name & " 終了完了")
		'			LogService.Write(scrnName, ctrlName, "FormClosed", "(画面終了)")
		'		Catch ex As Exception
		'			LogService.Write(scrnName, ctrlName, "FormClosed例外", ex.Message)
		'			ErrorFacade.Report(ex, ErrorContext.Manual)
		'		End Try
		'	End Sub

	End Sub

	''' <summary>
	''' 指定されたコントロールとその子孫コントロールのすべてのイベントをラップする。
	''' 動的に追加されたコントロールにも対応する。
	''' </summary>
	''' <param name="root">ルートとなるコントロール</param>
	Public Shared Sub WrapAllEvents(root As Control)
		WrapControlEvents(root)

		' 子コントロールを再帰的に処理
		For Each child As Control In root.Controls
			WrapAllEvents(child)
		Next

		' 動的追加されたコントロールにも対応
		AddHandler root.ControlAdded, AddressOf OnDynamicControlAdded
	End Sub

	''' <summary>
	''' 指定されたコントロールの公開インスタンスイベントをすべてラップする。
	''' </summary>
	Private Shared Sub WrapControlEvents(ctrl As Control)
		Dim t As Type = ctrl.GetType()
		' 対象外の型は無視
		If Not TargetEvents.ContainsKey(t) Then
			Return
		End If

		For Each evName In TargetEvents(t)

			Dim ev As EventInfo = t.GetEvent(evName)
			If ev Is Nothing Then
				Continue For
			End If

			' EventHandler 型以外は対象外
			If ev.EventHandlerType IsNot GetType(EventHandler) Then
				Continue For
			End If

			Dim key As String = ctrl.Name & "." & evName

			' 二重ラップ防止
			If _wrappedEvents.Contains(key) Then
				Continue For
			End If
			_wrappedEvents.Add(key)

			' ラップハンドラを追加
			AddHandlerDirect(ctrl, ev, key)
		Next

		'For Each ev As EventInfo In t.GetEvents(BindingFlags.Public Or BindingFlags.Instance)
		'	WrapEvent(ctrl, ev)
		'Next
	End Sub

	''' <summary>
	''' 動的に追加されたコントロールに対してもイベントラップを適用する。
	''' </summary>
	Private Shared Sub OnDynamicControlAdded(sender As Object, e As ControlEventArgs)
		If e.Control IsNot Nothing Then
			WrapAllEvents(e.Control)
		End If
	End Sub

	''' <summary>
	''' 指定されたイベントに対してログ出力を行うラップハンドラを追加する。
	''' CheckBox および RadioButton の場合は、Checked 状態（ON/OFF）もログに含める。
	''' </summary>
	''' <param name="ctrl">イベントを持つ対象コントロール。</param>
	''' <param name="ev">ラップ対象のイベント情報。</param>
	''' <param name="key">「コントロール名.イベント名」を表す識別キー。</param>
	''' <remarks>
	''' ・すべてのイベントラップはこのメソッドを経由するため、追加情報（ON/OFF）もここで一元的に処理できる。<br/>
	''' ・元のイベントハンドラは AddEventHandler により自動的に呼び出される。<br/>
	''' ・ログは開始と終了の 2 回出力される。
	''' </remarks>
	Private Shared Sub AddHandlerDirect(ctrl As Control, ev As EventInfo, key As String)

		Dim form As Form = ctrl.FindForm()
		Dim eventName As String = key
		Dim logAttr As New LogAttribute

		Dim wrapper As EventHandler =
			Sub(sender As Object, e As EventArgs)

				Try
					' ----------------------------------------------------
					' CheckBox / RadioButton の ON/OFF 状態を取得
					' ----------------------------------------------------
					Dim stateInfo As String = ""

					If TypeOf ctrl Is Button Then
						Dim bt = DirectCast(ctrl, Button)
						stateInfo = "クリック"

					ElseIf TypeOf ctrl Is CheckBox Then
						Dim cb = DirectCast(ctrl, CheckBox)
						stateInfo = If(cb.Checked, "ON", "OFF")

					ElseIf TypeOf ctrl Is RadioButton Then
						Dim rb = DirectCast(ctrl, RadioButton)
						stateInfo = If(rb.Checked, "ON", "OFF")

						' ComboBox の選択表示項目
					ElseIf TypeOf ctrl Is ComboBox Then
						Dim cmb = DirectCast(ctrl, ComboBox)
						Dim selectedText As String = If(cmb.Text, "")
						stateInfo = $"選択: {selectedText}"

						' TextBox の入力内容（LostFocus 時のみ）
					ElseIf TypeOf ctrl Is TextBox AndAlso ev.Name = "LostFocus" Then
						Dim tb = DirectCast(ctrl, TextBox)
						stateInfo = $"入力: {tb.Text}"

					End If

					logAttr.EvemtName = ev.Name
					logAttr.ControlName = "[" & ctrl.Text & "] " & GetJapaneseControlName(ctrl)
					logAttr.FormName = "[" & form.Text & "]" & " 画面"

					'Dim eventName As String = ev.Name
					Dim formName As String = "[" & ctrl.Text & "]" & GetJapaneseControlName(ctrl)
					Dim controlName As String = form.Text & "画面"


					' ----------------------------------------------------
					' ログ出力（開始）
					' ----------------------------------------------------
					If stateInfo <> "" Then
						'LogService.Write(form.Text, eventName, $"開始 ({stateInfo})")
						logAttr.EvemtName &= $" ({stateInfo})"
						LogService.Write(logAttr.FormName, logAttr.ControlName, logAttr.EvemtName, "", logAttr.Level, logAttr.ErrorCode, logAttr.Template)
					Else
						'LogService.Write(form.Text, eventName, "開始")
						LogService.Write(logAttr.FormName, logAttr.ControlName, logAttr.EvemtName, "", logAttr.Level, logAttr.ErrorCode, logAttr.Template)
					End If

					' 元のハンドラは AddEventHandler により自動で呼ばれる

					' ----------------------------------------------------
					' ログ出力（終了）
					' ----------------------------------------------------
					If stateInfo <> "" Then
						'LogService.Write(form.Text, eventName, $"終了 ({stateInfo})")
					Else
						'LogService.Write(form.Text, eventName, "終了")
					End If

				Catch ex As Exception
					logAttr.EvemtName &= $"例外: {ex.Message}"
					LogService.Write(logAttr.FormName, logAttr.ControlName, logAttr.EvemtName, "", logAttr.Level, logAttr.ErrorCode, logAttr.Template)
				End Try

			End Sub

		ev.AddEventHandler(ctrl, wrapper)
	End Sub

	'''' <summary>
	'''' 指定されたコントロールの特定イベントをラップし、
	'''' 元のイベントハンドラをログ付きのラッパーに差し替える。
	'''' </summary>
	'Private Shared Sub WrapEvent(ctrl As Control, ev As EventInfo)
	'	Debug.WriteLine("[" & ctrl.Name & "][" & ev.Name & "]")

	'	If ctrl.Name = "txtMonth" AndAlso ev.Name = "TextChanged" Then
	'		Debug.WriteLine("[" & ctrl.Name & "][" & ev.Name & "]")
	'	End If



	'	' Control.Events（EventHandlerList）取得
	'	Dim eventsProp As PropertyInfo =
	'	GetType(Control).GetProperty("Events", BindingFlags.NonPublic Or BindingFlags.Instance)
	'	If eventsProp Is Nothing Then
	'		Return
	'	End If

	'	Dim eventList As Object = eventsProp.GetValue(ctrl, Nothing)
	'	If eventList Is Nothing Then
	'		Return
	'	End If

	'	' EventKey 取得
	'	Dim key As Object = EventReflectionCache.GetEventKey(ev)
	'	If key Is Nothing Then
	'		Return
	'	End If

	'	' EventHandlerList.Item(key) プロパティ取得
	'	Dim itemProp As PropertyInfo = EventReflectionCache.GetEventListItemProperty(eventList)
	'	If itemProp Is Nothing Then
	'		Return
	'	End If

	'	' 現在登録されているイベントハンドラを取得
	'	Dim handler As [Delegate] = TryCast(itemProp.GetValue(eventList, New Object() {key}), [Delegate])
	'	If handler Is Nothing Then
	'		Return
	'	End If

	'	' フォーム単位でラップ済みチェック
	'	Dim form As Form = ctrl.FindForm()
	'	If form Is Nothing Then
	'		Return
	'	End If

	'	If ctrl.Name = "txtMonth" AndAlso ev.Name = "TextChanged" Then
	'		Debug.WriteLine("[" & ctrl.Name & "][" & ev.Name & "]")
	'	End If

	'	Dim wrapKey As String = form.Name & "." & ctrl.Name & "." & ev.Name
	'	If _wrappedEvents.Contains(wrapKey) Then
	'		Return
	'	End If
	'	_wrappedEvents.Add(wrapKey)

	'	' 元のハンドラを削除し、ラップしたハンドラを追加
	'	ev.RemoveEventHandler(ctrl, handler)
	'	Dim wrapped As [Delegate] = CreateWrappedHandler(ctrl, ev, handler, form)
	'	ev.AddEventHandler(ctrl, wrapped)
	'End Sub

	'''' <summary>
	'''' 元のイベントハンドラをラップするデリゲートを生成する。
	'''' </summary>
	'Private Shared Function CreateWrappedHandler(
	'ctrl As Control,
	'ev As EventInfo,
	'original As [Delegate],
	'form As Form) As [Delegate]

	'	Dim method As MethodInfo = original.Method

	'	' --- LogExcludeAttribute ---
	'	If method.IsDefined(GetType(LogExcludeAttribute), False) Then
	'		Return original
	'	End If

	'	' --- メソッドに付与された LogAttribute（元の属性そのもの） ---
	'	Dim methodAttr As LogAttribute =
	'	TryCast(method.GetCustomAttributes(GetType(LogAttribute), False).FirstOrDefault(), LogAttribute)

	'	' --- プリセット指定取得 ---
	'	Dim presetUse As LogPresetUseAttribute =
	'	TryCast(method.GetCustomAttributes(GetType(LogPresetUseAttribute), False).FirstOrDefault(),
	'			LogPresetUseAttribute)

	'	Dim preset As LogAttribute = Nothing
	'	If presetUse IsNot Nothing Then
	'		preset = LogPresetRegistry.GetPreset(presetUse.PresetName)
	'		If preset IsNot Nothing Then
	'			preset = preset.Clone() ' プリセット破壊防止
	'		End If
	'	End If

	'	' --- 実際に使用する LogAttribute インスタンス決定 ---
	'	Dim logAttr As LogAttribute
	'	If preset IsNot Nothing Then
	'		' プリセットがあればそれをベースに
	'		logAttr = preset.Clone()
	'	ElseIf methodAttr IsNot Nothing Then
	'		' なければメソッド属性をベースに
	'		logAttr = methodAttr.Clone()
	'	Else
	'		' どちらもなければデフォルト
	'		logAttr = New LogAttribute()
	'	End If

	'	' --- クラスデフォルト ---
	'	Dim defaultsArray As LogDefaultsAttribute() =
	'		CType(form.GetType().GetCustomAttributes(GetType(LogDefaultsAttribute), False),
	'		  LogDefaultsAttribute())

	'	Dim mergedDefaultEvents As New List(Of String)

	'	For Each d In defaultsArray
	'		If d.AllowControlEvents IsNot Nothing Then
	'			mergedDefaultEvents.AddRange(d.AllowControlEvents)
	'		End If
	'	Next

	'	' --- AllowControlEvents のマージ ---
	'	Dim merged As New List(Of String)

	'	' メソッド属性
	'	If methodAttr IsNot Nothing AndAlso methodAttr.AllowControlEvents IsNot Nothing Then
	'		merged.AddRange(methodAttr.AllowControlEvents)
	'	End If

	'	' プリセット
	'	If preset IsNot Nothing AndAlso preset.AllowControlEvents IsNot Nothing Then
	'		merged.AddRange(preset.AllowControlEvents)
	'	End If

	'	' クラスデフォルト（複数属性）
	'	merged.AddRange(mergedDefaultEvents)

	'	Dim allowEvents As String() = merged.Distinct().ToArray()

	'	' --- イベントフィルタリング ---
	'	Dim ctrlEventKey As String = ctrl.Name & "." & ev.Name
	'	If allowEvents.Length > 0 AndAlso Not allowEvents.Contains(ctrlEventKey) Then
	'		Return original
	'	End If

	'	' --- EvemtName / ControlName / FormName ---
	'	logAttr.EvemtName = ev.Name
	'	logAttr.ControlName = "[" & ctrl.Text & "] " & GetJapaneseControlName(ctrl)
	'	logAttr.FormName = "[" & form.Text & "]" & " 画面"


	'	Debug.WriteLine("[" & logAttr.FormName & "][" & logAttr.ControlName & "][" & logAttr.EvemtName & "]")

	'	'If Not ev.Name.Equals("Click") Then
	'	'	Return original
	'	'End If

	'	If Not IsLoggedEvents(ev) Then
	'		Return original
	'	End If

	'	' --- イベント名決定 ---
	'	Dim finalEventName As String = If(String.IsNullOrEmpty(logAttr.Name), $"{logAttr.ControlName}.{ev.Name}", logAttr.Name)

	'	'' --- クロージャで保持 ---
	'	'Dim eventName As String = ev.Name
	'	'Dim formName As String = "[" & ctrl.Text & "]" & GetJapaneseControlName(ctrl)
	'	'Dim controlName As String = form.Text & "画面"

	'	' --- ラップハンドラ ---
	'	Dim handler As EventHandler =
	'	Sub(sender As Object, e As EventArgs)

	'		Dim sw As Stopwatch = Nothing
	'		If logAttr.MeasureDuration Then
	'			sw = Stopwatch.StartNew()
	'		End If

	'		'LogService.Write(logAttr.FormName, logAttr.ControlName, logAttr.EvemtName, "(開始)", logAttr.Level, logAttr.ErrorCode, logAttr.Template)
	'		LogService.Write(logAttr.FormName, logAttr.ControlName, logAttr.EvemtName, "", logAttr.Level, logAttr.ErrorCode, logAttr.Template)

	'		Try
	'			original.DynamicInvoke(sender, e)

	'			If logAttr.MeasureDuration AndAlso sw IsNot Nothing Then
	'				sw.Stop()
	'				'LogService.Write(logAttr.FormName, logAttr.ControlName, $"{logAttr.EvemtName}", "(終了) ({sw.ElapsedMilliseconds}ms)", logAttr.Level, logAttr.ErrorCode, logAttr.Template)
	'			Else
	'				'LogService.Write(logAttr.FormName, logAttr.ControlName, $"{logAttr.EvemtName}", "(終了)", logAttr.Level, logAttr.ErrorCode, logAttr.Template)
	'			End If

	'		Catch ex As Exception
	'			LogService.Write(logAttr.FormName, logAttr.ControlName, ex.GetType().Name, "例外: " & ex.Message, LogLevels.Error, logAttr.ErrorCode, logAttr.Template)
	'			ErrorFacade.Report(ex, ErrorContext.Manual)
	'		End Try
	'	End Sub

	'	Return [Delegate].CreateDelegate(ev.EventHandlerType, handler.Target, handler.Method)
	'End Function

	Private Shared Function GetJapaneseControlName(ctrl As Control) As String
		Dim typeName As String = ctrl.GetType().Name

		If ControlTypeToJapanese.ContainsKey(typeName) Then
			Return ControlTypeToJapanese(typeName)
		End If

		' 未登録の型は型名そのまま返す
		Return typeName
	End Function

	'Private Shared Function GetJapaneseEventName(ByVal ev As EventInfo) As String
	'	Dim typeName As String = ev.Name

	'	If ControlTypeToJapanese.ContainsKey(typeName) Then
	'		Return ControlTypeToJapanese(typeName)
	'	End If

	'	' 未登録の型は型名そのまま返す
	'	Return typeName
	'End Function

	'Private Shared Function IsLoggedEvents(ByVal eventInfo As EventInfo) As Boolean
	'	Dim targetEvents As New List(Of String)(
	'				{"Click", "SelectedIndexChanged", "TextChanged", "CheckedChanged"}
	'			)
	'	Return targetEvents.Contains(eventInfo.Name)
	'End Function

End Class
