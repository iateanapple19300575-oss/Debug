﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmValidationErrors
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.dtGridView = New System.Windows.Forms.DataGridView()
		CType(Me.dtGridView, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'dtGridView
		'
		Me.dtGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.dtGridView.Dock = System.Windows.Forms.DockStyle.Fill
		Me.dtGridView.Location = New System.Drawing.Point(0, 0)
		Me.dtGridView.Name = "dtGridView"
        Me.dtGridView.RowHeadersVisible = False
        Me.dtGridView.RowHeadersWidth = 80
        Me.dtGridView.RowTemplate.Height = 21
        Me.dtGridView.Size = New System.Drawing.Size(984, 461)
        Me.dtGridView.TabIndex = 1
		'
		'FrmValidationErrors
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 461)
        Me.Controls.Add(Me.dtGridView)
        Me.Name = "FrmValidationErrors"
        Me.Text = "Form1"
        CType(Me.dtGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

	Protected WithEvents dtGridView As Windows.Forms.DataGridView
End Class
