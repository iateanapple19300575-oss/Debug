﻿Imports System.Data.SqlClient

''' <summary>
''' [T_Operation_Log]テーブル
''' </summary>
Public Class OperationLogTran
	Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 操作ログINSERT[T_Operation_Log]
    ''' </summary>
    ''' <param name="winName">画面名</param>
    ''' <param name="content">操作内容</param>
    ''' <param name="detail">詳細内容</param>
    Public Shared Sub Append(ByVal winName As String, ByVal content As String, Optional detail As String = "")

		' ログ登録用SQL文
		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("INSERT INTO ")
        sqlString.Append("  " & DBTableConst.TABLE_NAME_OPRATION_LOG).Append(" ")
        sqlString.Append("  ( ").Append(" ")
        sqlString.Append("    Event_Date_Time").Append(" ")
        sqlString.Append("    , Window_Name").Append(" ")
        sqlString.Append("    , Event_Content").Append(" ")
        sqlString.Append("    , Event_Details").Append(" ")
        sqlString.Append("    , Target_Date").Append(" ")
        sqlString.Append("    , Exe_Name").Append(" ")
        sqlString.Append("    , User_Id").Append(" ")
        sqlString.Append("    , Pc_Id").Append(" ")
        sqlString.Append("    , Execution_Date").Append(" ")
        sqlString.Append("    , Create_Date").Append(" ")
        sqlString.Append("    , Create_User").Append(" ")
        sqlString.Append("  ) VALUES ( ").Append(" ")
        sqlString.Append("    @Event_Date_Time").Append(" ")
        sqlString.Append("    , @Window_Name").Append(" ")
        sqlString.Append("    , @Event_Content").Append(" ")
        sqlString.Append("    , @Event_Details").Append(" ")
        sqlString.Append("    , @Target_Date").Append(" ")
        sqlString.Append("    , @Exe_Name").Append(" ")
        sqlString.Append("    , @User_Id").Append(" ")
        sqlString.Append("    , @Pc_Id").Append(" ")
        sqlString.Append("    , GETDATE()").Append(" ")
        sqlString.Append("    , GETDATE()").Append(" ")
        sqlString.Append("    , @Create_User").Append(" ")
        sqlString.Append("  )").Append(" ")
        sqlString.Append(";").Append(" ")


        ' ログ出力項目の整理
        Dim assemblyName As String = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name
		Dim exeName As String = System.IO.Path.GetFileName(System.Windows.Forms.Application.ExecutablePath)
		Dim targetDateW As Object = DBNull.Value
		If Not DateUtil.IsNullOrEmpty(AppState.TargetYearMonth) Then
			targetDateW = String.Format("{0}/{1}",
								AppState.TargetYearMonth.Year.ToString("0000;[0000]"),
								AppState.TargetYearMonth.Month.ToString("00;[00]"))
		End If

		Try
            SqlCommandExecutor.ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@Event_Date_Time", .Value = DateTime.Now},
                New SqlParameter() With {.ParameterName = "@Window_Name", .Value = LogScreenName(winName)},
                New SqlParameter() With {.ParameterName = "@Event_Content", .Value = content},
                New SqlParameter() With {.ParameterName = "@Event_Details", .Value = detail},
                New SqlParameter() With {.ParameterName = "@Target_Date", .Value = targetDateW},
                New SqlParameter() With {.ParameterName = "@Exe_Name", .Value = exeName},
                New SqlParameter() With {.ParameterName = "@User_Id", .Value = AppState.CurrentUserName},
                New SqlParameter() With {.ParameterName = "@Pc_Id", .Value = AppState.CurrentPcName},
                New SqlParameter() With {.ParameterName = "@Create_User", .Value = AppState.CurrentUserName}
            )

        Catch ex As Exception

		End Try

	End Sub

	''' <summary>
	''' ログ出力用画面名取得
	''' </summary>
	''' <param name="name"></param>
	''' <returns></returns>
	Private Shared Function LogScreenName(ByVal name As String) As String
		Return name & ""
	End Function
End Class
