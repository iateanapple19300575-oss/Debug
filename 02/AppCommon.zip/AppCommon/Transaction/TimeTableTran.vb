﻿Public Class TimeTableTran
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 全データ件数取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetAllDataCount() As ResultData
        Return GetAllCount(DBTableConst.TABLE_NAME_TIMETABLE_SITE)
    End Function

    ''' <summary>
    ''' 全データ削除
    ''' </summary>
    ''' <returns></returns>
    Public Function Truncate() As ResultData
        Return DeleteAllData(DBTableConst.TABLE_NAME_TIMETABLE_SITE)
    End Function

End Class
