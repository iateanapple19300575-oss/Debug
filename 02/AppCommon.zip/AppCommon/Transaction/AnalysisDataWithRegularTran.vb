﻿Imports System.Data.SqlClient

''' <summary>
''' 出講データ(通常)トラン
''' </summary>
Public Class AnalysisDataWithRegularTran
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    '''' <summary>
    '''' 集計用出講データ作成
    '''' </summary>
    '''' <param name="targetDate"></param>
    '''' <param name="phase"></param>
    '''' <param name="dataType"></param>
    '''' <returns></returns>
    'Public Function AnalysisCreateData(ByVal targetDate As Date, ByVal phase As Integer, ByVal dataType As Integer) As ResultData

    '	Dim resultData As New ResultData
    '	Dim importCount As Integer = 0
    '	Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
    '	Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

    '	Dim SqlQuery As New System.Text.StringBuilder
    '	SqlQuery.Length = 0
    '	SqlQuery.Append("INSERT INTO").Append(" ")
    '	SqlQuery.Append("  ").Append(W_Lecture_ActualEnum.フェーズ.Table).Append(" ")
    '	SqlQuery.Append("SELECT ")
    '	SqlQuery.Append("    ").Append(phase).Append(" As ").Append(W_Lecture_ActualEnum.フェーズ.Column).Append(" ")
    '	SqlQuery.Append("  , ").Append(dataType).Append(" As ").Append(W_Lecture_ActualEnum.データ種別.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.講師コード.Column).Append(" As ").Append(W_Lecture_ActualEnum.講師コード.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" As ").Append(W_Lecture_ActualEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.コマ.Column).Append(" As ").Append(W_Lecture_ActualEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.教室コード.Column).Append(" As ").Append(W_Lecture_ActualEnum.教室コード.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.学年.Column).Append(" As ").Append(W_Lecture_ActualEnum.学年.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.クラスコード.Column).Append(" As ").Append(W_Lecture_ActualEnum.クラスコード.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.科目.Column).Append(" As ").Append(W_Lecture_ActualEnum.科目.Column).Append(" ")
    '	SqlQuery.Append("  , RH.").Append(W_Lecture_PlanEnum.テキスト回.Column).Append(" As ").Append(W_Lecture_ActualEnum.テキスト回.Column).Append(" ")
    '	SqlQuery.Append("  , RS.").Append(M_Timetable_SiteEnum.開始時間.Column).Append(" As ").Append(W_Lecture_ActualEnum.開始時間.Column).Append(" ")
    '	SqlQuery.Append("  , RS.").Append(M_Timetable_SiteEnum.終了時間.Column).Append(" As ").Append(W_Lecture_ActualEnum.終了時間.Column).Append(" ")
    '	SqlQuery.Append("  , NULL").Append(" As ").Append(W_Lecture_ActualEnum.ピンチ種別.Column).Append(" ")
    '	SqlQuery.Append("FROM").Append(" ")
    '	SqlQuery.Append("    " & W_Lecture_PlanEnum.日付.Table & " RH ")
    '	SqlQuery.Append("    LEFT JOIN " & M_Time_PatternEnum.年月日.Table & " SP ")
    '	SqlQuery.Append("        ON (").Append(" ")
    '	SqlQuery.Append("            RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" =")
    '	SqlQuery.Append("            FORMAT(SP.").Append(M_Time_PatternEnum.年月日.Column).Append(", 'yyyyMMdd')").Append(" ")
    '	SqlQuery.Append("        )").Append(" ")
    '	SqlQuery.Append("    LEFT JOIN " & M_Timetable_SiteEnum.年.Table & " RS ")
    '	SqlQuery.Append("        ON (").Append(" ")
    '	SqlQuery.Append("              RS.").Append(M_Timetable_SiteEnum.教室コード.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("              RH.").Append(W_Lecture_PlanEnum.教室コード.Column).Append(" ")
    '	SqlQuery.Append("          AND RS.").Append(M_Timetable_SiteEnum.日程パターン名.Column).Append(" =")
    '	SqlQuery.Append("              SP.").Append(M_Time_PatternEnum.日程パターン名.Column).Append(" ")
    '	SqlQuery.Append("          AND RS.").Append(M_Timetable_SiteEnum.コマ.Column).Append(" =").Append(" ")
    '	SqlQuery.Append("              RH.").Append(W_Lecture_PlanEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append("        )").Append(" ")
    '	SqlQuery.Append("WHERE").Append(" ")
    '	SqlQuery.Append("    1= 1").Append(" ")
    '	SqlQuery.Append("  AND RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" >= " & "@日付1" & " ")
    '	SqlQuery.Append("  AND RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" <= " & "@日付2" & " ")
    '	SqlQuery.Append(" ")
    '	SqlQuery.Append("ORDER BY").Append(" ")
    '	SqlQuery.Append("      RH.").Append(W_Lecture_PlanEnum.講師コード.Column).Append(" ")
    '	SqlQuery.Append("    , RH.").Append(W_Lecture_PlanEnum.日付.Column).Append(" ")
    '	SqlQuery.Append("    , RH.").Append(W_Lecture_PlanEnum.コマ.Column).Append(" ")
    '	SqlQuery.Append("; ")

    '	Try
    '		Using sqlConnection As New SqlConnection(ConnectString)
    '			sqlConnection.Open()

    '			'本科実績データ投入
    '			Dim sqlCommand As SqlCommand
    '			sqlCommand = New SqlCommand(SqlQuery.ToString(), sqlConnection)
    '			resultData.DataCount = sqlCommand.ExecuteNonQuery()
    '		End Using

    '	Catch ex As SqlException
    '		resultData.Success = False
    '		resultData.ErrorCode = ex.Number
    '		Throw

    '	Catch ex As Exception
    '		resultData.Success = False
    '		Throw

    '	Finally

    '	End Try

    '	Return resultData
    'End Function
End Class
