﻿Imports System.Data.SqlClient

Public Class TransactionBase

    ''' <summary>
    ''' コネクションオブジェクト
    ''' </summary>
    Protected ReadOnly Property SQLConnection As SqlConnection

    ''' <summary>
    ''' トランザクションオブジェクト
    ''' </summary>
    Protected ReadOnly Property SQLTransaction As SqlTransaction

    ''' <summary>
    ''' コマンドオブジェクト
    ''' </summary>
    Protected ReadOnly Property SQLCommand As SqlCommand


    Protected Property ConnectString As String = SqlDataBaseUtil.GetConnectionString()


    Protected ReadOnly Property Connection As SqlConnection
    Protected ReadOnly Property Transaction As SqlTransaction

    Private _exec As SqlExecutor



    Public Sub New()
        Me._exec = New SqlExecutor(ConnectString)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        Me.Connection = sqDblConn.Connection
        Me.Transaction = sqDblConn.Transaction
        Me._exec = New SqlExecutor(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        Me.Connection = sqDblConn.Connection
        Me.Transaction = sqDblConn.Transaction
        Me._exec = New SqlExecutor(ConnectString)
    End Sub

    ''' <summary>
    ''' INSERT/UPDATE/DELE実行
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteNonQuery(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Integer
        Return _exec.ExecuteNonQuery(sql, parameters)
    End Function

    ''' <summary>
    ''' 1データ取得
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteScalar(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Object
        Return _exec.ExecuteScalar(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:DataTable)
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected  Function ExecuteDataTable(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As DataTable
        Return _exec.ExecuteDataTable(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:Dictionary(Of String, String))
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Shared Function ExecuteDictionary(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Dictionary(Of String, String)
        Return SqlCommandExecutor.ExecuteDictionary(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:Dictionary(Of String, String))
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExcuteQuery(Of T As New)(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As List(Of T)
        Return _exec.QueryList(Of T)(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:T)
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExcuteQuerySingle(Of T As New)(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As T
        Return _exec.QuerySingle(Of T)(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:ExecuteReader)
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteReader(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As SqlDataReader
        Return _exec.ExecuteReader(sql, parameters)
    End Function

    Public Const COLUMN_COUNT As String = "Count"


    '' <summary>
    '' 全データ件数取得
    '' </summary>
    '' <returns></returns>
    Protected Overridable Function GetAllCount(ByVal tableName As String) As ResultData
        Dim resultData As New ResultData
        Dim recData As New Dictionary(Of String, String)

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT TOP 1 ")
        sqlString.Append("    COUNT(*) As " & COLUMN_COUNT & " ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & tableName & " ")
        sqlString.Append("; ")

        Try
            Using sqlConnection As New SqlConnection(ConnectString)
                sqlConnection.Open()

                'Dim sqlCommand As SqlCommand
                'sqlCommand = New SqlCommand(sqlString.ToString(), sqlConnection)
                'resultData.DataCount = sqlCommand.ExecuteNonQuery()
                Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
                    Dim count As Integer = 0
                    Using reader As SqlDataReader = commandSourceData.ExecuteReader()
                        While reader.Read()
                            recData.Add(COLUMN_COUNT, reader.GetValue(reader.GetOrdinal(COLUMN_COUNT)))
                            count += 1
                        End While
                    End Using
                    resultData.Success = True
                    resultData.ResDicString = recData
                    resultData.DataCount = count
                End Using
            End Using
            resultData.Success = True

        Catch ex As SqlException
            resultData.Success = False
            resultData.ErrorCode = ex.Number
            Throw

        Catch ex As Exception
            resultData.Success = False

        Finally

        End Try

        Return resultData
    End Function

    ''' <summary>
    ''' 全データ削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteAllData(ByVal tableName As String) As ResultData
        Dim resultData As New ResultData()

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & tableName & " ")
        sqlString.Append("; ")

        Try
            Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                con.Open()

                Dim affectedRows As Integer = 0
                Using cmd As New SqlCommand(sqlString.ToString(), con)
                    affectedRows = cmd.ExecuteNonQuery()
                End Using

                con.Close()
                resultData.Success = True
                resultData.DataCount = affectedRows
            End Using
            resultData.SubStatus = True
        Catch ex As Exception
            resultData.Success = False
        Finally
        End Try

        Return resultData
    End Function

End Class
