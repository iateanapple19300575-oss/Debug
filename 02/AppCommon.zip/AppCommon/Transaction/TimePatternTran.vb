﻿Imports System.Data.SqlClient

Public Class TimePatternTran
  Inherits TransactionBase

  ' データ格納期間取得用
  Public Const FINAL_START_DATE As String = "開始日"
    Public Const FINAL_END_DATE As String = "終了日"

    ' 対象年月取得用
    Public Const LECTURE_YEAR_MONTH As String = "lecture_date"

    Private Const V_COLUMN_TITLE As String = "Title"
    Private Const V_COLUMN_FIRST_DAY As String = "FirstDay"
    Private Const V_COLUMN_LAST_DAY As String = "LastDay"
    Private Const V_COLUMN_YEAR As String = "Year"
    Private Const V_COLUMN_MONTH As String = "Month"

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 全データ件数取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetAllDataCount() As ResultData
        Return GetAllCount(DBTableConst.TABLE_NAME_TIME_PATTERN)
    End Function

    ''' <summary>
    ''' 全データ削除
    ''' </summary>
    ''' <returns></returns>
    Public Function Truncate() As ResultData
        Return DeleteAllData(DBTableConst.TABLE_NAME_TIME_PATTERN)
    End Function

    ''' <summary>
    ''' データ格納期間取得（全体）
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' テーブル全体の最初と最後の対象日付を取得する。
    ''' </remarks>
    Public Function GetDataStoragePeriod() As ResultData
        Dim resultData As New ResultData
        Dim recData As New Dictionary(Of String, String)

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT TOP 1 ")
		sqlString.Append("    MIN(Lecture_Date) as " & FINAL_START_DATE & " ")
		sqlString.Append("    , MAX(Lecture_Date) as " & FINAL_END_DATE & " ")
		sqlString.Append("FROM ")
        sqlString.Append("    " & DBTableConst.TABLE_NAME_TIME_PATTERN & " ")
        sqlString.Append("; ")

        Try
            Using sqlConnection As New SqlConnection(ConnectString)
                sqlConnection.Open()

				'Dim sqlCommand As SqlCommand
				'sqlCommand = New SqlCommand(sqlString.ToString(), sqlConnection)
				'resultData.DataCount = sqlCommand.ExecuteNonQuery()
				Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
                    Dim count As Integer = 0
                    Using reader As SqlDataReader = commandSourceData.ExecuteReader()
                        While reader.Read()
                            recData.Add(FINAL_START_DATE, reader.GetValue(reader.GetOrdinal(FINAL_START_DATE)))
                            recData.Add(FINAL_END_DATE, reader.GetValue(reader.GetOrdinal(FINAL_END_DATE)))
                            count += 1
                        End While
                    End Using
                    resultData.ResDicString = recData
                    resultData.DataCount = count
                End Using
                resultData.Success = True
            End Using

        Catch ex As SqlException
            resultData.Success = False
            resultData.ErrorCode = ex.Number
            Throw

        Catch ex As Exception
            resultData.Success = False

        Finally

        End Try

        Return resultData
    End Function

    ''' <summary>
    ''' 対象年月取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetLectureYearMonth() As ResultData
        Dim resultData As New ResultData
        Dim recData As New List(Of String)

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
		sqlString.Append("SELECT").Append(" ")
		sqlString.Append("  FORMAT(").Append(M_Time_PatternEnum.年月日.Column).Append(", 'yyyy年MM月') AS").Append(" ")
		sqlString.Append("  ").Append(M_Time_PatternEnum.年月日.Column).Append(" ")
		sqlString.Append("FROM").Append(" ")
		sqlString.Append("  ").Append(M_Time_PatternEnum.年度.Table).Append(" ")
		sqlString.Append("GROUP BY").Append(" ")
		sqlString.Append("  FORMAT(").Append(M_Time_PatternEnum.年月日.Column).Append(", 'yyyy年MM月')").Append(" ")
		sqlString.Append("ORDER BY").Append(" ")
		sqlString.Append("  FORMAT(").Append(M_Time_PatternEnum.年月日.Column).Append(", 'yyyy年MM月') DESC").Append(" ")
		sqlString.Append("; ")

		Try
            Using sqlConnection As New SqlConnection(ConnectString)
                sqlConnection.Open()

				'Dim sqlCommand As SqlCommand
				'sqlCommand = New SqlCommand(sqlString.ToString(), sqlConnection)
				'resultData.DataCount = sqlCommand.ExecuteNonQuery()
				Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
                    Dim count As Integer = 0
                    Using reader As SqlDataReader = commandSourceData.ExecuteReader()
                        While reader.Read()
                            recData.Add(reader.GetValue(reader.GetOrdinal(LECTURE_YEAR_MONTH)))
                            count += 1
                        End While
                    End Using
                    resultData.Success = True
                    resultData.ResList = recData
                    resultData.DataCount = count
                End Using
            End Using

        Catch ex As SqlException
            resultData.Success = False
            resultData.ErrorCode = ex.Number
            Throw

        Catch ex As Exception
            resultData.Success = False

        Finally

        End Try

        Return resultData
    End Function

End Class
