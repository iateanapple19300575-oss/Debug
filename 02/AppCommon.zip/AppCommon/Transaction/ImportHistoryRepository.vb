﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class ImportHistoryRepository
    Inherits TransactionBase

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sqDblConn As TransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' データ種別ごとの最終履歴データ取得
    ''' </summary>
    ''' <param name="p_yearMonth">対象年月(yyyyMM)</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' データ取込種別毎に最後の取込履歴データを取得する。
    ''' </remarks>
    Public Function HistoryFinalDateAll(Optional ByVal p_yearMonth As String = "") As List(Of HistoryImportDto)
        Dim resultData As New ResultData()
        Dim resDic As New Dictionary(Of String, IData)

        'Try
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("    HI." & T_History_ImportEnum.CSV種別.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.データ分類.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.データ名.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.ファイル名.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.対象年月.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.データ件数.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.実行PC.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.実行ユーザ.Column).Append(" ")
        sqlString.Append("  , HI." & T_History_ImportEnum.実行日.Column).Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & T_History_ImportEnum.CSV種別.Table).Append(" HI").Append(" ")
        sqlString.Append("  INNER JOIN (").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("            " & T_History_ImportEnum.CSV種別.Column).Append(" ")
        sqlString.Append("      , MAX(" & T_History_ImportEnum.実行日.Column).Append(")").Append(" ")
        sqlString.Append("AS " & T_History_ImportEnum.実行日.Column).Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      " & T_History_ImportEnum.CSV種別.Table).Append(" HI").Append(" ")
        sqlString.Append("    WHERE 1=1").Append(" ")

        If StringUtil.IsNotNullOrWhiteSpace(p_yearMonth) Then
            sqlString.Append("  AND (HI." & T_History_ImportEnum.データ分類.Column).Append(" = 'T'").Append(" ")
            sqlString.Append("   AND HI." & T_History_ImportEnum.対象年月.Column).Append(" =").Append(" ")
            sqlString.Append("         @" & T_History_ImportEnum.対象年月.Column).Append(")").Append(" ")
            sqlString.Append("   Or (HI." & T_History_ImportEnum.データ分類.Column).Append(" = 'M'").Append(") ")
            sqlString.Append(" ")
        Else
            sqlString.Append("  AND (HI." & T_History_ImportEnum.データ分類.Column).Append(" = 'T'").Append(" Or ")
            sqlString.Append("       HI." & T_History_ImportEnum.データ分類.Column).Append(" = 'M'").Append(") ")
        End If

        sqlString.Append("    GROUP BY").Append(" ")
        sqlString.Append("      " & T_History_ImportEnum.CSV種別.Column).Append(" ")
        sqlString.Append("  ) IJHI").Append(" ")
        sqlString.Append("    ON (").Append(" ")
        sqlString.Append("          HI." & T_History_ImportEnum.CSV種別.Column).Append(" =").Append(" ")
        sqlString.Append("        IJHI." & T_History_ImportEnum.CSV種別.Column).Append(" ")
        sqlString.Append("      AND HI." & T_History_ImportEnum.実行日.Column).Append(" =").Append(" ")
        sqlString.Append("        IJHI." & T_History_ImportEnum.実行日.Column).Append(" ")
        sqlString.Append("    )").Append(" ")
        sqlString.Append("; ")

        Return ExcuteQuery(Of HistoryImportDto)(sqlString.ToString(),
                        New SqlParameter() With {.ParameterName = T_History_ImportEnum.対象年月.Param, .Value = p_yearMonth}
                    )
    End Function

End Class
