﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class ReportLectureFeeService

    ''' <summary>
    ''' 対象年月度
    ''' </summary>
    Private Property TargetDate As Date

    '''' <summary>
    '''' 勤怠情報ドメインサービス
    '''' </summary>
    'Private _domain As New ReportLectureFeeDomain

    '''' <summary>
    '''' 勤怠情報リポジトリ
    '''' </summary>
    'Private _repository As New AttendanceRepository


    ''' <summary>
    ''' 勤怠情報ドメインサービス
    ''' </summary>
    Private _domain As AttendanceDomain

    ''' <summary>
    ''' 勤怠情報リポジトリ
    ''' </summary>
    Private _repository As New AttendanceRepository


    Public Sub New(ByVal p_targetDate As Date)
        TargetDate = p_targetDate
    End Sub


    ''' <summary>
    ''' データ取得(DataTable版)
    ''' </summary>
    ''' <returns></returns>
    Public Function GetDataForDataTable(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _domain = New AttendanceDomain(uow)
                dataList = _domain.LoadData(param)
                modelList = _domain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)

                dt = _domain.WorkListToDataTable(modelList)
            End Using

        Catch ex As Exception

        End Try

        Return dt
    End Function

    ''' <summary>
    ''' 打刻・出講実績・業務届・出講予定日次データ格納用 DataTable定義
    ''' </summary>
    Private Sub DataTableDefinition(ByRef dtTable As DataTable)

        ' 勤怠(出勤・退勤・開始・終了)関連
        dtTable.Columns.Add("講師ｺｰﾄﾞ", GetType(String))
        dtTable.Columns.Add("講師名", GetType(String))
        dtTable.Columns.Add("日付", GetType(String))
        dtTable.Columns.Add("状態", GetType(String))
        dtTable.Columns.Add("出勤時刻", GetType(String))
        dtTable.Columns.Add("退勤時刻", GetType(String))
        dtTable.Columns.Add("勤務開始時間", GetType(String))
        dtTable.Columns.Add("勤務終了時間", GetType(String))
        dtTable.Columns.Add("時間(みなし)", GetType(Decimal))
        dtTable.Columns.Add("出講開始時間", GetType(String))
        dtTable.Columns.Add("出講終了時間", GetType(String))
        dtTable.Columns.Add("業務届開始時間", GetType(String))
        dtTable.Columns.Add("業務届終了時間", GetType(String))
        dtTable.Columns.Add("開始(予定)", GetType(String))
        dtTable.Columns.Add("終了(予定)", GetType(String))

        ' コマ関連
        dtTable.Columns.Add("1年生", GetType(Integer))
        dtTable.Columns.Add("2年生", GetType(Integer))
        dtTable.Columns.Add("3年生", GetType(Integer))
        dtTable.Columns.Add("4年生", GetType(Integer))
        dtTable.Columns.Add("5年生", GetType(Integer))
        dtTable.Columns.Add("6年生", GetType(Integer))
        dtTable.Columns.Add("コマ数", GetType(Integer))
        dtTable.Columns.Add("コマ単価", GetType(Decimal))
        dtTable.Columns.Add("授業給", GetType(Decimal))

        For i As Integer = 1 To 6
            dtTable.Columns.Add("教室" & i, GetType(String))
            dtTable.Columns.Add("学年" & i, GetType(Integer))
            dtTable.Columns.Add("ｸﾗｽ" & i, GetType(String))
            dtTable.Columns.Add("コマ" & i, GetType(Integer))
            dtTable.Columns.Add("開始" & i, GetType(String))
            dtTable.Columns.Add("終了" & i, GetType(String))
            dtTable.Columns.Add("ﾋﾟﾝﾁ" & i, GetType(String))
            dtTable.Columns.Add("交通費" & i, GetType(String))
        Next

        ' 交通費
        dtTable.Columns.Add("交通費-1", GetType(String))
        dtTable.Columns.Add("交通費-2", GetType(String))
        dtTable.Columns.Add("交通費-3", GetType(String))

        dtTable.Columns.Add("基本報酬", GetType(Decimal))
        dtTable.Columns.Add("日報酬額", GetType(Decimal))
        dtTable.Columns.Add("コマ給計", GetType(Decimal))
        dtTable.Columns.Add("打刻回数", GetType(Decimal))



        ' 画面表示処理関連情報
        dtTable.Columns.Add("打出勤色", GetType(String))
        dtTable.Columns.Add("打退勤色", GetType(String))
        dtTable.Columns.Add("実出勤色", GetType(String))
        dtTable.Columns.Add("実退勤色", GetType(String))
        dtTable.Columns.Add("日付色", GetType(String))

        'Return dtTable
    End Sub

    ''' <summary>
    ''' DataReaderからデータ取得
    ''' </summary>
    ''' <param name="reader"></param>
    ''' <returns></returns>
    Private Function DataTableMapping(ByVal reader As SqlDataReader) As DataTable

        Dim dtTable As New DataTable
        DataTableDefinition(dtTable)
        Try
            While reader.Read()
                Dim rowRec As DataRow = dtTable.NewRow()
                Dim work As String = ""
                rowRec("講師ｺｰﾄﾞ") = GetStringSafe(reader, "Teacher_Code")
                rowRec("講師名") = GetStringSafe(reader, "Teacher_Name")
                rowRec("日付") = SqlDataReaderUtil.GetValue(reader, "Lecture_Date")
                rowRec("出勤時刻") = GetTimeSpanSafe(reader, "出勤時刻")
                rowRec("退勤時刻") = GetTimeSpanSafe(reader, "退勤時刻")
                rowRec("出講開始時間") = GetTimeSpanSafe(reader, "出講開始時間")
                rowRec("出講終了時間") = GetTimeSpanSafe(reader, "出講終了時間")
                rowRec("業務届開始時間") = GetTimeSpanSafe(reader, "業務届開始時間")
                rowRec("業務届終了時間") = GetTimeSpanSafe(reader, "業務届終了時間")

                'For i As Integer = 1 To 6
                '    Dim koma As String = SqlDataReaderUtil.GetValue(reader, i & "年生")
                '    If StringUtil.IsNotNullOrWhiteSpace(koma) Then
                '        rowRec(i & "年生") = Integer.Parse(koma)
                '    End If
                'Next

                rowRec("交通費-1") = ""
                rowRec("交通費-2") = ""
                rowRec("交通費-3") = ""

                Dim countValue As String = ""
                For i = 1 To 6
                    rowRec("教室" & i) = SqlDataReaderUtil.GetValue(reader, "出講教室" & i)

                    countValue = SqlDataReaderUtil.GetValue(reader, "出講学年" & i)
                    If StringUtil.IsNotNullOrWhiteSpace(countValue) Then
                        rowRec("学年" & i) = Integer.Parse(countValue)
                    End If

                    rowRec("ｸﾗｽ" & i) = SqlDataReaderUtil.GetValue(reader, "出講クラス" & i)

                    countValue = SqlDataReaderUtil.GetValue(reader, "出講コマ" & i)
                    If StringUtil.IsNotNullOrWhiteSpace(countValue) Then
                        rowRec("コマ" & i) = Integer.Parse(countValue)
                    End If

                    rowRec("開始" & i) = SqlDataReaderUtil.GetValue(reader, "出講開始" & i)
                    rowRec("終了" & i) = SqlDataReaderUtil.GetValue(reader, "出講終了" & i)
                    rowRec("ﾋﾟﾝﾁ" & i) = Trim(SqlDataReaderUtil.GetValue(reader, "出講ピンチ" & i))
                    rowRec("交通費" & i) = SqlDataReaderUtil.GetValue(reader, "交通費" & i)
                Next

                Dim transpo As New Dictionary(Of String, String)
                For i As Integer = 1 To 6
                    Dim room1 As String = rowRec("教室" & i)
                    Dim amount As String = rowRec("交通費" & i)
                    If StringUtil.IsNotNullOrWhiteSpace(room1) Then
                        If Not transpo.ContainsKey(room1) Then
                            transpo.Add(room1, amount)
                        End If
                    End If
                Next

                Dim idx1 As Integer = 1
                If transpo.Count > 0 Then
                    For Each kvp As KeyValuePair(Of String, String) In transpo
                        Dim key As String = kvp.Key
                        Dim value As String = kvp.Value
                        If StringUtil.IsNullOrWhiteSpace(value) Then
                            rowRec("交通費-" & idx1) = key & "：" & "未"
                        Else
                            Dim roundTrip As Double = Math.Round(Double.Parse(value), 1, MidpointRounding.AwayFromZero) * 2
                            rowRec("交通費-" & idx1) = key & "" & ""
                        End If
                        idx1 += 1
                    Next
                End If

                rowRec("打刻回数") = SqlDataReaderUtil.GetValueWithNothing(reader, "打刻回数")

                Dim model As New AttendanceModel()
                ' 打刻関連
                model.PunchStartTime = GetTimeSpanSafe(rowRec, "出勤時刻")
                model.PunchEndTime = GetTimeSpanSafe(rowRec, "退勤時刻")
                model.LectureStart = GetTimeSpanSafe(rowRec, "出講開始時間")
                model.LectureEnd = GetTimeSpanSafe(rowRec, "出講終了時間")
                model.TaskStart = GetTimeSpanSafe(rowRec, "業務届開始時間")
                model.TaskEnd = GetTimeSpanSafe(rowRec, "業務届終了時間")
                model.NumberOfPunched = GetByteSafe(rowRec, "打刻回数")

                ' みなし授業前時間、みなし授業後時間
                model.DeemedTimeBefore = GetTimeSpanSafe(reader, "Deemed_Time_Before")
                model.DeemedTimeAfter = GetTimeSpanSafe(reader, "Deemed_Time_After")

                ' みなし勤務開始・終了時間算出（出講、業務届考慮）
                model.DeemedStartTime = CalcDeemedTimeStart(model)
                model.DeemedEndTime = CalcDeemedTimeEnd(model)
                Dim ts As TimeSpan?
                ts = CalcScheduleStartTime(model)
                rowRec("実務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcScheduleEndTime(model)
                rowRec("実務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeStart(model)
                rowRec("勤務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeEnd(model)
                rowRec("勤務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)

                ' 時間重複(打刻・打刻外業務給)
                model.OverlapOther = GetIntSafe(rowRec, "打刻外業務重複")

                ' 時間重複(出講内)
                model.OverlapLecture = GetIntSafe(rowRec, "出講授業重複")

                ' 時間重複(出講・業務届)
                model.OverlapLectTask = GetIntSafe(rowRec, "出講業務届重複")

                ' 交通費関連
                Dim room As String = ""
                Dim idx As Integer = 1
                For i As Integer = 0 To 6 - 1
                    room = GetStringSafe(rowRec, "出講教室" & idx.ToString())
                    If StringUtil.IsNullOrWhiteSpace(room) Then
                        Exit For
                    End If

                    Dim item As New KomaInfoItem
                    item.Site_Code = GetStringSafe(rowRec, "出講教室" & idx.ToString())
                    item.Grade = GetStringSafe(rowRec, "出講学年" & idx.ToString())
                    item.Class_Code = GetStringSafe(rowRec, "出講クラス" & idx.ToString())
                    item.Koma_Seq = GetStringSafe(rowRec, "出講コマ" & idx.ToString())
                    item.Pinch_Type = GetStringSafe(rowRec, "出講ピンチ" & idx.ToString())
                    item.Start_Time = GetTimeSpanSafe(rowRec, "出講開始" & idx.ToString())
                    item.End_Time = GetTimeSpanSafe(rowRec, "出講終了" & idx.ToString())
                    item.Amount = GetDecimalSafe(rowRec, "交通費" & idx.ToString())
                    item.LectureCoefficient = GetDecimalSafe(rowRec, "授業給係数" & idx.ToString())
                    model.KomaInfoItems.Add(item)
                Next

                ' コマ単価
                model.LectureUnitPrice = GetIntSafe(reader, "Lecture_Unit_Price")
                ' 業務給標準単価、業務給講師単価
                model.TaskBaseUnitPrice = GetIntSafe(reader, "Task_Base_Unit_Price")
                model.TaskUnitPrice = GetIntSafe(reader, "Task_Unit_Price")

                ' バリデーション
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                Dim resDaily = vDaily.Validate(model)


                rowRec("状態") = ""
                If resDaily IsNot Nothing AndAlso resDaily.Count > 0 Then
                    rowRec("状態") = resDaily.OrderBy(Function(p) p.Priority).ToList(0).Message
                End If

                '  ' みなしの開始、終了、時間を取得
                '  Dim timeInfo As New WorkTimeEvaluator.PunchingTimeData With {
                '  .JobStart = rowRec("出勤(打刻)"),
                '  .JobEnd = rowRec("退勤(打刻)"),
                '  .ActStart = rowRec("開始(実績)"),
                '  .ActEnd = rowRec("終了(実績)"),
                '  .ReqStart = rowRec("開始(業務)"),
                '  .ReqEnd = rowRec("終了(業務)"),
                '  .WorkStart = "",
                '  .WorkEnd = "",
                '  .WorkTime = "",
                '  .PunchCount = rowRec("打刻回数")
                '}
                '  WorkTimeEvaluator.DeemedTimeInfo(timeInfo)
                '  rowRec("状態") = timeInfo.Info

                '  ' みなし時間(開始、終了)
                '  rowRec("出勤(みなし)") = SqlDataReaderUtil.GetValue(reader, "出勤(みなし)")
                '  rowRec("退勤(みなし)") = SqlDataReaderUtil.GetValue(reader, "退勤(みなし)")

                '  ' 時間(みなし:分(M))から時間(H)に変換する
                '  Dim workTimeHour As Decimal
                '  Dim workTimeStr = SqlDataReaderUtil.GetValue(reader, "業務時間(みなし)")
                '  If StringUtil.IsNotNullOrWhiteSpace(workTimeStr) Then
                '      Dim hourTime As Decimal = Decimal.Parse(workTimeStr)
                '      workTimeHour = Math.Round(hourTime / 60, 2, MidpointRounding.AwayFromZero)
                '      rowRec("時間(みなし)") = workTimeHour
                '  End If

                ' --------------------------------------------------------------------------------------
                ' 授業給(コマ給)日額
                ' --------------------------------------------------------------------------------------
                'Dim komaCount As String = SqlDataReaderUtil.GetValue(reader, "コマ数")
                'If StringUtil.IsNotNullOrWhiteSpace(komaCount) Then
                '    rowRec("コマ数") = Integer.Parse(komaCount)
                'End If



                ' --------------------------------------------------------------------------------------
                ' 業務給日額
                ' --------------------------------------------------------------------------------------
                'model.TaskBaseUnitPrice = GetIntSafe(reader, "標準単価")
                'Dim basicPrice As Integer = Integer.Parse(basePriceStr)
                'Dim basicAmont As Decimal = 0
                'If StringUtil.IsNotNullOrWhiteSpace(workTimeStr) Then
                '    basicAmont = workTimeHour * Integer.Parse(basePriceStr)
                '    rowRec("基本報酬") = Math.Round(basicAmont, 0, MidpointRounding.AwayFromZero).ToString()
                'Else
                '    rowRec("基本報酬") = DBNull.Value
                'End If

                ' --------------------------------------------------------------------------------------
                ' 合計報酬日額
                ' --------------------------------------------------------------------------------------
                'Dim tuitionFeeStr As String = IIf(IsDBNull(rowRec("授業給")), "", rowRec("授業給"))
                'Dim totalAmont As Decimal = 0
                'Dim totalAmontStr As String = ""
                'If StringUtil.IsNotNullOrWhiteSpace(tuitionFeeStr) Then
                '    ' 報酬日額 ＝ （みなし勤務時間(H) × @標準単価） ＋ 授業給(日計)
                '    totalAmont = (workTimeHour * basicPrice) + Decimal.Parse(tuitionFeeStr)
                '    totalAmont = Math.Round(totalAmont, 0, MidpointRounding.AwayFromZero)
                '    rowRec("日報酬額") = totalAmont
                'Else
                '    rowRec("日報酬額") = DBNull.Value
                'End If

                dtTable.Rows.Add(rowRec)
            End While

        Catch ex As Exception

        End Try

        Return dtTable
    End Function



    ''' <summary>
    ''' みなし開始時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleStartTime(ByVal model As AttendanceModel) As TimeSpan?

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.DeemedStartTime = model.LectureStart
            Else
                model.DeemedStartTime = model.TaskStart
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.DeemedStartTime = model.TaskStart
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.DeemedStartTime = model.LectureStart
        End If

        Return model.DeemedStartTime
    End Function

    ''' <summary>
    ''' みなし終了時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleEndTime(ByVal model As AttendanceModel) As TimeSpan?

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.DeemedEndTime = model.LectureEnd
            Else
                model.DeemedEndTime = model.TaskEnd
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.TaskEnd
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.LectureEnd
        End If

        Return model.DeemedEndTime
    End Function

    Public Function CalcDeemedTimeStart(ByVal model As AttendanceModel) As TimeSpan?

        If Not model.PunchStartTime.HasValue Then
            Return Nothing
        End If

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.DeemedStartTime = IIf(model.PunchStartTime < model.LectureStart - model.DeemedTimeBefore,
                                            model.PunchStartTime,
                                            model.LectureStart - model.DeemedTimeBefore)
            Else
                model.DeemedStartTime = model.PunchStartTime
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.DeemedStartTime = model.PunchStartTime
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.DeemedStartTime = IIf(model.PunchStartTime < model.LectureStart - model.DeemedTimeBefore,
                                        model.PunchStartTime,
                                        model.LectureStart - model.DeemedTimeBefore)
        End If

        Return model.DeemedStartTime
    End Function

    Public Function CalcDeemedTimeEnd(ByVal model As AttendanceModel) As TimeSpan?

        If Not model.PunchEndTime.HasValue Then
            Return Nothing
        End If

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.DeemedEndTime = IIf(model.PunchEndTime > model.LectureEnd + model.DeemedTimeAfter,
                                            model.PunchEndTime,
                                            model.LectureEnd + model.DeemedTimeAfter)
            Else
                model.DeemedEndTime = model.PunchEndTime
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.PunchEndTime
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.DeemedEndTime = IIf(model.PunchEndTime > model.LectureEnd + model.DeemedTimeAfter,
                                        model.PunchEndTime,
                                        model.LectureEnd + model.DeemedTimeAfter)
        End If

        Return model.DeemedEndTime
    End Function

    Private Function TimeSpanParse(ByVal row As DataRow, ByVal colName As String) As TimeSpan?
        Dim ts As TimeSpan? = Nothing

        If IsDBNull(row(colName)) Then
            Return ts
        End If

        Dim val As String = row(colName).ToString()
        ts = TimeSpan.Parse(val)
        Return ts
    End Function

    Private Function GetValueWithNothing(ByVal row As DataRow, ByVal colName As String) As Object
        If IsDBNull(row(colName)) Then
            Return Nothing
        End If

        Return row(colName)
    End Function
End Class
