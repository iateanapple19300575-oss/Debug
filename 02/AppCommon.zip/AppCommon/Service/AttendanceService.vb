﻿Imports MainApp.Data.Dto

''' <summary>
''' 勤怠情報アプリケーションサービスクラス
''' </summary>
Public Class AttendanceService

    ''' <summary>
    ''' 勤怠情報ドメインサービス
    ''' </summary>
    Private _domain As AttendanceDomain

    ''' <summary>
    ''' 勤怠情報リポジトリ
    ''' </summary>
    Private _repository As New AttendanceRepository

    '''' <summary>
    '''' 表示データ取得クエリ取得
    '''' </summary>
    '''' <returns>表示データ取得クエリ</returns>
    'Public Function DataLoadByMonthly(ByVal param As RepositoryFindParameterDto) As DataTable
    '    Dim dt As DataTable = _repository.DataLoadByMonthly(param)
    '    Return _domain.AttendanceAnalysis(dt)
    'End Function

    '''' <summary>
    '''' 表示データ取得クエリ取得
    '''' </summary>
    '''' <returns>表示データ取得クエリ</returns>
    'Public Function DataLoadByDays(ByVal param As RepositoryFindParameterDto) As DataTable
    '    Dim dt As DataTable = _repository.DataLoadByMonthly(param)
    '    Return _domain.AttendanceAnalysis(dt)
    'End Function

    ''' <summary>
    ''' 表示データ取得
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoad(ByVal param As LectureDetailsFindParameter) As DataTable

        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _domain = New AttendanceDomain(uow)
                dataList = _domain.LoadData(param)
                modelList = _domain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)

                dt = _domain.WorkListToDataTable(modelList)
            End Using

        Catch ex As Exception

        End Try

        Return dt
    End Function


    ''' <summary>
    ''' 表示データ取得（特定日、特定講師）
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoadByDay(ByVal param As LectureDetailsFindParameter) As DataTable

        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _domain = New AttendanceDomain(uow)
                dataList = _domain.LoadDataByDay(param)
                modelList = _domain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)

                dt = _domain.WorkListToDataTable(modelList)
            End Using

        Catch ex As Exception

        End Try

        Return dt
    End Function

End Class
