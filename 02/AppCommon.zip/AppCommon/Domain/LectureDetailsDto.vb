﻿Public Class LectureDetailsDto

    ''' <summary>
    ''' 日付
    ''' </summary>
    Public Property LectureDate As DateTime?

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property TeacherCode As String

    ''' <summary>
    ''' 講師名
    ''' </summary>
    Public Property TeacherName As String

    ''' <summary>
    ''' 出勤時間
    ''' </summary>
    Public Property PunchStartTime As TimeSpan?

    ''' <summary>
    ''' 退勤時間
    ''' </summary>
    Public Property PunchEndTime As TimeSpan?

    ''' <summary>
    ''' 出講開始時間（最小値）
    ''' </summary>
    Public Property LectureStartTimeMin As TimeSpan?

    ''' <summary>
    ''' 出講終了時間（最大値）
    ''' </summary>
    Public Property LectureEndTimeMax As TimeSpan?

    ''' <summary>
    ''' 業務届開始時間（最小値）
    ''' </summary>
    Public Property TaskStartTimeMin As TimeSpan?

    ''' <summary>
    ''' 業務届終了時間（最大値）
    ''' </summary>
    Public Property TaskEndTimeMax As TimeSpan?

    ''' <summary>
    ''' 打刻外業務給開始時間（最小値）
    ''' </summary>
    Public Property OthersStartTimeMin As TimeSpan?

    ''' <summary>
    ''' 打刻外業務給終了時間（最大値）
    ''' </summary>
    Public Property OthersEndTimeMax As TimeSpan?

    ''' <summary>
    ''' 実務開始時間（授業と業務届の一番小さい開始時間）
    ''' </summary>
    Public Property WorkStartTimeMin As TimeSpan?

    ''' <summary>
    ''' 実務終了時間（授業と業務届の一番大きい終了時間）
    ''' </summary>
    Public Property WorkEndTimeMax As TimeSpan?

    ''' <summary>
    ''' みなし開始時間（業務届含む）
    ''' </summary>
    Public Property DeemedStartTime As TimeSpan?

    ''' <summary>
    ''' みなし終了時間（業務届含む）
    ''' </summary>
    Public Property DeemedEndTime As TimeSpan?

    ''' <summary>
    ''' 出講作業タスク（複数）
    ''' </summary>
    ''' <returns></returns>
    Public Property LectureWorkItems As New List(Of LectureWorkItem)

    ''' <summary>
    ''' 業務届作業タスク（複数）
    ''' </summary>
    ''' <returns></returns>
    Public Property TaskWorkItems As New List(Of TaskWorkItem)

    ''' <summary>
    ''' 打刻外業務給作業タスク（複数）
    ''' </summary>
    ''' <returns></returns>
    Public Property OthersWorkItems As New List(Of OthersWorkItem)

    ''' <summary>
    ''' 打刻と打刻外業務届の時間重複
    ''' </summary>
    Public Property OverlapOther As Integer?

    ''' <summary>
    ''' 授業時間の時間重複（いらないような気がする）
    ''' </summary>
    Public Property OverlapLecture As Integer?

    ''' <summary>
    ''' 授業と業務届の時間重複
    ''' </summary>
    Public Property OverlapLectTask As Integer?

    ''' <summary>
    ''' ABeforeStart
    ''' </summary>
    Public Property ABeforeStart As Integer?

    ''' <summary>
    ''' AAfterEnd
    ''' </summary>
    Public Property AAfterEnd As Integer?

    ''' <summary>
    ''' BBeforeStart
    ''' </summary>
    Public Property BBeforeStart As Integer?

    ''' <summary>
    ''' BAfterEnd
    ''' </summary>
    Public Property BAfterEnd As Integer?

    ''' <summary>
    ''' CBeforeStart
    ''' </summary>
    Public Property CBeforeStart As Integer?

    ''' <summary>
    ''' CAfterEnd
    ''' </summary>
    Public Property CAfterEnd As Integer?

    ''' <summary>
    ''' みなし勤務時間(事前分)
    ''' </summary>
    Public Property DeemedTimeBefore As TimeSpan?

    ''' <summary>
    ''' みなし勤務時間(事後分)
    ''' </summary>
    Public Property DeemedTimeAfter As TimeSpan?

    ''' <summary>
    ''' 授業給コマ単価
    ''' </summary>
    Public Property LectureUnitPrice As Integer?

    ''' <summary>
    ''' 業務給標準単価
    ''' </summary>
    Public Property TaskBaseUnitPrice As Integer?

    ''' <summary>
    ''' 業務給単価（業務給標準単価よりも優先）
    ''' </summary>
    Private _TaskUnitPrice As Integer?
    Public Property TaskUnitPrice As Integer?
        Get
            If Not _TaskUnitPrice.HasValue Then
                Return TaskBaseUnitPrice
            End If
            Return _TaskUnitPrice
        End Get
        Set(value As Nullable(Of Integer))
            _TaskUnitPrice = value
        End Set
    End Property

    ''' <summary>
    ''' 打刻回数
    ''' </summary>
    Public Property NumberOfPunched As Byte?

    ''' <summary>
    ''' 状態（ここに必要か？？？）
    ''' </summary>
    Public Property Status As String

End Class


''' <summary>
''' 出講作業タスクアイテム
''' </summary>
Public Class LectureWorkItem

    ''' <summary>
    ''' 教室コード
    ''' </summary>
    Public Property SiteCode As String

    ''' <summary>
    ''' 学年
    ''' </summary>
    Public Property Grade As String

    ''' <summary>
    ''' クラスコード
    ''' </summary>
    Public Property ClassCode As String

    ''' <summary>
    ''' コマ
    ''' </summary>
    Public Property KomaSeq As String

    ''' <summary>
    ''' 代講タイプ
    ''' </summary>
    Public Property PinchType As String

    ''' <summary>
    ''' 開始時間
    ''' </summary>
    Public Property StartTime As TimeSpan?

    ''' <summary>
    ''' 終了時間
    ''' </summary>
    Public Property EndTime As TimeSpan?

    ''' <summary>
    ''' 授業給係数
    ''' </summary>
    Public Property LectureCoefficient As Decimal?

    ''' <summary>
    ''' 交通費
    ''' </summary>
    Public Property Amount As Decimal?

End Class

''' <summary>
''' 業務届作業タスクアイテム
''' </summary>
Public Class TaskWorkItem

    ''' <summary>
    ''' 教室コード
    ''' </summary>
    Public Property SiteCode As String

    ''' <summary>
    ''' 開始時間
    ''' </summary>
    Public Property StartTime As TimeSpan?

    ''' <summary>
    ''' 終了時間
    ''' </summary>
    Public Property EndTime As TimeSpan?

End Class

''' <summary>
''' 打刻外業務給タスクアイテム
''' </summary>
Public Class OthersWorkItem

    ''' <summary>
    ''' 教室コード
    ''' </summary>
    Public Property SiteCode As String

    ''' <summary>
    ''' 開始時間
    ''' </summary>
    Public Property StartTime As TimeSpan?

    ''' <summary>
    ''' 終了時間
    ''' </summary>
    Public Property EndTime As TimeSpan?

    ''' <summary>
    ''' 交通費
    ''' </summary>
    Public Property Amount As Decimal?

End Class
