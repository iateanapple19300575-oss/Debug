﻿Public Class LectureDetailsFindParameter

    ''' <summary>
    ''' 対象年月度
    ''' </summary>
    Public Property TargetDate As String

    ''' <summary>
    ''' 対象出講日付
    ''' </summary>
    Public Property LectureDate As String

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property TeacherCode As String


    ''' <summary>
    ''' 検索開始日付
    ''' </summary>
    Public Property SearchStartDate As Date

    ''' <summary>
    ''' 検索終了日付
    ''' </summary>
    Public Property SearchEndDate As Date


    ''' <summary>
    ''' ステータスレベル
    ''' </summary>
    Public Property RuleId As String


    Public Property ErrorOnly As Boolean

End Class
