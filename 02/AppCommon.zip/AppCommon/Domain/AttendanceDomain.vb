﻿Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Reflection
Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 勤怠情報ドメインクラス
''' </summary>
Public Class AttendanceDomain

    Private _uow As DbTransactionScope
    Private _exec As New SqlExecutor
    Private _repo As AttendanceRepository

    Public Sub New()
    End Sub

    Public Sub New(ByVal uow As DbTransactionScope)
        _uow = uow
        _repo = New AttendanceRepository(_uow)
    End Sub


#If 0 Then

    ''' <summary>
    ''' 勤怠情報解析処理
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <returns></returns>
    Public Function AttendanceAnalysis(ByVal dt As DataTable) As DataTable
        Dim destDt As DataTable = dt.Copy()

        destDt.Columns.Add("休憩時間")
        destDt.Columns.Add("深夜勤務")

        Try
            For Each rowRec As DataRow In destDt.Rows
                ' 日付関連
                Dim dtDate As Date = rowRec("Lecture_Date")
                Dim strDay As String = dtDate.ToString("ddd")
                rowRec("日付") = dtDate.ToString("yyyy/MM/dd") & "(" & strDay & ")"
                rowRec("日付KEY") = dtDate.ToString("yyyyMMdd")
                Dim dateForeColor As Color = Color.Black
                If (Weekday(dtDate) = 1) Then
                    dateForeColor = Color.Red
                ElseIf (Weekday(dtDate) = 7) Then
                    dateForeColor = Color.Blue
                End If
                rowRec("日付色") = dateForeColor.Name

                ' 打刻関連
                Dim model As New AttendanceModel()
                model.PunchStartTime = GetTimeSpanSafe(rowRec, "出勤時刻")
                model.PunchEndTime = GetTimeSpanSafe(rowRec, "退勤時刻")
                model.LectureStart = GetTimeSpanSafe(rowRec, "出講開始時間")
                model.LectureEnd = GetTimeSpanSafe(rowRec, "出講終了時間")
                model.TaskStart = GetTimeSpanSafe(rowRec, "業務届開始時間")
                model.TaskEnd = GetTimeSpanSafe(rowRec, "業務届終了時間")
                model.NumberOfPunched = GetByteSafe(rowRec, "打刻回数")

                ' みなし(授業前後)
                Dim workDecimal As Byte?
                workDecimal = GetDecimalSafe(rowRec, "Deemed_Time_Before")
                model.DeemedTimeBefore = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                workDecimal = GetDecimalSafe(rowRec, "Deemed_Time_After")
                model.DeemedTimeAfter = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                model.DeemedStartTime = CalcDeemedTimeStart(model)
                model.DeemedEndTime = CalcDeemedTimeEnd(model)
                Dim ts As TimeSpan?
                ts = CalcScheduleStartTime(model)
                rowRec("実務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcScheduleEndTime(model)
                rowRec("実務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeStart(model)
                rowRec("勤務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeEnd(model)
                rowRec("勤務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)

                ' 時間重複(打刻・打刻外業務給)
                model.OverlapOther = GetIntSafe(rowRec, "打刻外業務重複")

                ' 時間重複(出講内)
                model.OverlapLecture = GetIntSafe(rowRec, "出講授業重複")

                ' 時間重複(出講・業務届)
                model.OverlapLectTask = GetIntSafe(rowRec, "出講業務届重複")

                ' 交通費関連
                Dim room As String = ""
                Dim idx As Integer = 1
                For i As Integer = 0 To 6 - 1
                    room = GetStringSafe(rowRec, "出講教室" & idx.ToString())
                    If StringUtil.IsNullOrWhiteSpace(room) Then
                        Exit For
                    End If

                    Dim item As New KomaInfoItem
                    item.Site_Code = GetStringSafe(rowRec, "出講教室" & idx.ToString())
                    item.Grade = GetStringSafe(rowRec, "出講学年" & idx.ToString())
                    item.Class_Code = GetStringSafe(rowRec, "出講クラス" & idx.ToString())
                    item.Koma_Seq = GetStringSafe(rowRec, "出講コマ" & idx.ToString())
                    'item.Start_Time = GetStringSafe(rowRec, "出講ピンチ" & idx.ToString())
                    'item.Start_Time = GetTimeSpanSafe(rowRec, "出講開始" & idx.ToString())
                    'item.End_Time = GetTimeSpanSafe(rowRec, "出講終了" & idx.ToString())
                    item.Amount = GetDecimalSafe(rowRec, "交通費" & idx.ToString())
                    item.LectureCoefficient = GetDecimalSafe(rowRec, "授業給係数" & idx.ToString())
                    model.KomaInfoItems.Add(item)
                Next

                Dim calc As New DailySummaryCalculator
                Dim data As DailyWorkSummary = calc.Calculate(model)
                model.WorkStartTime = data.WorkStart
                model.WorkEndTime = data.WorkEnd
                model.WorkingHours = data.WorkingHours
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                Dim resDaily = vDaily.Validate(model)
                rowRec("状態") = ""
                If resDaily IsNot Nothing AndAlso resDaily.Count > 0 Then
                    rowRec("状態") = resDaily.OrderBy(Function(p) p.Priority).ToList(0).Message
                End If

                rowRec("休憩時間") = model.TaskUnBreakTime
                rowRec("深夜勤務") = model.LateNightShift
            Next
        Catch ex As Exception

        End Try

        Return destDt
    End Function

    Public Function AttendanceValidate(ByVal dt As DataTable) As List(Of ValidationRuleResult)
        Dim result As New List(Of ValidationRuleResult)
        Dim destDt As DataTable = dt.Copy()

        Try
            'destDt.Columns.Add("休憩時間")

            For Each rowRec As DataRow In destDt.Rows
                Dim model As New AttendanceModel()
                ' 打刻時間関連情報
                model.PunchStartTime = GetTimeSpanSafe(rowRec, "出勤時刻")
                model.PunchEndTime = GetTimeSpanSafe(rowRec, "退勤時刻")
                model.LectureStart = GetTimeSpanSafe(rowRec, "出講開始時間")
                model.LectureEnd = GetTimeSpanSafe(rowRec, "出講終了時間")
                model.TaskStart = GetTimeSpanSafe(rowRec, "業務届開始時間")
                model.TaskEnd = GetTimeSpanSafe(rowRec, "業務届終了時間")
                model.NumberOfPunched = GetByteSafe(rowRec, "打刻回数")

                ' みなし時間
                Dim workDecimal As Byte?
                workDecimal = GetDecimalSafe(rowRec, "Deemed_Time_Before")
                model.DeemedTimeBefore = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                workDecimal = GetDecimalSafe(rowRec, "Deemed_Time_After")
                model.DeemedTimeAfter = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                model.DeemedStartTime = CalcDeemedTimeStart(model)
                model.DeemedEndTime = CalcDeemedTimeEnd(model)

                Dim ts As TimeSpan?
                ts = CalcScheduleStartTime(model)
                rowRec("実務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcScheduleEndTime(model)
                rowRec("実務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeStart(model)
                rowRec("勤務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeEnd(model)
                rowRec("勤務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)

                ' 時間重複(打刻・打刻外業務給)
                model.OverlapOther = GetIntSafe(rowRec, "打刻外業務重複")

                ' 時間重複(出講内)
                model.OverlapLecture = GetIntSafe(rowRec, "出講授業重複")

                ' 時間重複(出講・業務届)
                model.OverlapLectTask = GetIntSafe(rowRec, "出講業務届重複")

                ' 交通費関連
                Dim room As String = ""
                Dim idx As Integer = 1
                For i As Integer = 0 To 6 - 1
                    room = GetStringSafe(rowRec, "出講教室" & idx.ToString())
                    If StringUtil.IsNullOrWhiteSpace(room) Then
                        Exit For
                    End If

                    Dim item As New KomaInfoItem
                    item.Site_Code = GetStringSafe(rowRec, "出講教室" & idx.ToString())
                    item.Grade = GetStringSafe(rowRec, "出講学年" & idx.ToString())
                    item.Class_Code = GetStringSafe(rowRec, "出講クラス" & idx.ToString())
                    item.Koma_Seq = GetStringSafe(rowRec, "出講コマ" & idx.ToString())
                    item.Pinch_Type = GetStringSafe(rowRec, "出講ピンチ" & idx.ToString())
                    item.Start_Time = GetTimeSpanSafe(rowRec, "出講開始" & idx.ToString())
                    item.End_Time = GetTimeSpanSafe(rowRec, "出講終了" & idx.ToString())
                    item.LectureCoefficient = GetDecimalSafe(rowRec, "授業給係数" & idx.ToString())
                    item.Amount = GetDecimalSafe(rowRec, "交通費" & idx.ToString())
                    model.KomaInfoItems.Add(item)
                Next

                Dim calc As New DailySummaryCalculator
                Dim data As DailyWorkSummary = calc.Calculate(model)
                model.WorkStartTime = data.WorkStart
                model.WorkEndTime = data.WorkEnd
                model.WorkingHours = data.WorkingHours
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                result = vDaily.Validate(model)

                rowRec("休憩時間") = model.TaskUnBreakTime
                rowRec("深夜勤務") = model.LateNightShift
            Next
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function
#End If


    ''' <summary>
    ''' 1月分の全員の勤務データを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function LoadData(ByVal param As LectureDetailsFindParameter) As List(Of LectureDetailsDto)

        Dim firstDay As String = DateUtil.FirstDayOfMonth(param.TargetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(param.TargetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT *").Append(" ")
        sqlString.Append("FROM VL_Lecture_Details LD").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1")
        sqlString.Append("  AND LD.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND LD.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("")
        sqlString.Append("")

        sqlString.Append("ORDER BY ")
        sqlString.Append("   LD.Lecture_Date ")
        sqlString.Append("   , LD.Teacher_Code ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay})
        params.Add(New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay})

        Dim result As List(Of LectureDetailsDto)
        result = _repo.LoadDataExecute(_uow, sqlString.ToString(), params.ToArray)
        Return result

    End Function

    ''' <summary>
    ''' 1講師の1日の勤務データを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function LoadDataByDay(ByVal param As LectureDetailsFindParameter) As List(Of LectureDetailsDto)

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT *").Append(" ")
        sqlString.Append("FROM VL_Lecture_Details LD").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1")
        sqlString.Append("  AND LD.Lecture_Date = @Lecture_Date").Append(" ")
        sqlString.Append("  AND LD.Teacher_Code = @Teacher_Code").Append(" ")
        sqlString.Append("")
        sqlString.Append("")

        sqlString.Append("ORDER BY ")
        sqlString.Append("   LD.Lecture_Date ")
        sqlString.Append("   , LD.Teacher_Code ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Date", .Value = param.LectureDate})
        params.Add(New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = param.TeacherCode})

        Dim result As List(Of LectureDetailsDto)
        result = _repo.LoadDataExecute(_uow, sqlString.ToString(), params.ToArray)
        Return result

    End Function

    ''' <summary>
    ''' 勤怠情報解析処理
    ''' </summary>
    ''' <param name="dataList"></param>
    ''' <returns></returns>
    Public Function AttendanceAnalysis(ByVal dataList As List(Of LectureDetailsDto)) As List(Of AttendanceModel)

        Dim models As New List(Of AttendanceModel)

        For Each item As LectureDetailsDto In dataList
            Dim model As New AttendanceModel
            ' ------------------------------
            ' DTO → MODEL
            ' ------------------------------

            ' 表示用日付の編集（日付、日付キー、日付色）
            Dim lectDate As Date = item.LectureDate
            Dim strDay As String = lectDate.ToString("ddd")
            model.DateStr = lectDate.ToString("yyyy/MM/dd") & "(" & strDay & ")"
            model.DateKey = lectDate.ToString("yyyyMMdd")
            model.DateColor = DateColor(lectDate)
            model.LectureDate = item.LectureDate
            model.TeacherCode = item.TeacherCode
            model.TeacherName = item.TeacherName

            ' 出勤、退勤の打刻時間
            model.PunchStartTime = item.PunchStartTime
            model.PunchEndTime = item.PunchEndTime

            ' 授業の最小開始時間と最大終了時間
            model.LectureStart = item.LectureStartTimeMin
            model.LectureEnd = item.LectureEndTimeMax

            ' 業務届の最小開始時間と最大終了時間
            model.TaskStart = item.TaskStartTimeMin
            model.TaskEnd = item.TaskEndTimeMax

            ' 打刻外業務給の最小開始時間と最大終了時間
            model.OthersStart = item.OthersStartTimeMin
            model.OthersEnd = item.OthersEndTimeMax

            ' 出講タスク詳細情報
            model.LectureWorkItems = LectureInfo(item.LectureWorkItems)
            ' 業務届タスク詳細情報
            model.TaskWorkItems = TaskItemInfo(item.TaskWorkItems)
            ' 打刻外業務給タスク詳細情報
            model.OthersWorkItems = OthersItemInfo(item.OthersWorkItems)

            ' 授業前後のみなし時間
            model.DeemedTimeBefore = item.DeemedTimeBefore
            model.DeemedTimeAfter = item.DeemedTimeAfter

            ' 打刻回数
            model.NumberOfPunched = item.NumberOfPunched

            ' 授業給
            model.LectureUnitPrice = item.LectureUnitPrice

            ' 業務給
            model.TaskUnitPrice = item.TaskUnitPrice

            ' 出講・出講重複
            model.OverlapLecture = item.OverlapLecture

            ' 出講・業務重複
            model.OverlapLectTask = item.OverlapLectTask

            ' 打刻・打刻外業務重複
            model.OverlapOther = item.OverlapOther


            ' ------------------------------
            ' MODEL→計算→MODEL
            ' ------------------------------
            model.GradeCount = CalcGradeCount(model, item.LectureWorkItems)
            '' 実務開始時間
            'model.WorkStartTime = CalcScheduleStartTime(model)
            '' 実務終了時間
            'model.WorkEndTime = CalcScheduleEndTime(model)
            '' 勤務開始時間
            'model.DeemedStartTime = CalcDeemedTimeStart(model)
            '' 勤務終了時間
            'model.DeemedEndTime = CalcDeemedTimeEnd(model)

            models.Add(model)
        Next

        Return models
    End Function

    ''' <summary>
    ''' List(Of AttendanceModel) -> DataTable 変換処理
    ''' ・打刻データ確認画面
    ''' ・日次勤怠明細画面
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function WorkListToDataTable(list As List(Of AttendanceModel)) As DataTable
        Dim dt As New DataTable("Work")

#Region "DataTableの定義関連"

        ' 打刻等の時間情報関連
        dt.Columns.Add("DateStr", GetType(String))
        dt.Columns.Add("DateKey", GetType(String))
        dt.Columns.Add("DateColor", GetType(String))
        dt.Columns.Add("StatusLevel", GetType(String))
        dt.Columns.Add("StatusStr", GetType(String))
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Punch_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Punch_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Lecture_Start", GetType(TimeSpan))
        dt.Columns.Add("Lecture_End", GetType(TimeSpan))
        dt.Columns.Add("Task_Start", GetType(TimeSpan))
        dt.Columns.Add("Task_End", GetType(TimeSpan))
        dt.Columns.Add("Work_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Work_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Hours", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Hour_Time", GetType(Decimal))

        ' 打刻等の時間外の情報
        dt.Columns.Add("Overlap_Other", GetType(Integer))
        dt.Columns.Add("Overlap_Lecture", GetType(Integer))
        dt.Columns.Add("Overlap_Lect_Task", GetType(Integer))
        dt.Columns.Add("Deemed_Time_Before", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Time_After", GetType(TimeSpan))
        dt.Columns.Add("Number_Of_Punched", GetType(Byte))
        dt.Columns.Add("Lecture_Unit_Price", GetType(Decimal))
        dt.Columns.Add("TaskBase_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Un_Break_Time", GetType(TimeSpan))
        dt.Columns.Add("Late_Night_Shift", GetType(TimeSpan))

        ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
        dt.Columns.Add("Lecture_Count", GetType(Integer))
        dt.Columns.Add("Daily_Rewards", GetType(Decimal))
        dt.Columns.Add("Lecture_Fee", GetType(Decimal))
        dt.Columns.Add("Work_Salary", GetType(Decimal))

        ' 日別報酬リスト：実績コマ回数で使用する。
        For i As Integer = 0 To 6 - 1
            dt.Columns.Add("Grade_Count" & (i + 1).ToString(), GetType(Integer))
        Next

        ' グループ毎に DTO 型を登録
        Dim groupInfo As New Dictionary(Of String, Type) From {
            {"A", GetType(LectureWorkItem)},
            {"B", GetType(TaskWorkItem)},
            {"C", GetType(OthersWorkItem)}
        }

        ' グループ毎に列を作成（コマ１～コマ６のコマ情報）
        For Each grp As String In groupInfo.Keys
            Dim props = groupInfo(grp).GetProperties(BindingFlags.Public Or BindingFlags.Instance)

            For i As Integer = 1 To 6
                For Each p As PropertyInfo In props
                    Dim colName As String = grp & p.Name & i

                    Dim colType As Type = p.PropertyType
                    If colType.IsGenericType AndAlso colType.GetGenericTypeDefinition() Is GetType(Nullable(Of )) Then
                        colType = colType.GetGenericArguments()(0)
                    End If

                    dt.Columns.Add(colName, colType)
                Next
            Next
        Next

#End Region

#Region "Data投入"

        '--- 行追加 ---
        For Each w In list
            Dim row = dt.NewRow()
            Dim statusLevel As String = ""
            Dim statusMessage As String = ""

            Try
                If (w.StatusList IsNot Nothing AndAlso w.StatusList.Count >= 1) Then
                    statusLevel = w.StatusList(0).LevelString
                    statusMessage = w.StatusList(0).Message
                End If

            Catch ex As Exception

            End Try

            ' 打刻等の時間情報関連
            row("DateStr") = ToStringSafe(w.DateStr)
            row("DateKey") = ToStringSafe(w.DateKey)
            row("DateColor") = ToStringSafe(w.DateColor)
            row("StatusLevel") = statusLevel
            row("StatusStr") = statusMessage
            row("Lecture_Date") = ToDateSafe(w.LectureDate)
            row("Teacher_Code") = ToStringSafe(w.TeacherCode)
            row("Teacher_Name") = ToStringSafe(w.TeacherName)
            row("Punch_Start_Time") = ToTimeSpanSafe(w.PunchStartTime)
            row("Punch_End_Time") = ToTimeSpanSafe(w.PunchEndTime)
            row("Lecture_Start") = ToTimeSpanSafe(w.LectureStart)
            row("Lecture_End") = ToTimeSpanSafe(w.LectureEnd)
            row("Task_Start") = ToTimeSpanSafe(w.TaskStart)
            row("Task_End") = ToTimeSpanSafe(w.TaskEnd)
            row("Work_Start_Time") = ToTimeSpanSafe(w.WorkStartTime)
            row("Work_End_Time") = ToTimeSpanSafe(w.WorkEndTime)
            row("Deemed_Start_Time") = ToTimeSpanSafe(w.DeemedStartTime)
            row("Deemed_End_Time") = ToTimeSpanSafe(w.DeemedEndTime)
            row("Deemed_Hours") = ToTimeSpanSafe(w.DeemedHours)
            row("Deemed_Hour_Time") = ToDecimalSafe(w.DeemedHourTime)

            ' 打刻等の時間外の情報
            row("Overlap_Other") = ToIntSafe(w.OverlapOther)
            row("Overlap_Lecture") = ToIntSafe(w.OverlapLecture)
            row("Overlap_Lect_Task") = ToIntSafe(w.OverlapLectTask)
            row("Deemed_Time_Before") = ToTimeSpanSafe(w.DeemedTimeBefore)
            row("Deemed_Time_After") = ToTimeSpanSafe(w.DeemedTimeAfter)
            row("Number_Of_Punched") = ToByteSafe(w.NumberOfPunched)
            row("Lecture_Unit_Price") = ToDecimalSafe(w.LectureUnitPrice)
            row("TaskBase_Unit_Price") = ToDecimalSafe(w.TaskBaseUnitPrice)
            row("Task_Unit_Price") = ToDecimalSafe(w.TaskUnitPrice)
            row("Task_Un_Break_Time") = ToTimeSpanSafe(w.TaskUnBreakTime)
            row("Late_Night_Shift") = ToTimeSpanSafe(w.LateNightShift)

            ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
            row("Lecture_Count") = ToIntSafe(w.LectureCount)
            row("Daily_Rewards") = ToDecimalSafe(w.DailyRewards)
            row("Lecture_Fee") = ToDecimalSafe(w.LectureFee)
            row("Work_Salary") = ToDecimalSafe(w.WorkSalary)

            ' 日別報酬リスト：実績コマ回数で使用する。
            Dim count() As Integer = w.GradeCount
            For i As Integer = 0 To 6 - 1
                row("Grade_Count" & (i + 1).ToString()) = count(i)
            Next

            FillGroup(row, "A", w.LectureWorkItems, GetType(LectureWorkItem))
            FillGroup(row, "B", w.TaskWorkItems, GetType(TaskWorkItem))
            FillGroup(row, "C", w.OthersWorkItems, GetType(OthersWorkItem))

            dt.Rows.Add(row)
        Next

#End Region

        Return dt
    End Function

    ''' <summary>
    ''' List(Of AttendanceModel) -> DataTable 変換処理
    ''' ・出講料アテンション確認画面
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function WorkListToAttentionCheckDataTable(list As List(Of AttendanceModel)) As DataTable
        Dim dt As New DataTable("Work")

#Region "DataTableの定義関連"

        ' 打刻等の時間情報関連
        dt.Columns.Add("DateStr", GetType(String))
        dt.Columns.Add("Level_String", GetType(String))
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Priority", GetType(Integer))
        dt.Columns.Add("Message", GetType(String))

#End Region

#Region "Data投入"

        '--- 行追加 ---
        For Each w In list
            ' 打刻等の時間情報関連
            If w.StatusList IsNot Nothing AndAlso w.StatusList.Count > 0 Then
                For Each item As ValidationRuleResult In w.StatusList
                    Dim row = dt.NewRow()
                    row("DateStr") = ToStringSafe(w.DateStr)
                    row("Level_String") = ToStringSafe(item.LevelString())
                    row("Lecture_Date") = ToDateSafe(w.LectureDate)
                    row("Teacher_Code") = ToStringSafe(w.TeacherCode)
                    row("Teacher_Name") = ToStringSafe(w.TeacherName)
                    row("Priority") = ToIntSafe(item.Priority)
                    row("Message") = ToStringSafe(item.Message)
                    dt.Rows.Add(row)
                Next
            End If
        Next

#End Region

        Return dt
    End Function

    ''' <summary>
    ''' バリデーションエラーをDataTableに変換する。
    ''' ・日次勤怠明細画面
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function ListToDataTable(ByVal list As List(Of ValidationRuleResult)) As DataTable

        Dim dt As New DataTable()
        dt.Columns.Add("Priority", GetType(Integer))
        dt.Columns.Add("IsError", GetType(Integer))
        dt.Columns.Add("Level", GetType(Integer))
        dt.Columns.Add("Message", GetType(String))
        dt.Columns.Add("RuleId", GetType(String))
        dt.Columns.Add("LevelString", GetType(String))

        For Each item As ValidationRuleResult In list
            Dim dr As DataRow = dt.NewRow()
            dr("Priority") = item.Priority
            dr("IsError") = item.IsError
            dr("Level") = item.Level
            dr("Message") = item.Message
            dr("RuleId") = item.RuleId
            dr("LevelString") = item.LevelString
            dt.Rows.Add(dr)
        Next

        Return dt
    End Function


#Region "内部共通部品"

    ''' <summary>
    ''' 日付色を返す。
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <returns></returns>
    Private Function DateColor(ByVal dtDate As Date) As String
        Dim dateForeColor As Color = Color.Black
        If (Weekday(dtDate) = 1) Then
            dateForeColor = Color.Red
        ElseIf (Weekday(dtDate) = 7) Then
            dateForeColor = Color.Blue
        End If
        Return dateForeColor.Name
    End Function

    ''' <summary>
    ''' 出講タスク情報DTO→MODEL
    ''' </summary>
    Private Function LectureInfo(ByVal dto As List(Of LectureWorkItem)) As List(Of LectureWorkItem)
        Dim items As New List(Of LectureWorkItem)
        For Each item As LectureWorkItem In dto
            items.Add(New LectureWorkItem With {
                .SiteCode = item.SiteCode,
                .Grade = item.Grade,
                .ClassCode = item.ClassCode,
                .KomaSeq = item.KomaSeq,
                .PinchType = item.PinchType,
                .StartTime = item.StartTime,
                .EndTime = item.EndTime,
                .LectureCoefficient = item.LectureCoefficient,
                .Amount = item.Amount
            })
        Next
        Return items
    End Function

    ''' <summary>
    ''' 業務届タスク情報DTO→MODEL
    ''' </summary>
    Private Function TaskItemInfo(ByVal dto As List(Of TaskWorkItem)) As List(Of TaskWorkItem)
        Dim items As New List(Of TaskWorkItem)
        For Each item As TaskWorkItem In dto
            items.Add(New TaskWorkItem With {
                .SiteCode = item.SiteCode,
                .StartTime = item.StartTime,
                .EndTime = item.EndTime
            })
        Next
        Return items
    End Function

    ''' <summary>
    ''' 業務届タスク情報DTO→MODEL
    ''' </summary>
    Private Function OthersItemInfo(ByVal dto As List(Of OthersWorkItem)) As List(Of OthersWorkItem)
        Dim items As New List(Of OthersWorkItem)
        For Each item As OthersWorkItem In dto
            items.Add(New OthersWorkItem With {
                .SiteCode = item.SiteCode,
                .StartTime = item.StartTime,
                .EndTime = item.EndTime,
                .Amount = item.Amount
            })
        Next
        Return items
    End Function

    ''' <summary>
    ''' 学年毎の1日の授業回数をカウントします。
    ''' </summary>
    Private Function CalcGradeCount(ByRef model As AttendanceModel, ByVal list As List(Of LectureWorkItem)) As Integer()
        Dim count() As Integer = {0, 0, 0, 0, 0, 0}
        Dim grade As Integer

        For Each item As LectureWorkItem In list
            If StringUtil.IsNotNullOrWhiteSpace(item.SiteCode) Then
                grade = Integer.Parse(item.Grade)
                count(grade - 1) += 1
            End If
        Next

        model.GradeCount = count

        Return count
    End Function

    ''' <summary>
    ''' リスト内メンバーの作成
    ''' </summary>
    ''' <param name="row">ROW</param>
    ''' <param name="groupName">グループ名</param>
    ''' <param name="list">グループ内リスト</param>
    ''' <param name="dtoType">DTOタイプ</param>
    Private Sub FillGroup(row As DataRow, groupName As String,
                          list As IList, dtoType As Type)

        If list Is Nothing Then
            Exit Sub
        End If

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        ' 0～5以内の
        For i As Integer = 0 To Math.Min(5, list.Count - 1)
            Dim item = list(i)
            ' プロパティメンバすべてを処理する
            For Each p As PropertyInfo In props
                ' グループの接頭辞作成
                Dim colName As String = groupName & p.Name & (i + 1)
                ' プロパティ値を取得
                Dim value As Object = p.GetValue(item, Nothing)
                ' 値をDataTableの項目に値を設定（Nullならば、DBNull.Value）
                If value Is Nothing Then
                    row(colName) = DBNull.Value
                Else
                    row(colName) = value
                End If
            Next
        Next
    End Sub

#End Region

End Class
