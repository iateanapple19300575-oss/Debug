﻿Imports System.Drawing
Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 出講料チェックリスト出力ドメインクラス
''' </summary>
Public Class ReportLectureFeeDomain

    ''' <summary>
    ''' 出講料チェックリスト解析処理
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <returns></returns>
    Public Function AttendanceAnalysis(ByVal dt As DataTable) As DataTable
        Dim destDt As DataTable = dt.Copy()

        destDt.Columns.Add("講師ｺｰﾄﾞ")
        destDt.Columns.Add("講師名")

        Try
            For Each rowRec As DataRow In destDt.Rows

                rowRec("日付") = rowRec("Lecture_Date")
                rowRec("講師ｺｰﾄﾞ") = rowRec("Teacher_Code")
                rowRec("講師名") = rowRec("Teacher_Name")

                ' 日付関連
                'Dim dtDate As Date = rowRec("Lecture_Date")
                'Dim strDay As String = dtDate.ToString("ddd")
                'rowRec("日付") = dtDate.ToString("yyyy/MM/dd") & "(" & strDay & ")"
                'rowRec("日付KEY") = dtDate.ToString("yyyyMMdd")
                'Dim dateForeColor As Color = Color.Black
                'If (Weekday(dtDate) = 1) Then
                '    dateForeColor = Color.Red
                'ElseIf (Weekday(dtDate) = 7) Then
                '    dateForeColor = Color.Blue
                'End If

                ' 打刻関連
                Dim model As New AttendanceModel()
                model.PunchStartTime = TimeSpanParse(rowRec, "出勤時刻")
                model.PunchEndTime = TimeSpanParse(rowRec, "退勤時刻")
                model.LectureStart = TimeSpanParse(rowRec, "出講開始時間")
                model.LectureEnd = TimeSpanParse(rowRec, "出講終了時間")
                model.TaskStart = TimeSpanParse(rowRec, "業務届開始時間")
                model.TaskEnd = TimeSpanParse(rowRec, "業務届終了時間")
                model.NumberOfPunched = GetValueWithNothing(rowRec, "打刻回数")

                ' みなし(授業前後)
                Dim workDecimal As Byte?
                workDecimal = GetValueWithNothing(rowRec, "Deemed_Time_Before")
                model.DeemedTimeBefore = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                workDecimal = GetValueWithNothing(rowRec, "Deemed_Time_After")
                model.DeemedTimeAfter = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                model.DeemedStartTime = CalcDeemedTimeStart(model)
                model.DeemedEndTime = CalcDeemedTimeEnd(model)
                Dim ts As TimeSpan?
                ts = CalcScheduleStartTime(model)
                rowRec("実務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcScheduleEndTime(model)
                rowRec("実務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeStart(model)
                rowRec("勤務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeEnd(model)
                rowRec("勤務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)

                ' 時間重複(打刻・打刻外業務給)
                model.OverlapOther = GetValueWithNothing(rowRec, "打刻外業務重複")

                ' 時間重複(出講内)
                model.OverlapLecture = GetValueWithNothing(rowRec, "出講授業重複")

                ' 時間重複(出講・業務届)
                model.OverlapLectTask = GetValueWithNothing(rowRec, "出講業務届重複")

                ' 交通費関連
                Dim room As String = ""
                Dim idx As Integer = 1
                For i As Integer = 0 To 6 - 1
                    room = GetValueWithNothing(rowRec, "出講教室" & idx.ToString())
                    If StringUtil.IsNullOrWhiteSpace(room) Then
                        Exit For
                    End If

                    Dim item As New KomaInfoItem
                    item.Site_Code = GetValueWithNothing(rowRec, "出講教室" & idx.ToString())
                    item.Grade = GetValueWithNothing(rowRec, "出講学年" & idx.ToString())
                    item.Class_Code = GetValueWithNothing(rowRec, "出講クラス" & idx.ToString())
                    item.Koma_Seq = GetValueWithNothing(rowRec, "出講コマ" & idx.ToString())
                    item.Pinch_Type = GetValueWithNothing(rowRec, "出講ピンチ" & idx.ToString())
                    item.Start_Time = TimeSpanParse(rowRec, "出講開始" & idx.ToString())
                    item.End_Time = TimeSpanParse(rowRec, "出講終了" & idx.ToString())
                    item.Amount = GetValueWithNothing(rowRec, "交通費" & idx.ToString())
                    item.LectureCoefficient = GetValueWithNothing(rowRec, "授業給係数" & idx.ToString())
                    model.KomaInfoItems.Add(item)
                Next

                Dim vMonthly As New AttendanceValidator(ValidationRuleSet.MonthlyCheck)
                Dim resDaily = vMonthly.Validate(model)

                rowRec("勤務開始時間") = model.DeemedStartTime
                rowRec("勤務終了時間") = model.DeemedEndTime
                rowRec("報酬日額") = model.DailyRewards
                rowRec("勤務時間") = model.DeemedHours
                rowRec("業務給") = model.WorkSalary
                rowRec("授業給") = model.LectureFee

                rowRec("状態") = ""
                If resDaily IsNot Nothing AndAlso resDaily.Count > 0 Then
                    rowRec("状態") = resDaily.OrderBy(Function(p) p.Priority).ToList(0).Message
                End If
            Next
        Catch ex As Exception

        End Try

        Return destDt
    End Function

    Public Function AttendanceValidate(ByVal dt As DataTable) As List(Of ValidationRuleResult)
        Dim result As New List(Of ValidationRuleResult)
        Dim destDt As DataTable = dt.Copy()

        Try
            For Each rowRec As DataRow In destDt.Rows
                Dim model As New AttendanceModel()
                ' 打刻時間関連情報
                model.PunchStartTime = TimeSpanParse(rowRec, "出勤時刻")
                model.PunchEndTime = TimeSpanParse(rowRec, "退勤時刻")
                model.LectureStart = TimeSpanParse(rowRec, "出講開始時間")
                model.LectureEnd = TimeSpanParse(rowRec, "出講終了時間")
                model.TaskStart = TimeSpanParse(rowRec, "業務届開始時間")
                model.TaskEnd = TimeSpanParse(rowRec, "業務届終了時間")
                model.NumberOfPunched = GetValueWithNothing(rowRec, "打刻回数")

                ' みなし時間
                Dim workDecimal As Byte?
                workDecimal = GetValueWithNothing(rowRec, "Deemed_Time_Before")
                model.DeemedTimeBefore = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                workDecimal = GetValueWithNothing(rowRec, "Deemed_Time_After")
                model.DeemedTimeAfter = IIf(workDecimal Is Nothing, Nothing, TimeSpan.FromMinutes(CDbl(workDecimal)))
                model.DeemedStartTime = CalcDeemedTimeStart(model)
                model.DeemedEndTime = CalcDeemedTimeEnd(model)

                Dim ts As TimeSpan?
                ts = CalcScheduleStartTime(model)
                rowRec("実務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcScheduleEndTime(model)
                rowRec("実務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeStart(model)
                rowRec("勤務開始時間") = IIf(ts Is Nothing, DBNull.Value, ts)
                ts = CalcDeemedTimeEnd(model)
                rowRec("勤務終了時間") = IIf(ts Is Nothing, DBNull.Value, ts)

                ' 時間重複(打刻・打刻外業務給)
                model.OverlapOther = GetValueWithNothing(rowRec, "打刻外業務重複")

                ' 時間重複(出講内)
                model.OverlapLecture = GetValueWithNothing(rowRec, "出講授業重複")

                ' 時間重複(出講・業務届)
                model.OverlapLectTask = GetValueWithNothing(rowRec, "出講業務届重複")

                ' 交通費関連
                Dim room As String = ""
                Dim idx As Integer = 1
                For i As Integer = 0 To 6 - 1
                    room = GetValueWithNothing(rowRec, "出講教室" & idx.ToString())
                    If StringUtil.IsNullOrWhiteSpace(room) Then
                        Exit For
                    End If

                    Dim item As New KomaInfoItem
                    item.Site_Code = GetValueWithNothing(rowRec, "出講教室" & idx.ToString())
                    item.Grade = GetValueWithNothing(rowRec, "出講学年" & idx.ToString())
                    item.Class_Code = GetValueWithNothing(rowRec, "出講クラス" & idx.ToString())
                    item.Koma_Seq = GetValueWithNothing(rowRec, "出講コマ" & idx.ToString())
                    item.Pinch_Type = GetValueWithNothing(rowRec, "出講ピンチ" & idx.ToString())
                    item.Start_Time = TimeSpanParse(rowRec, "出講開始" & idx.ToString())
                    item.End_Time = TimeSpanParse(rowRec, "出講終了" & idx.ToString())
                    item.LectureCoefficient = GetValueWithNothing(rowRec, "授業給係数" & idx.ToString())
                    item.Amount = GetValueWithNothing(rowRec, "交通費" & idx.ToString())
                    model.KomaInfoItems.Add(item)
                Next

                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                result = vDaily.Validate(model)
            Next
        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    ''' <summary>
    ''' バリデーションエラーをDataTableに変換する。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function ListToDataTable(ByVal list As List(Of ValidationRuleResult)) As DataTable

        Dim dt As New DataTable()
        dt.Columns.Add("Priority", GetType(Integer))
        dt.Columns.Add("IsError", GetType(Integer))
        dt.Columns.Add("Level", GetType(Integer))
        dt.Columns.Add("Message", GetType(String))
        dt.Columns.Add("RuleId", GetType(String))
        dt.Columns.Add("LevelString", GetType(String))

        For Each item As ValidationRuleResult In list
            Dim dr As DataRow = dt.NewRow()
            dr("Priority") = item.Priority
            dr("IsError") = item.IsError
            dr("Level") = item.Level
            dr("Message") = item.Message
            dr("RuleId") = item.RuleId
            dr("LevelString") = item.LevelString
            dt.Rows.Add(dr)
        Next

        Return dt
    End Function


    ''' <summary>
    ''' みなし開始時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleStartTime(ByVal model As AttendanceModel) As TimeSpan?

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.DeemedStartTime = model.LectureStart
            Else
                model.DeemedStartTime = model.TaskStart
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.DeemedStartTime = model.TaskStart
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.DeemedStartTime = model.LectureStart
        End If

        Return model.DeemedStartTime
    End Function

    ''' <summary>
    ''' みなし終了時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleEndTime(ByVal model As AttendanceModel) As TimeSpan?

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.DeemedEndTime = model.LectureEnd
            Else
                model.DeemedEndTime = model.TaskEnd
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.TaskEnd
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.LectureEnd
        End If

        Return model.DeemedEndTime
    End Function








    ''' <summary>
    ''' みなし開始時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeStart(ByVal model As AttendanceModel) As TimeSpan?

        If Not model.PunchStartTime.HasValue Then
            Return Nothing
        End If

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.DeemedStartTime = IIf(model.PunchStartTime < model.LectureStart - model.DeemedTimeBefore,
                                            model.PunchStartTime,
                                            model.LectureStart - model.DeemedTimeBefore)
            Else
                model.DeemedStartTime = model.PunchStartTime
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.DeemedStartTime = model.PunchStartTime
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.DeemedStartTime = IIf(model.PunchStartTime < model.LectureStart - model.DeemedTimeBefore,
                                        model.PunchStartTime,
                                        model.LectureStart - model.DeemedTimeBefore)
        End If

        Return model.DeemedStartTime
    End Function

    ''' <summary>
    ''' みなし終了時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeEnd(ByVal model As AttendanceModel) As TimeSpan?

        If Not model.PunchEndTime.HasValue Then
            Return Nothing
        End If

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.DeemedEndTime = IIf(model.PunchEndTime > model.LectureEnd + model.DeemedTimeAfter,
                                            model.PunchEndTime,
                                            model.LectureEnd + model.DeemedTimeAfter)
            Else
                model.DeemedEndTime = model.PunchEndTime
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.DeemedEndTime = model.PunchEndTime
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.DeemedEndTime = IIf(model.PunchEndTime > model.LectureEnd + model.DeemedTimeAfter,
                                        model.PunchEndTime,
                                        model.LectureEnd + model.DeemedTimeAfter)
        End If

        Return model.DeemedEndTime
    End Function



    Private Function TimeSpanParse(ByVal row As DataRow, ByVal colName As String) As TimeSpan?
        Dim ts As TimeSpan? = Nothing

        If IsDBNull(row(colName)) Then
            Return ts
        End If

        Dim val As String = row(colName).ToString()
        ts = TimeSpan.Parse(val)
        Return ts
    End Function

    Private Function GetValueWithNothing(ByVal row As DataRow, ByVal colName As String) As Object
        If IsDBNull(row(colName)) Then
            Return Nothing
        End If

        Return row(colName)
    End Function

End Class
