﻿Public Class ResponceData
    Inherits ResultInfoData

    Public Property ResultData As New ResultData

End Class
