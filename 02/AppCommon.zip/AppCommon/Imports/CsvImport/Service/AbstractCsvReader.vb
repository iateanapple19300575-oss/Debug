﻿'Imports System.IO

'Imports System.Text
'Imports ClassLibrary
'Imports Microsoft.VisualBasic.FileIO

'''' <summary>
'''' CSV Reader の共通処理を提供する抽象クラス。
'''' </summary>
'Public MustInherit Class AbstractCsvReader
'  Implements ICsvReader
'  Public MustOverride Property CsvName As String
'  Public MustOverride Function Headers() As List(Of String)
'  Public MustOverride Function ContentAlign() As List(Of Integer)
'  Public MustOverride Function CreateTableDefinition() As DataTable
'  Public MustOverride Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional ByVal yearMonth As Date = Nothing) As DataTable
'  Public MustOverride Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable


'  Protected Function ConvertNullToDBNullWithDateTime(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, DateTime.Parse(value))
'  End Function

'  Protected Function ConvertNullToDBNullWithTimeSpan(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, TimeSpan.Parse(value))
'  End Function

'  Protected Function ConvertNullToDBNullWithByte(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, Byte.Parse(value))
'  End Function

'  Protected Function ConvertNullToDBNullWithInt16(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, Int16.Parse(value))
'  End Function

'  Protected Function ConvertNullToDBNullWithInt32(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, Int32.Parse(value))
'  End Function

'  Protected Function ConvertNullToDBNullWithDecimal(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, Decimal.Parse(value))
'  End Function

'  Protected Function ConvertNullToDBNullWithDouble(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, Double.Parse(value))
'  End Function

'  Protected Function ConvertNullToDBNullWithString(ByVal value As String) As Object
'    Return If(String.IsNullOrEmpty(value), DBNull.Value, value)
'  End Function

'  Public Function Read(ByVal filePath As String) As List(Of Dictionary(Of String, String)) _
'      Implements ICsvReader.Read

'    Dim csvDataDic As New List(Of Dictionary(Of String, String))
'    Dim CsvDataCounter As Integer = 0
'    Using parser As New TextFieldParser(filePath, Encoding.GetEncoding("Shift_JIS"))

'      ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
'      parser.TextFieldType = FieldType.Delimited
'      parser.SetDelimiters(",")
'      parser.HasFieldsEnclosedInQuotes = True

'      Dim columns As String() = Headers.ToArray()

'      While Not parser.EndOfData
'        Dim fields As String() = parser.ReadFields()
'        CsvDataCounter += 1

'        ' CSV項目数チェック
'        If fields.Length <> columns.Count Then
'          'result.FormarError = True
'          'result.Success = False
'          Exit While
'        End If

'        ' ヘッダ行スキップ
'        If (CsvDataCounter = 1) Then
'          Continue While
'        End If

'        Dim row As New Dictionary(Of String, String)
'        For i As Integer = 0 To columns.Length - 1
'          row.Add(columns(i), fields(i))
'        Next
'        csvDataDic.Add(row)
'      End While

'    End Using

'    Return csvDataDic
'  End Function

'  Public Function FormatValidation(filePath As String) As Boolean Implements ICsvReader.FormatValidation
'    Throw New NotImplementedException()
'  End Function
'End Class