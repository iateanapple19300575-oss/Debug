﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto

Public Interface IImportProcessedRepository
  Function InsertProcessedData(ByVal param As CsvImportParameterDto, tran As SqlTransaction) As Integer
  Function BulkCopyImport(param As CsvImportParameterDto, tran As SqlTransaction) As Integer
End Interface
