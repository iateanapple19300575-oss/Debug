﻿Public Interface IMasterCsvImporter
    Function Execute() As ImportResultInfo
End Interface
