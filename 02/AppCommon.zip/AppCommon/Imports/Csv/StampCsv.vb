﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class StampCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.PunchData

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.PunchData

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.PunchData

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub

    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
            ({
              "(年月日)", "姓", "名", "姓 名", "スタッフコード", "出勤時刻", "退勤時刻", "出勤実時刻", "退勤実時刻", "打刻回数", "打刻修正数"
            })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
            ({
              DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleLeft _
              , DataGridViewContentAlignment.MiddleLeft _
              , DataGridViewContentAlignment.MiddleLeft _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleRight _
              , DataGridViewContentAlignment.MiddleRight
            })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            CsvDataTable.Columns.Add("Last_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("First_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Full_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Staff_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Plan_Start_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("Plan_End_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("Punch_Count", Type.GetType("System.Single"))
            CsvDataTable.Columns.Add("Punch_Revisions", Type.GetType("System.Single"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim checkdate As String = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnStamp.日付)))
                If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(checkdate, yearMonth) = False) Then
                    Continue For
                End If

                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnStamp.日付)))
                addRowData.Item("Last_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnStamp.姓)))
                addRowData.Item("First_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnStamp.名)))
                addRowData.Item("Full_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnStamp.姓名)))
                addRowData.Item("Staff_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnStamp.スタッフコード)))
                addRowData.Item("Plan_Start_time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnStamp.出勤時刻)))
                addRowData.Item("Plan_End_time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnStamp.退勤時刻)))
                addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnStamp.出勤実時刻)))
                addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnStamp.退勤実時刻)))
                addRowData.Item("Punch_Count") = ConvertNullToDBNullWithByte(rowData(Headers(CsvColumnStamp.打刻回数)))
                addRowData.Item("Punch_Revisions") = ConvertNullToDBNullWithByte(rowData(Headers(CsvColumnStamp.打刻修正数)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    ' 対象年月以外は、捨てる
                    If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(fields(CsvColumnStamp.日付), yearMonth) = False) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnStamp.日付))
                    addRowData.Item("Last_Name") = ConvertNullToDBNullWithString(fields(CsvColumnStamp.姓))
                    addRowData.Item("First_Name") = ConvertNullToDBNullWithString(fields(CsvColumnStamp.名))
                    addRowData.Item("Full_Name") = ConvertNullToDBNullWithString(fields(CsvColumnStamp.姓名))
                    addRowData.Item("Staff_Code") = ConvertNullToDBNullWithString(fields(CsvColumnStamp.スタッフコード))
                    addRowData.Item("Plan_Start_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnStamp.出勤時刻))
                    addRowData.Item("Plan_End_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnStamp.退勤時刻))
                    addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnStamp.出勤実時刻))
                    addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnStamp.退勤実時刻))
                    addRowData.Item("Punch_Count") = ConvertNullToDBNullWithDouble(fields(CsvColumnStamp.打刻回数))
                    addRowData.Item("Punch_Revisions") = ConvertNullToDBNullWithDouble(fields(CsvColumnStamp.打刻修正数))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
            New SqlBulkCopyColumnMapping("Last_Name", "Last_Name"),
            New SqlBulkCopyColumnMapping("First_Name", "First_Name"),
            New SqlBulkCopyColumnMapping("Full_Name", "Full_Name"),
            New SqlBulkCopyColumnMapping("Staff_Code", "Staff_Code"),
            New SqlBulkCopyColumnMapping("Plan_Start_Time", "Plan_Start_Time"),
            New SqlBulkCopyColumnMapping("Plan_End_Time", "Plan_End_Time"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time"),
            New SqlBulkCopyColumnMapping("Punch_Count", "Punch_Count"),
            New SqlBulkCopyColumnMapping("Punch_Revisions", "Punch_Revisions")
        }
    End Function
End Class
