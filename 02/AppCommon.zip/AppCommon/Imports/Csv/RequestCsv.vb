﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class RequestCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.RequestActual

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.RequestActual

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.RequestActual

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub


    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
                ({
                    "教室", "科目", "講師名", "日付", "業務名", "開始", "終了", "対象", "内容", "コード",
                    "区分", "実時間", "＠", "乗数", "みなし回数", "金額", "担当者", "リーダー", "教務室"
                })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
                ({
                    DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleLeft
                })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Subject", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Teacher_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            CsvDataTable.Columns.Add("Business_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("Target", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Contents", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Category", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Real_Time", Type.GetType("System.Int16"))
            CsvDataTable.Columns.Add("Unit_Pice", Type.GetType("System.Decimal"))
            CsvDataTable.Columns.Add("Multiplier", Type.GetType("System.Double"))
            CsvDataTable.Columns.Add("Deemed_Count", Type.GetType("System.Double"))
            CsvDataTable.Columns.Add("Amount", Type.GetType("System.Decimal"))
            CsvDataTable.Columns.Add("Person_In_Charge", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Leader", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Academic_Office", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim checkdate As String = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnStamp.日付)))
                If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(checkdate, yearMonth) = False) Then
                    Continue For
                End If

                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.教室)))
                addRowData.Item("Subject") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.科目)))
                addRowData.Item("Teacher_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.講師名)))
                addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnRequest.日付)))
                addRowData.Item("Business_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.業務名)))
                addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnRequest.開始)))
                addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnRequest.終了)))
                addRowData.Item("Target") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.対象)))
                addRowData.Item("Contents") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.内容)))
                addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.コード)))
                addRowData.Item("Category") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.区分)))
                addRowData.Item("Real_Time") = ConvertNullToDBNullWithInt16(rowData(Headers(CsvColumnRequest.実時間)))
                addRowData.Item("Unit_Pice") = ConvertNullToDBNullWithDecimal(rowData(Headers(CsvColumnRequest.単価)))
                addRowData.Item("Multiplier") = ConvertNullToDBNullWithDouble(rowData(Headers(CsvColumnRequest.乗数)))
                addRowData.Item("Deemed_Count") = ConvertNullToDBNullWithDouble(rowData(Headers(CsvColumnRequest.みなし回数)))
                addRowData.Item("Amount") = ConvertNullToDBNullWithDecimal(rowData(Headers(CsvColumnRequest.金額)))
                addRowData.Item("Person_In_Charge") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.担当者)))
                addRowData.Item("Leader") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.リーダー)))
                addRowData.Item("Academic_Office") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnRequest.教務室)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    ' 対象年月以外は、捨てる
                    If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(fields(CsvColumnRequest.日付), yearMonth) = False) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.教室))
                    addRowData.Item("Subject") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.科目))
                    addRowData.Item("Teacher_Name") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.講師名))
                    addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnRequest.日付))
                    addRowData.Item("Business_Name") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.業務名))
                    addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnRequest.開始))
                    addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnRequest.終了))
                    addRowData.Item("Target") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.対象))
                    addRowData.Item("Contents") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.内容))
                    addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.コード))
                    addRowData.Item("Category") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.区分))
                    addRowData.Item("Real_Time") = ConvertNullToDBNullWithInt16(fields(CsvColumnRequest.実時間))
                    addRowData.Item("Unit_Pice") = ConvertNullToDBNullWithDecimal(fields(CsvColumnRequest.単価))
                    addRowData.Item("Multiplier") = ConvertNullToDBNullWithDouble(fields(CsvColumnRequest.乗数))
                    addRowData.Item("Deemed_Count") = ConvertNullToDBNullWithDouble(fields(CsvColumnRequest.みなし回数))
                    addRowData.Item("Amount") = ConvertNullToDBNullWithDecimal(fields(CsvColumnRequest.金額))
                    addRowData.Item("Person_In_Charge") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.担当者))
                    addRowData.Item("Leader") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.リーダー))
                    addRowData.Item("Academic_Office") = ConvertNullToDBNullWithString(fields(CsvColumnRequest.教務室))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Subject", "Subject"),
            New SqlBulkCopyColumnMapping("Teacher_Name", "Teacher_Name"),
            New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
            New SqlBulkCopyColumnMapping("Business_Name", "Business_Name"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time"),
            New SqlBulkCopyColumnMapping("Target", "Target"),
            New SqlBulkCopyColumnMapping("Contents", "Contents"),
            New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
            New SqlBulkCopyColumnMapping("Category", "Category"),
            New SqlBulkCopyColumnMapping("Real_Time", "Real_Time"),
            New SqlBulkCopyColumnMapping("Unit_Pice", "Unit_Pice"),
            New SqlBulkCopyColumnMapping("Multiplier", "Multiplier"),
            New SqlBulkCopyColumnMapping("Deemed_Count", "Deemed_Count"),
            New SqlBulkCopyColumnMapping("Amount", "Amount"),
            New SqlBulkCopyColumnMapping("Person_In_Charge", "Person_In_Charge"),
            New SqlBulkCopyColumnMapping("Leader", "Leader"),
            New SqlBulkCopyColumnMapping("Academic_Office", "Academic_Office")
        }
    End Function

End Class
