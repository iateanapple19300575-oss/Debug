﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class TeacherWageCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.TeacherUnitPrice

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.TeacherUnitPrice

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.TeacherUnitPrice

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub


    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
            ({
              "講師コード", "適用年月日", "授業給コマ単価", "業務給単価"
            })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
            ({
              DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleCenter _
              , DataGridViewContentAlignment.MiddleRight _
              , DataGridViewContentAlignment.MiddleRight
            })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Effective_Date", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Lecture_Unit_Price", Type.GetType("System.Int32"))
            CsvDataTable.Columns.Add("Task_Unit_Price", Type.GetType("System.Int32"))
            'CsvDataTable.Columns.Add("Create_Date", Type.GetType("System.DateTime"))
            'CsvDataTable.Columns.Add("Create_User", Type.GetType("System.String"))
            'CsvDataTable.Columns.Add("Update_Date", Type.GetType("System.DateTime"))
            'CsvDataTable.Columns.Add("Update_User", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTeacherWage.講師コード)))
                addRowData.Item("Effective_Date") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTeacherWage.適用年月)))
                addRowData.Item("Lecture_Unit_Price") = ConvertNullToDBNullWithInt32(rowData(Headers(CsvColumnTeacherWage.授業給コマ単価)))
                addRowData.Item("Task_Unit_Price") = ConvertNullToDBNullWithInt32(rowData(Headers(CsvColumnTeacherWage.業務給単価)))
                'addRowData.Item("Create_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnTeacherWage.作成日)))
                'addRowData.Item("Create_User") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTeacherWage.作成者)))
                'addRowData.Item("Update_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnTeacherWage.更新日)))
                'addRowData.Item("Update_User") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTeacherWage.更新者)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(fields(CsvColumnTeacherWage.講師コード))
                    addRowData.Item("Effective_Date") = ConvertNullToDBNullWithString(fields(CsvColumnTeacherWage.適用年月))
                    addRowData.Item("Lecture_Unit_Price") = ConvertNullToDBNullWithInt32(fields(CsvColumnTeacherWage.授業給コマ単価))
                    addRowData.Item("Task_Unit_Price") = ConvertNullToDBNullWithInt32(fields(CsvColumnTeacherWage.業務給単価))
                    'addRowData.Item("Create_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnTeacherWage.作成日))
                    'addRowData.Item("Create_User") = ConvertNullToDBNullWithString(fields(CsvColumnTeacherWage.作成者))
                    'addRowData.Item("Update_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnTeacherWage.更新日))
                    'addRowData.Item("Update_User") = ConvertNullToDBNullWithString(fields(CsvColumnTeacherWage.更新者))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
            New SqlBulkCopyColumnMapping("Effective_Date", "Effective_Date"),
            New SqlBulkCopyColumnMapping("Lecture_Unit_Price", "Lecture_Unit_Price"),
            New SqlBulkCopyColumnMapping("Task_Unit_Price", "Task_Unit_Price")
        }
    End Function

End Class
