﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class TimeTableClassCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.TimeTableClass

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.TimeTableClass

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.TimeTableClass

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub


    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
                ({
                    "Setting_Category", "Site_Code", "Target_Period", "Grade", "Class_Code", "Koma_Seq",
                    "Start_Time", "End_Time", "Create_Date", "Create_User", "Update_Date", "Update_User"
                })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
                ({
                    DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft
                })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Setting_Category", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Target_Period", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Grade", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Class_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Koma_Seq", Type.GetType("System.Byte"))
            CsvDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            CsvDataTable.Columns.Add("Create_Date", Type.GetType("System.DateTime"))
            CsvDataTable.Columns.Add("Create_User", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Update_Date", Type.GetType("System.DateTime"))
            CsvDataTable.Columns.Add("Update_User", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Setting_Category") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableClass.設定区分)))
                addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableClass.教室コード)))
                addRowData.Item("Target_Period") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableClass.対象期間)))
                addRowData.Item("Grade") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableClass.学年)))
                addRowData.Item("Class_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableClass.クラスコード)))
                addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithByte(rowData(Headers(CsvColumnTimeTableClass.コマ)))
                addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnTimeTableClass.開始時間)))
                addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(rowData(Headers(CsvColumnTimeTableClass.終了時間)))
                addRowData.Item("Create_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnTimeTableClass.作成日)))
                addRowData.Item("Create_User") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableClass.作成者)))
                addRowData.Item("Update_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnTimeTableClass.更新日)))
                addRowData.Item("Update_User") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimeTableClass.更新者)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Setting_Category") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableClass.設定区分))
                    addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableClass.教室コード))
                    addRowData.Item("Target_Period") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableClass.対象期間))
                    addRowData.Item("Grade") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableClass.学年))
                    addRowData.Item("Class_Code") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableClass.クラスコード))
                    addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithByte(fields(CsvColumnTimeTableClass.コマ))
                    addRowData.Item("Start_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnTimeTableClass.開始時間))
                    addRowData.Item("End_Time") = ConvertNullToDBNullWithTimeSpan(fields(CsvColumnTimeTableClass.終了時間))
                    addRowData.Item("Create_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnTimeTableClass.作成日))
                    addRowData.Item("Create_User") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableClass.作成者))
                    addRowData.Item("Update_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnTimeTableClass.更新日))
                    addRowData.Item("Update_User") = ConvertNullToDBNullWithString(fields(CsvColumnTimeTableClass.更新者))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Setting_Category", "Setting_Category"),
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Target_Period", "Target_Period"),
            New SqlBulkCopyColumnMapping("Grade", "Grade"),
            New SqlBulkCopyColumnMapping("Class_Code", "Class_Code"),
            New SqlBulkCopyColumnMapping("Koma_Seq", "Koma_Seq"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time")
        }
    End Function

End Class
