﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class DelegationCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.PinchActual

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.PinchActual

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.PinchActual

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub

    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
            ({
              "日付", "曜日", "コマ", "教室", "クラス", "担当", "出講名", "科目", "テキスト回", "ピンチ", "入力日"
            })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
                ({
                    DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleRight _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter
                })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Lecture_Date", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Youbi", Type.GetType("System.Byte"))
            CsvDataTable.Columns.Add("Koma_Seq", Type.GetType("System.Byte"))
            CsvDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Class_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Lecture_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Subject", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Number_Of_Text", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Pinch_type", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Input_Date", Type.GetType("System.DateTime"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim checkdate As String = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.日付)))
                If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(checkdate, yearMonth) = False) Then
                    Continue For
                End If

                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Lecture_date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnPinchActual.日付)))
                addRowData.Item("Youbi") = ConvertNullToDBNullWithByte(rowData(Headers(CsvColumnPinchActual.曜日)))
                addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithByte(rowData(Headers(CsvColumnPinchActual.コマ)))
                addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.教室)))
                addRowData.Item("Class_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.クラス)))
                addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.講師コード)))
                addRowData.Item("Lecture_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.出講名)))
                addRowData.Item("Subject") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.科目)))
                addRowData.Item("Number_Of_Text") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.テキスト回)))
                addRowData.Item("Pinch_Type") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPinchActual.ピンチ区分)))
                addRowData.Item("Input_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnPinchActual.入力日)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function


    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    ' 対象年月以外は、捨てる
                    If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(fields(CsvColumnPinchActual.日付), yearMonth) = False) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnPinchActual.日付))
                    addRowData.Item("Youbi") = ConvertNullToDBNullWithByte(fields(CsvColumnPinchActual.曜日))
                    addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithByte(fields(CsvColumnPinchActual.コマ))
                    addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(fields(CsvColumnPinchActual.教室))
                    addRowData.Item("Class_Code") = ConvertNullToDBNullWithString(fields(CsvColumnPinchActual.クラス))
                    addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(fields(CsvColumnPinchActual.講師コード))
                    addRowData.Item("Lecture_Name") = ConvertNullToDBNullWithString(fields(CsvColumnPinchActual.出講名))
                    addRowData.Item("Subject") = ConvertNullToDBNullWithString(fields(CsvColumnPinchActual.科目))
                    addRowData.Item("Number_Of_Text") = ConvertNullToDBNullWithString(fields(CsvColumnPinchActual.テキスト回))
                    addRowData.Item("Pinch_Type") = ConvertNullToDBNullWithString(fields(CsvColumnPinchActual.ピンチ区分))
                    addRowData.Item("Input_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnPinchActual.入力日))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
            New SqlBulkCopyColumnMapping("Youbi", "Youbi"),
            New SqlBulkCopyColumnMapping("Koma_Seq", "Koma_Seq"),
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Class_Code", "Class_Code"),
            New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
            New SqlBulkCopyColumnMapping("Lecture_Name", "Lecture_Name"),
            New SqlBulkCopyColumnMapping("Subject", "Subject"),
            New SqlBulkCopyColumnMapping("Number_Of_Text", "Number_Of_Text"),
            New SqlBulkCopyColumnMapping("Pinch_Type", "Pinch_Type"),
            New SqlBulkCopyColumnMapping("Input_Date", "Input_Date")
        }
    End Function
End Class
