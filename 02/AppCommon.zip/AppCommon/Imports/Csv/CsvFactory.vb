﻿Imports ImportType

Public Class CsvFactory

    Private Property CsvDataType As Integer = 0

    Public Sub New(ByVal dataType As Integer)
        Me.CsvDataType = dataType
    End Sub

    Public Function CreateCsv(ByVal fileName As String) As ICsv
        Select Case CsvDataType
            Case ImportCsvType.PunchData
                Return New StampCsv(fileName)
            Case ImportCsvType.LecturePlan
                Return New PlanCsv(fileName)
            Case ImportCsvType.LecturePlan
                Return New RequestCsv(fileName)
            Case ImportCsvType.PinchActual
                Return New DelegationCsv(fileName)
            Case ImportCsvType.TimePattern
                Return New TimePatternCsv(fileName)
            Case ImportCsvType.TimeTableSite
                Return New TimeTableSiteCsv(fileName)
            Case ImportCsvType.TimeTableClass
                Return New TimeTableClassCsv(fileName)
            Case ImportCsvType.TeacherUnitPrice
                Return New TeacherWageCsv(fileName)
            Case Else
                Return Nothing
        End Select
    End Function
End Class
