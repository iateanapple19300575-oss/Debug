﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class PlanCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.LecturePlan

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.LecturePlan

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.LecturePlan

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub

    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
        ({
          "日付", "曜日", "コマ", "教室", "クラス", "科目", "担当", "出講名", "テキスト回"
        })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
                ({
                    DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleLeft _
                    , DataGridViewContentAlignment.MiddleRight
                })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            CsvDataTable.Columns.Add("Youbi", Type.GetType("System.Byte"))
            CsvDataTable.Columns.Add("Koma_Seq", Type.GetType("System.Byte"))
            CsvDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Grade", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Class_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Subject", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Lecture_Name", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Number_Of_Text", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim checkdate As String = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.日付)))
                If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(checkdate, yearMonth) = False) Then
                    Continue For
                End If

                Dim lectureDate As String = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.日付)))
                Dim wyearMonth() As String = lectureDate.Split("/")

                Dim value As String = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.クラス)))
                Dim gradeValue As String = If(String.IsNullOrEmpty(value), "", value.Substring(0, 1))
                Dim clazzValue As String = If(String.IsNullOrEmpty(value), "", value.Substring(1, 2))

                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.日付)))
                addRowData.Item("Youbi") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.曜日)))
                addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.コマ)))
                addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.教室)))
                addRowData.Item("Grade") = gradeValue
                addRowData.Item("Class_Code") = clazzValue
                addRowData.Item("Subject") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.科目)))
                addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.担当)))
                addRowData.Item("Lecture_Name") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.出講名)))
                addRowData.Item("Number_Of_Text") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnPlan.テキスト回)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    ' 対象年月以外は、捨てる
                    If (IsNothing(yearMonth) OrElse DateUtil.IsInRangeOfMonth(fields(CsvColumnPlan.日付), yearMonth) = False) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    Dim lectureDate As String = ConvertNullToDBNullWithString(fields(CsvColumnPlan.日付))
                    Dim wyearMonth() As String = lectureDate.Split("/")

                    ' 学年とクラスの分離
                    Dim value As String = ConvertNullToDBNullWithString(fields(CsvColumnPlan.クラス))
                    Dim gradeValue As String = If(String.IsNullOrEmpty(value), "", value.Substring(0, 1))
                    Dim clazzValue As String = If(String.IsNullOrEmpty(value), "", value.Substring(1, 2))

                    addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.日付))
                    addRowData.Item("Youbi") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.曜日))
                    addRowData.Item("Koma_Seq") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.コマ))
                    addRowData.Item("Site_Code") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.教室))
                    addRowData.Item("Grade") = gradeValue
                    addRowData.Item("Class_Code") = clazzValue
                    addRowData.Item("Subject") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.科目))
                    addRowData.Item("Teacher_Code") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.担当))
                    addRowData.Item("Lecture_Name") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.出講名))
                    addRowData.Item("Number_Of_Text") = ConvertNullToDBNullWithString(fields(CsvColumnPlan.テキスト回))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
            New SqlBulkCopyColumnMapping("Youbi", "Youbi"),
            New SqlBulkCopyColumnMapping("Koma_Seq", "Koma_Seq"),
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Grade", "Grade"),
            New SqlBulkCopyColumnMapping("Class_Code", "Class_Code"),
            New SqlBulkCopyColumnMapping("Subject", "Subject"),
            New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
            New SqlBulkCopyColumnMapping("Lecture_Name", "Lecture_Name"),
            New SqlBulkCopyColumnMapping("Number_Of_Text", "Number_Of_Text")
        }
    End Function

End Class
