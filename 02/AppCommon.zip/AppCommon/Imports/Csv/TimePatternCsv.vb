﻿Imports System.Text
Imports Microsoft.VisualBasic.FileIO
Imports System.Windows.Forms
Imports ImportType
Imports System.Data.SqlClient

Public Class TimePatternCsv
    Inherits CsvAbstract

    ''' <summary>
    ''' CSV種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property CsvType As Integer = ImportCsvType.TimePattern

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property Ccategory As String = ImportCcategory.TimePattern

    ''' <summary>
    ''' データ名
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Property DataName As String = ImportDataName.TimePattern

    Protected CsvDataTable As New DataTable

    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
        CreateTableDefinition()
    End Sub


    ''' <summary>
    ''' CSV項目名リスト
    ''' </summary>
    Public Overrides Function Headers() As List(Of String)
        Return New List(Of String) _
                ({
                    "年度", "年月日", "曜日", "曜日区分"
                })
    End Function

    Public Overrides Function ContentAlign() As List(Of Integer)
        Return New List(Of Integer) _
                ({
                    DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleCenter _
                    , DataGridViewContentAlignment.MiddleLeft
                })
    End Function

    Public Overrides Function CreateTableDefinition() As DataTable
        Try
            CsvDataTable = New DataTable
            CsvDataTable.Columns.Add("Year", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            CsvDataTable.Columns.Add("Youbi", Type.GetType("System.String"))
            CsvDataTable.Columns.Add("Schedule_Pattern", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function CreateDataTable(ByVal csvDataDic As List(Of Dictionary(Of String, String)), Optional yearMonth As Date = #1/1/0001 12:00:00 AM#) As DataTable
        Try
            For Each rowData As Dictionary(Of String, String) In csvDataDic
                Dim addRowData As DataRow = CsvDataTable.NewRow
                addRowData.Item("Year") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimePattern.年度)))
                addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(rowData(Headers(CsvColumnTimePattern.年月日)))
                addRowData.Item("Youbi") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimePattern.曜日)))
                addRowData.Item("Schedule_Pattern") = ConvertNullToDBNullWithString(rowData(Headers(CsvColumnTimePattern.曜日区分)))
                CsvDataTable.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return CsvDataTable
    End Function

    ''' <summary>
    ''' CSV読み込み
    ''' </summary>
    ''' <param name="csvFileName"></param>
    ''' <returns></returns>
    Public Overrides Function Reader(ByVal csvFileName As String, Optional ByVal yearMonth As Date = Nothing) As DataTable
        Dim result As Boolean = False
        Dim columns As String() = Headers.ToArray()
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(csvFileName, Encoding.GetEncoding("Shift_JIS"))

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Count Then
                        result = False
                        Exit While
                    End If

                    ' ヘッダ行スキップ
                    If (CsvDataCounter = 1) Then
                        Continue While
                    End If

                    Dim addRowData As DataRow = CsvDataTable.NewRow
                    addRowData.Item("Year") = ConvertNullToDBNullWithString(fields(CsvColumnTimePattern.年度))
                    addRowData.Item("Lecture_Date") = ConvertNullToDBNullWithDateTime(fields(CsvColumnTimePattern.年月日))
                    addRowData.Item("Youbi") = ConvertNullToDBNullWithString(fields(CsvColumnTimePattern.曜日))
                    addRowData.Item("Schedule_Pattern") = ConvertNullToDBNullWithString(fields(CsvColumnTimePattern.曜日区分))
                    CsvDataTable.Rows.Add(addRowData)
                End While

            End Using

        Catch ex As Exception
            result = False
            Throw

        Finally

        End Try

        Return CsvDataTable
    End Function

    Public Overrides Function BuckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Year", "Year"),
            New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
            New SqlBulkCopyColumnMapping("Youbi", "Youbi"),
            New SqlBulkCopyColumnMapping("Schedule_Pattern", "Schedule_Pattern")
        }
    End Function

End Class
