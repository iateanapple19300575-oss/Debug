﻿Public Class CsvReaderFactory

	Private Property CsvDataType As Integer = 0

	Public Sub New(ByVal dataType As Integer)
		Me.CsvDataType = dataType
	End Sub

    Public Function CreateReader(ByVal fileName As String) As CsvReader
        Select Case CsvDataType
            Case TableImportHistoryConst.TYPE_T_STAMP
                Return New CsvReader(New StampCsv(fileName))
            Case TableImportHistoryConst.TYPE_LECTURE_REGULAR
                Return New CsvReader(New PlanCsv(fileName))
            Case TableImportHistoryConst.TYPE_BUSINESS_PUNCH
                Return New CsvReader(New RequestCsv(fileName))
            Case TableImportHistoryConst.TYPE_T_DELEGATION
                Return New CsvReader(New DelegationCsv(fileName))
            Case TableImportHistoryConst.TYPE_TIME_PATTERN
                Return New CsvReader(New TimePatternCsv(fileName))
            Case TableImportHistoryConst.TYPE_TIME_TABLE_SITE
                Return New CsvReader(New TimeTableSiteCsv(fileName))
            Case TableImportHistoryConst.TYPE_TIME_TABLE_CLASS
                Return New CsvReader(New TimeTableClassCsv(fileName))
            Case TableImportHistoryConst.TYPE_TEACHER_WAGE
                Return New CsvReader(New TeacherWageCsv(fileName))
            Case Else
                Return Nothing
        End Select
    End Function
End Class
