﻿Imports System.Data.SqlClient
Imports System.Windows.Forms

Public MustInherit Class DataGridViewDisplayService

    ' DataGridViewオブジェクト
    Property DataGridView As DataGridView

    ' SqlConnectionオブジェクト
    Property SqlConnection As SqlConnection

    ' SqlCommandオブジェクト
    Property SqlCommand As SqlCommand

    Private m_readerCount As Integer = 0

    Protected Property TargetDate As Date

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Sub New()

    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="p_targetDate">対象年月</param>
    Sub New(ByVal p_targetDate As Date, ByVal p_dataGridView As DataGridView)
        TargetDate = p_targetDate
        DataGridView = p_dataGridView
    End Sub

    Public Overridable Sub Display(Optional ByVal param As DaoParameter = Nothing)
        GetQuesryExecute(TargetDate, param)
    End Sub

    Protected MustOverride Function GetQuery(Optional ByVal param As DaoParameter = Nothing) As String

    Protected MustOverride Sub GetReaderValue(ByVal reader As SqlDataReader)

    Protected Function GetQuesryExecute(ByVal p_targetDate As Date, Optional ByVal param As DaoParameter = Nothing) As Boolean
        Dim result As Boolean = False

        Try
            Dim connStr As String = SqlDataBaseUtil.GetConnectionString()

            Using sourceSqlConnection As New SqlConnection(connStr)
                Using commandSourceData As New SqlCommand(GetQuery(param), sourceSqlConnection)
                    sourceSqlConnection.Open()
                    Dim reader As SqlDataReader = commandSourceData.ExecuteReader()
                    GetReaderValue(reader)
                    sourceSqlConnection.Close()
                End Using
            End Using
            result = True

        Catch ex As Exception
            MessageBox.Show("データベースアクセス中にエラーが発生しました: " & ex.Message)
            result = False
        Finally

        End Try

        Return result
    End Function

End Class
