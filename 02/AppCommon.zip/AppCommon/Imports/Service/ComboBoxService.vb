﻿Public Class ComboBoxService

  'Public Function SetComboForHalfYear(ByRef cmb As ComboBox) As DataTable
  '  Dim dtTable As New DataTable

  '  Dim result As ResultData = LoadClassRoomData()
  '  If result.Success Then
  '    dtTable = result.ResDataTable

  '    With cmbClassRoom
  '      Dim newRow As DataRow
  '      newRow = dtTable.NewRow()
  '      newRow("Site_Code") = ""
  '      newRow("Site_Name") = "(未選択)"
  '      dtTable.Rows.InsertAt(newRow, 0)
  '      newRow = dtTable.NewRow()
  '      newRow("Site_Code") = "ZZ"
  '      newRow("Site_Name") = "ZZ:全教室"
  '      dtTable.Rows.InsertAt(newRow, 1)

  '      .DataSource = dtTable
  '      .DisplayMember = "Site_Name"
  '      .ValueMember = "Site_Code"
  '    End With
  '  End If

  '  Return dtTable
  'End Function

End Class
