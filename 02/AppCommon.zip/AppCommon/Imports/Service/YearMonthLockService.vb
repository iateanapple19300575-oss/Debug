﻿Imports MainApp.Data.Entity

Public Class YearMonthLockService

    ''' <summary>
    ''' ロック状態
    ''' </summary>
    Private Const YEAR_MONTH_LOCKED As String = "L"

    ''' <summary>
    ''' ロック解除状態
    ''' </summary>
    Private Const YEAR_MONTH_UNLOCKED As String = "U"

    '''' <summary>
    '''' 対象年月ロックトラン
    '''' </summary>
    'Private tran As New YearMonthLockTran
    Private tran As New YearMonthLockDao

    ''' <summary>
    ''' 年月度ロック処理
    ''' </summary>
    ''' <param name="newYearMonth">新たにロックしようとしている年月</param>
    ''' <param name="nowYearMonth">現在ロックしている対象年月</param>
    ''' <returns></returns>
    Public Function YearMonthLock(ByVal newYearMonth As Date, ByVal nowYearMonth As Date) As ResultData
        Dim resCnount As Integer
        Dim resultDate As New List(Of YearMonthLockEntity)
        Dim result As New ResultData
        Try
            ' トランザクション開始
            'result = tran.BeginTransaction()
            'If Not result.Success Then
            '	Return result
            'End If

            ' 現在の対象年月度ロック解除
            If Not DateUtil.IsNullOrEmpty(nowYearMonth) Then
                resCnount = tran.UnLock(nowYearMonth.ToString("yyyyMM"))
                If resCnount < 1 Then
                    Return New ResultData
                End If
            End If

            ' 年月のロック情報取得
            Dim yearMonthStr As String = newYearMonth.ToString("yyyyMM")
            resultDate = tran.GetTargetDateInUse(yearMonthStr)

            ' 今回の対象年度ロック処理
            If resultDate.Count <= 0 Then
                ' 未登録(新規)
                resCnount = tran.LockForInsert(yearMonthStr)
            Else
                ' 他ユーザロック中
                If IsLocked(resultDate(0)) Then
                    ' 他ユーザロック中
                    result.SubStatus = 1
                    result.ResDataClass = resultDate(0)
                Else
                    ' 解除中または、自端末ロック中
                    resCnount = tran.LockForUpdate(yearMonthStr)
                End If
            End If
            result.Success = True

        Catch ex As Exception
            result.Success = False
            Throw
        Finally

            '' トランザクション異常終了
            'If result.Success Then
            '	result = tran.CommitTransaction()
            'Else
            '	result = tran.RollbackTransaction()
            'End If

        End Try

        Return result
    End Function

    '''' <summary>
    '''' 他ユーザロック中判定
    '''' </summary>
    '''' <param name="dic"></param>
    '''' <returns></returns>
    'Private Function IsLocked(ByVal dic As Dictionary(Of String, String)) As Boolean
    '  If dic(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック状態)) = YEAR_MONTH_LOCKED AndAlso
    '    (Not dic(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始ユーザー)) = Environment.UserName OrElse
    '     Not dic(DbMapper.GetColumnName(Of T_Year_Month_LockEnum)(T_Year_Month_LockEnum.ロック開始PC)) = Environment.MachineName) Then
    '    Return True
    '  End If

    '  Return False
    'End Function

    ''' <summary>
    ''' 他ユーザロック中判定
    ''' </summary>
    ''' <param name="dic"></param>
    ''' <returns></returns>
    Private Function IsLocked(ByVal dic As YearMonthLockEntity) As Boolean
        If dic.Lock_Status = YEAR_MONTH_LOCKED AndAlso
          (Not dic.Lock_User = Environment.UserName OrElse
           Not dic.Lock_Pc = Environment.MachineName) Then
            Return True
        End If

        Return False
    End Function


    ''' <summary>
    ''' ロック強制解除
    ''' </summary>
    ''' <param name="yearMonth"></param>
    ''' <returns></returns>
    Public Function UnLockedTargetYearMonth(ByVal yearMonth As Date) As ResultData
        Dim result As New ResultData
        Dim resCnount As Integer

        Try
            ' トランザクション開始
            'result = tran.BeginTransaction()
            'If Not result.Success Then
            '	Return result
            'End If

            ' 対象年月度ロック済み
            If Not DateUtil.IsNullOrEmpty(yearMonth) Then
                ' 年月度ロック解除
                resCnount = tran.ForcedRelease(yearMonth.ToString("yyyyMM"))
                'If Not result.Success Then
                '  Return result
                'End If
            End If
            result.Success = True

        Catch ex As Exception
            result.Success = False
            Throw

        Finally
            ' トランザクション異常終了
            'If result.Success Then
            '	result = tran.CommitTransaction()
            'Else
            '	result = tran.RollbackTransaction()
            'End If
        End Try

        Return result
    End Function

End Class
