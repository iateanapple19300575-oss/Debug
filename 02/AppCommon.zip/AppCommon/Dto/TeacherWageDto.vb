Namespace MainApp.Data.Dto

    ''' <summary>
    ''' DTO�B
    ''' </summary>
    Public Class TeacherWageDto

        ''' <summary>
        ''' �u�t�R�[�h
        ''' </summary>
        Public Property Teacher_Code As String

        ''' <summary>
        ''' �K�p�N����
        ''' </summary>
        Public Property Effective_Date As Date

        ''' <summary>
        ''' ���Ƌ��R�}�P��
        ''' </summary>
        Public Property Lecture_Unit_Price As Integer

        ''' <summary>
        ''' �Ɩ����P��
        ''' </summary>
        Public Property Task_Unit_Price As Integer

    End Class

End Namespace
