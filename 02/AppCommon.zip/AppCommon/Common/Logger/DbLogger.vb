﻿Imports System.Data.SqlClient
Imports System.Threading

''' <summary>
''' データベースへログを書き込むためのロガークラス。
''' アプリケーション内の操作ログ・エラーログを永続化する役割を持つ。
''' </summary>
Public Class DbLogger

	''' <summary>
	''' ログ書き込みに使用するデータベース接続文字列。
	''' </summary>
	Private Shared ReadOnly _connectionString As String = SqlDataBaseUtil.GetConnectionString()

	''' <summary>
	''' ログを非同期でデータベースへ書き込む。
	''' ThreadPool に処理を投げるため、呼び出し元スレッドをブロックしない。
	''' DB 書き込みに失敗した場合は Windows イベントログへエラーを記録する。
	''' </summary>
	''' <param name="screenName">ログ発生元の画面名</param>
	''' <param name="controlName">ログ発生元のコントロール名</param>
	''' <param name="eventName">ログイベント名</param>
	''' <param name="message">ログメッセージ本文</param>
	''' <param name="level">ログレベル（文字列）</param>
	''' <param name="errorCode">エラーコード（未指定の場合は NULL として保存）</param>
	Public Shared Sub InsertAsync(screenName As String,
                                  controlName As String,
                                  eventName As String,
                                  message As String,
                                  level As String,
                                  errorCode As String)

        ThreadPool.QueueUserWorkItem(
            Sub(state)
				Try
					Insert(screenName, controlName, eventName, message, level, errorCode)
				Catch ex As Exception
					' DB 書き込みに失敗した場合は Windows イベントログにエラーを書き込む
					Try
                        EventLog.WriteEntry("Application",
                                            "[LectPay]DataBase Log Write Error: " & ex.Message,
                                            EventLogEntryType.Error)
                    Catch
                        ' イベントログ書き込みにも失敗した場合は握りつぶす
                    End Try
                End Try
            End Sub)
    End Sub

	''' <summary>
	''' ログをデータベースへ同期的に書き込む。
	''' DB 接続の確立、パラメータ化クエリによる INSERT 実行を行う。
	''' 書き込み失敗時は Windows イベントログへエラーを記録する。
	''' </summary>
	''' <param name="screenName">ログ発生元の画面名</param>
	''' <param name="controlName">ログ発生元のコントロール名</param>
	''' <param name="eventName">ログイベント名</param>
	''' <param name="message">ログメッセージ本文</param>
	''' <param name="level">ログレベル（文字列）</param>
	''' <param name="errorCode">エラーコード（空文字または NULL の場合は DB には NULL を保存）</param>
	Public Shared Sub Insert(screenName As String,
							 controlName As String,
							 eventName As String,
							 message As String,
							 level As String,
							 errorCode As String)

		'Try
		'	' DB接続開始
		'	Using cn As New SqlConnection(_connectionString)
		'		cn.Open()

		'		' INSERT 文
		'		Dim sql As String =
		'			"INSERT INTO LogTable (LogDate, ScreenName, ControlName, EventName, Message, Level, ErrorCode) " &
		'			"VALUES (@LogDate, @ScreenName, @ControlName, @EventName, @Message, @Level, @ErrorCode)"

		'		' コマンド実行
		'		Using cmd As New SqlCommand(sql, cn)
		'			cmd.Parameters.AddWithValue("@LogDate", DateTime.Now)
		'			cmd.Parameters.AddWithValue("@ScreenName", screenName)
		'			cmd.Parameters.AddWithValue("@ControlName", controlName)
		'			cmd.Parameters.AddWithValue("@EventName", eventName)
		'			cmd.Parameters.AddWithValue("@Message", message)
		'			cmd.Parameters.AddWithValue("@Level", level)

		'			' errorCode が空なら DB には NULL を保存
		'			cmd.Parameters.AddWithValue("@ErrorCode",
		'				If(String.IsNullOrEmpty(errorCode), CType(DBNull.Value, Object), errorCode))

		'			cmd.ExecuteNonQuery()
		'		End Using
		'	End Using

		'Catch ex As Exception
		'	' DB 書き込みに失敗した場合は Windows イベントログにエラーを書き込む
		'	Try
		'		EventLog.WriteEntry("Application",
		'							"[LectPay]DataBase Log Write Error: " & ex.Message,
		'							EventLogEntryType.Error)
		'	Catch
		'		' イベントログ書き込みにも失敗した場合は握りつぶす
		'	End Try
		'End Try
		Dim details As String = eventName & " " & message
		OperationLogTran.Append(screenName, controlName, details)
	End Sub



	''' <summary>
	''' ログ保存
	''' </summary>
	''' <param name="winName">画面名</param>
	''' <param name="content">操作内容</param>
	''' <param name="detail">詳細内容</param>
	Protected Shared Sub LogWrite(ByVal winName As String, ByVal content As String, Optional detail As String = "")

		'' ログ登録用SQL文
		'Dim sqlString As New System.Text.StringBuilder
		'sqlString.Length = 0
		'sqlString.Append("INSERT INTO ")
		'sqlString.Append("  " & T_Operation_LogEnum.イベントID.Table).Append(" ")
		'sqlString.Append("  (")
		'sqlString.Append("      " & T_Operation_LogEnum.イベント発生日時.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.画面名.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.操作内容.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.操作詳細情報.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.対象年月度.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.実行ファイル名.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.実行ユーザー.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.実行PC.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.実行日.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.作成日.Column).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.作成者.Column).Append(" ")
		'sqlString.Append("  ) VALUES ( ")
		'sqlString.Append("      " & T_Operation_LogEnum.イベント発生日時.Param).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.画面名.Param).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.操作内容.Param).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.操作詳細情報.Param).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.対象年月度.Param).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.実行ファイル名.Param).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.実行ユーザー.Param).Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.実行PC.Param).Append(" ")
		'sqlString.Append("    , GETDATE()").Append(" ")
		'sqlString.Append("    , GETDATE()").Append(" ")
		'sqlString.Append("    , " & T_Operation_LogEnum.作成者.Param).Append(" ")
		'sqlString.Append("  )")
		'sqlString.Append(";")


		'' ログ出力項目の整理
		'Dim assemblyName As String = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name
		'Dim exeName As String = System.IO.Path.GetFileName(System.Windows.Forms.Application.ExecutablePath)
		'Dim targetDateW As Object = DBNull.Value
		'If Not DateUtil.IsNullOrEmpty(AppState.TargetYearMonth) Then
		'	targetDateW = String.Format("{0}/{1}",
		'						AppState.TargetYearMonth.Year.ToString("0000;[0000]"),
		'						AppState.TargetYearMonth.Month.ToString("00;[00]"))
		'End If

		'Try
		'	SqlCommandHelper.ExcuteNonQuery(sqlString.ToString(),
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.イベント発生日時.Param, .Value = DateTime.Now},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.画面名.Param, .Value = LogScreenName(winName)},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.操作内容.Param, .Value = content},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.操作詳細情報.Param, .Value = detail},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.対象年月度.Param, .Value = targetDateW},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行ファイル名.Param, .Value = exeName},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行ユーザー.Param, .Value = AppState.CurrentUserName},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.実行PC.Param, .Value = AppState.CurrentPcName},
		'		New SqlParameter() With {.ParameterName = T_Operation_LogEnum.作成者.Param, .Value = AppState.CurrentUserName}
		'	)

		'Catch ex As Exception

		'End Try
		Try
			OperationLogTran.Append(winName, content, detail)
		Catch ex As Exception

		End Try

	End Sub

	'''' <summary>
	'''' ログ出力用画面名取得
	'''' </summary>
	'''' <param name="name"></param>
	'''' <returns></returns>
	'Private Shared Function LogScreenName(ByVal name As String) As String
	'	Return name & "画面"
	'End Function

End Class