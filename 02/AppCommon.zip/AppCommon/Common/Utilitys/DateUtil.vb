﻿Imports Nts.Freamwork.Common.Utilities

Namespace MainApp.Common.Utility

    ''' <summary>
    ''' Date型ユーティリティクラス
    ''' </summary>
    Public Class DateUtil

        ''' <summary>
        ''' 年月日→年、期を取得する
        ''' </summary>
        ''' <param name="targetDate">取得対象の年月日(Date)</param>
        ''' <param name="year">年度年</param>
        ''' <param name="period">期</param>
        Public Shared Sub DateToNendoAndPeriod(ByVal targetDate As Date, ByRef year As Integer, ByRef period As Integer)
            If targetDate.Month = 1 Then
                year = targetDate.Year - 1
                period = If(targetDate.Month >= 2 AndAlso targetDate.Month <= 7, 1, 2)
            End If
        End Sub

        Public Shared Function DateStringToTryDate(ByVal strDate As String) As Date?
            If StringUtil.IsNullOrWhiteSpace(strDate) Then
                Return Nothing
            End If

            Dim tryDate As Date
            If Not Date.TryParse(strDate, tryDate) Then
                Return Nothing
            End If

            Return tryDate
        End Function






    End Class
End Namespace
