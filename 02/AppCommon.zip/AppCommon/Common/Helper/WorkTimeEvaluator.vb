﻿Public Class WorkTimeEvaluator

    ''' <summary>
    ''' 時間パラメタ用クラス
    ''' </summary>
    Public Class PunchingTimeData
        ' ジョブカン打刻：出勤時刻、退勤時刻
        Public Property JobStart As String = ""
        Public Property JobEnd As String = ""
        Public Property PunchCount As Integer = 0

        ' 業務届：開始時間、終了時間)
        Public Property ReqStart As String = ""
        Public Property ReqEnd As String = ""

        ' 出講：開始時間、終了時間　※計画＋代講実績
        Public Property ActStart As String = ""
        Public Property ActEnd As String = ""

        ' みなし：開始時間、終了時間、勤務時間)
        Public Property WorkStart As String = ""
        Public Property WorkEnd As String = ""
        Public Property WorkTime As String = ""
        Public Property Info As String = ""

        Public Property Trans_Expenses As New List(Of KeyValuePair(Of String, String))

        Public Property Duplicates As Integer = 0

    End Class

    ''' <summary>
    ''' みなし時間情報取得
    ''' </summary>
    ''' <param name="times"></param>
    Public Shared Sub DeemedTimeInfo(ByRef times As PunchingTimeData)
        Try
            ' みなし出勤時刻算出（出勤打刻、出講開始、業務開始から算出）
            Dim deemedStart = WorkTimeEvaluator.GetDeemedWorkStartTime(times.JobStart, times.ActStart, times.ReqStart, 20)
            ' みなし退勤時刻算出（出勤打刻、出講開始、業務開始から算出）
            Dim deemedEnd = WorkTimeEvaluator.GetDeemedWorkEndTime(times.JobEnd, times.ActEnd, times.ReqEnd, 20)

            ' みなし出勤時刻
            times.WorkStart = TimeUtil.TimeFormat(deemedStart)
            ' みなし退勤時刻
            times.WorkEnd = TimeUtil.TimeFormat(deemedEnd)
            ' みなし勤務時間
            times.WorkTime = WorkTimeEvaluator.GetDeemedDuration(deemedStart, deemedEnd).ToString()
            ' 打刻状態内容
            times.Info = WorkTimeEvaluator.GetWorkTimeStatus(times, 20)
        Catch ex As Exception
            Debug.WriteLine("")
        End Try
    End Sub

    ''' <summary>
    ''' みなし開始時刻取得
    ''' </summary>
    ''' <param name="jobStartStr">出勤時刻</param>
    ''' <param name="actStartStr">授業開始時刻</param>
    ''' <param name="reqStartStr">業務開始時刻</param>
    ''' <param name="deemedMinutes">みなし時間</param>
    ''' <returns></returns>
    Public Shared Function GetDeemedWorkStartTime(ByVal jobStartStr As String, ByVal actStartStr As String, ByVal reqStartStr As String, ByVal deemedMinutes As Integer) As DateTime?
        Dim jobStart, actStart, reqStart As DateTime
        Dim hasJob = DateTime.TryParse(jobStartStr, jobStart)
        Dim hasAct = DateTime.TryParse(actStartStr, actStart)
        Dim hasReq = DateTime.TryParse(reqStartStr, reqStart)

        ' 出勤時間なし
        If Not hasJob Then
            Return Nothing
        End If

        ' 授業開始なし 且つ 業務開始なし
        If Not hasAct AndAlso Not hasReq Then
            Return Nothing
        End If

        ' 出勤 + みなし時間
        Dim deemedStart As DateTime
        If hasAct Then
            deemedStart = actStart.AddMinutes(deemedMinutes * (-1))
        End If

        ' 授業のみ 
        If hasAct AndAlso Not hasReq Then
            ' 出勤時刻 <= 授業開始 + みなし時間 Or 出勤時刻 >= 授業開始 
            If jobStart < deemedStart OrElse jobStart >= actStart Then
                ' 出勤時刻
                Return jobStartStr
            Else
                ' 授業開始+みなし時間
                Return deemedStart.ToString("HH:mm")
            End If
        End If

        ' 業務届のみ 
        If Not hasAct AndAlso hasReq Then
            Return jobStartStr
        End If

        ' 業務開始 < 授業開始
        If reqStart < actStart Then
            Return jobStartStr
        End If

        ' 出勤時刻 < 授業開始+みなし時間 Or 出勤時刻 >= 授業開始 
        If jobStart < deemedStart OrElse jobStart >= actStart Then
            ' 出勤時刻
            Return jobStartStr
        Else
            ' 授業開始+みなし時間
            Return deemedStart.ToString("HH:mm")
        End If

    End Function

    ''' <summary>
    ''' みなし退勤時刻取得
    ''' </summary>
    ''' <param name="jobEndStr">退勤時刻</param>
    ''' <param name="actEndStr">授業終了時刻</param>
    ''' <param name="ReqEndStr">業務終了時刻</param>
    ''' <param name="deemedMinutes">みなし時間</param>
    ''' <returns></returns>
    Public Shared Function GetDeemedWorkEndTime(ByVal jobEndStr As String, ByVal actEndStr As String, ByVal ReqEndStr As String, ByVal deemedMinutes As Integer) As DateTime?
        Dim jobEnd, actEnd, reqEnd As DateTime
        Dim hasJob = DateTime.TryParse(jobEndStr, jobEnd)
        Dim hasAct = DateTime.TryParse(actEndStr, actEnd)
        Dim hasReq = DateTime.TryParse(ReqEndStr, reqEnd)

        ' 退勤時間なし
        If Not hasJob Then
            Return Nothing
        End If

        ' 授業終了なし 且つ 業務終了なし
        If Not hasAct AndAlso Not hasReq Then
            Return Nothing
        End If

        ' 退勤 + みなし時間
        Dim deemedEnd As DateTime
        If hasAct Then
            deemedEnd = actEnd.AddMinutes(deemedMinutes)
        End If

        ' 授業のみ 
        If hasAct AndAlso Not hasReq Then
            ' 退勤時刻 <= 授業終了 + みなし時間 Or 退勤時刻 >= 授業終了 
            If jobEnd > deemedEnd OrElse jobEnd >= actEnd Then
                ' 退勤時刻
                Return jobEndStr
            Else
                ' 授業終了 + みなし時間
                Return deemedEnd.ToString("HH:mm")
            End If
        End If

        ' 業務届のみ 
        If Not hasAct AndAlso hasReq Then
            Return jobEndStr
        End If

        ' 授業終了 <= 業務終了
        If actEnd <= reqEnd Then
            Return jobEndStr
        End If

        ' 退勤時刻 > 授業終了+みなし時間 Or 退勤時刻 >= 授業終了 
        If jobEnd > deemedEnd OrElse jobEnd >= actEnd Then
            ' 退勤時刻
            Return jobEndStr
        Else
            ' 授業終了+みなし時間
            Return deemedEnd.ToString("HH:mm")
        End If
    End Function

    ''' <summary>
    ''' みなし時間取得
    ''' </summary>
    ''' <param name="deemedStart"></param>
    ''' <param name="deemedEnd"></param>
    ''' <returns></returns>
    Public Shared Function GetDeemedDuration(ByVal deemedStart As Date?, ByVal deemedEnd As Date?) As Decimal?
        If deemedStart.HasValue AndAlso deemedEnd.HasValue AndAlso deemedEnd > deemedStart Then
            Dim deemedHour As Decimal = (deemedEnd.Value - deemedStart.Value).Hours
            Dim deemedTime As Decimal = (deemedEnd.Value - deemedStart.Value).Minutes
            'Return deemedHour + Math.Round(Decimal.Parse(deemedTime) / 60, 2, MidpointRounding.AwayFromZero)
            Return deemedHour * 60 + deemedTime
        Else
            Return Nothing
        End If
    End Function

    ''' <summary>
    ''' 差分時間取得
    ''' </summary>
    ''' <param name="time1"></param>
    ''' <param name="time2"></param>
    ''' <returns></returns>
    Private Shared Function DifferentialTime(ByVal time1 As DateTime, ByVal time2 As DateTime) As Decimal
        If time1 > time2 Then
            Return (time1 - time2).Hours * 60 + (time1 - time2).Minutes
        Else
            Return (time2 - time1).Hours * 60 + (time2 - time1).Minutes
        End If
    End Function

    ''' <summary>
    ''' 勤怠ステータス取得
    ''' </summary>
    ''' <param name="times"></param>
    ''' <param name="deemedMinutes"></param>
    ''' <returns></returns>
    Public Shared Function GetWorkTimeStatus(ByVal times As PunchingTimeData, ByVal deemedMinutes As Integer) As String
        Dim jobStart, actStart, reqStart, jobEnd, actEnd, reqEnd As DateTime
        Dim punchCount As Integer = times.PunchCount
        Dim hasJobStart = DateTime.TryParse(times.JobStart, jobStart)
        Dim hasActStart = DateTime.TryParse(times.ActStart, actStart)
        Dim hasReqStart = DateTime.TryParse(times.ReqStart, reqStart)
        Dim hasJobEnd = DateTime.TryParse(times.JobEnd, jobEnd)
        Dim hasActEnd = DateTime.TryParse(times.ActEnd, actEnd)
        Dim hasReqEnd = DateTime.TryParse(times.ReqEnd, reqEnd)
        Dim lateNight = jobEnd.Date.AddHours(22)

        ' 授業と業務なし
        If Not hasActStart AndAlso Not hasReqStart Then
            If hasJobStart Or hasJobEnd Then
                Return "出講・業務届なし"
            End If
            Return ""
        End If

        ' 出退勤打刻なし
        If (Not hasJobStart AndAlso Not hasJobEnd) OrElse punchCount = 0 Then
            Return "打刻なし(出勤・退勤)"
        End If

        ' 出勤打刻なし
        If Not hasJobStart Then
            Return "打刻なし(出勤)"
        End If

        ' 退勤打刻なし
        If Not hasJobEnd Then
            Return "打刻なし(退勤)"
        End If

        ' 打刻回数3回以上
        If punchCount >= 3 Then
            Return "打刻回数3回以上"
        End If

        ' 深夜勤務
        If jobEnd.ToShortTimeString() > lateNight.ToShortTimeString() Then
            Return String.Format("深夜勤務発生({0}分)", (jobEnd - lateNight).TotalMinutes())
        End If

        ' 交通費未登録あり
        For Each kv In times.Trans_Expenses
            If Not String.IsNullOrEmpty(kv.Key) AndAlso String.IsNullOrEmpty(kv.Value) Then
                Return String.Format("交通費未登録区間あり({0})", kv.Key)
            End If
        Next

        ' 期間重複有無
        If times.Duplicates > 0 Then
            Return "時間重複(授業時間・業務届)"
        End If


        ' 授業開始あり 且つ 業務開始あり
        Dim startTime As DateTime
        If hasActStart AndAlso hasReqStart Then
            If actStart < reqStart Then
                startTime = actStart.AddMinutes(deemedMinutes * (-1))
                If jobStart < startTime Then
                    Return "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"
                ElseIf jobStart > actStart Then
                    Return "出講遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"
                End If
            ElseIf actStart > reqStart Then
                startTime = reqStart.AddMinutes(deemedMinutes * (-1))
                If jobStart < startTime Then
                    Return "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"
                ElseIf jobStart > reqStart Then
                    Return "業務届遅刻(" & DifferentialTime(jobStart, reqStart).ToString() & "分)"
                End If
            Else
                Return ""
            End If
            Return Nothing
        End If

        ' 授業のみ 
        If hasActStart AndAlso Not hasReqStart Then
            startTime = actStart.AddMinutes(deemedMinutes * (-1))
            If jobStart < startTime Then
                Return "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"
            ElseIf jobStart > actStart Then
                Return "出講遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"
            End If
        End If

        ' 業務届のみ 
        If Not hasActStart AndAlso hasReqStart Then
            startTime = reqStart.AddMinutes(deemedMinutes * (-1))
            If jobStart < startTime Then
                Return "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"
            ElseIf jobStart > actStart Then
                Return "業務届遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"
            End If
        End If


        ' 授業終了あり 且つ 業務終了あり
        Dim endTime As DateTime
        If hasActEnd AndAlso hasReqEnd Then
            If actEnd > reqEnd Then
                endTime = actEnd.AddMinutes(deemedMinutes)
                If jobEnd > endTime Then
                    Return "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"
                ElseIf jobEnd < actEnd Then
                    Return "出講早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"
                End If
            ElseIf actEnd < reqEnd Then
                endTime = reqEnd.AddMinutes(deemedMinutes)
                If jobEnd > endTime Then
                    Return "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"
                ElseIf jobEnd < reqEnd Then
                    Return "業務届早退(" & DifferentialTime(jobEnd, reqEnd).ToString() & "分)"
                End If
            Else
                Return ""
            End If
            Return Nothing
        End If

        ' 授業のみ 
        If hasActEnd AndAlso Not hasReqEnd Then
            endTime = actEnd.AddMinutes(deemedMinutes)
            If jobEnd > endTime Then
                Return "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"
            ElseIf jobEnd < actEnd Then
                Return "出講早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"
            End If
        End If

        ' 業務届のみ 
        If Not hasActEnd AndAlso hasReqEnd Then
            endTime = reqEnd.AddMinutes(deemedMinutes)
            If jobEnd > endTime Then
                Return "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"
            ElseIf jobEnd < actEnd Then
                Return "業務届早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"
            End If
        End If

        Return ""
    End Function



    ''' <summary>
    ''' 勤怠ステータス取得
    ''' </summary>
    ''' <param name="times"></param>
    ''' <param name="deemedMinutes"></param>
    ''' <returns></returns>
    Public Shared Function GetWorkTimeAllStatus(ByVal times As PunchingTimeData, ByVal deemedMinutes As Integer) As List(Of KeyValuePair(Of String, String))
        Dim errorsInfo As New List(Of KeyValuePair(Of String, String))

        Dim jobStart, actStart, reqStart, jobEnd, actEnd, reqEnd As DateTime
        Dim punchCount As Integer = times.PunchCount
        Dim hasJobStart = DateTime.TryParse(times.JobStart, jobStart)
        Dim hasActStart = DateTime.TryParse(times.ActStart, actStart)
        Dim hasReqStart = DateTime.TryParse(times.ReqStart, reqStart)
        Dim hasJobEnd = DateTime.TryParse(times.JobEnd, jobEnd)
        Dim hasActEnd = DateTime.TryParse(times.ActEnd, actEnd)
        Dim hasReqEnd = DateTime.TryParse(times.ReqEnd, reqEnd)
        Dim lateNight = jobEnd.Date.AddHours(22)


        ' 授業と業務なし
        If Not hasActStart AndAlso Not hasReqStart Then
            If hasJobStart Or hasJobEnd Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講・業務届なし"))
            End If
        End If

        ' 打刻なし
        If (Not hasJobStart AndAlso Not hasJobEnd) OrElse punchCount = 0 Then
            ' 出退勤打刻なし
            errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "打刻なし(出勤・退勤)"))
            Return errorsInfo

        ElseIf Not hasJobStart Then
            ' 出勤打刻なし
            errorsInfo.Add(New KeyValuePair(Of String, String)("エラー", "打刻なし(出勤)"))
        ElseIf Not hasJobEnd Then
            ' 退勤打刻なし
            errorsInfo.Add(New KeyValuePair(Of String, String)("エラー", "打刻なし(退勤)"))
        End If

        ' 打刻回数3回以上
        If punchCount >= 3 Then
            errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "打刻回数3回以上"))
        End If

        ' 深夜勤務
        If jobEnd.ToShortTimeString() > lateNight.ToShortTimeString() Then
            errorsInfo.Add(New KeyValuePair(Of String, String)("情報", String.Format("深夜勤務発生({0}分)", (jobEnd - lateNight).TotalMinutes())))
        End If

        ' 交通費未登録あり
        For Each kv In times.Trans_Expenses
            If Not String.IsNullOrEmpty(kv.Key) AndAlso String.IsNullOrEmpty(kv.Value) Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("情報", String.Format("交通費未登録区間あり({0})", kv.Key)))
            End If
        Next

        ' 期間重複有無
        If times.Duplicates > 0 Then
            errorsInfo.Add(New KeyValuePair(Of String, String)("エラー", "時間重複(授業時間・業務届)"))
        End If

        ' 授業開始あり 且つ 業務開始あり
        Dim startTime As DateTime
        If hasActStart AndAlso hasReqStart Then
            If actStart < reqStart Then
                startTime = actStart.AddMinutes(deemedMinutes * (-1))
                If jobStart < startTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("エラー", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
                ElseIf jobStart > actStart Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"))
                End If
            ElseIf actStart > reqStart Then
                startTime = reqStart.AddMinutes(deemedMinutes * (-1))
                If jobStart < startTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
                ElseIf jobStart > reqStart Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届遅刻(" & DifferentialTime(jobStart, reqStart).ToString() & "分)"))
                End If
            Else
            End If
            'Return Nothing
        End If

        ' 授業のみ 
        If hasActStart AndAlso Not hasReqStart Then
            startTime = actStart.AddMinutes(deemedMinutes * (-1))
            If jobStart < startTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
            ElseIf jobStart > actStart Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"))
            End If
        End If

        ' 業務届のみ 
        If Not hasActStart AndAlso hasReqStart Then
            startTime = reqStart.AddMinutes(deemedMinutes * (-1))
            If jobStart < startTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出勤早(" & DifferentialTime(startTime, jobStart).ToString() & "分)"))
            ElseIf jobStart > actStart Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届遅刻(" & DifferentialTime(jobStart, actStart).ToString() & "分)"))
            End If
        End If


        ' 授業終了あり 且つ 業務終了あり
        Dim endTime As DateTime
        If hasActEnd AndAlso hasReqEnd Then
            If actEnd > reqEnd Then
                endTime = actEnd.AddMinutes(deemedMinutes)
                If jobEnd > endTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
                ElseIf jobEnd < actEnd Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"))
                End If
            ElseIf actEnd < reqEnd Then
                endTime = reqEnd.AddMinutes(deemedMinutes)
                If jobEnd > endTime Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
                ElseIf jobEnd < reqEnd Then
                    errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届早退(" & DifferentialTime(jobEnd, reqEnd).ToString() & "分)"))
                End If
            Else
            End If
            'Return Nothing
        End If

        ' 授業のみ 
        If hasActEnd AndAlso Not hasReqEnd Then
            endTime = actEnd.AddMinutes(deemedMinutes)
            If jobEnd > endTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
            ElseIf jobEnd < actEnd Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "出講早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"))
            End If
        End If

        ' 業務届のみ 
        If Not hasActEnd AndAlso hasReqEnd Then
            endTime = reqEnd.AddMinutes(deemedMinutes)
            If jobEnd > endTime Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "退勤遅(" & DifferentialTime(endTime, jobEnd).ToString() & "分)"))
            ElseIf jobEnd < actEnd Then
                errorsInfo.Add(New KeyValuePair(Of String, String)("警告", "業務届早退(" & DifferentialTime(jobEnd, actEnd).ToString() & "分)"))
            End If
        End If

        Return errorsInfo
    End Function

End Class
