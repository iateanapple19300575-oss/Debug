﻿Imports System.Windows.Forms
Imports LecturePay.Common.Infrastructure

''' <summary>
''' 全フォーム共通の UI 更新処理を提供するヘルパークラス。
''' グローバル状態の変更に応じて、コントロール名の UI を自動的に更新する。
''' </summary>
Public NotInheritable Class StateUpdateHelper

  ''' <summary>
  ''' 指定された状態キーと値に基づいて、対象フォーム内の対応するUIコントロールを更新する。
  ''' </summary>
  ''' <param name="target">UI を更新する対象フォーム。</param>
  ''' <param name="key">変更された状態キー。</param>
  ''' <param name="value">キーに対応する新しい値。</param>
  Public Shared Sub UpdateState(target As Form, key As String, value As Object)
    Dim pnl As Panel = target.Controls.OfType(Of Panel)().FirstOrDefault(Function(p) p.Name = "HeaderTitlePanel")
    If pnl Is Nothing Then
      Return
    End If

    Select Case key
      Case GlobalState.GS_APP_NAME
        Dim lbl = pnl.Controls.Find("lblAppliName", True).FirstOrDefault()
        If lbl IsNot Nothing Then
          lbl.Text = AppCommon.ApplicationName()
        End If
      Case GlobalState.GS_YEAR_MONTH
        Dim lbl = pnl.Controls.Find("lblYearMonth", True).FirstOrDefault()
        If lbl IsNot Nothing Then
          lbl.Text = AppCommon.GetTargetYearMonth()
        End If
      Case GlobalState.GS_LOCK_STATE
        Dim lbl = pnl.Controls.Find("lblLockState", True).FirstOrDefault()
        If lbl IsNot Nothing Then
          lbl.Text = AppCommon.GetLockStatus()
        End If
      Case GlobalState.GS_USER_NAME
        Dim lbl = pnl.Controls.Find("lblUserName", True).FirstOrDefault()
        If lbl IsNot Nothing Then
          lbl.Text = AppCommon.GetUser()
        End If
    End Select
  End Sub
End Class