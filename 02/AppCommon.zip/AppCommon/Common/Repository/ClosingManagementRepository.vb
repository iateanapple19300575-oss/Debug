﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto

Public Class ClosingManagementRepository
    Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' SELECT(標準)
    ''' </summary>
    Public Function GetAll() As DataTable
        Dim queryString As String = GetAllSql()
        Return ExecuteDataTable(queryString.ToString(), Nothing)
    End Function

    ''' <summary>
    ''' SELECT(標準)
    ''' </summary>
    Public Function GetAllDtoList() As List(Of ClosingManagementDto)
        Dim queryString As String = GetAllSql()
        Return ExcuteQuery(Of ClosingManagementDto)(queryString.ToString(), Nothing)
    End Function

    Private Function GetAllSql() As String
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Year_Month").Append(" ")
        sqlString.Append("  , Temp_Close_User").Append(" ")
        sqlString.Append("  , Temp_Close_Datetime ").Append(" ")
        sqlString.Append("  , Final_Close_User").Append(" ")
        sqlString.Append("  , Final_Close_Datetime ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  C_Closing_Management").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1 ").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year_Month ASC").Append(" ")
        sqlString.Append(";")
        Return sqlString.ToString()
    End Function

    ''' <summary>
    ''' 指定年月度締め情報取得
    ''' </summary>
    ''' <param name="dto"></param>
    ''' <returns></returns>
    Public Function GetByYearMonth(ByVal dto As ClosingManagementDto) As ClosingManagementDto

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Year_Month").Append(" ")
        sqlString.Append("  , Temp_Close_User").Append(" ")
        sqlString.Append("  , Temp_Close_Datetime ").Append(" ")
        sqlString.Append("  , Final_Close_User").Append(" ")
        sqlString.Append("  , Final_Close_Datetime ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  C_Closing_Management").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1 ").Append(" ")
        sqlString.Append("  AND Year_Month = @Year_Month").Append(" ")
        sqlString.Append(";")

        Return ExcuteQuerySingle(Of ClosingManagementDto)(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@Year_Month", .Value = dto.YearMonth}
        )
    End Function

    ''' <summary>
    ''' 仮締め処理
    ''' </summary>
    ''' <param name="dto"></param>
    ''' <returns></returns>
    Public Function TemporaryTightening(ByVal dto As ClosingManagementDto) As Integer

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Append("MERGE ").Append(" ")
        sqlString.Append("INTO C_Closing_Management AS Target ").Append(" ")
        sqlString.Append("  USING ( ").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      @Year_Month As Year_Month").Append(" ")
        sqlString.Append("      , @Temp_Close_User As Temp_Close_User").Append(" ")
        sqlString.Append("      , @Temp_Close_Datetime As Temp_Close_Datetime").Append(" ")
        'sqlString.Append("      , @Final_Close_User As Final_Close_User").Append(" ")
        'sqlString.Append("      , @Final_Close_Datetime As Final_Close_Datetime").Append(" ")
        sqlString.Append("  ) AS Source ").Append(" ")
        sqlString.Append("    ON Target.Year_Month = Source.Year_Month").Append(" ")
        sqlString.Append("    WHEN MATCHED THEN UPDATE ").Append(" ")
        sqlString.Append("SET").Append(" ")
        sqlString.Append("  Target.Temp_Close_User = Source.Temp_Close_User").Append(" ")
        sqlString.Append("  , Target.Temp_Close_Datetime = Source.Temp_Close_Datetime").Append(" ")
        sqlString.Append("  WHEN NOT MATCHED THEN ").Append(" ")
        sqlString.Append("INSERT ( ").Append(" ")
        sqlString.Append("  Year_Month").Append(" ")
        sqlString.Append("  , Temp_Close_User").Append(" ")
        sqlString.Append("  , Temp_Close_Datetime").Append(" ")
        sqlString.Append("  , Final_Close_User").Append(" ")
        sqlString.Append("  , Final_Close_Datetime").Append(" ")
        sqlString.Append(") ").Append(" ")
        sqlString.Append("VALUES ( ").Append(" ")
        sqlString.Append("  Source.Year_Month").Append(" ")
        sqlString.Append("  , Source.Temp_Close_User").Append(" ")
        sqlString.Append("  , Source.Temp_Close_Datetime").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append(");").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@Year_Month", .Value = dto.YearMonth},
            New SqlParameter() With {.ParameterName = "@Temp_Close_User", .Value = dto.TempCloseUser},
            New SqlParameter() With {.ParameterName = "@Temp_Close_Datetime", .Value = dto.TempCloseDatetime}
        )
    End Function

    ''' <summary>
    ''' 本締め処理
    ''' </summary>
    ''' <param name="dto"></param>
    ''' <returns></returns>
    Public Function FinalTightening(ByVal dto As ClosingManagementDto) As Integer

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Append("UPDATE").Append(" ")
        sqlString.Append("  C_Closing_Management").Append(" ")
        sqlString.Append("SET ").Append(" ")
        sqlString.Append("  Final_Close_User = @Final_Close_User").Append(" ")
        sqlString.Append("  , Final_Close_Datetime = @Final_Close_Datetime").Append(" ")
        sqlString.Append("WHERE ").Append(" ")
        sqlString.Append("  Year_Month = @Year_Month").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@Year_Month", .Value = dto.YearMonth},
            New SqlParameter() With {.ParameterName = "@Final_Close_User", .Value = dto.FinalCloseUser},
            New SqlParameter() With {.ParameterName = "@Final_Close_Datetime", .Value = dto.FinalCloseDatetime}
        )
    End Function

    ''' <summary>
    ''' 仮締め解除処理
    ''' </summary>
    ''' <param name="dto"></param>
    ''' <returns></returns>
    Public Function ReleaseTemporaryTightening(ByVal dto As ClosingManagementDto) As Integer

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Append("UPDATE").Append(" ")
        sqlString.Append("  C_Closing_Management").Append(" ")
        sqlString.Append("SET ").Append(" ")
        sqlString.Append("  Temp_Close_User = NULL").Append(" ")
        sqlString.Append("  , Temp_Close_Datetime = NULL").Append(" ")
        sqlString.Append("WHERE ").Append(" ")
        sqlString.Append("  Year_Month = @Year_Month").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@Year_Month", .Value = dto.YearMonth}
        )
    End Function

End Class
