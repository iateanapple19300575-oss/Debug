﻿Imports System.Data.SqlClient

#If 0 Then

Public Class MNSPM10Tran
    Inherits TransactionBase

    Private _corporate As String = "1"

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' SELECT(標準)
    ''' </summary>
    Public Function SqlSelectKeyValuePair() As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  Corporate_KND").Append(" ")
        SqlQuery.Append("  , Division_KND").Append(" ")
        SqlQuery.Append("  , Division_Name ").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  [LECTPAY].[dbo].[MNSPM10] ").Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")
        SqlQuery.Append("  AND Corporate_KND = @Corporate_KND").Append(" ")
        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  Corporate_KND ASC").Append(" ")
        SqlQuery.Append("  , Division_KND ASC").Append(" ")
        SqlQuery.Append(";")

        Return ExecuteDataTable(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@Corporate_KND", .Value = _corporate}
        )
    End Function

End Class

#End If
