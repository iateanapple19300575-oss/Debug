﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities

#If 0 Then

Public Class MNSPM11Tran
    Inherits TransactionBase

    Private _corporate As String = "1"

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' SELECT(部門＋教室)
    ''' </summary>
    ''' <param name="group"></param>
    ''' <returns></returns>
    Public Function FetchByGroup(ByVal group As String) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  M11.Site_Code").Append(" ")
        SqlQuery.Append("  , CONCAT(").Append(" ")
        SqlQuery.Append("      M11.Site_Code").Append(" ")
        SqlQuery.Append("      , '：'").Append(" ")
        SqlQuery.Append("      , REPLACE (NS.Site_Name, '　', '') COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("    ) As Site_Name").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  [LECTPAY].[dbo].[MNSPM10] M10").Append(" ")
        SqlQuery.Append("  LEFT JOIN [LECTPAY].[dbo].[MNSPM11] M11").Append(" ")
        SqlQuery.Append("    ON (").Append(" ")
        SqlQuery.Append("      M10.Corporate_KND = M11.Corporate_KND").Append(" ")
        SqlQuery.Append("      AND M10.Division_KND = M11.Division_KND").Append(" ")
        SqlQuery.Append("    )").Append(" ")

        SqlQuery.Append("  LEFT JOIN [LECTPAY].[dbo].[ntb_Site] NS").Append(" ")
        SqlQuery.Append("    ON (").Append(" ")
        SqlQuery.Append("      M11.Site_Code = NS.Site_Code COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("    )").Append(" ")

        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")

        If StringUtil.IsNotNullOrWhiteSpace(_corporate) Then
            SqlQuery.Append("  AND M10.Corporate_KND = @Corporate_KND").Append(" ")
            If StringUtil.IsNotNullOrWhiteSpace(group) Then
                SqlQuery.Append("  AND M10.Corporate_KND = @Corporate_KND").Append(" ")
                SqlQuery.Append("  AND M10.Division_KND = @Division_KND COLLATE Japanese_CS_AS_KS_WS").Append(" ")
            End If
        End If

        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  M10.Corporate_KND ASC").Append(" ")
        SqlQuery.Append("  , M10.Division_KND ASC").Append(" ")
        SqlQuery.Append("  , M11.Site_Code ASC").Append(" ")
        SqlQuery.Append(";").Append(" ")

        Return ExecuteDataTable(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@Corporate_KND", .Value = _corporate},
            New SqlParameter() With {.ParameterName = "@Division_KND", .Value = group}
          )
    End Function

    ''' <summary>
    ''' 教室に存在する学年を取得する。
    ''' </summary>
    ''' <param name="site"></param>
    ''' <returns></returns>
    Public Function GradeInSite(ByVal site As String) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  TC.Grade ").Append(" ")
        SqlQuery.Append("  , CONCAT(TC.Grade, '年') As Grade_Name").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  M_Timetable_Class TC ").Append(" ")
        SqlQuery.Append("  INNER JOIN ( ").Append(" ")
        SqlQuery.Append("    SELECT").Append(" ")
        SqlQuery.Append("      M11.Site_Code").Append(" ")
        SqlQuery.Append("      , M11.Site_Code As Site_Name ").Append(" ")
        SqlQuery.Append("    FROM").Append(" ")
        SqlQuery.Append("      [LECTPAY].[dbo].[MNSPM10] M10 ").Append(" ")
        SqlQuery.Append("      LEFT JOIN [LECTPAY].[dbo].[MNSPM11] M11 ").Append(" ")
        SqlQuery.Append("        ON ( ").Append(" ")
        SqlQuery.Append("          M10.Corporate_KND = M11.Corporate_KND ").Append(" ")
        SqlQuery.Append("          AND M10.Division_KND = M11.Division_KND").Append(" ")
        SqlQuery.Append("        ) ").Append(" ")
        SqlQuery.Append("    WHERE").Append(" ")
        SqlQuery.Append("      1 = 1 ").Append(" ")
        SqlQuery.Append("      AND M10.Corporate_KND = @Corporate_KND").Append(" ")

        If Not String.IsNullOrEmpty(site) Then
            SqlQuery.Append("      AND M11.Site_Code = @Site_Code").Append(" ")
        End If

        SqlQuery.Append("  ) M11 ").Append(" ")
        SqlQuery.Append("  ON (TC.Site_Code = M11.Site_Code  COLLATE Japanese_CS_AS_KS_WS)").Append(" ")
        SqlQuery.Append("GROUP BY").Append(" ")
        SqlQuery.Append("  TC.Grade ").Append(" ")
        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  TC.Grade").Append(" ")
        SqlQuery.Append(";").Append(" ")

        Return ExecuteDataTable(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@Corporate_KND", .Value = _corporate},
            New SqlParameter() With {.ParameterName = "@Site_Code", .SqlDbType = SqlDbType.Char, .Size = 1, .Value = site}
          )
    End Function

    ''' <summary>
    ''' 教室に存在するクラスを取得する。
    ''' </summary>
    ''' <param name="site"></param>
    ''' <returns></returns>
    Public Function ClassInSite(ByVal site As String) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  TC.Class_Code ").Append(" ")
        SqlQuery.Append("  , TC.Class_Code As Class_Name").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  M_Timetable_Class TC ").Append(" ")
        SqlQuery.Append("  INNER JOIN ( ").Append(" ")
        SqlQuery.Append("    SELECT").Append(" ")
        SqlQuery.Append("      M11.Site_Code").Append(" ")
        SqlQuery.Append("      , M11.Site_Code As Site_Name ").Append(" ")
        SqlQuery.Append("    FROM").Append(" ")
        SqlQuery.Append("      [LECTPAY].[dbo].[MNSPM10] M10 ").Append(" ")
        SqlQuery.Append("      LEFT JOIN [LECTPAY].[dbo].[MNSPM11] M11 ").Append(" ")
        SqlQuery.Append("        ON ( ").Append(" ")
        SqlQuery.Append("          M10.Corporate_KND = M11.Corporate_KND ").Append(" ")
        SqlQuery.Append("          AND M10.Division_KND = M11.Division_KND").Append(" ")
        SqlQuery.Append("        ) ").Append(" ")
        SqlQuery.Append("    WHERE").Append(" ")
        SqlQuery.Append("      1 = 1 ").Append(" ")
        SqlQuery.Append("      AND M10.Corporate_KND = @Corporate_KND").Append(" ")

        If Not String.IsNullOrEmpty(site) Then
            SqlQuery.Append("      AND M11.Site_Code = @Site_Code").Append(" ")
        End If

        SqlQuery.Append("  ) M11 ").Append(" ")
        SqlQuery.Append("  ON (TC.Site_Code = M11.Site_Code  COLLATE Japanese_CS_AS_KS_WS)").Append(" ")
        SqlQuery.Append("GROUP BY").Append(" ")
        SqlQuery.Append("  TC.Class_Code ").Append(" ")
        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  TC.Class_Code").Append(" ")
        SqlQuery.Append(";").Append(" ")

        Return ExecuteDataTable(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@Corporate_KND", .Value = _corporate},
            New SqlParameter() With {.ParameterName = "@Site_Code", .Value = site}
          )
    End Function


End Class

#End If
