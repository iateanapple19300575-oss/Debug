﻿''' <summary>
''' インポート用(拡張)ユーザコントロール
''' </summary>
Public Class ImportRowControlEx

	Public Event FileSelected(ByVal sender As Object, ByVal filePath As String)
	Public Event ImportRequested(ByVal sender As Object, ByVal filePath As String)
	Public Event DisplayRequested(ByVal sender As Object)

	Public Sub New()
		InitializeComponent()
		txtFilePath.ReadOnly = True
	End Sub

	''' <summary>
	''' コンストラクタ
	''' </summary>
	Public Sub New(ByVal visible As Boolean)
		InitializeComponent()
		txtFilePath.ReadOnly = True
    cmbCategory.Visible = visible
    lblCategoryTitle.Visible = visible
  End Sub

	''' <summary>
	''' データ種別
	''' </summary>
	''' <returns></returns>
	Public Property DataTypeLabel As String
		Get
			Return lblDataType.Text
		End Get
		Set(ByVal value As String)
			lblDataType.Text = value
		End Set
	End Property

	''' <summary>
	''' ファイルパス
	''' </summary>
	''' <returns></returns>
	Public ReadOnly Property FilePath As String
		Get
			Return txtFilePath.Text
		End Get
	End Property

	''' <summary>
	''' 前回日時
	''' </summary>
	''' <returns></returns>
	Public Property LastImportTime As String
		Get
			Return lblLastTime.Text
		End Get
		Set(ByVal value As String)
			lblLastTime.Text = value
		End Set
	End Property

  ''' <summary>
  ''' 前回取込件数
  ''' </summary>
  ''' <returns></returns>
  Public Property LastImportCount As String
    Get
      Return lblLastCount.Text
    End Get
    Set(ByVal value As String)
      lblLastCount.Text = value
    End Set
  End Property

  ''' <summary>
  ''' 前回処理結果
  ''' </summary>
  ''' <returns></returns>
  Public Property LastResult As String
    Get
      Return lblLastResult.Text
    End Get
    Set(ByVal value As String)
      lblLastResult.Text = value
    End Set
  End Property

  ''' <summary>
  ''' カテゴリコンボ表示/非表示設定
  ''' </summary>
  ''' <returns></returns>
  <System.ComponentModel.Browsable(True)>
	<System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Visible)>
	Public Property CategoryVisible As Boolean
		Get
			Return cmbCategory.Visible
		End Get
		Set(ByVal value As Boolean)
			cmbCategory.Visible = value
			lblCategoryTitle.Visible = value
		End Set
	End Property

  Public Property Category As Integer
    Get
      Return cmbCategory.SelectedValue
    End Get
    Set(ByVal value As Integer)
      cmbCategory.SelectedIndex = value
    End Set
  End Property

  Public Property AppCommon As Object

	''' <summary>
	''' [参照]ボタン押下イベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub BtnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
		Dim dlg As New OpenFileDialog()
		dlg.Filter = "CSV(カンマ区切り)(*.csv)|*.csv"
		If dlg.ShowDialog() = DialogResult.OK Then
			txtFilePath.Text = dlg.FileName
			RaiseEvent FileSelected(Me, dlg.FileName)
		End If
	End Sub

	''' <summary>
	''' [取込]ボタン押下イベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub BtnImport_Click(sender As Object, e As EventArgs) Handles btnImport.Click
		If txtFilePath.Text <> "" Then
			RaiseEvent ImportRequested(Me, txtFilePath.Text)
		End If
	End Sub

  ''' <summary>
  ''' 前回処理結果表示
  ''' </summary>
  ''' <param name="time"></param>
  ''' <param name="count"></param>
  ''' <param name="result"></param>
  Public Sub SetLastImportResult(ByVal time As String, ByVal count As String, ByVal result As String)
    lblCurrentTime.Text = time
    lblCurrentCount.Text = count
    lblCurrentResult.Text = result
  End Sub

  ''' <summary>
  ''' 今回処理結果表示
  ''' </summary>
  ''' <param name="time"></param>
  ''' <param name="count"></param>
  ''' <param name="result"></param>
  Public Sub SetCurrentImportResult(ByVal time As String, ByVal count As String, ByVal result As String)
		lblCurrentTime.Text = time
		lblCurrentCount.Text = count
		lblCurrentResult.Text = result
	End Sub

  ''' <summary>
  ''' 今回処理結果表示
  ''' </summary>
  ''' <param name="result"></param>
  Public Sub SetCurrentImportResult(ByVal result As String)
		lblCurrentResult.Text = result
	End Sub

	''' <summary>
	''' 講習区分データロード
	''' </summary>
	''' <param name="dt"></param>
	Public Sub SetLectureCategory(ByVal dt As DataTable)
		cmbCategory.DataSource = dt
		cmbCategory.DisplayMember = "Name"
		cmbCategory.ValueMember = "ID"
	End Sub

  ''' <summary>
  ''' 今回処理結果ラベル
  ''' </summary>
  ''' <returns></returns>
  Public Property Result As Label
		Get
			Return lblCurrentResult
		End Get
		Set(ByVal value As Label)
			lblCurrentResult = value
		End Set
	End Property

End Class
