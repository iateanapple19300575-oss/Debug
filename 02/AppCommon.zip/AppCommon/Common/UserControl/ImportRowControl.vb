﻿''' <summary>
''' インポート用ユーザコントロール
''' </summary>
Public Class ImportRowControl

	Public Event FileSelected(ByVal sender As Object, ByVal filePath As String)
	Public Event ImportRequested(ByVal sender As Object, ByVal filePath As String)

	''' <summary>
	''' コンストラクタ
	''' </summary>
	Public Sub New()
		InitializeComponent()
		txtFilePath.ReadOnly = True
	End Sub

	''' <summary>
	''' データ種別
	''' </summary>
	''' <returns></returns>
	Public Property DataTypeLabel As String
		Get
			Return lblDataType.Text
		End Get
		Set(ByVal value As String)
			lblDataType.Text = value
		End Set
	End Property

	''' <summary>
	''' 前回日時
	''' </summary>
	''' <returns></returns>
	Public Property LastImportTime As String
		Get
			Return lblLastTime.Text
		End Get
		Set(ByVal value As String)
			lblLastTime.Text = value
		End Set
	End Property

	''' <summary>
	''' 前回取込件数
	''' </summary>
	''' <returns></returns>
	Public Property LastImportCount As String
		Get
			Return lblLastCount.Text
		End Get
		Set(ByVal value As String)
			lblLastCount.Text = value
		End Set
	End Property

	''' <summary>
	''' [参照]ボタン押下イベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub BtnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
		Dim dlg As New OpenFileDialog()
		dlg.Filter = "CSV(カンマ区切り)(*.csv)|*.csv"
		If dlg.ShowDialog() = DialogResult.OK Then
			txtFilePath.Text = dlg.FileName
			RaiseEvent FileSelected(Me, dlg.FileName)
		End If
	End Sub

	''' <summary>
	''' [取込]ボタン押下イベント
	''' </summary>
	''' <param name="sender"></param>
	''' <param name="e"></param>
	Private Sub BtnImport_Click(sender As Object, e As EventArgs) Handles btnImport.Click
		If txtFilePath.Text <> "" Then
			RaiseEvent ImportRequested(Me, txtFilePath.Text)
		End If
	End Sub

	''' <summary>
	''' 処理結果表示
	''' </summary>
	''' <param name="time"></param>
	''' <param name="count"></param>
	''' <param name="result"></param>
	Public Sub SetCurrentImportResult(ByVal time As String, ByVal count As String, ByVal result As String)
		lblCurrentTime.Text = time
		lblCurrentCount.Text = count
		lblCurrentResult.Text = result
	End Sub
End Class
