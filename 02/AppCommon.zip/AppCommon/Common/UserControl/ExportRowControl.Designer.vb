﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ExportRowControl
	Inherits System.Windows.Forms.UserControl

	'UserControl はコンポーネント一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.btnExport = New System.Windows.Forms.Button()
		Me.btnBrowse = New System.Windows.Forms.Button()
		Me.txtFilePath = New System.Windows.Forms.TextBox()
		Me.lblDataType = New System.Windows.Forms.Label()
		Me.btnDisplay = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnExport
		'
		Me.btnExport.Location = New System.Drawing.Point(535, 37)
		Me.btnExport.Margin = New System.Windows.Forms.Padding(4)
		Me.btnExport.Name = "btnExport"
		Me.btnExport.Size = New System.Drawing.Size(70, 28)
		Me.btnExport.TabIndex = 3
		Me.btnExport.Text = "出力"
		Me.btnExport.UseVisualStyleBackColor = True
		'
		'btnBrowse
		'
		Me.btnBrowse.Location = New System.Drawing.Point(465, 37)
		Me.btnBrowse.Margin = New System.Windows.Forms.Padding(4)
		Me.btnBrowse.Name = "btnBrowse"
		Me.btnBrowse.Size = New System.Drawing.Size(60, 28)
		Me.btnBrowse.TabIndex = 2
		Me.btnBrowse.Text = "参照..."
		Me.btnBrowse.UseVisualStyleBackColor = True
		'
		'txtFilePath
		'
		Me.txtFilePath.Location = New System.Drawing.Point(15, 36)
		Me.txtFilePath.Margin = New System.Windows.Forms.Padding(4)
		Me.txtFilePath.Name = "txtFilePath"
		Me.txtFilePath.ReadOnly = True
		Me.txtFilePath.Size = New System.Drawing.Size(440, 28)
		Me.txtFilePath.TabIndex = 1
		Me.txtFilePath.TabStop = False
		'
		'lblDataType
		'
		Me.lblDataType.AutoSize = True
		Me.lblDataType.Location = New System.Drawing.Point(10, 15)
		Me.lblDataType.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
		Me.lblDataType.Name = "lblDataType"
		Me.lblDataType.Size = New System.Drawing.Size(138, 17)
		Me.lblDataType.TabIndex = 0
		Me.lblDataType.Text = "出講料チェックリスト"
		'
		'btnDisplay
		'
		Me.btnDisplay.Location = New System.Drawing.Point(615, 37)
		Me.btnDisplay.Margin = New System.Windows.Forms.Padding(4)
		Me.btnDisplay.Name = "btnDisplay"
		Me.btnDisplay.Size = New System.Drawing.Size(70, 28)
		Me.btnDisplay.TabIndex = 4
		Me.btnDisplay.Text = "確認"
		Me.btnDisplay.UseVisualStyleBackColor = True
		'
		'ExportRowControl
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.Controls.Add(Me.btnDisplay)
		Me.Controls.Add(Me.btnExport)
		Me.Controls.Add(Me.btnBrowse)
		Me.Controls.Add(Me.txtFilePath)
		Me.Controls.Add(Me.lblDataType)
		Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "ExportRowControl"
		Me.Size = New System.Drawing.Size(696, 80)
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents btnExport As Button
	Friend WithEvents btnBrowse As Button
	Friend WithEvents txtFilePath As TextBox
	Friend WithEvents lblDataType As Label
	Friend WithEvents btnDisplay As Button
End Class
