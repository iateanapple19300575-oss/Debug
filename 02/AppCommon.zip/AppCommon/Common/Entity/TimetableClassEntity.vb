Namespace MainApp.Data.Entity

    ''' <summary>
    ''' Entity�B
    ''' </summary>
    Public Class TimetableClassEntity

        ''' <summary>
        ''' �N�x�J�n�N
        ''' </summary>
        Public Property FirstYear As String

        ''' <summary>
        ''' �N�x�I���N
        ''' </summary>
        Public Property LastYear As String

        ''' <summary>
        ''' ����
        ''' </summary>
        Public Property Division_KND As String

        ''' <summary>
        ''' �����R�[�h
        ''' </summary>
        Public Property Site_Code As String

        ''' <summary>
        ''' �w�N
        ''' </summary>
        Public Property Grade As Integer?

        ''' <summary>
        ''' �N���X�R�[�h
        ''' </summary>
        Public Property Class_Code As String

    End Class

End Namespace
