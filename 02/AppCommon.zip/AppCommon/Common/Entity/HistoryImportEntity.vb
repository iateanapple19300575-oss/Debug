Namespace MainApp.Data.Entity

    ''' <summary>
    ''' Entity�B
    ''' </summary>
    Public Class HistoryImportEntity

        ''' <summary>
        ''' �f�[�^�^�C�v
        ''' </summary>
        Public Property CsvType As Integer

        ''' <summary>
        ''' ����
        ''' </summary>
        Public Property Category As String

        ''' <summary>
        ''' �f�[�^��
        ''' </summary>
        Public Property DataName As String

        ''' <summary>
        ''' �捞�t�@�C����
        ''' </summary>
        Public Property FileName As String

        ''' <summary>
        ''' �����Ώ۔N���x
        ''' </summary>
        Public Property FiscalYearMonth As String

        ''' <summary>
        ''' ���s����
        ''' </summary>
        Public Property ExecutionDate As Date

        ''' <summary>
        ''' ���s��
        ''' </summary>
        Public Property ExecutionUser As String

        ''' <summary>
        ''' ���s�[��
        ''' </summary>
        Public Property ExecutionPc As String

        ''' <summary>
        ''' ��������
        ''' </summary>
        Public Property ExecutionStatus As Integer

        ''' <summary>
        ''' �����f�[�^����
        ''' </summary>
        Public Property ExecutionCount As Integer

        ''' <summary>
        ''' �쐬��
        ''' </summary>
        Public Property CreateUser As String

        ''' <summary>
        ''' �쐬��
        ''' </summary>
        Public Property CreateDate As Date

        ''' <summary>
        ''' �X�V��
        ''' </summary>
        Public Property UpdateUser As String

        ''' <summary>
        ''' �X�V��
        ''' </summary>
        Public Property UpdateDate As Date

    End Class

End Namespace
