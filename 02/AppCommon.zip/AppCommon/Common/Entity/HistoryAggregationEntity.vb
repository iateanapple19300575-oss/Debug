Namespace MainApp.Data.Entity

  ''' <summary>
  ''' Entity�B
  ''' </summary>
  Public Class HistoryAggregationEntity

    ''' <summary>
    ''' ���s��
    ''' </summary>
    Public Property Executoed_Date As Date

    ''' <summary>
    ''' ������
    ''' </summary>
    Public Property Process_Name As String

    ''' <summary>
    ''' �����Ώۓ�
    ''' </summary>
    Public Property Target_Date As String

    ''' <summary>
    ''' ��������
    ''' </summary>
    Public Property Processing_Results As String

    ''' <summary>
    ''' ���s�[��
    ''' </summary>
    Public Property Executed_Terminal As String

    ''' <summary>
    ''' ���s��
    ''' </summary>
    Public Property Executoed_User As String

    ''' <summary>
    ''' �쐬��
    ''' </summary>
    Public Property Create_User As String

    ''' <summary>
    ''' �쐬��
    ''' </summary>
    Public Property Create_Date As Date

    ''' <summary>
    ''' �X�V��
    ''' </summary>
    Public Property Update_User As String

    ''' <summary>
    ''' �X�V��
    ''' </summary>
    Public Property Update_Date As Date

  End Class

End Namespace
