﻿Imports System.Data.SqlClient

Public Class BulkCopyExecutor

    Public Shared Sub ExecuteWithTran(conn As SqlConnection,
                                      tran As SqlTransaction,
                                      tableName As String,
                                      dt As DataTable)

        Using sqlBulkCopy As New SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, tran)
            sqlBulkCopy.BatchSize = CommonConst.BulkCopyConst.BULK_COPY_BATCH_SIZE
            sqlBulkCopy.BulkCopyTimeout = CommonConst.BulkCopyConst.BULK_COPY_TIMEOUT_MINUTE
            sqlBulkCopy.DestinationTableName = tableName
            sqlBulkCopy.WriteToServer(dt)
        End Using

    End Sub


    Public Shared Sub ExecuteWithTran(conn As SqlConnection,
                                      tran As SqlTransaction,
                                      tableName As String,
                                      dt As DataTable,
                                      mappings As List(Of SqlBulkCopyColumnMapping))

        Using sqlBulkCopy As New SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, tran)
            sqlBulkCopy.BatchSize = CommonConst.BulkCopyConst.BULK_COPY_BATCH_SIZE
            sqlBulkCopy.BulkCopyTimeout = CommonConst.BulkCopyConst.BULK_COPY_TIMEOUT_MINUTE
            sqlBulkCopy.DestinationTableName = tableName
            For Each item As SqlBulkCopyColumnMapping In mappings
                sqlBulkCopy.ColumnMappings.Add(item)
            Next

            sqlBulkCopy.WriteToServer(dt)
        End Using

    End Sub

End Class

