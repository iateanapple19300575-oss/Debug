﻿''' <summary>
''' CSV インポートに必要なコンポーネントのセット。
''' </summary>
Public Interface ICsvImportMasterComponents
    ReadOnly Property Csv As ICsv
    ReadOnly Property Validator As ICsvValidation
End Interface