﻿''' <summary>
''' CSV取込処理コンポーネント
''' </summary>
Public Class CsvImportMasterComponents
    Implements ICsvImportMasterComponents

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="csv"></param>
    ''' <param name="validator"></param>
    Public Sub New(csv As ICsv, validator As ICsvValidation)
        Me.Csv = csv
        Me.Validator = validator
    End Sub

    ''' <summary>
    ''' CSVリーダーインスタンス
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property Csv As ICsv Implements ICsvImportMasterComponents.Csv

    ''' <summary>
    ''' CSVデータバリデーションインスタンス
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property Validator As ICsvValidation Implements ICsvImportMasterComponents.Validator

End Class