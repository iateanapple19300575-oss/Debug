﻿Public Interface ICsvImporter
    Function Execute() As ImportResultInfo
End Interface
