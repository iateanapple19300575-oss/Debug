﻿''' <summary>
''' CSV インポートに必要なコンポーネントのセット。
''' </summary>
Public Interface ICsvImportComponents
    ReadOnly Property Csv As ICsv
    ReadOnly Property Validator As ICsvValidation
End Interface