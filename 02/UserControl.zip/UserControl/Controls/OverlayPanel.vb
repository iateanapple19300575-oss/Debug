﻿Public Class OverlayPanel

	Private fadeTimer As Timer
	Private targetAlpha As Integer
	Private currentAlpha As Integer
	Private fadeStep As Integer = 15

	Private lbl As Label

	Public Sub New()
		InitializeComponent()

		Me.Dock = DockStyle.Fill
		Me.BackColor = Color.FromArgb(0, 0, 0, 0)

		lbl = New Label()
		lbl.Text = "処理中..."
		lbl.ForeColor = Color.White
		lbl.AutoSize = True
		lbl.Font = New Font("Meiryo", 16, FontStyle.Bold)
		Me.Controls.Add(lbl)

		AddHandler Me.Resize, AddressOf OverlayPanel_Resize

		fadeTimer = New Timer()
		fadeTimer.Interval = 15
		AddHandler fadeTimer.Tick, AddressOf FadeTimerTick
	End Sub

	Private Sub OverlayPanel_Resize(sender As Object, e As EventArgs)
		CurrentLabel()
	End Sub

	Private Sub CurrentLabel()
		lbl.Left = (Me.Width - lbl.Width) \ 2
		lbl.Top = (Me.Height - lbl.Height) \ 2
	End Sub

	Public Sub SetMessage(ByVal msg As String)
		lbl.Text = msg
		CurrentLabel()
	End Sub

	Public Sub SetMessageFont(ByVal font As Font)
		lbl.Font = font
		CurrentLabel()
	End Sub

	Public Sub SetMessageColor(ByVal color As Color)
		lbl.ForeColor = color
		CurrentLabel()
	End Sub

	Public Sub SetMessageStyle(ByVal font As Font, ByVal color As Color)
		lbl.Font = font
		lbl.ForeColor = color
		CurrentLabel()
	End Sub

	Public Property FadeSpeed As Integer
		Get
			Return fadeStep
		End Get
		Set(value As Integer)
			fadeStep = Math.Max(1, Math.Min(50, value))
		End Set
	End Property

	Public Sub FadeIn(Optional ByVal alpha As Integer = 120)
		Me.Visible = True
		targetAlpha = alpha
		fadeTimer.Start()
	End Sub

	Public Sub FadeOut()
		targetAlpha = 0
		fadeTimer.Start()
	End Sub

	Private Sub FadeTimerTick(sender As Object, e As EventArgs)
		If currentAlpha < targetAlpha Then
			currentAlpha = Math.Min(currentAlpha + fadeStep, targetAlpha)
		Else
			currentAlpha = Math.Max(currentAlpha - fadeStep, targetAlpha)
		End If

		Me.BackColor = Color.FromArgb(currentAlpha, 0, 0, 0)
		If currentAlpha = targetAlpha Then
			If targetAlpha = 0 Then
				Me.Visible = False
			End If
		End If
	End Sub
End Class
