﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ImportRowControl
	Inherits System.Windows.Forms.UserControl

	'UserControl はコンポーネント一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.btnImport = New System.Windows.Forms.Button()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.ThisTimeTitle = New System.Windows.Forms.Label()
        Me.LastTimeTitle = New System.Windows.Forms.Label()
        Me.lblCurrentResult = New System.Windows.Forms.Label()
        Me.lblCurrentCount = New System.Windows.Forms.Label()
        Me.lblCurrentTime = New System.Windows.Forms.Label()
        Me.lblLastCount = New System.Windows.Forms.Label()
        Me.lblLastTime = New System.Windows.Forms.Label()
        Me.txtFilePath = New System.Windows.Forms.TextBox()
        Me.lblDataType = New System.Windows.Forms.Label()
        Me.cmbCategory = New System.Windows.Forms.ComboBox()
        Me.lblCategoryTitle = New System.Windows.Forms.Label()
        Me.lblLastResult = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnImport
        '
        Me.btnImport.Location = New System.Drawing.Point(700, 35)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.Size = New System.Drawing.Size(70, 28)
        Me.btnImport.TabIndex = 3
        Me.btnImport.Text = "取込"
        Me.btnImport.UseVisualStyleBackColor = True
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(630, 35)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(60, 28)
        Me.btnBrowse.TabIndex = 2
        Me.btnBrowse.Text = "参照..."
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'ThisTimeTitle
        '
        Me.ThisTimeTitle.AutoSize = True
        Me.ThisTimeTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ThisTimeTitle.Location = New System.Drawing.Point(66, 100)
        Me.ThisTimeTitle.Name = "ThisTimeTitle"
        Me.ThisTimeTitle.Size = New System.Drawing.Size(47, 17)
        Me.ThisTimeTitle.TabIndex = 9
        Me.ThisTimeTitle.Text = "今回："
        '
        'LastTimeTitle
        '
        Me.LastTimeTitle.AutoSize = True
        Me.LastTimeTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.LastTimeTitle.Location = New System.Drawing.Point(66, 75)
        Me.LastTimeTitle.Name = "LastTimeTitle"
        Me.LastTimeTitle.Size = New System.Drawing.Size(47, 17)
        Me.LastTimeTitle.TabIndex = 6
        Me.LastTimeTitle.Text = "前回："
        '
        'lblCurrentResult
        '
        Me.lblCurrentResult.AutoSize = True
        Me.lblCurrentResult.Location = New System.Drawing.Point(370, 100)
        Me.lblCurrentResult.Name = "lblCurrentResult"
        Me.lblCurrentResult.Size = New System.Drawing.Size(34, 17)
        Me.lblCurrentResult.TabIndex = 12
        Me.lblCurrentResult.Text = "状態"
        '
        'lblCurrentCount
        '
        Me.lblCurrentCount.Location = New System.Drawing.Point(256, 100)
        Me.lblCurrentCount.Name = "lblCurrentCount"
        Me.lblCurrentCount.Size = New System.Drawing.Size(55, 17)
        Me.lblCurrentCount.TabIndex = 11
        Me.lblCurrentCount.Text = "--,---"
        Me.lblCurrentCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCurrentTime
        '
        Me.lblCurrentTime.AutoSize = True
        Me.lblCurrentTime.Location = New System.Drawing.Point(111, 100)
        Me.lblCurrentTime.Name = "lblCurrentTime"
        Me.lblCurrentTime.Size = New System.Drawing.Size(100, 17)
        Me.lblCurrentTime.TabIndex = 10
        Me.lblCurrentTime.Text = "----/--/-- --:--"
        Me.lblCurrentTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLastCount
        '
        Me.lblLastCount.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblLastCount.Location = New System.Drawing.Point(256, 75)
        Me.lblLastCount.Name = "lblLastCount"
        Me.lblLastCount.Size = New System.Drawing.Size(55, 17)
        Me.lblLastCount.TabIndex = 8
        Me.lblLastCount.Text = "--,---"
        Me.lblLastCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblLastTime
        '
        Me.lblLastTime.AutoSize = True
        Me.lblLastTime.Location = New System.Drawing.Point(111, 75)
        Me.lblLastTime.Name = "lblLastTime"
        Me.lblLastTime.Size = New System.Drawing.Size(100, 17)
        Me.lblLastTime.TabIndex = 7
        Me.lblLastTime.Text = "----/--/-- --:--"
        Me.lblLastTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtFilePath
        '
        Me.txtFilePath.Location = New System.Drawing.Point(20, 35)
        Me.txtFilePath.Name = "txtFilePath"
        Me.txtFilePath.ReadOnly = True
        Me.txtFilePath.Size = New System.Drawing.Size(600, 28)
        Me.txtFilePath.TabIndex = 1
        Me.txtFilePath.TabStop = False
        '
        'lblDataType
        '
        Me.lblDataType.AutoSize = True
        Me.lblDataType.Location = New System.Drawing.Point(15, 10)
        Me.lblDataType.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDataType.Name = "lblDataType"
        Me.lblDataType.Size = New System.Drawing.Size(138, 17)
        Me.lblDataType.TabIndex = 0
        Me.lblDataType.Text = "○○○○○○○データ"
        '
        'cmbCategory
        '
        Me.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCategory.FormattingEnabled = True
        Me.cmbCategory.Location = New System.Drawing.Point(246, 5)
        Me.cmbCategory.Name = "cmbCategory"
        Me.cmbCategory.Size = New System.Drawing.Size(78, 25)
        Me.cmbCategory.TabIndex = 5
        '
        'lblCategoryTitle
        '
        Me.lblCategoryTitle.AutoSize = True
        Me.lblCategoryTitle.Location = New System.Drawing.Point(180, 10)
        Me.lblCategoryTitle.Name = "lblCategoryTitle"
        Me.lblCategoryTitle.Size = New System.Drawing.Size(60, 17)
        Me.lblCategoryTitle.TabIndex = 4
        Me.lblCategoryTitle.Text = "講習区分"
        '
        'lblLastResult
        '
        Me.lblLastResult.AutoSize = True
        Me.lblLastResult.Location = New System.Drawing.Point(370, 75)
        Me.lblLastResult.Name = "lblLastResult"
        Me.lblLastResult.Size = New System.Drawing.Size(34, 17)
        Me.lblLastResult.TabIndex = 13
        Me.lblLastResult.Text = "状態"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(310, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 17)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "件"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(310, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 17)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "件"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ImportRowControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LastTimeTitle)
        Me.Controls.Add(Me.lblLastResult)
        Me.Controls.Add(Me.lblCurrentTime)
        Me.Controls.Add(Me.lblLastTime)
        Me.Controls.Add(Me.lblCategoryTitle)
        Me.Controls.Add(Me.cmbCategory)
        Me.Controls.Add(Me.btnImport)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.ThisTimeTitle)
        Me.Controls.Add(Me.lblCurrentResult)
        Me.Controls.Add(Me.lblCurrentCount)
        Me.Controls.Add(Me.lblLastCount)
        Me.Controls.Add(Me.txtFilePath)
        Me.Controls.Add(Me.lblDataType)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "ImportRowControl"
        Me.Size = New System.Drawing.Size(790, 130)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnImport As Button
	Friend WithEvents btnBrowse As Button
	Friend WithEvents ThisTimeTitle As Label
	Friend WithEvents LastTimeTitle As Label
	Friend WithEvents lblCurrentResult As Label
	Friend WithEvents lblCurrentCount As Label
	Friend WithEvents lblCurrentTime As Label
	Friend WithEvents lblLastCount As Label
	Friend WithEvents lblLastTime As Label
	Friend WithEvents txtFilePath As TextBox
	Friend WithEvents lblDataType As Label
	Friend WithEvents cmbCategory As ComboBox
	Friend WithEvents lblCategoryTitle As Label
  Friend WithEvents lblLastResult As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
