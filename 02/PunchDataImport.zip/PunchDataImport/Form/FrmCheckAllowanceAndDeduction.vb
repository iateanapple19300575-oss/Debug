﻿Public Class FrmCheckAllowanceAndDeduction
  Inherits BaseForm


  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  Public Sub New()
    MyBase.New("手当・控除データ確認")
    InitializeComponent()
    FormLogWrapper.WrapFormLifecycle(Me)
    FormLogWrapper.WrapAllEvents(Me)
  End Sub


#Region "Windows イベント"

  ''' <summary>
  ''' Loadイベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub FrmCheckAllowanceAndDeduction_Load(sender As Object, e As EventArgs) Handles Me.Load

  End Sub

#End Region

#Region "画面操作イベント"

  ''' <summary>
  ''' [検索]ボタン押下イベント
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

  End Sub

#End Region
End Class