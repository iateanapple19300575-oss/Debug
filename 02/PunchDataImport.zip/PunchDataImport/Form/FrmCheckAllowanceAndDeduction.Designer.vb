﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmCheckAllowanceAndDeduction
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.txtTeacherCode = New System.Windows.Forms.TextBox()
    Me.txtTeacherName = New System.Windows.Forms.TextBox()
    Me.txtExpenseItem = New System.Windows.Forms.TextBox()
    Me.GroupBox1 = New System.Windows.Forms.GroupBox()
    Me.chkTransExpManual = New System.Windows.Forms.CheckBox()
    Me.chkDeductionNonTaxable = New System.Windows.Forms.CheckBox()
    Me.chkSettlementNonTaxable = New System.Windows.Forms.CheckBox()
    Me.chkDeductionTaxable = New System.Windows.Forms.CheckBox()
    Me.chkAllowanceTaxable = New System.Windows.Forms.CheckBox()
    Me.btnSearch = New System.Windows.Forms.Button()
    Me.DataGridView1 = New System.Windows.Forms.DataGridView()
    Me.GroupBox1.SuspendLayout()
    CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(20, 20)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(73, 17)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "講師コード"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(160, 20)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(47, 17)
    Me.Label2.TabIndex = 2
    Me.Label2.Text = "講師名"
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(353, 20)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(34, 17)
    Me.Label3.TabIndex = 4
    Me.Label3.Text = "費目"
    '
    'txtTeacherCode
    '
    Me.txtTeacherCode.Location = New System.Drawing.Point(100, 14)
    Me.txtTeacherCode.MaxLength = 4
    Me.txtTeacherCode.Name = "txtTeacherCode"
    Me.txtTeacherCode.Size = New System.Drawing.Size(40, 28)
    Me.txtTeacherCode.TabIndex = 1
    '
    'txtTeacherName
    '
    Me.txtTeacherName.Location = New System.Drawing.Point(214, 14)
    Me.txtTeacherName.MaxLength = 8
    Me.txtTeacherName.Name = "txtTeacherName"
    Me.txtTeacherName.Size = New System.Drawing.Size(116, 28)
    Me.txtTeacherName.TabIndex = 3
    '
    'txtExpenseItem
    '
    Me.txtExpenseItem.Location = New System.Drawing.Point(393, 14)
    Me.txtExpenseItem.Name = "txtExpenseItem"
    Me.txtExpenseItem.Size = New System.Drawing.Size(116, 28)
    Me.txtExpenseItem.TabIndex = 5
    '
    'GroupBox1
    '
    Me.GroupBox1.Controls.Add(Me.chkTransExpManual)
    Me.GroupBox1.Controls.Add(Me.chkDeductionNonTaxable)
    Me.GroupBox1.Controls.Add(Me.chkSettlementNonTaxable)
    Me.GroupBox1.Controls.Add(Me.chkDeductionTaxable)
    Me.GroupBox1.Controls.Add(Me.chkAllowanceTaxable)
    Me.GroupBox1.Location = New System.Drawing.Point(26, 65)
    Me.GroupBox1.Name = "GroupBox1"
    Me.GroupBox1.Size = New System.Drawing.Size(483, 92)
    Me.GroupBox1.TabIndex = 6
    Me.GroupBox1.TabStop = False
    Me.GroupBox1.Text = "手当・控除種別"
    '
    'chkTransExpManual
    '
    Me.chkTransExpManual.AutoSize = True
    Me.chkTransExpManual.Checked = True
    Me.chkTransExpManual.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkTransExpManual.Location = New System.Drawing.Point(330, 55)
    Me.chkTransExpManual.Name = "chkTransExpManual"
    Me.chkTransExpManual.Size = New System.Drawing.Size(105, 21)
    Me.chkTransExpManual.TabIndex = 4
    Me.chkTransExpManual.Text = "手入力交通費"
    Me.chkTransExpManual.UseVisualStyleBackColor = True
    '
    'chkDeductionNonTaxable
    '
    Me.chkDeductionNonTaxable.AutoSize = True
    Me.chkDeductionNonTaxable.Checked = True
    Me.chkDeductionNonTaxable.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkDeductionNonTaxable.Location = New System.Drawing.Point(157, 55)
    Me.chkDeductionNonTaxable.Name = "chkDeductionNonTaxable"
    Me.chkDeductionNonTaxable.Size = New System.Drawing.Size(118, 21)
    Me.chkDeductionNonTaxable.TabIndex = 3
    Me.chkDeductionNonTaxable.Text = "控除（非課税）"
    Me.chkDeductionNonTaxable.UseVisualStyleBackColor = True
    '
    'chkSettlementNonTaxable
    '
    Me.chkSettlementNonTaxable.AutoSize = True
    Me.chkSettlementNonTaxable.Checked = True
    Me.chkSettlementNonTaxable.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkSettlementNonTaxable.Location = New System.Drawing.Point(20, 55)
    Me.chkSettlementNonTaxable.Name = "chkSettlementNonTaxable"
    Me.chkSettlementNonTaxable.Size = New System.Drawing.Size(131, 21)
    Me.chkSettlementNonTaxable.TabIndex = 2
    Me.chkSettlementNonTaxable.Text = "精算金（非課税）"
    Me.chkSettlementNonTaxable.UseVisualStyleBackColor = True
    '
    'chkDeductionTaxable
    '
    Me.chkDeductionTaxable.AutoSize = True
    Me.chkDeductionTaxable.Checked = True
    Me.chkDeductionTaxable.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkDeductionTaxable.Location = New System.Drawing.Point(157, 28)
    Me.chkDeductionTaxable.Name = "chkDeductionTaxable"
    Me.chkDeductionTaxable.Size = New System.Drawing.Size(105, 21)
    Me.chkDeductionTaxable.TabIndex = 1
    Me.chkDeductionTaxable.Text = "控除（課税）"
    Me.chkDeductionTaxable.UseVisualStyleBackColor = True
    '
    'chkAllowanceTaxable
    '
    Me.chkAllowanceTaxable.AutoSize = True
    Me.chkAllowanceTaxable.Checked = True
    Me.chkAllowanceTaxable.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkAllowanceTaxable.Location = New System.Drawing.Point(20, 28)
    Me.chkAllowanceTaxable.Name = "chkAllowanceTaxable"
    Me.chkAllowanceTaxable.Size = New System.Drawing.Size(105, 21)
    Me.chkAllowanceTaxable.TabIndex = 0
    Me.chkAllowanceTaxable.Text = "手当（課税）"
    Me.chkAllowanceTaxable.UseVisualStyleBackColor = True
    '
    'btnSearch
    '
    Me.btnSearch.Location = New System.Drawing.Point(526, 74)
    Me.btnSearch.Name = "btnSearch"
    Me.btnSearch.Size = New System.Drawing.Size(138, 83)
    Me.btnSearch.TabIndex = 7
    Me.btnSearch.Text = "検索"
    Me.btnSearch.UseVisualStyleBackColor = True
    '
    'DataGridView1
    '
    Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.DataGridView1.Location = New System.Drawing.Point(26, 174)
    Me.DataGridView1.Name = "DataGridView1"
    Me.DataGridView1.RowTemplate.Height = 21
    Me.DataGridView1.Size = New System.Drawing.Size(638, 451)
    Me.DataGridView1.TabIndex = 8
    '
    'FrmCheckAllowanceAndDeduction
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(684, 637)
    Me.Controls.Add(Me.DataGridView1)
    Me.Controls.Add(Me.btnSearch)
    Me.Controls.Add(Me.GroupBox1)
    Me.Controls.Add(Me.txtExpenseItem)
    Me.Controls.Add(Me.txtTeacherName)
    Me.Controls.Add(Me.txtTeacherCode)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.Label1)
    Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.Margin = New System.Windows.Forms.Padding(4)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "FrmCheckAllowanceAndDeduction"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "手当・控除データ確認"
    Me.GroupBox1.ResumeLayout(False)
    Me.GroupBox1.PerformLayout()
    CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents Label1 As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents Label3 As Label
	Friend WithEvents txtTeacherCode As TextBox
	Friend WithEvents txtTeacherName As TextBox
	Friend WithEvents txtExpenseItem As TextBox
	Friend WithEvents GroupBox1 As GroupBox
	Friend WithEvents chkTransExpManual As CheckBox
	Friend WithEvents chkDeductionNonTaxable As CheckBox
	Friend WithEvents chkSettlementNonTaxable As CheckBox
	Friend WithEvents chkDeductionTaxable As CheckBox
	Friend WithEvents chkAllowanceTaxable As CheckBox
	Friend WithEvents btnSearch As Button
	Friend WithEvents DataGridView1 As DataGridView
End Class
