﻿''' <summary>
''' 出講予定CSVデータバリデーションエラー表示画面
''' </summary>
Public Class PlanCsvError
    Inherits FrmValidationErrors

	'''' <summary>
	'''' Windowタイトル名
	'''' </summary>
	'Protected Overrides Property WINDOW_TITLE As String = "エラー一覧（出講予定）"

	'''' <summary>
	'''' 出講予定CSVデータ
	'''' </summary>
	'Private csvFileInfo As New PlanCsv


	'''' <summary>
	'''' コンストラクタ
	'''' </summary>
	'''' <param name="validationResultList"></param>
	'Public Sub New(ByVal validationResultList As Dictionary(Of Integer, List(Of ValidationResult)), ByVal csvInfo As CsvAbstract)
	'	MyBase.New(validationResultList)
	'End Sub

	'''' <summary>
	'''' カラム情報設定
	'''' </summary>
	'Protected Overrides Sub InitializeDataGridView()
	'	' カラム名と表示位置
	'	Dim csvColumns() As String = csvFileInfo.Headers.ToArray()
	'	Add(csvColumns(0), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(1), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(2), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(3), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(4), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(5), DataGridViewContentAlignment.MiddleCenter)
	'	Add(csvColumns(6), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(7), DataGridViewContentAlignment.MiddleLeft)
	'	Add(csvColumns(8), DataGridViewContentAlignment.MiddleRight)
	'End Sub
End Class
