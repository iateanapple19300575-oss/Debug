﻿''' <summary>
''' 打刻CSVデータバリデーションエラー表示画面
''' </summary>
Public Class StampCsvError
    Inherits FrmValidationErrors

	'''' <summary>
	'''' Windowタイトル名
	'''' </summary>
	'Protected Overrides Property WINDOW_TITLE As String = "エラー一覧（打刻実績）"

	'''' <summary>
	'''' 打刻実績CSVデータ
	'''' </summary>
	'Private csvFileInfo As New StampCsv


	'''' <summary>
	'''' コンストラクタ
	'''' </summary>
	'''' <param name="validationResultList"></param>
	'Public Sub New(ByVal validationResultList As Dictionary(Of Integer, List(Of ValidationResult)), ByVal csvInfo As CsvAbstract)
	'	MyBase.New(validationResultList)
	'	csvFileInfo = csvInfo
	'End Sub

	'''' <summary>
	'''' カラム情報設定
	'''' </summary>
	'Protected Overrides Sub InitializeDataGridView()
	'	'Dim csvColumns() As String = csvFileInfo.Headers.ToArray()
	'	'Add(csvColumns(0), DataGridViewContentAlignment.MiddleCenter)
	'	'Add(csvColumns(1), DataGridViewContentAlignment.MiddleLeft)
	'	'Add(csvColumns(2), DataGridViewContentAlignment.MiddleLeft)
	'	'Add(csvColumns(3), DataGridViewContentAlignment.MiddleLeft)
	'	'Add(csvColumns(4), DataGridViewContentAlignment.MiddleCenter)
	'	'Add(csvColumns(5), DataGridViewContentAlignment.MiddleLeft)
	'	'Add(csvColumns(6), DataGridViewContentAlignment.MiddleLeft)
	'	'Add(csvColumns(7), DataGridViewContentAlignment.MiddleLeft)
	'	'Add(csvColumns(8), DataGridViewContentAlignment.MiddleCenter)
	'	'Add(csvColumns(9), DataGridViewContentAlignment.MiddleCenter)
	'	'Add(csvColumns(10), DataGridViewContentAlignment.MiddleCenter)
	'	'Add(csvColumns(11), DataGridViewContentAlignment.MiddleCenter)
	'	'Add(csvColumns(12), DataGridViewContentAlignment.MiddleCenter)
	'	'Add(csvColumns(13), DataGridViewContentAlignment.MiddleRight)

	'	Dim csvColumnNames() As String = csvFileInfo.Headers.ToArray()
	'	Dim colmunAligns() As Integer = csvFileInfo.ContentAlign.ToArray()
	'	For i As Integer = 0 To csvColumnNames.Length - 1
	'		Add(csvColumnNames(i), colmunAligns(i))
	'	Next
	'End Sub
End Class
