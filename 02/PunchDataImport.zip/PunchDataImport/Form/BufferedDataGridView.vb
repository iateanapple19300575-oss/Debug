﻿
Imports System.Windows.Forms
Imports System.ComponentModel

<DesignerCategory("Code")>
Public Class BufferedDataGridView
	Inherits DataGridView

	Public Sub New()
		Me.DoubleBuffered = True
		Me.SetStyle(ControlStyles.OptimizedDoubleBuffer Or ControlStyles.AllPaintingInWmPaint, True)
	End Sub
End Class
