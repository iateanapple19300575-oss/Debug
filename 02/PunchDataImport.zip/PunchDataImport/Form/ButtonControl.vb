﻿Imports LecturePay.Common.Infrastructure

Public Class ButtonControl

  Private Property SystemDate As Date

  Private Property TargetMonth As Date

  'Private Property PariodDate As PariodRange

  Private Property CurrentDate As WeekRange

  Private PeriodRange As PariodRange

  ''' <summary>
  ''' 表示モード
  ''' </summary>
  Private Enum DisplayMode
    Week
    Day
    Month
  End Enum

  ''' <summary>
  ''' 表示対象期間
  ''' </summary>
  Private Structure PariodRange
    Public StartDay As Date
    Public EndDay As Date
  End Structure

  ''' <summary>
  ''' 対象週の月曜と日曜の日付
  ''' </summary>
  Private Structure WeekRange
    Public Monday As Date
    Public Sunday As Date
  End Structure

  Private Property CurrentMode As DisplayMode = DisplayMode.Week

  ''' <summary>
  ''' 対象年月の月初日
  ''' </summary>
  ''' <returns></returns>
  Private Property MonthFirstDay As Date = DateUtil.FirstDayOfMonth(AppCommon.SystemDate())

  ''' <summary>
  ''' 対象年月の月末日
  ''' </summary>
  ''' <returns></returns>
  Private Property MonthLastDay As Date = DateUtil.LastDayOfMonth(AppCommon.SystemDate())


  ''' <summary>
  ''' 　コンストラクタ
  ''' </summary>
  Public Sub New()

  End Sub

  ''' <summary>
  ''' コンストラクタ
  ''' </summary>
  ''' <param name="systemDate"></param>
  ''' <param name="targetMonth"></param>
  Public Sub New(ByVal systemDate As Date, ByVal targetMonth As Date)
    Me.SystemDate = systemDate
    Me.TargetMonth = targetMonth
  End Sub

  Private Sub PrevDay()
    CurrentMode = DisplayMode.Day
    PeriodRange.StartDay = DateWithinTheMonth(PeriodRange.StartDay.AddDays(-1), TargetMonth)
    PeriodRange.EndDay = PeriodRange.StartDay
    'UpdateDisplay()
    'UpdateNavigationButtons()
  End Sub


  Public Function GetStartDateWeekDayName() As String
    Return PeriodRange.StartDay.ToString("ddd")
  End Function

  Public Function GetEndDateWeekDayName() As String
    Return PeriodRange.EndDay.ToString("ddd")
  End Function

  Public Function GetStartDateIndex() As Integer
    Return PeriodRange.StartDay.Day - 1
  End Function

  Public Function GetEnddateIndex() As String
    Return PeriodRange.EndDay.Day - 1
  End Function


  ''' <summary>
  ''' 月内日付の取得
  ''' </summary>
  ''' <param name="targetDate"></param>
  ''' <param name="targetMonth"></param>
  ''' <returns></returns>
  Private Function DateWithinTheMonth(ByVal targetDate As Date, targetMonth As Date) As Date
    Dim firstDay As Date = New Date(targetMonth.Year, targetMonth.Month, 1)
    Dim lastDay As Date = firstDay.AddMonths(1).AddDays(-1)
    If targetDate < firstDay Then
      Return firstDay
    ElseIf targetDate > lastDay Then
      Return lastDay
    Else
      Return targetDate
    End If
  End Function



  Private Sub UpdateDisplay(ByRef baseDate As PariodRange)
    Dim firstDay As Date = MonthFirstDay()
    Dim lastDay As Date = MonthLastDay()

    Select Case CurrentMode
      Case DisplayMode.Day
        ' 日単位表示
        baseDate.StartDay = baseDate.StartDay.AddDays(-1)
        baseDate.EndDay = baseDate.StartDay

      Case DisplayMode.Week
        ' 週単位表示
        Dim weekRange As WeekRange = GetWeekRange(baseDate.StartDay)
        Dim displayStart As Date = If(weekRange.Monday < firstDay, firstDay, weekRange.Monday)
        Dim displayEnd As Date = If(weekRange.Sunday > lastDay, lastDay, weekRange.Sunday)

        baseDate.StartDay = displayStart
        baseDate.EndDay = displayEnd

      Case DisplayMode.Month
        ' 月単位表示

        baseDate.StartDay = firstDay
        baseDate.EndDay = lastDay
    End Select
  End Sub

  Private Function GetWeekRange(ByVal baseDate As Date) As WeekRange
    Dim dayOfWeek As Integer = CInt(baseDate.DayOfWeek)
    Dim monday As Date = baseDate.AddDays(-((dayOfWeek + 6) Mod 7))
    Dim sunday As Date = monday.AddDays(6)
    Dim range As WeekRange
    range.Monday = monday
    range.Sunday = sunday
    Return range
  End Function

End Class
