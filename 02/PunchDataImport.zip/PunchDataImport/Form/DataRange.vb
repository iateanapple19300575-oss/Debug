﻿Public Interface IDataRange
  Function GetRange(ByVal baseDate As Date, ByVal monthStart As Date, ByVal monthEnd As Date) As DataRange
End Interface

Public Class DayRange
	Implements IDataRange

	Public Function GetRange(baseDate As Date, monthStart As Date, monthEnd As Date) As DataRange Implements IDataRange.GetRange
		Dim d As Date = DateClampHelper.Clamp(baseDate, monthStart, monthEnd)
		Return New DataRange(d, d)
	End Function
End Class

Public Class WeekRange
	Implements IDataRange

	Public Function GetRange(baseDate As Date, monthStart As Date, monthEnd As Date) As DataRange Implements IDataRange.GetRange
		Dim monday As Date = baseDate.AddDays(-(Weekday(baseDate, FirstDayOfWeek.Monday) - 1))
		Dim sunday As Date = monday.AddDays(6)
		Dim fromDate As Date = If(monday < monthStart, monthStart, monday)
		Dim toDate As Date = If(sunday > monthEnd, monthEnd, sunday)
		Return New DataRange(fromDate, toDate)
	End Function
End Class

Public Class MonthRange
  Implements IDataRange

  Public Function GetRange(baseDate As Date, monthStart As Date, monthEnd As Date) As DataRange Implements IDataRange.GetRange
    Dim fromDate As Date = New DateTime(baseDate.Year, baseDate.Month, 1)
    Dim toDate As Date = New DateTime(baseDate.Year, baseDate.Month, 1).AddMonths(1).AddDays(-1)
    Return New DataRange(fromDate, toDate)
  End Function
End Class

Public Class DataRange
	Public Property FromDate As Date
	Public Property ToDate As Date

	Public Sub New(ByVal fromDate As Date, ByVal toDate As Date)
		Me.FromDate = fromDate
		Me.ToDate = toDate
	End Sub
End Class

Public Class DateClampHelper
	Public Shared Function Clamp(d As Date, ByVal min As Date, ByVal max As Date) As Date
		If d < min Then
			Return min
		End If
		If d > max Then
			Return max
		End If
		Return d
	End Function
End Class

