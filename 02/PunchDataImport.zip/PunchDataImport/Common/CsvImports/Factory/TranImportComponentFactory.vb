﻿Imports ImportType
Imports MainApp.Data.Dto

Public Class TranImportComponentFactory

    Public Shared Function Create(type As ImportCsvType, param As CsvImportParameterDto) As CsvImportComponents
        Select Case type
            Case ImportCsvType.PunchData
                Return New CsvImportComponents(
                            New StampCsv(param.FilePath),
                            New StampCsvValidation(New StampCsv(param.FilePath))
                            )
            Case ImportCsvType.LecturePlan
                Return New CsvImportComponents(
                            New PlanCsv(param.FilePath),
                            New PlanCsvValidation(New PlanCsv(param.FilePath))
                            )
            Case ImportCsvType.LectureCourse
                Return New CsvImportComponents(
                            New PlanCsv(param.FilePath),
                            New PlanCsvValidation(New PlanCsv(param.FilePath))
                            )
            Case ImportCsvType.PinchActual
                Return New CsvImportComponents(
                            New DelegationCsv(param.FilePath),
                            New DelegationCsvValidation(New DelegationCsv(param.FilePath))
                            )
            Case ImportCsvType.RequestActual
                Return New CsvImportComponents(
                            New RequestCsv(param.FilePath),
                            New RequestCsvValidation(New RequestCsv(param.FilePath))
                            )
            Case ImportCsvType.RequsttNoPunch
                Return New CsvImportComponents(
                            New RequsttNoPunchCsv(param.FilePath),
                            New RequestNoPunchCsvValidation(New RequsttNoPunchCsv(param.FilePath))
                            )

                'Case ImportCsvType.TimePattern
                '    Return New CsvImportMasterComponents(
                '                New TimePatternCsv(param.FilePath),
                '                New TimePatternCsvValidation(New TimePatternCsv(param.FilePath))
                '                )
                'Case ImportCsvType.TimeTableSite
                '    Return New CsvImportMasterComponents(
                '                New TimeTableSiteCsv(param.FilePath),
                '                New TimeTableSiteCsvValidation(New TimeTableSiteCsv(param.FilePath))
                '                )
                'Case ImportCsvType.TimeTableClass
                '    Return New CsvImportMasterComponents(
                '                New TimeTableClassCsv(param.FilePath),
                '                New TimeTableClassCsvValidation(New TimeTableClassCsv(param.FilePath))
                '                )
                'Case ImportCsvType.TeacherUnitPrice
                '    Return New CsvImportMasterComponents(
                '                New TeacherWageCsv(param.FilePath),
                '                New TeacherWageCsvValidation(New TeacherWageCsv(param.FilePath))
                '                )
            Case Else
                Throw New NotSupportedException("未対応の CSV 種類です: " & type)
        End Select
    End Function

End Class