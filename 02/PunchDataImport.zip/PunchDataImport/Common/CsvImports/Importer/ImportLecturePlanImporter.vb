﻿Imports System.Globalization
Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities

Public Class ImportLecturePlanImporter
    Inherits CsvImporterTranBase

    Private ReadOnly Property _parameter As CsvImportParameterDto

    Private ReadOnly _components As CsvImportComponents

    Public Sub New(parameter As CsvImportParameterDto, components As CsvImportComponents)
        MyBase.New(parameter, components.Csv, components.Validator)
        _parameter = parameter
    End Sub

    Protected Overrides ReadOnly Property TargetTableName As String
        Get
            Return TranDataImportTable.LECTURE_PLAN
        End Get
    End Property

    Protected Overrides ReadOnly Property ImportTypeName As String
        Get
            Return TranDataImportTypes.LecturePlan
        End Get
    End Property

    Protected Overrides ReadOnly Property DataType As String
        Get
            Return TableImportHistoryConst.TYPE_LECTURE_REGULAR
        End Get
    End Property

    Protected Overrides Function GetDtoType() As Type
        Return Nothing
    End Function

    Protected Overrides Sub DeleteSwapData(ByVal sqlDbConn As DbTransactionScope, targetDates As List(Of String))
        Dim repo As New LecturePlanRepository(sqlDbConn)
        repo.DeleteSwapData(_parameter.TargetDate)
        Return
    End Sub

    ''' <summary>
    ''' 出講実績データ作成
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Function AppendJob(ByVal sqlDbConn As DbTransactionScope) As Integer
        Dim repo As New LectureActualRepository(sqlDbConn)
        repo.DeleteSwapData(_parameter.TargetDate, LectureFeeConst.PHASE_ACTUAL, _parameter.DataType, _parameter.CourseType)

        Dim count As Integer
        count = repo.LectuerPlanToLectuerActual(_parameter.TargetDate, LectureFeeConst.PHASE_ACTUAL, _parameter.DataType, _parameter.CourseType)

        Return count
    End Function

    Protected Overrides Sub PreparatoryWork(sqlDbConn As DbTransactionScope, impDataDic As List(Of Dictionary(Of String, String)), delMonths As List(Of String))
        DeleteSwapData(sqlDbConn, delMonths)
    End Sub

    Protected Overrides Function ValidationMonthPeriod(ByRef delKeys As List(Of String), impDataList As List(Of Dictionary(Of String, String))) As ImportDataErrorType

        ' 事前削除対象の年月日を取得する
        Dim storedDates As List(Of String) = GetYearMonthList(impDataList)
        If storedDates.Count <= 0 Then
            Return ImportDataErrorType.DataNotFound
        End If

        ' 年度の範囲外のデータが存在するならばエラーとして処理しない。
        Dim strStartDate As String = DateUtil.FirstDayOfMonth(AppState.TargetYearMonth).ToShortDateString().Substring(0, 7)
        Dim strEndDate As String = DateUtil.LastDayOfMonth(AppState.TargetYearMonth).ToShortDateString().Substring(0, 7)
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        For Each ymd As String In storedDates.ToArray
            If strStartDate <= ymd AndAlso strEndDate >= ymd Then
                delKeys.Add(ymd)
                trueCnt += 1
            Else
                falseCnt += 1
            End If
        Next

        If trueCnt = 1 AndAlso falseCnt = 0 Then
            Return ImportDataErrorType.Success
        ElseIf trueCnt > 0 AndAlso falseCnt > 0 Then
            Return ImportDataErrorType.IncludingNonEligible
        ElseIf trueCnt = 0 AndAlso falseCnt > 0 Then
            Return ImportDataErrorType.OnlyNonEligible
        End If

        Return ImportDataErrorType.OtherError
    End Function

    '' <summary>
    '' 事前削除対象の年月日を収集します。
    '' CSVファイル内の年月日項目のサマリを取得して事前削除対象の年月日とします。
    '' </summary>
    '' <param name="list"></param>
    '' <returns></returns>
    Private Function GetYearMonthList(list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYearMonths =
                  list.
                  Where(Function(d) d.ContainsKey("日付") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("日付"))).
                  Select(Function(d)
                             Dim dt As DateTime
                             ' 日付変換（安全に TryParseExact）
                             If DateTime.TryParseExact(d("日付"), {"yyyy/MM/dd", "yyyy-MM-dd"},
                                                   CultureInfo.InvariantCulture,
                                                   DateTimeStyles.None, dt) Then
                                 Return dt.ToString("yyyy/MM") ' 年月に変換
                             Else
                                 Return Nothing
                             End If
                         End Function).
                  Where(Function(s) s IsNot Nothing).
                  Distinct().
                  OrderBy(Function(s) s).
                  ToList()
        Return distinctYearMonths
    End Function

    ''' <summary>
    ''' 重複データがあるか否かを判定します。
    ''' </summary>
    ''' <param name="impDataDic"></param>
    ''' <returns></returns>
    Protected Overrides Function DuplicateValidation(ByVal impDataDic As List(Of Dictionary(Of String, String))) As Boolean
        ' 重複チェック
        Dim duplicates = impDataDic.
            GroupBy(Function(d) String.Join("|", {
                d("日付"),
                d("教室"),
                d("クラス"),
                d("コマ"),
                d("担当")
            })).
            Where(Function(g) g.Count() > 1).
            ToList()
        Return duplicates.Any()
    End Function

End Class