﻿''' <summary>
''' 画面/トランインターフェース
''' </summary>
Public Class TrasportExpensesIF
  Public Property Subjects As String = ""
  Public Property TeacherCode As String = ""
  Public Property GroupCode As String = ""
  Public Property SiteCode As String = ""
  Public Property UnregisteredOnly As Boolean = False
End Class
