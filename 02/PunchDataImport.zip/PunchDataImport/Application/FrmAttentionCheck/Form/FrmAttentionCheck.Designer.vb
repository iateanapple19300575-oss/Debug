﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmAttentionCheck
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.chkError = New System.Windows.Forms.CheckBox()
    Me.chkWarning = New System.Windows.Forms.CheckBox()
    Me.chkInfo = New System.Windows.Forms.CheckBox()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Panel1 = New System.Windows.Forms.Panel()
    Me.dgvAttention = New System.Windows.Forms.DataGridView()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Panel1.SuspendLayout()
    CType(Me.dgvAttention, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(22, 20)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(151, 17)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "出講料アテンション一覧"
    '
    'chkError
    '
    Me.chkError.AutoSize = True
    Me.chkError.Location = New System.Drawing.Point(104, 10)
    Me.chkError.Name = "chkError"
    Me.chkError.Size = New System.Drawing.Size(66, 21)
    Me.chkError.TabIndex = 1
    Me.chkError.Text = "エラー"
    Me.chkError.UseVisualStyleBackColor = True
    '
    'chkWarning
    '
    Me.chkWarning.AutoSize = True
    Me.chkWarning.Location = New System.Drawing.Point(176, 10)
    Me.chkWarning.Name = "chkWarning"
    Me.chkWarning.Size = New System.Drawing.Size(53, 21)
    Me.chkWarning.TabIndex = 2
    Me.chkWarning.Text = "警告"
    Me.chkWarning.UseVisualStyleBackColor = True
    '
    'chkInfo
    '
    Me.chkInfo.AutoSize = True
    Me.chkInfo.Location = New System.Drawing.Point(235, 10)
    Me.chkInfo.Name = "chkInfo"
    Me.chkInfo.Size = New System.Drawing.Size(53, 21)
    Me.chkInfo.TabIndex = 3
    Me.chkInfo.Text = "情報"
    Me.chkInfo.UseVisualStyleBackColor = True
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(10, 11)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(60, 17)
    Me.Label2.TabIndex = 0
    Me.Label2.Text = "表示条件"
    '
    'Panel1
    '
    Me.Panel1.Controls.Add(Me.Label2)
    Me.Panel1.Controls.Add(Me.chkInfo)
    Me.Panel1.Controls.Add(Me.chkError)
    Me.Panel1.Controls.Add(Me.chkWarning)
    Me.Panel1.Location = New System.Drawing.Point(466, 0)
    Me.Panel1.Name = "Panel1"
    Me.Panel1.Size = New System.Drawing.Size(297, 38)
    Me.Panel1.TabIndex = 1
    '
    'dgvAttention
    '
    Me.dgvAttention.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.dgvAttention.Location = New System.Drawing.Point(25, 40)
    Me.dgvAttention.Name = "dgvAttention"
    Me.dgvAttention.RowTemplate.Height = 21
    Me.dgvAttention.Size = New System.Drawing.Size(740, 698)
    Me.dgvAttention.TabIndex = 2
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(29, 748)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(424, 17)
    Me.Label3.TabIndex = 3
    Me.Label3.Text = "※エラーデータが存在する場合、締め処理を進めることができません。"
    '
    'FrmAttentionCheck
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(788, 781)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.dgvAttention)
    Me.Controls.Add(Me.Panel1)
    Me.Controls.Add(Me.Label1)
    Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.Margin = New System.Windows.Forms.Padding(4)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "FrmAttentionCheck"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "出講料アテンション確認"
    Me.Panel1.ResumeLayout(False)
    Me.Panel1.PerformLayout()
    CType(Me.dgvAttention, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents Label1 As Label
	Friend WithEvents chkError As CheckBox
	Friend WithEvents chkWarning As CheckBox
	Friend WithEvents chkInfo As CheckBox
	Friend WithEvents Label2 As Label
	Friend WithEvents Panel1 As Panel
	Friend WithEvents dgvAttention As DataGridView
	Friend WithEvents Label3 As Label
End Class
