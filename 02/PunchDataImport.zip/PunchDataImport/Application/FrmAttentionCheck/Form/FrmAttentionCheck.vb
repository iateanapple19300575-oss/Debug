﻿Imports Freamwork.Common.Helper
''' <summary>
''' [出講料アテンション確認]画面クラス
''' </summary>
Public Class FrmAttentionCheck
    Inherits BaseForm

    Private _controller As New FrmAttentionCheckFormController

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("出講料アテンション確認")
        InitializeComponent()
        FormLogWrapper.WrapFormLifecycle(Me)
        FormLogWrapper.WrapAllEvents(Me)
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmAttentionCheck_Load(sender As Object, e As EventArgs) Handles Me.Load
        MouseCursor.WaitCursor(Me)

        InitDisplay()

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' 画面初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        ' 表示条件
        chkError.Checked = True
        chkWarning.Checked = True
        chkInfo.Checked = True

        ' 出講料アテンション一覧
        Dim _controller As New FrmAttentionCheckFormController
        dgvAttention.DataSource = _controller.DataLoad(dgvAttention)

    End Sub

    ''' <summary>
    ''' [エラー]チェックボックスクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub chkError_CheckedChanged(sender As Object, e As EventArgs) Handles chkError.CheckedChanged
        FilteredSearch()
    End Sub

    ''' <summary>
    ''' [警告]チェックボックスクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub chkWarning_CheckedChanged(sender As Object, e As EventArgs) Handles chkWarning.CheckedChanged
        FilteredSearch()
    End Sub

    ''' <summary>
    ''' [情報]チェックボックスクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub chkInfo_CheckedChanged(sender As Object, e As EventArgs) Handles chkInfo.CheckedChanged
        FilteredSearch()
    End Sub

    ''' <summary>
    ''' フィルター検索処理
    ''' </summary>
    Private Sub FilteredSearch()
        ' DatGridViewにフィルター条件設定
        Dim objData As DataTable = CType(dgvAttention.DataSource, DataTable)
        If IsNothing(objData) = False Then
            Dim objBind As BindingSource
            objBind = New BindingSource
            objBind.DataSource = objData
            objBind.Filter = GetFilterString()
        End If

        ' 再描画(DataGridView反映)
        dgvAttention.Refresh()
    End Sub

    ''' <summary>
    ''' フィルター設定
    ''' </summary>
    ''' <returns></returns>
    Private Function GetFilterString() As String
        ' 勤怠状態
        Dim filterExpession As String = ""
        If chkError.Checked Then
            If Not String.IsNullOrEmpty(filterExpession) Then
                filterExpession &= " OR "
            End If
            filterExpession &= "Level_String LIKE '*エラー*' "
        End If

        If chkWarning.Checked Then
            If Not String.IsNullOrEmpty(filterExpession) Then
                filterExpession &= " OR "
            End If
            filterExpession &= "Level_String LIKE '*警告*' "
        End If

        If chkInfo.Checked Then
            If Not String.IsNullOrEmpty(filterExpession) Then
                filterExpession &= " Or "
            End If
            filterExpession &= "Level_String LIKE '情報' "
        End If

        Return filterExpession
    End Function

End Class