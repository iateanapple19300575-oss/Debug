﻿Imports Freamwork.Common.Helper
Imports ImportType
Imports LecturePay.Common.Infrastructure
Imports MainApp.Data.Dto
Imports PunchDataImport.MainApp.Data.Dto
Imports UserControl

''' <summary>
''' 出講データ取込画面
''' </summary>
Public Class FrmLectureImport
    Inherits BaseForm

#Region "フィールド変数関連"

    ''' <summary>
    ''' CSV取込用ユーザコントロール
    ''' </summary>
    Private _currentUserControl As ImportRowControl

    ''' <summary>
    ''' 出講データ取込画面 ViewController
    ''' </summary>
    Private _viewController As LectureImportViewController

    ' CSV取込データ種別
    Private ReadOnly DataTypes As String(,) = {
      {ImportCsvType.PunchData, "打刻データ", "False"},
      {ImportCsvType.LecturePlan, "出講データ", "False"},
      {ImportCsvType.LectureCourse, "出講データ（講習）", "True"},
      {ImportCsvType.PinchActual, "代講実績データ", "False"},
      {ImportCsvType.RequestActual, "業務届データ", "False"},
      {ImportCsvType.RequsttNoPunch, "打刻外業務給", "False"}
    }


#End Region

#Region "Windowsイベント"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("データ取込")
        InitializeComponent()

        FormLogWrapper.WrapFormLifecycle(Me)
        FormLogWrapper.WrapAllEvents(Me)
    End Sub

#End Region

#Region "初期表示処理"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmDataImport_Load(sender As Object, e As EventArgs) Handles Me.Load
        MouseCursor.WaitCursor(Me)

        _viewController = New LectureImportViewController(Me)

        ' 画面初期表示処理
        InitDisplay()

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' 画面初期表示処理
    ''' </summary>
    Private Sub InitDisplay()

        ' 講習区分
        LoadLectureCategory()

        ' 前回のCSV取込結果情報の取得と表示
        DisplayHistory()
    End Sub

#End Region

#Region "[データ取込]ボタン押下イベント"

    ''' <summary>
    ''' [取込]押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnImportRequested(ByVal sender As Object, ByVal e As EventArgs)
        MouseCursor.WaitCursor(Me)

        Dim uctrl = DirectCast(sender, ImportRowControl)
        Dim param As New CsvImportParameterDto

        ' 取込起動
        Dim vm As LectureImportModel
        vm = _viewController.CsvImport(uctrl)

        ' 結果表示
        DisplayExecutionResults(uctrl, vm.ImportResult)

        MouseCursor.DefaultCursor(Me)
    End Sub

#End Region

#Region "[データ確認]ボタン押下イベント"

    ''' <summary>
    ''' [打刻データ確認]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BtnStampList_Click(sender As Object, e As EventArgs) Handles BtnStampList.Click
        MouseCursor.WaitCursor(Me)

        Dim frmStamp As FrmDailyCheck = New FrmDailyCheck()
        frmStamp.ShowDialog()

        MouseCursor.DefaultCursor(Me)
    End Sub

#End Region

#Region "[参照]ボタン押下イベント"

    ''' <summary>
    ''' [参照]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnFileSelected(ByVal sender As Object, ByVal e As EventArgs)
        ' 今は何もしない
    End Sub

#End Region

#Region "取込結果表示処理"

    ''' <summary>
    ''' 取込結果表示
    ''' </summary>
    ''' <param name="uctrl"></param>
    ''' <param name="dto"></param>
    Public Sub DisplayExecutionResults(ByVal uctrl As ImportRowControl, ByVal dto As ImportResultInfo)
        uctrl.SetCurrentImportResult(dto.ExecutDateStr, dto.ExecutCount, dto.StatusString)
    End Sub

    ''' <summary>
    ''' 履歴情報の初期表示
    ''' </summary>
    Private Sub DisplayHistory()

        ' 前回のCSV取込結果情報の取得
        Dim viewModel As New LectureImportModel
        viewModel = _viewController.InitialDisplay()
        'InitializeHistory(viewModel)

        Dim panelHeight As Integer = 0
        Dim dic As Dictionary(Of Integer, ImportResultsDto)
        dic = viewModel.ImportResults

        For i As Integer = 0 To DataTypes.GetLength(0) - 1
            ' [確認]ボタン表示制御（True:表示／False:非表示）
            Dim row As New ImportRowControl()
            Dim display As Boolean = DataTypes(i, 2) = "True"
            row.Category.Visible = display
            row.ImportButton.Enabled = False
            panelHeight += row.Size.Height

            ' 対象データのタイトル名設定
            Dim dto As ImportResultsDto
            row.DataTypeLabel = DataTypes(i, 1)
            Dim id As Integer
            If Integer.TryParse(DataTypes(i, 0), id) Then
                If dic.ContainsKey(id) Then
                    dto = dic(id)
                    row.SetLastImportResult(dto.ExecutDate, dto.ExecutCount, dto.StatusString)
                End If
            End If

            ' ユーザコントロールからのイベント処理
            AddHandler row.FileSelected, AddressOf OnFileSelected
            AddHandler row.ImportButtonClick, AddressOf OnImportRequested

            ' FlowLayoutPanelに登録
            flpRows.Controls.Add(row)
        Next

        flpRows.AutoScrollMinSize = New Drawing.Size(0, panelHeight)
    End Sub

    ''' <summary>
    ''' 講習区分コンボデータ設定
    ''' </summary>
    Private Sub LoadLectureCategory()
        Dim dt As DataTable = AppCommon.GetLectureCategory()
        Dim ctrl As ImportRowControl
        For i As Integer = 0 To flpRows.Controls.Count - 1
            ctrl = DirectCast(flpRows.Controls(i), ImportRowControl)
            If ctrl.Visible Then
                With ctrl.Category
                    .DataSource = dt
                    .DisplayMember = "Name"
                    .ValueMember = "ID"
                End With
            End If
        Next
    End Sub

#End Region

End Class