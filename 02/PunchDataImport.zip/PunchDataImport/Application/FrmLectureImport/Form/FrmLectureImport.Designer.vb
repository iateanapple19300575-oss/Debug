﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmLectureImport
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()>
	Private Sub InitializeComponent()
        Me.flpRows = New System.Windows.Forms.FlowLayoutPanel()
        Me.BtnStampList = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'flpRows
        '
        Me.flpRows.AutoScroll = True
        Me.flpRows.Location = New System.Drawing.Point(12, 47)
        Me.flpRows.MinimumSize = New System.Drawing.Size(0, 500)
        Me.flpRows.Name = "flpRows"
        Me.flpRows.Size = New System.Drawing.Size(816, 740)
        Me.flpRows.TabIndex = 0
        '
        'BtnStampList
        '
        Me.BtnStampList.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.BtnStampList.Location = New System.Drawing.Point(676, 10)
        Me.BtnStampList.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnStampList.Name = "BtnStampList"
        Me.BtnStampList.Size = New System.Drawing.Size(140, 28)
        Me.BtnStampList.TabIndex = 2
        Me.BtnStampList.Tag = "NoLog"
        Me.BtnStampList.Text = "打刻データ確認"
        Me.BtnStampList.UseVisualStyleBackColor = True
        '
        'FrmLectureImport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(834, 791)
        Me.Controls.Add(Me.BtnStampList)
        Me.Controls.Add(Me.flpRows)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmLectureImport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "出講データ取込"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents flpRows As FlowLayoutPanel
	Friend WithEvents BtnStampList As Button
End Class
