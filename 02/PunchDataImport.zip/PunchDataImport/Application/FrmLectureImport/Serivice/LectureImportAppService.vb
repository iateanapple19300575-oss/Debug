﻿Imports ImportType
Imports MainApp.Data.Dto
Imports MainApp.Data.Entity
Imports PunchDataImport.MainApp.Data.Dto

''' <summary>
''' 出講データ取込サービス
''' </summary>
Public Class LectureImportAppService

    ''' <summary>データ取込履歴</summary>
    Private ReadOnly _repository As HistoryImportRepository

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        _repository = New HistoryImportRepository
    End Sub

    ''' <summary>
    ''' 初期表示データ取得
    ''' </summary>
    Public Function Initilaize(ByVal param As CsvImportParameterDto) As List(Of HistoryImportEntity)
        Return _repository.HistoryFinalData(param)
    End Function

    ''' <summary>
    ''' CSV取込処理
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function CsvImport(ByVal param As CsvImportParameterDto, model As LectureImportModel) As LectureImportModel
        ' IMPORT処理実行
        Dim components = TranImportComponentFactory.Create(param.CsvType, param)
        Dim importer As ICsvImporter = TranImporterFactory.Create(param.CsvType, param, components)
        Dim importResultInfo As New ImportResultInfo
        importResultInfo = importer.Execute()

        ' Modelへ詰め替え
        Dim resultModel As New LectureImportModel
        resultModel.ImportResult = importResultInfo

        Return resultModel
    End Function

End Class
