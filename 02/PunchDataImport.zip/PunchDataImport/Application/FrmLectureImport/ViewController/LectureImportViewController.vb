﻿Imports ImportType
Imports MainApp.Data.Dto
Imports MainApp.Data.Entity
Imports PunchDataImport.MainApp.Data.Dto
Imports UserControl

''' <summary>
''' 出講データ取込ViewController
''' </summary>
Public Class LectureImportViewController
    Implements ICsvImportView

    ''' <summary>出講データ取込画面Form</summary>
    Private ReadOnly _form As FrmLectureImport

    ''' <summary>出講データ取込Service</summary>
    Private ReadOnly _service As LectureImportAppService

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="frm"></param>
    Public Sub New(ByVal frm As Form)
        _form = frm
        _service = New LectureImportAppService()
    End Sub

    ''' <summary>
    ''' 初期表示データ取得要求
    ''' </summary>
    Public Function InitialDisplay() As LectureImportModel
        Dim model As New LectureImportModel
        Dim param As New CsvImportParameterDto
        Dim entitys As List(Of HistoryImportEntity)

        param.TargetDate = AppState.TargetYearMonth
        entitys = _service.Initilaize(param)

        Dim dic As New Dictionary(Of Integer, ImportResultsDto)
        For Each entity As HistoryImportEntity In entitys
            Dim dto As New ImportResultsDto
            dto.ExecutDate = entity.ExecutionDate
            dto.ExecutCount = entity.ExecutionCount
            dto.Success = entity.ExecutionStatus
            dto.StatusString = IIf(entity.ExecutionStatus = 0, "状態：正常終了", "状態：異常終了")
            dic.Add(entity.CsvType, dto)
        Next
        model.ImportResults = dic

        Return model
    End Function

    ''' <summary>
    ''' [取込]ボタン押下要求(インポート要求)
    ''' </summary>
    ''' <param name="uctrl"></param>
    Public Function CsvImport(uctrl As ImportRowControl) As LectureImportModel

        ' パラメタ情報収集
        Dim dataType As String = uctrl.DataTypeLabel
        Dim fileName As String = uctrl.FilePath
        Dim courseType As Integer = uctrl.Category.SelectedValue

        ' パラメタ生成
        Dim serviceParam As CsvImportParameterDto
        serviceParam = CreateParameter(dataType, fileName, courseType)

        ' 取込実行
        Dim model As LectureImportModel = CsvImport(serviceParam)

        ' 処理結果表示用に編集
        Dim result As ImportResultInfo = model.ImportResult
        model.ImportResult = New ImportResultInfo With {
            .ExecutDateStr = DateUtil.EmptyDateToDefaultLong(result.ExecutDate),
            .ExecutCount = NumberUtil.DigitComma(result.ExecutCount),
            .Success = result.Success,
            .StatusString = IIf(result.Success, "状態：正常終了", "状態：異常終了")
        }

        Return model
    End Function

    ''' <summary>
    ''' 実際の取込要求
    ''' </summary>
    ''' <param name="param"></param>
    Public Function CsvImport(ByVal param As CsvImportParameterDto) As LectureImportModel

        ProcessingService.Show(_form, "データ取込中...")

        Dim model As New LectureImportModel
        Dim resultModel As New LectureImportModel

        resultModel = _service.CsvImport(param, model)

        ProcessingService.Close()

        Dim res As CsvImportResultOutputDto

        ' エラー
        If Not resultModel.ImportResult.Success Then
            If resultModel.ImportResult.ErrorType = ImportDataErrorType.DataNotFound Then
                MessageBox.Show(MessageIdConst.MSGID_E3001)
            ElseIf resultModel.ImportResult.ErrorType = ImportDataErrorType.FormatError Then
                MessageBox.Show(MessageIdConst.MSGID_E3002)
            ElseIf resultModel.ImportResult.ErrorType = ImportDataErrorType.DuplicateError Then
                MessageBox.Show(MessageIdConst.MSGID_E3003)
            ElseIf resultModel.ImportResult.ErrorType = ImportDataErrorType.IncludingNonEligible Then
                MessageBox.Show(MessageIdConst.MSGID_E3201)
            ElseIf resultModel.ImportResult.ErrorType = ImportDataErrorType.OnlyNonEligible Then
                MessageBox.Show(MessageIdConst.MSGID_E3202)
            Else
                Dim errorCount As Integer = resultModel.ImportResult.ErrorCount
                If (errorCount > 0) Then
                    Dim factory As New CsvFactory(param.CsvType)
                    Dim frmError As Form = New FrmValidationErrors(resultModel.ImportResult.ValidationResultList, factory.CreateCsv(""))
                    frmError.ShowDialog()
                End If
            End If

            res = CsvImportResultOutputDto.Fail(resultModel.ImportResult.ExecutCount, resultModel.ImportResult.ExecutDate, resultModel.ImportResult.ErrorType)
            resultModel.ImportResult.ExecutDateStr = res.ProcessedAt
            resultModel.ImportResult.ExecutCount = res.ProcessCount
            resultModel.ImportResult.StatusString = res.ProcessMessage
            Return resultModel
        End If

        'DisplayDataEditing(resultModel.ImportResult)
        'Return CsvImportResultOutputDto.Success(result.ExecutCount, result.ExecutDate)
        res = CsvImportResultOutputDto.Success(resultModel.ImportResult.ExecutCount, resultModel.ImportResult.ExecutDate)
        resultModel.ImportResult.ExecutDateStr = res.ProcessedAt
        resultModel.ImportResult.ExecutCount = Res.ProcessCount
        resultModel.ImportResult.StatusString = Res.ProcessMessage

        Return resultModel
    End Function

    ''' <summary>
    ''' 各種CSV取込毎のパラメタ生成
    ''' </summary>
    ''' <param name="dataType"></param>
    ''' <param name="fileName"></param>
    ''' <param name="courseType"></param>
    ''' <returns></returns>
    Private Function CreateParameter(ByVal dataType As String, ByVal fileName As String, ByVal courseType As Integer) As CsvImportParameterDto
        Dim param As New CsvImportParameterDto
        param.TargetDate = AppState.TargetYearMonth

        Try
            Select Case dataType
                Case "打刻データ"
                    param.Phase = LectureFeeConst.PHASE_PUNCHING
                    param.DataType = LectureFeeConst.DATA_PUNCHING
                    param.CourseType = 0
                    param.FilePath = fileName
                    param.CsvType = ImportCsvType.PunchData
                    param.DataName = dataType

                Case "出講データ"
                    param.Phase = LectureFeeConst.PHASE_PLAN
                    param.DataType = LectureFeeConst.DATA_CLASSWORK
                    param.CourseType = 0
                    param.FilePath = fileName
                    param.CsvType = ImportCsvType.LecturePlan
                    param.DataName = dataType

                Case "出講データ（講習）"
                    param.Phase = LectureFeeConst.PHASE_PLAN
                    param.DataType = LectureFeeConst.DATA_CLASSWORK
                    param.CourseType = courseType
                    param.FilePath = fileName
                    param.CsvType = ImportCsvType.LectureCourse
                    param.DataName = dataType

                Case "代講実績データ"
                    param.Phase = LectureFeeConst.PHASE_ACTUAL
                    param.DataType = LectureFeeConst.DATA_CLASSWORK
                    param.CourseType = 99
                    param.FilePath = fileName
                    param.CsvType = ImportCsvType.PinchActual
                    param.DataName = dataType

                Case "業務届データ"
                    param.Phase = LectureFeeConst.PHASE_ACTUAL
                    param.DataType = LectureFeeConst.DATA_REQUEST
                    param.CourseType = 99
                    param.FilePath = fileName
                    param.CsvType = ImportCsvType.RequestActual
                    param.DataName = dataType

                Case "打刻外業務給"
                    param.Phase = LectureFeeConst.PHASE_ACTUAL
                    param.DataType = LectureFeeConst.DATA_REQUEST
                    param.CourseType = 99
                    param.FilePath = fileName
                    param.CsvType = ImportCsvType.RequsttNoPunch
                    param.DataName = dataType
                Case Else
            End Select
        Catch ex As Exception
            MessageBox.Show(Me, "出力失敗！！")
        End Try

        Return param
    End Function

    ''' <summary>
    ''' 画面表示用に処理結果を編集する。
    ''' </summary>
    ''' <param name="dto"></param>
    Public Sub DisplayDataEditing(ByRef dto As ImportResultInfo)
        dto.ExecutDateStr = DateUtil.EmptyDateToDefaultLong(dto.ExecutDate)
        dto.ExecutCount = NumberUtil.DigitComma(dto.ExecutCount)
        dto.Success = dto.Success
        dto.StatusString = IIf(dto.Success, "状態：正常終了", "状態：異常終了")
    End Sub

End Class
