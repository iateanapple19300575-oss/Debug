﻿Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text
Imports Freamwork.Common.Helper
Imports LecturePay.Common.Infrastructure
Imports Nts.Freamwork.Common.Utilities

Public Class FrmDailyCheck
    Inherits BaseForm
    ' CSV出力ファイル名接頭辞
    Private Const EXPORT_FILE_NAME_PREFIX = "時刻パターン"

#Region "プロパティ"

    ' 対象年月度
    Public ReadOnly Property TargetDate() As Date
        Get
            Return AppState.TargetYearMonth
        End Get
    End Property

    ' 初期化処理フラグ(イベント制御用)
    Private Property IsInitializing As Boolean = True


    Private _viewController As New FrmDailyCheckFormController


    ' 画面サービス
    Private displayService As DailyChecksService

    ' カスタムヘッダクラス
    Private CustomDataGridView As DataGridViewCustomHeader

    ' デバッグクラス
    Private DebugUtil = New DebugUtil()

    'Private loader As DataLoader
    Private processingForm As ProcessingForm

    ''' <summary>
    ''' 対象月の月初日
    ''' </summary>
    ''' <returns></returns>
    Private Property MonthFirstDay As Date = DateUtil.FirstDayOfMonth(AppCommon.SystemDate())

    ''' <summary>
    ''' 対象月の月末日
    ''' </summary>
    ''' <returns></returns>
    Private Property MonthLastDay As Date = DateUtil.LastDayOfMonth(AppCommon.SystemDate())

    ''' <summary>
    ''' 基準日
    ''' </summary>
    ''' <returns></returns>
    Private Property CurrentDate As Date

    ''' <summary>
    ''' 表示対象開始日
    ''' </summary>
    ''' <returns></returns>
    Private Property displayStartDate As Date

    ''' <summary>
    ''' 表示対象終了日
    ''' </summary>
    ''' <returns></returns>
    Private Property displayEndDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("打刻確認")
        InitializeComponent()
        FormLogWrapper.WrapFormLifecycle(Me)
        FormLogWrapper.WrapAllEvents(Me)
    End Sub

#End Region

#Region "Windowメインイベント"

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmStampList_Load(sender As Object, e As EventArgs) Handles Me.Load
        EventOff()

        ' 初期表示処理開始
        IsInitializing = True

        'LogLoad()
        Initialize()

        ' 初期表示処理終了
        IsInitializing = False

        DebugUtil.StopwatchStop("Load")

        EventOn()
    End Sub

    Private Sub Initialize()
        CustomDataGridView = New DataGridViewCustomHeader(dgvData)

        ' 対象月情報
        MonthFirstDay = DateUtil.FirstDayOfMonth(AppState.TargetYearMonth)
        MonthLastDay = DateUtil.LastDayOfMonth(AppState.TargetYearMonth)
        CurrentDate = DateClampHelper.Clamp(AppCommon.SystemDate(), MonthFirstDay, MonthLastDay)

        'ProcessingService.RunAsync(Me, AddressOf ShowDay, "処理中...")
        ProcessingService.Show(Me, "処理中...")
        'ShowDay()
        ShowMonth()
        ProcessingService.Close()
    End Sub

    ''' <summary>
    ''' 画面サイズ変更イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmStampList_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        With dgvData
            .Height = Size.Height - dgvData.Top - 60
            .Width = Me.Size.Width - 56
        End With
    End Sub

    ''' <summary>
    ''' DataGridView描画
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub DataGridView1_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles dgvData.CellPainting
        CustomDataGridView.CellPainting(sender, e)
    End Sub

#End Region

#Region "操作イベント"

    ''' <summary>
    ''' [検索]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSaerch_Click(sender As Object, e As EventArgs) Handles btnSaerch.Click
        FilteredSearch()
    End Sub

    ''' <summary>
    ''' [勤怠ステータスフィルター]コンボの選択イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub CmbFilters_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles CmbFilters.SelectionChangeCommitted
        FilteredSearch()
    End Sub

    ''' <summary>
    ''' フィルター検索処理
    ''' </summary>
    Private Sub FilteredSearch()
        MouseCursor.WaitCursor(Me)

        Dim param As New LectureDetailsFindParameter
        param.TargetDate = AppState.TargetYearMonth
        param.SearchStartDate = displayStartDate
        param.SearchEndDate = displayEndDate
        param.RuleId = CmbFilters.SelectedValue
        param.ErrorOnly = chkErrorOnly.Checked
        dgvData.DataSource = _viewController.FilteredSearch(param)

        DisplayResult()


        ' DatGridViewにフィルター条件設定
        'Dim objData As DataTable = CType(dgvData.DataSource, DataTable)
        'If IsNothing(objData) = False Then
        '    Dim objBind As BindingSource
        '    objBind = New BindingSource
        '    objBind.DataSource = objData
        '    objBind.Filter = GetFilterString()
        '    LblDataCount.Text = String.Concat(NumberUtil.DigitComma(objBind.Count), "件")
        '    If (objBind.Count > 0) Then
        '        SetCellBackColor()
        '    End If
        'End If

        ' 再描画(DataGridView反映)
        dgvData.Refresh()

        MouseCursor.DefaultCursor(Me)
    End Sub

#End Region

#Region "内部共通処理"

    ''' <summary>
    ''' 初期表示処理
    ''' </summary>
    Private Sub InitDisplay()

        MouseCursor.WaitCursor(Me)

        ' 画面左上隅に表示
        Me.Height = Screen.PrimaryScreen.WorkingArea.Height
        Me.StartPosition = FormStartPosition.Manual
        Me.Location = New Point(0, 0)

        ' 打刻情報：一覧(データ)表示
        IsInitializing = True
        chkErrorOnly.Checked = True
        dgvData.SuspendLayout()

        ' 選択肢コンボ設定(開始日、終了日、勤怠状況フィルター)
        SetComboStartDay()
        SetComboEndDay()
        SetComboBoxFilters()

        ' 一覧データ取得表示
        'Dim param As New DaoParameter
        'Dim service As New DailyChecksService(TargetDate, dgvData)

        displayStartDate = DateUtil.FirstDayOfMonth(AppState.TargetYearMonth)
        displayEndDate = DateUtil.LastDayOfMonth(AppState.TargetYearMonth)

        Dim param As New LectureDetailsFindParameter
        param.TargetDate = AppState.TargetYearMonth
        param.SearchStartDate = displayStartDate
        param.SearchEndDate = displayEndDate
        param.RuleId = CmbFilters.SelectedValue
        param.ErrorOnly = chkErrorOnly.Checked

        dgvData.DataSource = _viewController.DataLoad(param, dgvData)
        SetCellBackColor()
        'dgvData.Refresh()

        '' 対象件数
        LblDataCount.Text = String.Concat(NumberUtil.DigitComma(dgvData.Rows.Count), "件")

        ' 表示対象期間
        lblStartYearMonth.Text = DateUtil.FormatKanjiYearMonth(displayStartDate)
        lblEndYearMonth.Text = DateUtil.FormatKanjiYearMonth(displayEndDate)
        cmbStartDay.SelectedIndex = displayStartDate.Day - 1
        cmbEndDay.SelectedIndex = displayEndDate.Day - 1
        lblStartYobi.Text = String.Format("日({0})", displayStartDate.ToString("ddd"))
        lblEndYobi.Text = String.Format("日({0})", displayEndDate.ToString("ddd"))

        'chkErrorOnly.Checked = True

        'FilteredSearch()

        'DisplayResult()

        ' 再描画(DataGridView反映)
        dgvData.Refresh()
        dgvData.ResumeLayout()
        IsInitializing = False

        MouseCursor.DefaultCursor(Me)
    End Sub

    ''' <summary>
    ''' フィルタ項目設定
    ''' </summary>
    Private Sub SetComboBoxFilters()
        Dim isErrOnly As Boolean = chkErrorOnly.Checked
        With CmbFilters
            .DataSource = _viewController.FilterComboLoadData(isErrOnly)
            .DisplayMember = "Name"
            .ValueMember = "ID"
            If .Items.Count > 0 Then
                .SelectedIndex = 0
            End If
        End With
    End Sub

    Private Sub SetComboStartDay()
        MonthlyDateSetting(cmbStartDay)
    End Sub

    Private Sub SetComboEndDay()
        MonthlyDateSetting(cmbEndDay)
    End Sub

    Private Sub MonthlyDateSetting(ByRef cmb As ComboBox)
        Dim lastDay As Integer = DateUtil.LastDayOfMonth(AppState.TargetYearMonth).Day
        cmb.Items.Clear()
        For i As Integer = 1 To lastDay
            cmb.Items.Add(i.ToString("D2"))
        Next
    End Sub

    ''' <summary>
    ''' ヘッダ行のカスタマイズ設定（セル連結）
    ''' </summary>
    Private Sub CustomHeaderInitializ()
        ' 単一結合カラム名
        CustomDataGridView.SingleHeaderAdd(0, 2, "講師")
        CustomDataGridView.SingleHeaderAdd(1, 2, "講師名")
        CustomDataGridView.SingleHeaderAdd(2, 2, "日付")
        CustomDataGridView.SingleHeaderAdd(3, 2, "区分")
        CustomDataGridView.SingleHeaderAdd(4, 2, "状態")
        CustomDataGridView.SingleHeaderAdd(9, 2, "打刻回数")
        ' 複数連結カラム名
        CustomDataGridView.HeaderGroupAdd(5, 2, "ジョブカン")
        CustomDataGridView.HeaderGroupAdd(7, 2, "出講・業務予定")
        ' 各カラム名
        CustomDataGridView.HeaderColumnAdd(0, "講師ｺｰﾄﾞ")
        CustomDataGridView.HeaderColumnAdd(1, "講師名")
        CustomDataGridView.HeaderColumnAdd(2, "日付")
        CustomDataGridView.HeaderColumnAdd(3, "区分")
        CustomDataGridView.HeaderColumnAdd(4, "状態")
        CustomDataGridView.HeaderColumnAdd(5, "出勤")
        CustomDataGridView.HeaderColumnAdd(6, "退勤")
        CustomDataGridView.HeaderColumnAdd(7, "開始")
        CustomDataGridView.HeaderColumnAdd(8, "終了")
        CustomDataGridView.HeaderColumnAdd(9, "打刻回数")
    End Sub

    ''' <summary>
    ''' セルの背景色設定
    ''' </summary>
    Private Sub SetCellBackColor()
#If 0 Then

        ' 打刻関連エラーセルの背景色設定
        With dgvData
            ' 打刻時間(出勤、退勤)、実績時間(開始、終了)と対応する背景色情報列番号のDICTIONARY作成
            Dim dic As New Dictionary(Of Integer, Integer)
            dic.Add(.Columns(DailyCheckColumnsConst.PUNCH_START_TIME).Index, .Columns(DailyCheckColumnsConst.PUNCH_START_COLOR).Index)
            dic.Add(.Columns(DailyCheckColumnsConst.PUNCH_END_TIME).Index, .Columns(DailyCheckColumnsConst.PUNCH_END_COLOR).Index)

            ' 背景色の設定
            For colIndex As Integer = 0 To .Columns.Count - 1
                If (dic.ContainsKey(colIndex)) Then
                    For rowIndex As Integer = 0 To .Rows.Count - 1
                        Dim colorColumn As Integer = dic(colIndex)
                        Dim objColor As Object = .Rows(rowIndex).Cells(colorColumn).Value
                        Dim colorStr As String = IIf(IsDBNull(objColor), "", objColor)
                        If Not String.IsNullOrEmpty(colorStr) Then
                            .Rows(rowIndex).Cells(colIndex).Style.BackColor = Color.FromName(colorStr)
                        End If
                    Next
                End If
            Next
        End With
#End If

        ' 日付(土日)の文字色設定
        With dgvData
            ' 日付色列の列番号取得
            Dim colorColumn As Integer = .Columns("DateKey").Index
            ' 日付の文字色設定
            For rowIndex As Integer = 0 To .Rows.Count - 1
                Dim objColor As Object = .Rows(rowIndex).Cells(colorColumn).Value
                Dim colorStr As String = IIf(IsDBNull(objColor), "", objColor)
                If Not String.IsNullOrEmpty(colorStr) Then
                    .Rows(rowIndex).Cells(.Columns("DateStr").Index).Style.ForeColor = Color.FromName(colorStr)
                End If
            Next
        End With
    End Sub


#End Region


    Private Function GetFilterString() As String
        ' 勤怠状態
        Dim filterItem As String = CmbFilters.SelectedItem.ToString()
        Dim levelEnable As Boolean = chkErrorOnly.Checked

        Dim filterExpession As String = ""
        If chkErrorOnly.Checked Then
            filterExpession = "StatusLevel LIKE '*エラー*' "
        End If

        If Not filterExpession = "" Then
            filterExpession &= " AND "
        End If

        If filterItem = "全て" Then
            filterExpession &= "StatusStr IS NOT NULL AND StatusStr <> ''"
        Else
            filterExpession &= "StatusStr LIKE '*" & filterItem & "*'"
        End If

        ' 期間指定
        Dim startDateStr As String = DateUtil.DateStringFormat(AppState.TargetYearMonth, "yyyyMM") & cmbStartDay.SelectedItem
        Dim endDateStr As String = DateUtil.DateStringFormat(AppState.TargetYearMonth, "yyyyMM") & cmbEndDay.SelectedItem
        If StringUtil.IsNotNullOrWhiteSpace(filterExpession) Then
            filterExpession &= " AND "
        End If
        filterExpession &= "[DateKey] >= " & startDateStr & " AND [DateKey] <= " & endDateStr

        Return filterExpession
    End Function

#Region "表示切り替えボタン処理とボタン活性／非活性制御関連"

    ''' <summary>
    ''' 前の日ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnPrevDay_Click(sender As Object, e As EventArgs) Handles btnPrevDay.Click
        CurrentDate = DateClampHelper.Clamp(displayStartDate.AddDays(-1), MonthFirstDay, MonthLastDay)
        ShowDay()
    End Sub

    ''' <summary>
    ''' 次の日ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnNexDay_Click(sender As Object, e As EventArgs) Handles btnNexDay.Click
        CurrentDate = DateClampHelper.Clamp(displayEndDate.AddDays(1), MonthFirstDay, MonthLastDay)
        ShowDay()
    End Sub

    ''' <summary>
    ''' 前の週ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnPrevWeek_Click(sender As Object, e As EventArgs) Handles btnPrevWeek.Click
        CurrentDate = DateClampHelper.Clamp(displayStartDate.AddDays(-7), MonthFirstDay, MonthLastDay)
        ShowWeek()
    End Sub

    ''' <summary>
    ''' 次の週ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnNextWeek_Click(sender As Object, e As EventArgs) Handles btnNextWeek.Click
        CurrentDate = DateClampHelper.Clamp(displayStartDate.AddDays(7), MonthFirstDay, MonthLastDay)
        ShowWeek()
    End Sub

    ''' <summary>
    ''' 今日のボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnToday_Click(sender As Object, e As EventArgs) Handles btnToday.Click
        CurrentDate = DateClampHelper.Clamp(AppCommon.SystemDate, MonthFirstDay, MonthLastDay)
        ShowDay()
    End Sub

    ''' <summary>
    ''' 日単位の表示
    ''' </summary>
    Private Sub ShowDay()
        ShowDisplay(New DayRange())
    End Sub

    ''' <summary>
    ''' 週単位の表示
    ''' </summary>
    Private Sub ShowWeek()
        ShowDisplay(New WeekRange())
    End Sub

    ''' <summary>
    ''' 月単位の表示
    ''' </summary>
    Private Sub ShowMonth()
        ShowDisplay(New MonthRange())
    End Sub

    ''' <summary>
    ''' 表示切替処理
    ''' </summary>
    ''' <param name="strategy"></param>
    Private Sub ShowDisplay(ByVal strategy As IDataRange)
        ProcessingService.Show(Me, "処理中...")

        Try
            ' 期間表示
            Dim range = strategy.GetRange(CurrentDate, MonthFirstDay, MonthLastDay)
            displayStartDate = range.FromDate
            displayEndDate = range.ToDate

            ' データ表示
            'loader.Loader(range, dgvData, lblDate)
            InitDisplay()
            CustomHeaderInitializ()

            ' ボタン表示制御
            UpdateButtons()

        Catch ex As Exception

        Finally
            ProcessingService.Close()

        End Try

    End Sub

    ''' <summary>
    ''' ボタン活性／非活性表示更新
    ''' </summary>
    Private Sub UpdateButtons()
        ' 前日ボタン
        btnPrevDay.Enabled = displayStartDate.AddDays(-1) >= MonthFirstDay
        ' 翌日ボタン
        btnNexDay.Enabled = displayEndDate.AddDays(1) <= MonthLastDay
        ' 前週ボタン
        Dim prevWeekMonday = displayStartDate.AddDays(-7 - (Weekday(displayStartDate, FirstDayOfWeek.Monday) - 1))
        Dim prevWeekSunday = prevWeekMonday.AddDays(6)
        btnPrevWeek.Enabled = prevWeekSunday >= MonthFirstDay
        ' 翌週ボタン
        Dim nextWeekMonday = displayStartDate.AddDays(7 - (Weekday(displayStartDate, FirstDayOfWeek.Monday) - 1))
        Dim nextWeekSunday = nextWeekMonday.AddDays(6)
        btnNextWeek.Enabled = nextWeekMonday <= MonthLastDay
    End Sub

    ''' <summary>
    ''' 一覧ダブルクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub dgvData_DoubleClick(sender As Object, e As EventArgs) Handles dgvData.DoubleClick
        Try
            If dgvData.SelectedRows.Count > 0 Then
                ' 選択行のDataRowを取得
                Dim drv As DataRowView = TryCast(dgvData.SelectedRows(0).DataBoundItem, DataRowView)
                If drv IsNot Nothing Then
                    Dim row As DataRow = drv.Row
                    Dim param As New DaoParameter()
                    param.LectureDate = row("Lecture_Date").ToString().Substring(0, 10)
                    param.TeacherCode = row("Teacher_Code").ToString()
                    param.TargetDate = AppState.TargetYearMonth
                    Dim frm As New FrmDailyAttendanceStatement(param)
                    frm.ShowDialog()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("エラー: " & ex.Message)
        End Try
    End Sub

    Private Sub dgvData_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvData.CellFormatting
        If IsTimeFormat(dgvData.Columns(e.ColumnIndex).Name) AndAlso e.Value IsNot Nothing Then
            Dim dateValue As DateTime
            If DateTime.TryParse(e.Value.ToString(), dateValue) Then
                e.Value = dateValue.ToString("HH:mm")
                e.FormattingApplied = True ' 書式適用済みをマーク
            End If
        End If
    End Sub

    ''' <summary>
    ''' 時間( HH:mm)フォーマット項目判定
    ''' </summary>
    ''' <param name="colName"></param>
    ''' <returns></returns>
    Private Function IsTimeFormat(ByVal colName As String) As Boolean
        Dim timeFields As String() = {"Punch_Start_Time", "Punch_End_Time", "Work_Start_Time", "Work_End_Time"}
        Return timeFields.Contains(colName)
    End Function

#End Region

#Region "EXCEL出力関連"

    ''' <summary>
    ''' EXCEL出力
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExcel_Click(sender As Object, e As EventArgs) Handles btnExcel.Click

        MouseCursor.WaitCursor(Me)

        Try

            ' デフォルトファイル名生成
            Dim defFileName As String =
                lblStartYearMonth.Text & cmbStartDay.Text & "日" &
                "～" &
                lblEndYearMonth.Text & cmbEndDay.Text & "日" & "打刻チェック一覧" &
                "_" & Now.ToString("yyyyMMdd_HHmmss") & ".xlsx"

            MouseCursor.DefaultCursor(Me)

            ' 4. 保存ダイアログでExcel形式に保存
            Using sfd As New SaveFileDialog()
                sfd.Filter = "Excelファイル (*.xlsx)|*.xlsx"
                sfd.FileName = defFileName
                If sfd.ShowDialog() = DialogResult.OK Then
                    MouseCursor.WaitCursor(Me)
                    ExcelOutput(sfd.FileName)
                    MouseCursor.DefaultCursor(Me)
                    MessageBox.Show("Excel形式で保存しました。", "完了", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End Using

        Catch ex As Exception
            MessageBox.Show("エクスポート中にエラーが発生しました: " & ex.Message,
                            "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            MouseCursor.DefaultCursor(Me)
        End Try
    End Sub

    ''' <summary>
    ''' DataGridView表示データEXCELに保存します。
    ''' </summary>
    Private Sub ExcelOutput(ByVal fileName As String)
        Dim excelApp As Excel.Application = Nothing
        Dim workbook As Excel.Workbook = Nothing
        Dim workSheet As Excel.Worksheet = Nothing

        Try
            ' 一時CSVファイルパス
            Dim tempCsvPath As String = Path.Combine(Path.GetTempPath(), "temp_export.csv")

            ' デフォルトファイル名生成
            Dim defFileName As String =
                lblStartYearMonth.Text & cmbStartDay.Text & "日" &
                "～" &
                lblEndYearMonth.Text & cmbEndDay.Text & "日" & "打刻チェック一覧" &
                "_" & Now.ToString("yyyyMMdd_HHmmss") & ".xlsx"

            ' 1. DataGridView → CSV出力
            ExportDataGridViewToCsv(dgvData, tempCsvPath)

            ' 2. Excelの起動
            excelApp = New Excel.Application
            excelApp.Visible = False ' 画面を非表示に設定
            excelApp.DisplayAlerts = False ' アラートを非表示にする
            excelApp.Visible = False
            excelApp.WindowState = Excel.XlWindowState.xlMinimized

            ' 3. ExcelでCSVを開く
            workbook = excelApp.Workbooks.Open(tempCsvPath)
            workSheet = CType(workbook.Sheets(1), Excel.Worksheet)
            workSheet.Columns.AutoFit()
            workbook.SaveAs(fileName, Excel.XlFileFormat.xlOpenXMLWorkbook)

        Catch ex As Exception
            MessageBox.Show("EXCEL保存中にエラーが発生しました: " & ex.Message,
                            "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If workbook IsNot Nothing Then
                workbook.Close()
                Marshal.ReleaseComObject(workbook)
            End If

            If workSheet IsNot Nothing Then
                Marshal.ReleaseComObject(workSheet)
            End If

            If excelApp IsNot Nothing Then
                excelApp.Visible = True
                excelApp.Quit()
                Marshal.ReleaseComObject(excelApp)
            End If

            GC.Collect()
            GC.WaitForPendingFinalizers()
            GC.Collect()
            GC.WaitForPendingFinalizers()
        End Try
    End Sub

    ''' <summary>
    ''' DataGridViewの表示中データを列ヘッダ付きでCSV出力（非表示列は除外）
    ''' </summary>
    Private Sub ExportDataGridViewToCsv(dgv As DataGridView, filePath As String)
        Dim sb As New StringBuilder()

        ' ヘッダ行
        Dim headerValues As New List(Of String)
        For Each col As DataGridViewColumn In dgv.Columns
            If col.Visible Then
                headerValues.Add(EscapeCsv(col.HeaderText))
            End If
        Next
        sb.AppendLine(String.Join(",", headerValues.ToArray))

        ' データ行
        Dim colValue As String = ""
        For Each row As DataGridViewRow In dgv.Rows
            If Not row.IsNewRow Then
                Dim cellValues As New List(Of String)
                For Each col As DataGridViewColumn In dgv.Columns
                    If col.Visible Then
                        If col.ValueType.Name = "TimeSpan" Then
                            colValue = If(row.Cells(col.Index).Value, "").ToString().PadRight(5)
                            cellValues.Add(EscapeCsv(colValue.Substring(0, 5)))
                        Else
                            cellValues.Add(EscapeCsv(If(row.Cells(col.Index).Value, "").ToString()))
                        End If
                    End If
                Next
                sb.AppendLine(String.Join(",", cellValues.ToArray))
            End If
        Next

        File.WriteAllText(filePath, sb.ToString(), New UTF8Encoding(True))
    End Sub

    ''' <summary>
    ''' CSV用エスケープ処理
    ''' </summary>
    Private Function EscapeCsv(value As String) As String
        If value.Contains("""") Then
            value = value.Replace("""", """""")
        End If
        If value.Contains(",") OrElse value.Contains(vbCr) OrElse value.Contains(vbLf) Then
            value = $"""{value}"""
        End If
        Return value
    End Function

    Private Sub chkErrorOnly_CheckedChanged(sender As Object, e As EventArgs) Handles chkErrorOnly.CheckedChanged
        MouseCursor.WaitCursor(Me)

        SetComboBoxFilters()
        FilteredSearch()

        MouseCursor.DefaultCursor(Me)
    End Sub

#End Region

    ''' <summary>
    ''' 結果表示
    ''' </summary>
    Private Sub DisplayResult()

        ' 対象件数
        LblDataCount.Text = String.Concat(NumberUtil.DigitComma(dgvData.Rows.Count), "件")

        ' 表示対象期間
        lblStartYearMonth.Text = DateUtil.FormatKanjiYearMonth(displayStartDate)
        lblEndYearMonth.Text = DateUtil.FormatKanjiYearMonth(displayEndDate)
        cmbStartDay.SelectedIndex = displayStartDate.Day - 1
        cmbEndDay.SelectedIndex = displayEndDate.Day - 1
        lblStartYobi.Text = String.Format("日({0})", displayStartDate.ToString("ddd"))
        lblEndYobi.Text = String.Format("日({0})", displayEndDate.ToString("ddd"))

    End Sub

    ''' <summary>
    ''' イベント抑止
    ''' </summary>
    Private Sub EventOff()
        RemoveHandler chkErrorOnly.CheckedChanged, AddressOf chkErrorOnly_CheckedChanged
        RemoveHandler CmbFilters.SelectionChangeCommitted, AddressOf CmbFilters_SelectionChangeCommitted
    End Sub

    ''' <summary>
    ''' イベント発生
    ''' </summary>
    Private Sub EventOn()
        AddHandler chkErrorOnly.CheckedChanged, AddressOf chkErrorOnly_CheckedChanged
        AddHandler CmbFilters.SelectionChangeCommitted, AddressOf CmbFilters_SelectionChangeCommitted
    End Sub

    Private Sub cmbStartDay_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbStartDay.SelectionChangeCommitted
        Dim stDate As New Date(AppState.TargetYearMonth.Year, AppState.TargetYearMonth.Month, cmbStartDay.SelectedIndex + 1)
        displayStartDate = stDate
        lblStartYobi.Text = String.Format("日({0})", displayStartDate.ToString("ddd"))
    End Sub

    Private Sub cmbEndDay_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbEndDay.SelectionChangeCommitted
        Dim edDate As New Date(AppState.TargetYearMonth.Year, AppState.TargetYearMonth.Month, cmbEndDay.SelectedIndex + 1)
        displayEndDate = edDate
        lblEndYobi.Text = String.Format("日({0})", displayEndDate.ToString("ddd"))
    End Sub
End Class