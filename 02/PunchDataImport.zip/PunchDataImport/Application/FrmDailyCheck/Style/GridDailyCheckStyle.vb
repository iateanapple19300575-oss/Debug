﻿Public Class GridDailyCheckStyle
    Implements IGridColumnDefinition

    ''' <summary>
    ''' 打刻忘れの一覧に必要な列定義を作成し、指定された DataGridView に適用する。
    ''' </summary>
    ''' <param name="grid"></param>
    Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 打刻忘れ一覧の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("Teacher_Code", "講師", 70).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Teacher_Name", "講師名", 120).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("DateStr", "日付", 140).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("StatusLevel", "区分", 60).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("StatusStr", "状態", 260).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Punch_Start_Time", "出勤", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Format("HH:mm").
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Punch_End_Time", "退勤", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Format("HH:mm").
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Work_Start_Time", "開始", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Format("HH:mm").
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Work_End_Time", "終了", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Format("HH:mm").
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Number_Of_Punched", "打刻回数", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("DateKey", "日付KEY", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Hide.
                Build(),
            New GridColumnBuilder("DateColor", "日付色", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Hide.
                Build(),
            New GridColumnBuilder("打出勤色", "打出勤色", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Hide.
                Build(),
            New GridColumnBuilder("打退勤色", "打退勤色", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Hide.
                Build(),
            New GridColumnBuilder("実出勤色", "実出勤色", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Hide.
                Build(),
            New GridColumnBuilder("実退勤色", "実退勤色", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Hide.
                Build()
        }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
        grid.AutoGenerateColumns = False

        ' 列定義を DataGridView に追加
        For Each def In defs
            grid.Columns.Add(GridColumnFactory.Create(def))
        Next

    End Sub
End Class
