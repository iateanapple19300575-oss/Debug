﻿Imports MainApp.Data.Dto

''' <summary>
''' 打刻状況画面用サービスクラス
''' </summary>
Public Class DailyChecksService

    ''' <summary>
    ''' Domainサービス
    ''' </summary>
    Private _domain As New DailyCheckDomain

    ''' <summary>
    ''' 打刻一覧取得
    ''' </summary>
    Private _punchCheckRepository As New FrmAttentionCheckRepository

    ''' <summary>
    ''' 打刻状況LIST
    ''' </summary>
    Private _modelList As New List(Of AttendanceModel)



    ''' <summary>
    ''' 表示データ取得クエリ取得
    ''' </summary>
    ''' <returns>表示データ取得クエリ</returns>
    Public Function DataLoad(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable
        Dim _attendanceDomain As New AttendanceDomain
        Try
            Using uow As New DbTransactionScope()
                _attendanceDomain = New AttendanceDomain(uow)
                dataList = _attendanceDomain.LoadData(param)
                modelList = _attendanceDomain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)
                _modelList = modelList

                'dt = _attendanceDomain.WorkListToDataTable(modelList)

                dt = _domain.FilteredSearch(param, modelList)
            End Using

        Catch ex As Exception

        End Try

        Return dt
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function FilteredSearch(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            modelList = _modelList

            'modelList = _domain.AttendanceAnalysis(dataList)
            'Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
            'vDaily.Validate(modelList)
            '    _modelList = modelList

            dt = _domain.FilteredSearch(param, modelList)

        Catch ex As Exception

        End Try

        Return dt
    End Function



End Class
