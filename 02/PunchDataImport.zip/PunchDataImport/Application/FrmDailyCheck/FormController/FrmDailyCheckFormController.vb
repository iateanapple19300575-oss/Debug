﻿Imports MainApp.Data.Dto

Public Class FrmDailyCheckFormController
    Private _service As New DailyChecksService
    'Private _service As New AttendanceService

    Public Function DataLoad(ByRef param As LectureDetailsFindParameter, ByRef dgv As DataGridView) As DataTable
        Dim def As New GridDailyCheckStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.ApplyCustom(dgv)

        'Dim param As New LectureDetailsFindParameter
        param.TargetDate = AppState.TargetYearMonth
        Dim dt As DataTable = _service.DataLoad(param)

        Return dt
    End Function

    ''' <summary>
    ''' フィルター検索
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function FilteredSearch(ByRef param As LectureDetailsFindParameter) As DataTable

        param.TargetDate = AppState.TargetYearMonth
        Dim dt As DataTable = _service.FilteredSearch(param)

        Return dt
    End Function

    ''' <summary>
    ''' 状態フィルター
    ''' </summary>
    Public Function FilterComboLoadData(ByVal isErrOnly As Boolean) As DataTable
        Dim cmbDataList(,) As String = {
                {"", "すべて"},
                {"D1020", "打刻なし(退勤)"},
                {"D1030", "打刻なし(出勤・退勤)"},
                {"D1040", "時間重複(ジョブカン打刻・打刻外業務給)"},
                {"D1050", "時間重複(複数授業)"},
                {"D1060", "講師単価未登録"},
                {"D2010", "時間重複(授業時間・業務届)"},
                {"D2020", "交通費未登録区間あり"},
                {"D2030", "授業遅刻"},
                {"D2040", "授業早退"},
                {"D2050", "出勤早"},
                {"D2060", "退勤遅"},
                {"D2070", "出講・業務届なし"},
                {"D2080", "打刻回数3回以上"},
                {"D3010", "休憩発生"},
                {"D3020", "深夜勤務発生"},
                {"D3030", "残業手当発生"},
                {"D3040", "授業給係数発生"}
            }

        ' DataTableインスタンス化
        Dim dt As New DataTable

        ' 列の定義 (列名, 型)
        dt.Columns.Add("ID", GetType(String))
        dt.Columns.Add("Name", GetType(String))

        ' データ行追加
        If isErrOnly Then
            For i As Integer = 0 To cmbDataList.GetUpperBound(0)
                If cmbDataList(i, 0) <> "" AndAlso cmbDataList(i, 0).Substring(0, 2) <> "D1" Then
                    Continue For
                End If
                dt.Rows.Add(cmbDataList(i, 0), cmbDataList(i, 1))
            Next
        Else
            For i As Integer = 0 To cmbDataList.GetUpperBound(0)
                dt.Rows.Add(cmbDataList(i, 0), cmbDataList(i, 1))
            Next
        End If

        Return dt
    End Function


End Class
