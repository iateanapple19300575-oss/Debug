﻿Imports Freamwork.Common.Helper
Imports Nts.Freamwork.Common.Utilities
Imports UserControl

''' <summary>
''' [勤怠データ確認]画面クラス
''' </summary>
Public Class FrmCheckAttendanceData
    Inherits BaseForm

    ' [勤怠データ確認]画面サービス
    Private service As New FrmAttentionCheckService


    ' 出力情報の種別（タイトルと[確認]ボタン表示制御）
    Private ReadOnly DataTypes As String(,) = {
      {"出講料チェックリスト", "False"},
      {"出講料アテンション", "True"}
    }

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New("勤怠データ確認")
        InitializeComponent()
        FormLogWrapper.WrapFormLifecycle(Me)
        FormLogWrapper.WrapAllEvents(Me)
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmCheckAttendanceData_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' 画面初期表示
        InitDisplay()
    End Sub

    ''' <summary>
    ''' 画面初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        ' FlowLayoutPanelの属性設定
        flpRows.FlowDirection = FlowDirection.TopDown
        flpRows.WrapContents = False
        flpRows.AutoScroll = True

        For i As Integer = 0 To DataTypes.GetLength(0) - 1
            ' [確認]ボタン表示制御（True:表示／False:非表示）
            Dim display As Boolean = DataTypes(i, 1) = "True"
            Dim row As New ExportRowControl(i, display)

            ' 対象データのタイトル名設定
            row.DataTypeLabel = DataTypes(i, 0)

            ' ユーザコントロールからのイベント処理
            AddHandler row.BrowseClicked, AddressOf OnBrowseClicked
            AddHandler row.ExportRequested, AddressOf OnExportRequested
            AddHandler row.DisplayRequested, AddressOf OnDisplayRequested

            ' FlowLayoutPanelに登録
            flpRows.Controls.Add(row)
        Next
    End Sub

    ''' <summary>
    ''' [参照]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="filePath"></param>
    Private Sub OnBrowseClicked(sender As Object, filePath As String)
        Dim fileTitles As New List(Of String)({"出講料チェックリスト", "出講料アテンションリスト"})
        Dim id = DirectCast(sender, ExportRowControl).Id

        ' デフォルトファイル名生成
        Dim targetDate As Date = AppState.TargetYearMonth
        Dim fileName As String = fileTitles(id) & "(" & targetDate.Year & "年" & targetDate.Month & "月分)" & "_" & Now().ToString("yyyyMMdd_HHmm") & ".xlsx"

        ' 保存ファイルダイアログ表示
        Dim folderPath As String = System.Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
        Dim savePath As String = FileDialog.SaveFileForExcel(fileName, folderPath)

        ' 指定パスを表示
        If StringUtil.IsNotNullOrWhiteSpace(savePath) Then
            DirectCast(sender, ExportRowControl).FilePath = savePath
        End If
    End Sub

    ''' <summary>
    ''' [出力]押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="filePath"></param>
    Private Sub OnExportRequested(sender As Object, filePath As String)

        Select Case DirectCast(sender, ExportRowControl).Id
            Case 0
                CheckListExport(filePath)
            Case 1
                AttentionExport(filePath)
            Case Else
        End Select

    End Sub

    ''' <summary>
    ''' [確認]ボタン押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    Private Sub OnDisplayRequested(sender As Object)
        Dim frm As New FrmAttentionCheck
        frm.ShowDialog()
    End Sub

    ''' <summary>
    ''' 出講料チェックリストの[出力]処理
    ''' </summary>
    Private Sub CheckListExport(ByVal filePath As String)
        MouseCursor.WaitCursor(Me)

        ' EXCEL出力処理
        Dim resultData As ResultData = service.ExportForLecturePunch(AppState.TargetYearMonth, filePath)

        MouseCursor.DefaultCursor(Me)

        ' 処理結果メッセージ表示
        Dim message As String = MessageIdConst.MSGID_I2001
        If (Not resultData.Success) Then
            MessageBox.Show(MessageIdConst.MSGID_E2001)
        End If

        MessageBox.Show(message)
    End Sub

    ''' <summary>
    ''' 出講料アテンションの[出力]処理
    ''' </summary>
    Private Sub AttentionExport(ByVal filePath As String)
        MouseCursor.WaitCursor(Me)

        ' EXCEL出力処理
        Dim resultData As ResultData = service.ExportForLectureAttention(AppState.TargetYearMonth, filePath)

        MouseCursor.DefaultCursor(Me)

        ' 処理結果メッセージ表示
        Dim message As String = MessageIdConst.MSGID_I2001
        If (Not resultData.Success) Then
            MessageBox.Show(MessageIdConst.MSGID_E2001)
        End If

        MessageBox.Show(message)
    End Sub
End Class