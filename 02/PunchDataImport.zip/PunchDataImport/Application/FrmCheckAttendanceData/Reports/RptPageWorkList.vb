﻿Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 勤怠状況チェックシート出力
''' </summary>
Public Class RptPageWorkList
    Inherits VBReportPage

#Region "[定数]"

    ' ページタイトル名
    Private Const REPORT_PAGE_NAME As String = "勤怠状況チェックシート（{0}年{1}月度）"

    ' ページタイトルの変数名
    Private Const REPORT_SHEET_NAME As String = "CHECK_LIST"

    ' ページタイトル出力項目の変数
    Private Const REPORT_CELL_TITLE As String = "**TITLE"

    ' 出力項目変数
    Private Const FMT_CELL_TEACHER_CODE As String = "**TeacherCode"
    Private Const FMT_CELL_TEACHER_NAME As String = "**TeacherName"
    Private Const FMT_CELL_WORKING_DAY As String = "**WorkingDay"
    Private Const FMT_CELL_STATUS As String = "**Status"
    Private Const FMT_CELL_ST_JOBKAN As String = "**St_Jobkan"
    Private Const FMT_CELL_ED_JOBKAN As String = "**Ed_Jobkan"
    Private Const FMT_CELL_ST_MINASHI As String = "**St_Minashi"
    Private Const FMT_CELL_ED_MINASHI As String = "**Ed_Minashi"
    Private Const FMT_CELL_ST_ACTUAL As String = "**St_Actual"
    Private Const FMT_CELL_ED_ACTUAL As String = "**Ed_Actual"
    Private Const FMT_CELL_ST_REQUEST As String = "**St_Request"
    Private Const FMT_CELL_ED_REQUEST As String = "**Ed_Request"

    ' 基本セル書式参照セル
    Private Const ATTR_CELL_TEACHER_CODE As String = "B6"
    Private Const ATTR_CELL_TEACHER_NAME As String = "C6"
    Private Const ATTR_CELL_WORKING_DAY As String = "D6"
    Private Const ATTR_CELL_STATUS As String = "E6"
    Private Const ATTR_CELL_ST_JOBKAN As String = "F6"
    Private Const ATTR_CELL_ED_JOBKAN As String = "G6"
    Private Const ATTR_CELL_ST_MINASHI As String = "H6"
    Private Const ATTR_CELL_ED_MINASHI As String = "I6"
    Private Const ATTR_CELL_ST_ACTUAL As String = "J6"
    Private Const ATTR_CELL_ED_ACTUAL As String = "K6"
    Private Const ATTR_CELL_ST_REQUEST As String = "L6"
    Private Const ATTR_CELL_ED_REQUEST As String = "M6"

    ' 出力項目対応テーブル項目名
    Private Const SQL_COL_TEACHER_CODE As String = "Teacher_Code"
    Private Const SQL_COL_TEACHER_NAME As String = "Teacher_Name"
    Private Const SQL_COL_WORKING_DAY As String = "Lecture_Date"
    Private Const SQL_COL_STATUS As String = "StatusStr"
    Private Const SQL_COL_ST_JOBKAN As String = "Punch_Start_Time"
    Private Const SQL_COL_ED_JOBKAN As String = "Punch_End_Time"
    Private Const SQL_COL_ST_MINASHI As String = "Deemed_Start_Time"
    Private Const SQL_COL_ED_MINASHI As String = "Deemed_End_Time"
    Private Const SQL_COL_ST_ACTUAL As String = "Lecture_Start"
    Private Const SQL_COL_ED_ACTUAL As String = "Lecture_End"
    Private Const SQL_COL_ST_REQUEST As String = "Task_Start"
    Private Const SQL_COL_ED_REQUEST As String = "Task_End"
    Private Const SQL_COL_ST_PLAN As String = "開始(予定)"
    Private Const SQL_COL_ED_PLAN As String = "終了(予定)"

    Private Const SQL_COL_ROOM As String = "ASiteCode"
    Private Const SQL_COL_GRADE As String = "AGrade"
    Private Const SQL_COL_CLASS As String = "AClassCode"
    Private Const SQL_COL_KOMA As String = "AKomaSeq"
    Private Const SQL_COL_ST_TIME As String = "AStartTime"
    Private Const SQL_COL_ED_TIME As String = "AEndTime"
    Private Const SQL_COL_PINCH As String = "APinchType"

    ' 一覧の先頭セル(列)
    Private Const CELL_COL_OFFSET As Integer = 17

    ' 一覧の先頭セル(行)
    Private Const CELL_ROW_OFFSET As Integer = 6

#End Region

#Region "[プロパティ]"

    ''' <summary>
    ''' ページタイトルセル
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageTitleCell As String
        Get
            Return REPORT_CELL_TITLE
        End Get
    End Property

    ''' <summary>
    ''' ページタイトル名
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageTitleName As String
        Get
            Return REPORT_PAGE_NAME
        End Get
    End Property

    ''' <summary>
    ''' シート名
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageSheetName As String
        Get
            Return REPORT_SHEET_NAME
        End Get
    End Property

#End Region

#Region "[メソッド]"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    Public Sub New(ByVal targetDate As Date)
        MyBase.New(targetDate)
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    Public Sub New(ByVal targetDate As Date, ByVal reportSourceDataTable As DataTable)
        MyBase.New(targetDate, reportSourceDataTable)
    End Sub

    ''' <summary>
    ''' 初期設定
    ''' </summary>
    Public Overrides Sub InitialSetup()
        m_PageName = String.Format(REPORT_PAGE_NAME, Year(MyBase.TargetDate), Month(MyBase.TargetDate))
        m_SheetName = REPORT_SHEET_NAME
    End Sub

    ''' <summary>
    ''' 出力データ取得クエリ
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function ReportQuery() As String
        Return StampListQuery.SelectSql(MyBase.TargetDate)
    End Function

    ''' <summary>
    ''' ページデータ出力
    ''' </summary>
    Public Overrides Sub PageOutput()
        OutputDetail(ReportSourceDataTable)
    End Sub

    ''' <summary>
    ''' 明細出力
    ''' </summary>
    ''' <param name="dtTable"></param>
    Public Overrides Sub OutputDetail(ByVal dtTable As DataTable)
        Dim cellUtil As New CellReportUtil(m_CellReport)
        Dim rowNo As Integer = 0

        Try

            For Each row As DataRow In dtTable.Rows
                With m_CellReport
                    cellUtil.CellValue(FMT_CELL_TEACHER_CODE, 0, rowNo, GetValue(row(SQL_COL_TEACHER_CODE)), ATTR_CELL_TEACHER_CODE)
                    cellUtil.CellValue(FMT_CELL_TEACHER_NAME, 0, rowNo, GetValue(row(SQL_COL_TEACHER_NAME)), ATTR_CELL_TEACHER_NAME)
                    cellUtil.CellValueDateFormat(FMT_CELL_WORKING_DAY, 0, rowNo, GetValue(row(SQL_COL_WORKING_DAY)), ATTR_CELL_WORKING_DAY)
                    cellUtil.CellValue(FMT_CELL_STATUS, 0, rowNo, GetValue(row(SQL_COL_STATUS)), ATTR_CELL_STATUS)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ST_JOBKAN, 0, rowNo, GetValue(row(SQL_COL_ST_JOBKAN)), ATTR_CELL_ST_JOBKAN)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ED_JOBKAN, 0, rowNo, GetValue(row(SQL_COL_ED_JOBKAN)), ATTR_CELL_ED_JOBKAN)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ST_MINASHI, 0, rowNo, GetValue(row(SQL_COL_ST_MINASHI)), ATTR_CELL_ST_MINASHI)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ED_MINASHI, 0, rowNo, GetValue(row(SQL_COL_ED_MINASHI)), ATTR_CELL_ED_MINASHI)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ST_ACTUAL, 0, rowNo, GetValue(row(SQL_COL_ST_ACTUAL)), ATTR_CELL_ST_ACTUAL)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ED_ACTUAL, 0, rowNo, GetValue(row(SQL_COL_ED_ACTUAL)), ATTR_CELL_ED_ACTUAL)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ST_REQUEST, 0, rowNo, GetValue(row(SQL_COL_ST_REQUEST)), ATTR_CELL_ST_REQUEST)
                    cellUtil.CellValueTimeFormat(FMT_CELL_ED_REQUEST, 0, rowNo, GetValue(row(SQL_COL_ED_REQUEST)), ATTR_CELL_ED_REQUEST)

                    Dim columnIdx As Integer = 0
                    For komaGroup As Integer = 1 To 6
                        cellUtil.CellValue(columnIdx, rowNo, CELL_COL_OFFSET, CELL_ROW_OFFSET, GetValue(row(SQL_COL_ROOM & komaGroup.ToString()))) : columnIdx += 1
                        cellUtil.CellValue(columnIdx, rowNo, CELL_COL_OFFSET, CELL_ROW_OFFSET, GetValue(row(SQL_COL_GRADE & komaGroup.ToString()))) : columnIdx += 1
                        cellUtil.CellValue(columnIdx, rowNo, CELL_COL_OFFSET, CELL_ROW_OFFSET, GetValue(row(SQL_COL_CLASS & komaGroup.ToString()))) : columnIdx += 1
                        cellUtil.CellValue(columnIdx, rowNo, CELL_COL_OFFSET, CELL_ROW_OFFSET, GetValue(row(SQL_COL_KOMA & komaGroup.ToString()))) : columnIdx += 1
                        cellUtil.CellValueTimeFormat(columnIdx, rowNo, CELL_COL_OFFSET, CELL_ROW_OFFSET, GetValue(row(SQL_COL_ST_TIME & komaGroup.ToString()))) : columnIdx += 1
                        cellUtil.CellValueTimeFormat(columnIdx, rowNo, CELL_COL_OFFSET, CELL_ROW_OFFSET, GetValue(row(SQL_COL_ED_TIME & komaGroup.ToString()))) : columnIdx += 1

                        Dim countValue As String = GetValue(row(SQL_COL_PINCH & komaGroup.ToString())).ToString().Trim()
                        If StringUtil.IsNotNullOrWhiteSpace(countValue) Then
                            If "U".Equals(countValue) Then
                                countValue = "○"
                            ElseIf "TP".Equals(countValue) Then
                                countValue = "◎"
                            End If
                        End If
                        cellUtil.CellValue(columnIdx, rowNo, CELL_COL_OFFSET, CELL_ROW_OFFSET, countValue) : columnIdx += 1
                    Next

                    rowNo = rowNo + 1
                End With
            Next
        Catch ex As Exception

        End Try
    End Sub

#End Region

End Class
