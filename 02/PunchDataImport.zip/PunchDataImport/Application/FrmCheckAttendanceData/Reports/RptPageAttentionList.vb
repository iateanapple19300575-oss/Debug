﻿''' <summary>
''' アテンションチェックシート出力
''' </summary>
Public Class RptPageAttentionList
    Inherits VBReportPage

#Region "[定数]"

    ' ページタイトル名
    Private Const REPORT_PAGE_NAME As String = "出講料アテンションリスト（{0}年{1}月度）"

    ' ページタイトルの変数名
    Private Const REPORT_SHEET_NAME As String = "CHECK_ATTENTION"

    ' ページタイトル出力項目の変数
    Private Const REPORT_CELL_TITLE As String = "**TITLE"

    ' 出力項目変数
    Private Const FMT_CELL_CLASSIFICATION As String = "**Classification"
    Private Const FMT_CELL_TEACHER_CODE As String = "**TeacherCode"
    Private Const FMT_CELL_TEACHER_NAME As String = "**TeacherName"
    Private Const FMT_CELL_WORKING_DAY As String = "**WorkingDay"
    Private Const FMT_CELL_CONTENT As String = "**Contents"

    ' 基本セル書式参照セル
    Private Const ATTR_CELL_CLASSIFICATION As String = "B5"
    Private Const ATTR_CELL_TEACHER_CODE As String = "C5"
    Private Const ATTR_CELL_TEACHER_NAME As String = "D5"
    Private Const ATTR_CELL_WORKING_DAY As String = "E5"
    Private Const ATTR_CELL_CONTENT As String = "F5"

    ' 出力項目対応テーブル項目名
    Private Const SQL_COL_CLASSIFICATION As String = "Level_String"
    Private Const SQL_COL_TEACHER_CODE As String = "Teacher_Code"
    Private Const SQL_COL_TEACHER_NAME As String = "Teacher_Name"
    Private Const SQL_COL_WORKING_DAY As String = "Lecture_Date"
    Private Const SQL_COL_CONTENT As String = "Message"

    ' 一覧の先頭セル(列)
    Private Const CELL_COL_OFFSET As Integer = 17

    ' 一覧の先頭セル(行)
    Private Const CELL_ROW_OFFSET As Integer = 6

#End Region

#Region "[プロパティ]"

    ''' <summary>
    ''' ページタイトルセル
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageTitleCell As String
        Get
            Return REPORT_CELL_TITLE
        End Get
    End Property

    ''' <summary>
    ''' ページタイトル名
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageTitleName As String
        Get
            Return REPORT_PAGE_NAME
        End Get
    End Property

    ''' <summary>
    ''' シート名
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides ReadOnly Property PageSheetName As String
        Get
            Return REPORT_SHEET_NAME
        End Get
    End Property

#End Region

#Region "[メソッド]"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="param"></param>
    Public Sub New(ByVal param As DaoParameter)
        MyBase.New(param.TargetDate, Nothing)
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="reportSourceDataTable"></param>
    Public Sub New(ByVal targetDate As Date, ByVal reportSourceDataTable As DataTable)
        MyBase.New(targetDate, reportSourceDataTable)
    End Sub

    ''' <summary>
    ''' 初期設定
    ''' </summary>
    Public Overrides Sub InitialSetup()
        m_PageName = String.Format(REPORT_PAGE_NAME, Year(MyBase.TargetDate), Month(MyBase.TargetDate))
        m_SheetName = REPORT_SHEET_NAME
    End Sub

    ''' <summary>
    ''' 出力データ取得クエリ
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function ReportQuery() As String
        Return StampListQuery.SelectSql(MyBase.TargetDate)
    End Function

    ''' <summary>
    ''' ページデータ出力
    ''' </summary>
    Public Overrides Sub PageOutput()
        OutputDetail(ReportSourceDataTable)
    End Sub

    ''' <summary>
    ''' 明細出力
    ''' </summary>
    ''' <param name="dtTable"></param>
    Public Overrides Sub OutputDetail(ByVal dtTable As DataTable)
        Dim cellUtil As New CellReportUtil(m_CellReport)
        Dim rowNo As Integer = 0

        For Each row As DataRow In dtTable.Rows
            With m_CellReport
                cellUtil.CellValue(FMT_CELL_CLASSIFICATION, 0, rowNo, GetValue(row(SQL_COL_CLASSIFICATION)), ATTR_CELL_CLASSIFICATION)
                cellUtil.CellValue(FMT_CELL_TEACHER_CODE, 0, rowNo, GetValue(row(SQL_COL_TEACHER_CODE)), ATTR_CELL_TEACHER_CODE)
                cellUtil.CellValue(FMT_CELL_TEACHER_NAME, 0, rowNo, GetValue(row(SQL_COL_TEACHER_NAME)), ATTR_CELL_TEACHER_NAME)
                cellUtil.CellValueDateFormat(FMT_CELL_WORKING_DAY, 0, rowNo, GetValue(row(SQL_COL_WORKING_DAY)), ATTR_CELL_WORKING_DAY)
                cellUtil.CellValue(FMT_CELL_CONTENT, 0, rowNo, GetValue(row(SQL_COL_CONTENT)), ATTR_CELL_CONTENT)
                rowNo = rowNo + 1
            End With
        Next
    End Sub

#End Region

End Class
