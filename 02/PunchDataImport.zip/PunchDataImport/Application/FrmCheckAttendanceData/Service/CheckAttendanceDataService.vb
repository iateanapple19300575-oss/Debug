﻿'Imports ClassLibrary

'''' <summary>
'''' [勤怠データ確認]画面サービスクラス
'''' </summary>
'Public Class CheckAttendanceDataService

'  ''' <summary>
'  ''' 出講料チェックリスト(EXCEL出力処理)
'  ''' </summary>
'  ''' <param name="targetYearMonth"></param>
'  ''' <returns></returns>
'  Public Function ExportForLecturePunch(ByVal targetYearMonth As String, ByVal filePath As String) As ResultData
'    Dim resultData As ResultData

'    ' 対象年月度(String) → Date型に変換
'    Dim dtTargetYearMonth As Date
'    If (Not Date.TryParse(targetYearMonth, dtTargetYearMonth)) Then
'      resultData = New ResultData()
'      resultData.Success = False
'      Return resultData
'    End If

'    ' TODO:デバッグ
'    Dim systemData As New SystemEnvData
'    systemData.BaseUnitPrice = 1500
'    'systemData.TimeSpan = 20

'    ' 取得したシステム設定情報をパラメタにEXCEL出力実行
'    Dim report As New ReportLectureFee(dtTargetYearMonth, filePath)
'    resultData = report.Output(systemData)

'    Return resultData
'  End Function

'  ''' <summary>
'  ''' 出講料アテンションリスト(EXCEL出力処理)
'  ''' </summary>
'  ''' <param name="targetYearMonth"></param>
'  ''' <returns></returns>
'  Public Function ExportForLectureAttention(ByVal targetYearMonth As String, ByVal filePath As String) As ResultData
'    Dim resultData As ResultData

'    ' 対象年月度(String) → Date型に変換
'    Dim dtTargetYearMonth As Date
'    If (Not Date.TryParse(targetYearMonth, dtTargetYearMonth)) Then
'      resultData = New ResultData()
'      resultData.Success = False
'      Return resultData
'    End If

'    Dim param As New DaoParameter
'    param.TargetDate = targetYearMonth
'    param.ExportFilePath = filePath

'    ' 取得したシステム設定情報をパラメタにEXCEL出力実行
'    Dim report As New ReportAttentionCheck(dtTargetYearMonth, filePath)
'    resultData = report.Output(param)

'    Return resultData
'  End Function


'End Class
