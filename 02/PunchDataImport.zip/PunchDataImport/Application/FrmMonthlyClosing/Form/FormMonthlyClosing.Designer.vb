﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMonthlyClosing
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnTempClose = New System.Windows.Forms.Button()
        Me.btnFinalClose = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblFinalCloseExecDate = New System.Windows.Forms.Label()
        Me.lblTempCloseExecDate = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblCloseState = New System.Windows.Forms.Label()
        Me.lblTargetYearMonth = New System.Windows.Forms.Label()
        Me.btnRelease = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("游ゴシック", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 30)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(210, 42)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "対象年月度："
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("游ゴシック", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(40, 80)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(114, 42)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "状態："
        '
        'btnTempClose
        '
        Me.btnTempClose.Font = New System.Drawing.Font("游ゴシック", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnTempClose.Location = New System.Drawing.Point(40, 150)
        Me.btnTempClose.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnTempClose.Name = "btnTempClose"
        Me.btnTempClose.Size = New System.Drawing.Size(450, 70)
        Me.btnTempClose.TabIndex = 5
        Me.btnTempClose.Text = "仮締め処理"
        Me.btnTempClose.UseVisualStyleBackColor = True
        '
        'btnFinalClose
        '
        Me.btnFinalClose.Font = New System.Drawing.Font("游ゴシック", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnFinalClose.Location = New System.Drawing.Point(40, 245)
        Me.btnFinalClose.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnFinalClose.Name = "btnFinalClose"
        Me.btnFinalClose.Size = New System.Drawing.Size(450, 70)
        Me.btnFinalClose.TabIndex = 6
        Me.btnFinalClose.Text = "本締め処理"
        Me.btnFinalClose.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(40, 360)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(170, 21)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "仮締め処理実行日時："
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(40, 400)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(170, 21)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "本締め処理実行日時："
        '
        'lblFinalCloseExecDate
        '
        Me.lblFinalCloseExecDate.AutoSize = True
        Me.lblFinalCloseExecDate.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblFinalCloseExecDate.Location = New System.Drawing.Point(220, 400)
        Me.lblFinalCloseExecDate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFinalCloseExecDate.Name = "lblFinalCloseExecDate"
        Me.lblFinalCloseExecDate.Size = New System.Drawing.Size(60, 21)
        Me.lblFinalCloseExecDate.TabIndex = 10
        Me.lblFinalCloseExecDate.Text = "Label5"
        '
        'lblTempCloseExecDate
        '
        Me.lblTempCloseExecDate.AutoSize = True
        Me.lblTempCloseExecDate.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTempCloseExecDate.Location = New System.Drawing.Point(220, 360)
        Me.lblTempCloseExecDate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTempCloseExecDate.Name = "lblTempCloseExecDate"
        Me.lblTempCloseExecDate.Size = New System.Drawing.Size(60, 21)
        Me.lblTempCloseExecDate.TabIndex = 8
        Me.lblTempCloseExecDate.Text = "Label6"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(40, 480)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(377, 21)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "本締め処理：給与奉行用CSVを出力可能になります"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("游ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(40, 450)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(363, 21)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "仮締め処理：給与明細PDFを出力可能になります"
        '
        'lblCloseState
        '
        Me.lblCloseState.AutoSize = True
        Me.lblCloseState.Font = New System.Drawing.Font("游ゴシック", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCloseState.Location = New System.Drawing.Point(168, 80)
        Me.lblCloseState.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCloseState.Name = "lblCloseState"
        Me.lblCloseState.Size = New System.Drawing.Size(178, 42)
        Me.lblCloseState.TabIndex = 3
        Me.lblCloseState.Text = "締め処理前"
        '
        'lblTargetYearMonth
        '
        Me.lblTargetYearMonth.AutoSize = True
        Me.lblTargetYearMonth.Font = New System.Drawing.Font("游ゴシック", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblTargetYearMonth.Location = New System.Drawing.Point(253, 30)
        Me.lblTargetYearMonth.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTargetYearMonth.Name = "lblTargetYearMonth"
        Me.lblTargetYearMonth.Size = New System.Drawing.Size(190, 42)
        Me.lblTargetYearMonth.TabIndex = 1
        Me.lblTargetYearMonth.Text = "2025年12月"
        '
        'btnRelease
        '
        Me.btnRelease.Font = New System.Drawing.Font("游ゴシック", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnRelease.Location = New System.Drawing.Point(416, 80)
        Me.btnRelease.Name = "btnRelease"
        Me.btnRelease.Size = New System.Drawing.Size(74, 42)
        Me.btnRelease.TabIndex = 4
        Me.btnRelease.Text = "解除"
        Me.btnRelease.UseVisualStyleBackColor = True
        '
        'FormMonthlyClosing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 549)
        Me.Controls.Add(Me.btnRelease)
        Me.Controls.Add(Me.lblCloseState)
        Me.Controls.Add(Me.lblTargetYearMonth)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lblFinalCloseExecDate)
        Me.Controls.Add(Me.lblTempCloseExecDate)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnFinalClose)
        Me.Controls.Add(Me.btnTempClose)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormMonthlyClosing"
        Me.Text = "月締め処理"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnTempClose As Button
    Friend WithEvents btnFinalClose As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblFinalCloseExecDate As Label
    Friend WithEvents lblTempCloseExecDate As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblCloseState As Label
    Friend WithEvents lblTargetYearMonth As Label
    Friend WithEvents btnRelease As Button
End Class
