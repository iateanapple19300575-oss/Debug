﻿Imports MainApp.Data.Dto

Namespace MainApp.Data.Model

    ''' <summary>
    ''' Model: C_Closing_Management
    ''' C_Closing_Management
    ''' </summary>
    Public Class ClosingManagementModel

        ''' <summary>
        ''' Year_Month
        ''' </summary>
        Public Property YearMonth As String

        ''' <summary>
        ''' Temp_Close_User
        ''' </summary>
        Public Property TempCloseUser As String

        ''' <summary>
        ''' Temp_Close_Datetime
        ''' </summary>
        Public Property TempCloseDatetime As Nullable(Of DateTime)

        ''' <summary>
        ''' Final_Close_User
        ''' </summary>
        Public Property FinalCloseUser As String

        ''' <summary>
        ''' Final_Close_Datetime
        ''' </summary>
        Public Property FinalCloseDatetime As Nullable(Of DateTime)

        ''' <summary>
        ''' 月締め状態
        ''' </summary>
        ''' <returns></returns>
        Public Property MonthlyClosingState As MonthlyClosingMode = MonthlyClosingMode.None


        ''' <summary>
        ''' Model から DTO へ変換
        ''' </summary>
        Public Function ToDto() As ClosingManagementDto
            Dim dto As New ClosingManagementDto()
            dto.YearMonth = Me.YearMonth
            dto.TempCloseUser = Me.TempCloseUser
            dto.TempCloseDatetime = Me.TempCloseDatetime
            dto.FinalCloseUser = Me.FinalCloseUser
            dto.FinalCloseDatetime = Me.FinalCloseDatetime

            Return dto
        End Function

        ''' <summary>
        ''' DTO から Model を生成
        ''' </summary>
        Public Function FromDto(source As ClosingManagementDto) As ClosingManagementModel
            Dim model As New ClosingManagementModel()
            model.YearMonth = source.YearMonth
            model.TempCloseUser = source.TempCloseUser
            model.TempCloseDatetime = source.TempCloseDatetime
            model.FinalCloseUser = source.FinalCloseUser
            model.FinalCloseDatetime = source.FinalCloseDatetime

            Return model
        End Function
    End Class
End Namespace
