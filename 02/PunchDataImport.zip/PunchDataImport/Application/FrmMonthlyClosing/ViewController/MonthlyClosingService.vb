﻿Imports MainApp.Data.Dto
Imports PunchDataImport.MainApp.Data.Model

''' <summary>
''' 月締め処理 Service
''' </summary>
Public Class MonthlyClosingService

    Private _domain As New MonthlyClosingDomain

    Private _repo As New ClosingManagementRepository

    ''' <summary>
    ''' 月締め状態取得
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function LoadData(ByVal model As ClosingManagementModel) As ClosingManagementModel
        Dim dto As ClosingManagementDto = model.ToDto
        dto = _repo.GetByYearMonth(dto)
        If dto IsNot Nothing Then
            model = model.FromDto(dto)
        End If

        Return model
    End Function

    ''' <summary>
    ''' 仮締め処理
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function TempClose(ByVal model As ClosingManagementModel) As ClosingManagementModel
        Dim dto As ClosingManagementDto = _domain.TempClose(model)
        Dim cnt As Integer = _repo.TemporaryTightening(dto)
        If cnt > 0 Then
            model = LoadData(model)
        End If

        Return model
    End Function

    ''' <summary>
    ''' 本締め処理
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function FinalClose(ByVal model As ClosingManagementModel) As ClosingManagementModel
        Dim dto As ClosingManagementDto = _domain.FinalClose(model)
        Dim cnt As Integer = _repo.FinalTightening(dto)
        If cnt > 0 Then
            model = LoadData(model)
        End If

        Return model
    End Function

    ''' <summary>
    ''' 仮締め解除処理
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function TempCloseRelease(ByVal model As ClosingManagementModel) As ClosingManagementModel
        Dim dto As ClosingManagementDto = model.ToDto
        Dim cnt As Integer = _repo.ReleaseTemporaryTightening(dto)
        If cnt > 0 Then
            model = LoadData(model)
        End If

        Return model
    End Function

End Class
