﻿Public Class GridBusinessPayStyle
  Implements IGridColumnDefinition

  ''' <summary>
  ''' 打刻外業務給データの一覧に必要な列定義を作成し、指定された DataGridView に適用する。
  ''' </summary>
  ''' <param name="grid"></param>
  Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 出講・業務届明細一覧の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("Site_Name2", "教室", 130).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Start_Time", "開始", 50).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Format("H:mm").
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("End_Time", "終了", 50).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Format("H:mm").
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Contents", "内容", 240).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build()
        }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
    grid.AutoGenerateColumns = False

    ' 列定義を DataGridView に追加
    For Each def In defs
      grid.Columns.Add(GridColumnFactory.Create(def))
    Next

  End Sub
End Class
