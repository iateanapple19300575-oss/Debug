﻿Public Class GridDailyStatementStyle
  Implements IGridColumnDefinition

  ''' <summary>
  ''' 出講・業務届明細の一覧に必要な列定義を作成し、指定された DataGridView に適用する。
  ''' </summary>
  ''' <param name="grid"></param>
  Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

    ' 出講・業務届明細一覧の項目定義
    Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("Site_Name", "教室", 104).
                Align(DataGridViewContentAlignment.MiddleLeft).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Koma_Seq", "ｺﾏ", 30).
                Align(DataGridViewContentAlignment.MiddleRight).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Start_Time", "開始", 50).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("End_Time", "終了", 50).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Contents", "内容", 235).
                Align(DataGridViewContentAlignment.MiddleLeft).
                CellReadOnly().
                Build()
        }

    ' 既存列をクリアし、自動生成を無効化
    grid.Columns.Clear()
    grid.AutoGenerateColumns = False

    ' 列定義を DataGridView に追加
    For Each def In defs
      grid.Columns.Add(GridColumnFactory.Create(def))
    Next

  End Sub
End Class
