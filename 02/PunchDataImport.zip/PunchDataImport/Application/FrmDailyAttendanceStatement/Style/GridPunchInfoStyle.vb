﻿Public Class GridPunchInfoStyle
  Implements IGridColumnDefinition

  ''' <summary>
  ''' 日の打刻明細情報に必要な列定義を作成し、指定された DataGridView に適用する。
  ''' </summary>
  ''' <param name="grid"></param>
  Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 打刻明細情報の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("Teacher_Code", "講師コード", 100).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Teacher_Name", "講師名", 170).
                Align(DataGridViewContentAlignment.MiddleLeft).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Lecture_Date", "日付", 126).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("StatusStr", "状態", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Hide().
                Build(),
            New GridColumnBuilder("Punch_Start_Time", "出勤", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Punch_End_Time", "退勤", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Work_Start_Time", "開始", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Work_End_Time", "終了", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Number_Of_Punched", "打刻回数", 80).
                Align(DataGridViewContentAlignment.MiddleRight).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Task_Un_Break_Time", "休憩時間", 80).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("Late_Night_Shift", "深夜勤務", 80).
                Align(DataGridViewContentAlignment.MiddleCenter).
                CellReadOnly().
                Build()
        }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
    grid.AutoGenerateColumns = False

    ' 列定義を DataGridView に追加
    For Each def In defs
      grid.Columns.Add(GridColumnFactory.Create(def))
    Next

    grid.ColumnHeadersHeight = 30
    grid.RowHeadersWidth = 20
    grid.RowTemplate.Height = 30

  End Sub
End Class
