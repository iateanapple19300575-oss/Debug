﻿Imports MainApp.Data.Dto

''' <summary>
''' 日次勤怠明細画面
''' </summary>
Public Class FrmDailyAttendanceStatement
    Inherits BaseForm

    ''' <summary>
    ''' 打刻明細データ(打刻忘れ確認画面からのパラメタ)
    ''' </summary>
    ''' <returns></returns>
    Private Property daoParam As DaoParameter

    ''' <summary>
    ''' 日次勤怠明細画面サービス
    ''' </summary>
    ''' <returns></returns>
    Private Property service As New DailyAttendanceStatementDisplayService


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="param"></param>
    Sub New(ByVal param As DaoParameter)
        ' コンポーネント初期化
        InitializeComponent()

        ' ここから本処理
        Me.daoParam = param
        FormLogWrapper.WrapFormLifecycle(Me)
        FormLogWrapper.WrapAllEvents(Me)
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmDailyAttendanceStatement_Load(sender As Object, e As EventArgs) Handles Me.Load
        InitDisplay()
    End Sub

    ''' <summary>
    ''' 画面初期表示処理
    ''' </summary>
    Private Sub InitDisplay()
        ' 画面表示情報取得
        Dim result As New AttendanceStatementWinData
        Dim param As New LectureDetailsFindParameter
        param.TargetDate = daoParam.TargetDate
        param.LectureDate = daoParam.LectureDate
        param.TeacherCode = daoParam.TeacherCode
        result = service.DataLoad(param)
        If Not result.Success Then
            Return
        End If

        '　打刻明細表示
        DisplayStampDetails(result.AttendanceDataTable)
        dgvPunchInfo.Height = 50

        ' エラー・警告等情報表示
        DisplayErrorInfoDetails(result.ErrorInfoDataTable)

        ' 出講・業務届明細表示
        DisplayLectureWorkDetails(result.LectureWorkDataTable)

        ' 打刻外業務給データ表示
        DisplayBusinessPayData(result.WorkSalaryDataTable)
    End Sub

    ''' <summary>
    ''' 打刻明細表示
    ''' </summary>
    Private Sub DisplayStampDetails(ByVal dt As DataTable)
        Dim def As New GridPunchInfoStyle()
        def.Apply(Me.dgvPunchInfo)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(Me.dgvPunchInfo)
        dgvPunchInfo.DataSource = dt
    End Sub

    ''' <summary>
    ''' エラー・警告等情報表示
    ''' </summary>
    ''' <param name="dt"></param>
    Private Sub DisplayErrorInfoDetails(ByVal dt As DataTable)
        Dim def As New GridErrorInfoStyle()
        def.Apply(Me.dgvErrorInfo)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(Me.dgvErrorInfo)
        dgvErrorInfo.DataSource = dt
        dt.DefaultView.Sort = "Priority ASC"
    End Sub

    ''' <summary>
    ''' 出講・業務届明細表示
    ''' </summary>
    Private Sub DisplayLectureWorkDetails(ByVal dt As DataTable)
        Dim def As New GridDailyStatementStyle()
        def.Apply(Me.dgvDailyStatement)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(Me.dgvDailyStatement)
        dgvDailyStatement.DataSource = dt
    End Sub

    ''' <summary>
    ''' 打刻外業務給データ表示
    ''' </summary>
    Private Sub DisplayBusinessPayData(ByVal dt As DataTable)
        Dim def As New GridBusinessPayStyle()
        def.Apply(Me.dgvBusinessPayData)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(Me.dgvBusinessPayData)
        dgvBusinessPayData.DataSource = dt
    End Sub

    ''' <summary>
    ''' DataGridView選択無効化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub DisableSelection(sender As Object, e As EventArgs) Handles dgvPunchInfo.SelectionChanged, dgvErrorInfo.SelectionChanged, dgvDailyStatement.SelectionChanged, dgvBusinessPayData.SelectionChanged
        Dim dgv As DataGridView = DirectCast(sender, DataGridView)
        dgv.ClearSelection()
        dgv.CurrentCell = Nothing
    End Sub

    Private Sub dgvPunchInfo_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvPunchInfo.CellFormatting
        If IsTimeFormat(dgvPunchInfo.Columns(e.ColumnIndex).Name) AndAlso e.Value IsNot Nothing Then
            Dim dateValue As DateTime
            If DateTime.TryParse(e.Value.ToString(), dateValue) Then
                e.Value = dateValue.ToString("H:mm")
                e.FormattingApplied = True ' 書式適用済みをマーク
            End If
        End If
    End Sub

    Private Sub dgvDailyStatement_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvDailyStatement.CellFormatting
        If IsTimeFormat(dgvDailyStatement.Columns(e.ColumnIndex).Name) AndAlso e.Value IsNot Nothing Then
            Dim dateValue As DateTime
            If DateTime.TryParse(e.Value.ToString(), dateValue) Then
                e.Value = dateValue.ToString("H:mm")
                e.FormattingApplied = True ' 書式適用済みをマーク
            End If
        End If
    End Sub

    Private Sub dgvBusinessPayData_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvBusinessPayData.CellFormatting
        If IsTimeFormat(dgvBusinessPayData.Columns(e.ColumnIndex).Name) AndAlso e.Value IsNot Nothing Then
            Dim dateValue As DateTime
            If DateTime.TryParse(e.Value.ToString(), dateValue) Then
                e.Value = dateValue.ToString("H:mm")
                e.FormattingApplied = True ' 書式適用済みをマーク
            End If
        End If
    End Sub

    ''' <summary>
    ''' 時間( HH:mm)フォーマット項目判定
    ''' </summary>
    ''' <param name="colName"></param>
    ''' <returns></returns>
    Private Function IsTimeFormat(ByVal colName As String) As Boolean
        Dim timeFields As String() = {
                "Punch_Start_Time", "Punch_End_Time",
                "Work_Start_Time", "Work_End_Time",
                "Start_Time", "End_Time",
                "Task_Un_Break_Time", "Late_Night_Shift"
            }
        Return timeFields.Contains(colName)
    End Function
End Class