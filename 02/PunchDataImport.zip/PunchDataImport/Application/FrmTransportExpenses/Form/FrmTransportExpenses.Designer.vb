﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmTransportExpenses
	Inherits BaseForm

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
    Me.cmbSubject = New System.Windows.Forms.ComboBox()
    Me.cmbSite = New System.Windows.Forms.ComboBox()
    Me.dgvTranspExpens = New System.Windows.Forms.DataGridView()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.cbxUnregisteredOnly = New System.Windows.Forms.CheckBox()
    Me.cmbTeacher = New System.Windows.Forms.ComboBox()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.cmbGroup = New System.Windows.Forms.ComboBox()
    CType(Me.dgvTranspExpens, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'cmbSubject
    '
    Me.cmbSubject.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbSubject.FormattingEnabled = True
    Me.cmbSubject.Location = New System.Drawing.Point(46, 8)
    Me.cmbSubject.Margin = New System.Windows.Forms.Padding(4)
    Me.cmbSubject.Name = "cmbSubject"
    Me.cmbSubject.Size = New System.Drawing.Size(80, 25)
    Me.cmbSubject.TabIndex = 1
    '
    'cmbSite
    '
    Me.cmbSite.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbSite.FormattingEnabled = True
    Me.cmbSite.Location = New System.Drawing.Point(546, 8)
    Me.cmbSite.Margin = New System.Windows.Forms.Padding(4)
    Me.cmbSite.Name = "cmbSite"
    Me.cmbSite.Size = New System.Drawing.Size(120, 25)
    Me.cmbSite.TabIndex = 7
    '
    'dgvTranspExpens
    '
    Me.dgvTranspExpens.AllowUserToAddRows = False
    Me.dgvTranspExpens.AllowUserToDeleteRows = False
    Me.dgvTranspExpens.AllowUserToResizeColumns = False
    Me.dgvTranspExpens.AllowUserToResizeRows = False
    Me.dgvTranspExpens.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.dgvTranspExpens.Location = New System.Drawing.Point(12, 40)
    Me.dgvTranspExpens.MultiSelect = False
    Me.dgvTranspExpens.Name = "dgvTranspExpens"
    Me.dgvTranspExpens.RowHeadersWidth = 20
    Me.dgvTranspExpens.RowTemplate.Height = 21
    Me.dgvTranspExpens.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
    Me.dgvTranspExpens.Size = New System.Drawing.Size(800, 594)
    Me.dgvTranspExpens.TabIndex = 9
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(12, 12)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(34, 17)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "科目"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(510, 12)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(34, 17)
    Me.Label2.TabIndex = 6
    Me.Label2.Text = "教室"
    '
    'cbxUnregisteredOnly
    '
    Me.cbxUnregisteredOnly.AutoSize = True
    Me.cbxUnregisteredOnly.Location = New System.Drawing.Point(720, 10)
    Me.cbxUnregisteredOnly.Name = "cbxUnregisteredOnly"
    Me.cbxUnregisteredOnly.Size = New System.Drawing.Size(92, 21)
    Me.cbxUnregisteredOnly.TabIndex = 8
    Me.cbxUnregisteredOnly.Text = "未登録のみ"
    Me.cbxUnregisteredOnly.UseVisualStyleBackColor = True
    '
    'cmbTeacher
    '
    Me.cmbTeacher.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbTeacher.FormattingEnabled = True
    Me.cmbTeacher.Location = New System.Drawing.Point(176, 8)
    Me.cmbTeacher.Margin = New System.Windows.Forms.Padding(4)
    Me.cmbTeacher.Name = "cmbTeacher"
    Me.cmbTeacher.Size = New System.Drawing.Size(120, 25)
    Me.cmbTeacher.TabIndex = 3
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(140, 12)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(34, 17)
    Me.Label3.TabIndex = 2
    Me.Label3.Text = "講師"
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(310, 12)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(60, 17)
    Me.Label4.TabIndex = 4
    Me.Label4.Text = "グループ"
    '
    'cmbGroup
    '
    Me.cmbGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbGroup.FormattingEnabled = True
    Me.cmbGroup.Location = New System.Drawing.Point(374, 8)
    Me.cmbGroup.Margin = New System.Windows.Forms.Padding(4)
    Me.cmbGroup.Name = "cmbGroup"
    Me.cmbGroup.Size = New System.Drawing.Size(100, 25)
    Me.cmbGroup.TabIndex = 5
    '
    'FrmTransportExpenses
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(824, 641)
    Me.Controls.Add(Me.Label4)
    Me.Controls.Add(Me.cmbGroup)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.cmbTeacher)
    Me.Controls.Add(Me.cbxUnregisteredOnly)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.dgvTranspExpens)
    Me.Controls.Add(Me.cmbSite)
    Me.Controls.Add(Me.cmbSubject)
    Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
    Me.Margin = New System.Windows.Forms.Padding(4)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "FrmTransportExpenses"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "交通費管理"
    CType(Me.dgvTranspExpens, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents cmbSubject As ComboBox
	Friend WithEvents cmbSite As ComboBox
	Friend WithEvents dgvTranspExpens As DataGridView
	Friend WithEvents Label1 As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents cbxUnregisteredOnly As CheckBox
	Friend WithEvents cmbTeacher As ComboBox
	Friend WithEvents Label3 As Label
	Friend WithEvents Label4 As Label
	Friend WithEvents cmbGroup As ComboBox
End Class
