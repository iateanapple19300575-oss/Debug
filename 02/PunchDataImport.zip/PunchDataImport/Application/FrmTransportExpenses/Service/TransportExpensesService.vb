﻿''' <summary>
''' 交通費画面サービスクラス
''' </summary>
Public Class TransportExpensesService

    ''' <summary>
    ''' グループトラン
    ''' </summary>
    Private vmGroupRepository As New VMGroupRepository

    ''' <summary>
    ''' 教室トラン
    ''' </summary>
    Private vmSiteRepository As New VMSiteRepository

    ''' <summary>
    ''' 講師トラン
    ''' </summary>
    Private teacherTran As New TeacherTran


	''' <summary>
	''' 初期画面表示データ取得
	''' </summary>
	''' <param name="yearMonth"></param>
	''' <returns></returns>
	Public Function GetInitDisplayData(Optional ByVal yearMonth As String = "") As ResultData
		Dim resultData As New ResultData

		Try
			resultData.ResDataTable = LoadComboDataForSite("1", "1")
			resultData.Success = True
		Catch ex As Exception
			resultData.Success = False
			Throw
		Finally
		End Try

		Return resultData
	End Function

	''' <summary>
	''' グループコンボデータ取得
	''' </summary>
	''' <returns></returns>
	Public Function LoadComboDataForGroup(ByVal corporate As String) As DataTable
		Dim dt As New DataTable

		Try
            dt = vmGroupRepository.GetAll()
        Catch ex As Exception
			Throw
		Finally
		End Try
		Return dt
	End Function

	''' <summary>
	''' 教室コンボデータ取得
	''' </summary>
	''' <returns></returns>
	Public Function LoadComboDataForSite(ByVal corporate As String, ByVal division As String) As DataTable
		Dim dt As New DataTable

		Try
            dt = vmSiteRepository.FetchByGroup(division)
        Catch ex As Exception
			Throw
		Finally
		End Try
		Return dt
	End Function

	''' <summary>
	''' 講師コンボデータ取得
	''' </summary>
	''' <param name="targetDate"></param>
	''' <param name="teacherCode"></param>
	''' <param name="subjectCode"></param>
	''' <returns></returns>
	Public Function LoadTeacherData(ByVal targetDate As Date, ByVal teacherCode As String, ByVal subjectCode As String) As ResultData
		Dim result As New ResultData

		Try
			result.ResDataTable = teacherTran.SqlSelectKeyValuePair(targetDate, teacherCode, subjectCode)
		Catch ex As Exception
			Throw
		Finally
		End Try
		Return result
	End Function

	''' <summary>
	''' 
	''' </summary>
	''' <param name="grid"></param>
	''' <param name="cond"></param>
	''' <returns></returns>
	Public Function LoadTransportationExpensesData(ByRef grid As Windows.Forms.DataGridView, ByVal cond As TrasportExpensesIF) As ResultData
		Dim result As New ResultData
		Dim tran As New TransportExpensesTran()
		Try
			result = tran.LoadTransportExpensesCond(cond)
			BindToGrid(grid, result)
		Catch ex As Exception
			Throw
		End Try

		Return result
	End Function


	Protected Sub BindToGrid(ByRef grid As Windows.Forms.DataGridView, ByVal result As ResultData)
		If Not result.Success Then
			Return
		End If

		Dim dtTable As DataTable = result.ResDataTable
		' TODO:DataTable
		dtTable = result.ResDataTable

		With grid
			.DataSource = dtTable

			grid.ReadOnly = True
			grid.AllowUserToAddRows = False
			grid.AllowUserToDeleteRows = False
			grid.AllowUserToResizeRows = False
			grid.AllowUserToOrderColumns = False
			grid.AllowUserToResizeColumns = False
			grid.AllowUserToResizeRows = False
			grid.RowHeadersWidth = 20

			grid.DataSource = dtTable
			grid.Columns("Lecture_Date").HeaderText = "日付"
			grid.Columns("Teacher_Code").HeaderText = "講師CD"
			grid.Columns("Full_Name").HeaderText = "講師名"
			grid.Columns("Site_Code").HeaderText = "教室CD"
			grid.Columns("Site_Name").HeaderText = "教室名"
			grid.Columns("Effective_Date").HeaderText = "適用開始日"
			grid.Columns("Amount").HeaderText = "交通費"

			' 表示幅設定
			.Columns(.Columns("Lecture_Date").Index).Width = 110
			.Columns(.Columns("Teacher_Code").Index).Width = 60
			.Columns(.Columns("Full_Name").Index).Width = 120
			.Columns(.Columns("Site_Code").Index).Width = 60
			.Columns(.Columns("Site_Name").Index).Width = 200
			.Columns(.Columns("Effective_Date").Index).Width = 110
			.Columns(.Columns("Amount").Index).Width = 100

			.Columns(.Columns("Lecture_Date").Index).SortMode = DataGridViewColumnSortMode.NotSortable
			.Columns(.Columns("Teacher_Code").Index).SortMode = DataGridViewColumnSortMode.NotSortable
			.Columns(.Columns("Full_Name").Index).SortMode = DataGridViewColumnSortMode.NotSortable
			.Columns(.Columns("Site_Code").Index).SortMode = DataGridViewColumnSortMode.NotSortable
			.Columns(.Columns("Site_Name").Index).SortMode = DataGridViewColumnSortMode.NotSortable
			.Columns(.Columns("Effective_Date").Index).SortMode = DataGridViewColumnSortMode.NotSortable
			.Columns(.Columns("Amount").Index).SortMode = DataGridViewColumnSortMode.NotSortable

			grid.Columns("Lecture_Date").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Teacher_Code").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Full_Name").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Site_Code").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Site_Name").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Effective_Date").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Amount").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter

			grid.Columns("Lecture_Date").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Teacher_Code").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Full_Name").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
			grid.Columns("Site_Code").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Site_Name").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
			grid.Columns("Effective_Date").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
			grid.Columns("Amount").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

			grid.Columns("Effective_Date").DefaultCellStyle.Format = "yyyy/MM/dd"

			' 非表示設定
			'.Columns(.Columns("Teacher_Code").Index).Visible = False
			'.Columns(.Columns("Site_Code").Index).Visible = False
			'.Columns(.Columns("Effective_Date").Index).Visible = False
			'.Columns(.Columns("Amount").Index).Visible = False

			If .Rows.Count > 0 Then
				'.Rows(0).Selected = True
			End If
			.Refresh()
		End With

	End Sub

  '''' <summary>
  '''' 画面/トランインターフェース
  '''' </summary>
  'Public Class TrasportExpensesIF
  '	Public Property Subjects As String = ""
  '	Public Property TeacherCode As String = ""
  '	Public Property GroupCode As String = ""
  '	Public Property SiteCode As String = ""
  '	Public Property UnregisteredOnly As Boolean = False
  'End Class

End Class
