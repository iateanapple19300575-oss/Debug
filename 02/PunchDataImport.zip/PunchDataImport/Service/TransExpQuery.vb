﻿Public Class TransExpQuery

  ''' <summary>
  ''' 現在の交通費情報取得
  ''' </summary>
  ''' <param name="TargetDate"></param>
  ''' <param name="TimeSpan"></param>
  ''' <param name="BaseUnitPrice"></param>
  ''' <param name="param"></param>
  ''' <returns></returns>
  Public Shared Function SelectSql(ByVal TargetDate As Date, ByVal TimeSpan As Integer, ByVal BaseUnitPrice As Integer, Optional ByVal param As DaoParameter = Nothing) As String

    Dim firstDay As String = DateUtil.FirstDayOfMonth(TargetDate, "yyyy/MM/dd")
    Dim lastDay As String = DateUtil.LastDayOfMonth(TargetDate, "yyyy/MM/dd")

    Dim sqlString As New System.Text.StringBuilder

    sqlString.Append("SELECT ")
    sqlString.Append("    TR.講師コード")
    sqlString.Append("    , LC.教室Code")
    sqlString.Append("    , LC.出講場所名")
    sqlString.Append("    , TE3.交通費 ")
    sqlString.Append("    , TE3.鮮度")
    sqlString.Append("    , TE3.所要時間")
    sqlString.Append("    , TE3.適用開始日")
    sqlString.Append("FROM ")
    sqlString.Append("    Location As LC ")
    sqlString.Append("    CROSS JOIN (")
    sqlString.Append("        SELECT ")
    sqlString.Append("            講師コード ")
    sqlString.Append("        FROM ")
    sqlString.Append("            TeacherRegistry ")
    sqlString.Append("        WHERE ")
    sqlString.Append("            退社日 IS NULL")
    sqlString.Append("    ) As TR ")
    sqlString.Append("    LEFT JOIN (")
    sqlString.Append("        SELECT")
    sqlString.Append("            TE1.講師コード")
    sqlString.Append("            , TE1.出講場所")
    sqlString.Append("            , TE1.適用開始日")
    sqlString.Append("            , TE1.鮮度")
    sqlString.Append("            , TE1.交通費")
    sqlString.Append("            , TE1.所要時間")
    sqlString.Append("        FROM ")
    sqlString.Append("            TransportExpensive TE1 ")
    sqlString.Append("            INNER JOIN (")
    sqlString.Append("                SELECT ")
    sqlString.Append("                    [講師コード]")
    sqlString.Append("                    , [出講場所]")
    sqlString.Append("                    , MAX([適用開始日]) AS [適用開始日]")
    sqlString.Append("                FROM ")
    sqlString.Append("                    TransportExpensive TE ")
    sqlString.Append("                WHERE 1 = 1 ")
    sqlString.Append("                GROUP BY ")
    sqlString.Append("                    [講師コード]")
    sqlString.Append("                    , [出講場所]")
    sqlString.Append("            ) TE2")
    sqlString.Append("                ON (")
    sqlString.Append("                    TE1.[講師コード]=TE2.[講師コード] ")
    sqlString.Append("                    AND TE1.[出講場所]=TE2.[出講場所] ")
    sqlString.Append("                    AND TE1.[適用開始日]=TE2.[適用開始日] ")
    sqlString.Append("                ) ")
    sqlString.Append("            ) TE3 ")
    sqlString.Append("                ON (")
    sqlString.Append("                    LC.教室Code = TE3.出講場所 ")
    sqlString.Append("                    AND TR.講師コード = TE3.講師コード ")
    sqlString.Append("                )")
    sqlString.Append("ORDER BY")
    sqlString.Append("    TR.講師コード")
    sqlString.Append("    , LC.教室Code")

    Return sqlString.ToString()
  End Function

End Class
