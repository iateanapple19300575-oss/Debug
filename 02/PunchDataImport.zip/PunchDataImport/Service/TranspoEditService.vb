﻿Imports Nts.Freamwork.Common.Utilities

Public Class TranspoEditService

  ''' <summary>
  ''' 交通費トラン
  ''' </summary>
  Private transpoEditTran As New TranspoEditTran()


  ''' <summary>
  ''' 交通費データ登録
  ''' </summary>
  ''' <param name="recData"></param>
  ''' <returns></returns>
  Public Function Register(ByVal recData As TranspoExpensesData) As ResultData
    Dim result As New ResultData()

    Try
      Dim mode As Integer = UpdateModeAnalysis(recData)
      Select Case mode
        Case 1
          ' 追加
          result = transpoEditTran.RegisterWithAdd(recData)
        Case 3
          ' 削除
          result = transpoEditTran.RegisterWithDelete(recData)
        Case Else
          ' 更新
          result = transpoEditTran.RegisterWithUpdate(recData)
      End Select
      result.Success = True

    Catch ex As Exception
      result.Success = False
    Finally
    End Try

    Return result
  End Function


  ''' <summary>
  ''' 追加／更新／削除のモード判定
  ''' </summary>
  ''' <param name="recData"></param>
  ''' <returns></returns>
  Private Function UpdateModeAnalysis(ByVal recData As TranspoExpensesData) As Integer

    ' オリジナルの適用開始日が空ならば、追加
    If StringUtil.IsNullOrWhiteSpace(recData.EffectiveDate) Then
      Return 1
    End If

    ' 入力した適用開始日が空ならば、削除
    If StringUtil.IsNullOrWhiteSpace(recData.NewEffectiveDate) Then
      Return 3
    End If

    '以外は、更新
    Return 2

  End Function

End Class
