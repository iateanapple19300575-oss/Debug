﻿Imports System.Data.SqlClient

Public Class AttendanceTran
	Inherits TransactionBase


    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 打刻外業務給講師１日データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function LoadOneDayData(ByVal param As DaoParameter) As DataTable
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  CONCAT(LA.").Append(ntb_SiteEnum.教室コード.Column).Append(", ':',").Append(" ")
        sqlString.Append("    ").Append("REPLACE(L.").Append(ntb_SiteEnum.教室名.Column).Append(",'　','')").Append(" ")
        sqlString.Append("    ").Append("COLLATE Japanese_CS_AS_KS_WS) As ").Append(ntb_SiteEnum.教室名.Column).Append(" ")
        sqlString.Append("  , Convert(Char(5), LA.").Append(W_Lecture_ActualEnum.開始時間.Column).Append(") As ").Append(W_Lecture_ActualEnum.開始時間.Column).Append(" ")
        sqlString.Append("  , Convert(Char(5), LA.").Append(W_Lecture_ActualEnum.終了時間.Column).Append(") As ").Append(W_Lecture_ActualEnum.終了時間.Column).Append(" ")
        sqlString.Append("  , Case").Append(" ")
        sqlString.Append("      ").Append("When LA.").Append(W_Lecture_ActualEnum.データ種別.Column).Append(" = 1 Then '出講：'").Append(" ")
        sqlString.Append("      ").Append("Else Case When LA.").Append(W_Lecture_ActualEnum.データ種別.Column).Append(" = 2 Then '業務届：'").Append(" ")
        sqlString.Append("      ").Append("Else '不明：' End End").Append(" ")
        sqlString.Append("      + CONCAT(LA.").Append(W_Lecture_ActualEnum.学年.Column).Append(", '年',").Append(" ")
        sqlString.Append("        ").Append("TRIM(LA.").Append(W_Lecture_ActualEnum.クラスコード.Column).Append("),'クラス')" & " ")
        sqlString.Append("      + IIF(LA.").Append(W_Lecture_ActualEnum.ピンチ種別.Column).Append(" IS NULL, '', '　※ピンチ受け')").Append(" ")
        sqlString.Append("    As Content" & " ")
        sqlString.Append("FROM ")
        sqlString.Append("  ").Append(W_Lecture_ActualEnum.フェーズ.Table).Append(" LA").Append(" ")
        sqlString.Append("  LEFT JOIN (").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      ").Append(ntb_SiteEnum.教室コード.Column).Append(" ")
        sqlString.Append("      , ").Append(ntb_SiteEnum.教室名.Column).Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      ").Append(ntb_SiteEnum.教室コード.Table).Append(" ")
        sqlString.Append("  ) L").Append(" ")
        sqlString.Append("    On (LA.").Append(W_Lecture_ActualEnum.教室コード.Column).Append(" = ").Append(" ")
        sqlString.Append("         L.").Append(ntb_SiteEnum.教室コード.Column).Append(" COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        sqlString.Append("       )").Append(" ")
        sqlString.Append("WHERE 1=1").Append(" ")
        sqlString.Append("  AND LA.").Append(W_Lecture_ActualEnum.フェーズ.Column).Append(" = '2'").Append(" ")
        sqlString.Append("  AND LA.").Append(W_Lecture_ActualEnum.講師コード.Column).Append(" =").Append(" ")
        sqlString.Append("         ").Append(W_Lecture_ActualEnum.講師コード.Param).Append(" ")
        sqlString.Append("  AND LA.").Append(W_Lecture_ActualEnum.日付.Column).Append(" =").Append(" ")
        sqlString.Append("         ").Append(W_Lecture_ActualEnum.日付.Param).Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  LA.").Append(W_Lecture_ActualEnum.開始時間.Column).Append(" ASC").Append(" ")
        sqlString.Append(";")

        Return SqlUtil.ExecuteDataTable(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = W_Lecture_ActualEnum.講師コード.Param, .Value = param.TeacherCode},
                New SqlParameter() With {.ParameterName = W_Lecture_ActualEnum.日付.Param, .Value = param.LectureDate}
            )
    End Function

End Class
