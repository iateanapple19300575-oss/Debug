﻿Imports System.Data.SqlClient

Public Class HourlyWageManualEntryTran
	Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 打刻外業務給講師１日データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function LoadOneDayData(ByVal param As DailyStatementParam) As DataTable
		' SQL文の生成
		Dim SqlQuery As New System.Text.StringBuilder
		SqlQuery.Length = 0
		SqlQuery.Append("SELECT").Append(" ")
		SqlQuery.Append("  CONCAT(HWME.").Append(W_Hourly_Wage_Manual_EntryEnum.教室コード.Column).Append(", ':',").Append(" ")
		SqlQuery.Append("    ").Append("REPLACE(L.").Append(ntb_SiteEnum.教室名.Column).Append(",'　','')").Append(" ")
		SqlQuery.Append("    ").Append("COLLATE Japanese_CS_AS_KS_WS) As ").Append(ntb_SiteEnum.教室名.Column).Append(" ")
		SqlQuery.Append("  , Convert(Char(5), HWME.").Append(W_Hourly_Wage_Manual_EntryEnum.開始時間.Column).Append(") As ").Append(W_Hourly_Wage_Manual_EntryEnum.開始時間.Column).Append(" ")
		SqlQuery.Append("  , Convert(Char(5), HWME.").Append(W_Hourly_Wage_Manual_EntryEnum.終了時間.Column).Append(") As ").Append(W_Hourly_Wage_Manual_EntryEnum.終了時間.Column).Append(" ")
		SqlQuery.Append("  , HWME.Note").Append(" ")
		SqlQuery.Append("FROM").Append(" ")
		SqlQuery.Append("  ").Append(W_Hourly_Wage_Manual_EntryEnum.講師コード.Table).Append(" HWME").Append(" ")
		SqlQuery.Append("  LEFT JOIN (").Append(" ")
		SqlQuery.Append("    SELECT").Append(" ")
		SqlQuery.Append("        ").Append(ntb_SiteEnum.教室コード.Column).Append(" ")
		SqlQuery.Append("      , ").Append(ntb_SiteEnum.教室名.Column).Append(" ")
		SqlQuery.Append("    FROM").Append(" ")
		SqlQuery.Append("      ").Append(ntb_SiteEnum.教室コード.Table).Append(" ")
		SqlQuery.Append("  ) L").Append(" ")
		SqlQuery.Append("    On (HWME.").Append(W_Hourly_Wage_Manual_EntryEnum.教室コード.Column).Append(" = ").Append(" ")
		SqlQuery.Append("           L.").Append(ntb_SiteEnum.教室コード.Column).Append(" COLLATE Japanese_CS_AS_KS_WS").Append(" ")
		SqlQuery.Append("       )").Append(" ")
		SqlQuery.Append("WHERE 1=1").Append(" ")
		SqlQuery.Append("  AND HWME.").Append(W_Hourly_Wage_Manual_EntryEnum.講師コード.Column).Append(" =").Append(" ")
		SqlQuery.Append("           ").Append(W_Hourly_Wage_Manual_EntryEnum.講師コード.Param).Append(" ")
		SqlQuery.Append("  AND HWME.").Append(W_Hourly_Wage_Manual_EntryEnum.勤務日.Column).Append(" =").Append(" ")
		SqlQuery.Append("           ").Append(W_Hourly_Wage_Manual_EntryEnum.勤務日.Param).Append(" ")
		SqlQuery.Append("ORDER BY").Append(" ")
		SqlQuery.Append("  HWME.").Append(W_Lecture_ActualEnum.開始時間.Column).Append(" ASC").Append(" ")
		SqlQuery.Append(";")

		Return ExecuteDataTable(SqlQuery.ToString(),
				New SqlParameter() With {.ParameterName = W_Hourly_Wage_Manual_EntryEnum.講師コード.Param, .Value = param.TeacherCode},
				New SqlParameter() With {.ParameterName = W_Hourly_Wage_Manual_EntryEnum.勤務日.Param, .Value = param.LectureDate}
			)
	End Function

End Class
