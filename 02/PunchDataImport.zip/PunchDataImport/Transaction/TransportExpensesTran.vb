﻿Imports Nts.Freamwork.Common.Utilities

Public Class TransportExpensesTran
  Inherits DataGriViewLoader

  Private SqlCondition As TrasportExpensesIF

  Public Sub New()
  End Sub

  Public Sub New(ByVal cond As TrasportExpensesIF)
    Me.SqlCondition = cond
  End Sub

  Protected Overrides ReadOnly Property SqlQuery As String
    Get
      Return GetSqlQuery()
    End Get
  End Property

  Private Function GetSqlQuery(Optional ByVal cond As TrasportExpensesIF = Nothing) As String
    Dim sqlString As New System.Text.StringBuilder

    sqlString.Length = 0
    sqlString.Append("SELECT" & " ")
    sqlString.Append("  LA0.[Lecture_Date]" & " ")
    sqlString.Append("  , LA0.[Teacher_Code]" & " ")
    sqlString.Append("  , CONCAT(TR.姓, '　', TR.名) As Full_Name" & " ")
    sqlString.Append("  , LA0.[Site_Code]" & " ")
    sqlString.Append("  , REPLACE(S.[教室名],'　','') As Site_Name" & " ")
    sqlString.Append("  , CONVERT(DATE, LA0.Effective_Date) As Effective_Date" & " ")
    sqlString.Append("  , FORMAT(LA0.Amount, '#,##0') As Amount" & " ")
    sqlString.Append("  , LA0.[Subject]" & " ")
    sqlString.Append("FROM (" & " ")
    sqlString.Append("  SELECT" & " ")
    sqlString.Append("    LA.[Lecture_Date]" & " ")
    sqlString.Append("    , LA.[Teacher_Code]" & " ")
    sqlString.Append("    , LA.[Site_Code]" & " ")
    sqlString.Append("    , LA.[Subject]" & " ")
    sqlString.Append("    , MAX(TE.Effective_Date) As Effective_Date" & " ")
    sqlString.Append("    , MAX(TE.Amount) As Amount" & " ")
    sqlString.Append("  FROM" & " ")
    sqlString.Append("    " & W_Lecture_ActualEnum.フェーズ.Table & " LA" & " ")
    sqlString.Append("    LEFT JOIN (" & " ")
    sqlString.Append("      SELECT" & " ")
    sqlString.Append("        TEM.Teacher_Code" & " ")
    sqlString.Append("        , TEM.Site_Code" & " ")
    sqlString.Append("        , TEM.Effective_Date" & " ")
    sqlString.Append("        , TEM.Amount" & " ")
    sqlString.Append("      FROM" & " ")
    sqlString.Append("        " & M_Transpo_ExpensesEnum.講師コード.Table & " TEM" & " ")
    sqlString.Append("        INNER JOIN (" & " ")
    sqlString.Append("          SELECT" & " ")
    sqlString.Append("            Teacher_Code" & " ")
    sqlString.Append("            , Site_Code" & " ")
    sqlString.Append("            , MAX(Effective_Date) As Effective_Date" & " ")
    sqlString.Append("          FROM")
    sqlString.Append("            " & M_Transpo_ExpensesEnum.講師コード.Table & " ")
    sqlString.Append("          GROUP BY" & " ")
    sqlString.Append("            Teacher_Code" & " ")
    sqlString.Append("            , Site_Code" & " ")
    sqlString.Append("        ) TEG" & " ")
    sqlString.Append("          ON (" & " ")
    sqlString.Append("            TEM.Teacher_Code = TEG.Teacher_Code" & " ")
    sqlString.Append("            AND TEM.Site_Code = TEG.Site_Code" & " ")
    sqlString.Append("            AND TEM.Effective_Date = TEG.Effective_Date" & " ")
    sqlString.Append("          )" & " ")
    sqlString.Append("        ) TE" & " ")
    sqlString.Append("          ON (" & " ")
    sqlString.Append("            LA.Teacher_Code = TE.Teacher_Code" & " ")
    sqlString.Append("            AND LA.Site_Code = TE.Site_Code" & " ")
    sqlString.Append("            AND LA.Lecture_Date >= TE.Effective_Date" & " ")
    sqlString.Append("          )")
    sqlString.Append("      WHERE" & " ")
    sqlString.Append("        1=1" & " ")
    sqlString.Append("        AND [Phase] = 2" & " ")
    sqlString.Append("      GROUP BY" & " ")
    sqlString.Append("        LA.[Teacher_Code]" & " ")
    sqlString.Append("        , LA.[Lecture_Date]" & " ")
    sqlString.Append("        , LA.[Site_Code]" & " ")
    sqlString.Append("        , LA.[Subject]" & " ")
    sqlString.Append("        , TE.Effective_Date" & " ")
    sqlString.Append("    ) LA0" & " ")
    sqlString.Append("    LEFT JOIN" & " ")
    sqlString.Append("      " & TeacherRegistryEnum.姓.Table & " TR" & " ")
    sqlString.Append("        ON (" & " ")
    sqlString.Append("          LA0.Teacher_Code = TR.講師コード" & " ")
    sqlString.Append("          AND TR.状態 IS NULL" & " ")
    sqlString.Append("        )")
    sqlString.Append("    LEFT JOIN (" & " ")
    sqlString.Append("      SELECT" & " ")
    sqlString.Append("        [教室名]" & " ")
    sqlString.Append("        , [教室コード]" & " ")
    sqlString.Append("      FROM" & " ")
    sqlString.Append("        " & DBTableConst.TABLE_NAME_SITE & ") S" & " ")
    sqlString.Append("          ON (" & " ")
    sqlString.Append("            LA0.Site_Code = S.[教室コード]" & " ")
    sqlString.Append("          )" & " ")
    sqlString.Append("WHERE" & " ")
    sqlString.Append("  1=1" & " ")

    If Not cond Is Nothing Then
      If StringUtil.IsNotNullOrWhiteSpace(cond.Subjects) Then
        sqlString.Append("  AND Subject = '" & cond.Subjects & "'" & " ")
      End If

      If StringUtil.IsNotNullOrWhiteSpace(cond.GroupCode) Then
        sqlString.Append("  AND LA0.[Site_Code] COLLATE Japanese_CS_AS_KS_WS IN (" & " ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      M11.Site_Code").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      [LECTPAY].[dbo].[MNSPM10] M10").Append(" ")
        sqlString.Append("      LEFT JOIN [LECTPAY].[dbo].[MNSPM11] M11").Append(" ")
        sqlString.Append("        ON (").Append(" ")
        sqlString.Append("            M10.Corporate_KND = M11.Corporate_KND").Append(" ")
        sqlString.Append("            AND M10.Division_KND = M11.Division_KND").Append(" ")
        sqlString.Append("           )").Append(" ")
        sqlString.Append("      WHERE").Append(" ")
        sqlString.Append("        1=1").Append(" ")
        sqlString.Append("        AND M10.Corporate_KND = '1'").Append(" ")
        sqlString.Append("        AND M10.Division_KND = '" & cond.GroupCode & "'").Append(" ")
        sqlString.Append("  )").Append(" ")
      End If

      If StringUtil.IsNotNullOrWhiteSpace(cond.SiteCode) Then
        sqlString.Append("  AND Site_Code = '" & cond.SiteCode & "'" & " ")
      End If

      If StringUtil.IsNotNullOrWhiteSpace(cond.TeacherCode) Then
        sqlString.Append("  AND Teacher_Code = '" & cond.TeacherCode & "'" & " ")
      End If

      If cond.UnregisteredOnly Then
        sqlString.Append("  AND Amount Is NULL" & " ")
      End If
    End If

    sqlString.Append("ORDER BY" & " ")
    sqlString.Append("  LA0.[Teacher_Code]" & " ")
    sqlString.Append("  , LA0.[Lecture_Date]" & " ")
    sqlString.Append("  , LA0.[Site_Code]" & " ")
    sqlString.Append(";" & " ")

    Return sqlString.ToString()
  End Function

  Protected Overrides Sub BindToGrid(ByRef grid As DataGridView, ByRef dtTable As DataTable)
    'Throw New NotImplementedException()
  End Sub


  Public Function LoadTransportExpensesCond(ByVal cond As TrasportExpensesIF) As ResultData
    Dim result As New ResultData
    Dim SqlQuery As String = GetSqlQuery(cond)

    result = LoadOnly(SqlQuery)

    Return result
  End Function


End Class
