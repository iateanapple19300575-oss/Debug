﻿Imports System.Data.SqlClient

Public Class TranspoEditTran
  Inherits TransactionBase


    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 交通費データ追加
    ''' </summary>
    ''' <param name="recData"></param>
    ''' <returns></returns>
    Public Function RegisterWithAdd(ByVal recData As TranspoExpensesData) As ResultData
		Dim resultData As New ResultData()

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("INSERT INTO ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_TRANSPORT_EXPENSES & " ")
		sqlString.Append("( ")
		sqlString.Append("    Teacher_Code ")
		sqlString.Append("    , Site_Code ")
		sqlString.Append("    , Effective_Date ")
		sqlString.Append("    , freshness ")
		sqlString.Append("    , Amount ")
		sqlString.Append("    , travel_time ")
		sqlString.Append(") VALUES ( ")
		sqlString.Append("    @Teacher_Code ")
		sqlString.Append("    , @Site_Code ")
		sqlString.Append("    , @Effective_Date ")
		sqlString.Append("    , @freshness ")
		sqlString.Append("    , @Amount ")
		sqlString.Append("    , @travel_time ")
		sqlString.Append(") ")
		sqlString.Append("; ")

		Try
			Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
				con.Open()
				Using cmd As New SqlCommand(sqlString.ToString(), con)
					cmd.Parameters.AddWithValue("@Teacher_Code", recData.TeacherCode)
					cmd.Parameters.AddWithValue("@Site_Code", recData.RoomCode)
					cmd.Parameters.AddWithValue("@Effective_Date", recData.NewEffectiveDate)
					cmd.Parameters.AddWithValue("@freshness", recData.Freshness)
					cmd.Parameters.AddWithValue("@Amount", recData.NewAmount)
					cmd.Parameters.AddWithValue("@travel_time", recData.TravelTime)
					resultData.DataCount = cmd.ExecuteNonQuery()
				End Using

				con.Close()
				resultData.Success = True
			End Using
		Catch ex As Exception
			resultData.Success = False
		Finally
		End Try

		Return resultData
	End Function

	''' <summary>
	''' 交通費データ更新
	''' </summary>
	''' <param name="recData"></param>
	''' <returns></returns>
	Public Function RegisterWithUpdate(ByVal recData As TranspoExpensesData) As ResultData
		Dim resultData As New ResultData()

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("UPDATE ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_TRANSPORT_EXPENSES & " ")
		sqlString.Append("SET ")
		sqlString.Append("      Effective_Date = @new_Effective_Date ")
		sqlString.Append("    , freshness = @freshness ")
		sqlString.Append("    , Amount = @new_Amount ")
		sqlString.Append("    , travel_time = @travel_time ")
		sqlString.Append("WHERE 1=1 ")
		sqlString.Append("    AND Teacher_Code = @Teacher_Code ")
		sqlString.Append("    AND Site_Code = @Site_Code ")
		sqlString.Append("    AND Effective_Date = @Effective_Date ")
		sqlString.Append("; ")

		Try
			Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
				con.Open()
				Using cmd As New SqlCommand(sqlString.ToString(), con)
					cmd.Parameters.AddWithValue("@Teacher_Code", recData.TeacherCode)
					cmd.Parameters.AddWithValue("@Site_Code", recData.RoomCode)
					cmd.Parameters.AddWithValue("@Effective_Date", recData.EffectiveDate)
					cmd.Parameters.AddWithValue("@freshness", recData.Freshness)
					cmd.Parameters.AddWithValue("@new_Amount", recData.NewAmount)
					cmd.Parameters.AddWithValue("@travel_time", recData.TravelTime)
					cmd.Parameters.AddWithValue("@Effective_Date", recData.NewEffectiveDate)
					resultData.DataCount = cmd.ExecuteNonQuery()
				End Using

				con.Close()
				resultData.Success = True
			End Using
		Catch ex As Exception
			resultData.Success = False
		Finally
		End Try

		Return resultData
	End Function

	''' <summary>
	''' 交通費データ削除
	''' </summary>
	''' <param name="recData"></param>
	''' <returns></returns>
	Public Function RegisterWithDelete(ByVal recData As TranspoExpensesData) As ResultData
		Dim resultData As New ResultData()

		Dim sqlString As New System.Text.StringBuilder
		sqlString.Length = 0
		sqlString.Append("DELETE FROM ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_TRANSPORT_EXPENSES & " ")
		sqlString.Append("WHERE 1=1 ")
		sqlString.Append("    AND Teacher_Code = @Teacher_Code ")
		sqlString.Append("    AND Site_Code = @Site_Code ")
		sqlString.Append("    AND Effective_Date = @old_Effective_Date ")
		sqlString.Append("; ")

		Try
			Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
				con.Open()
				Using cmd As New SqlCommand(sqlString.ToString(), con)
					cmd.Parameters.AddWithValue("@Teacher_Code", recData.TeacherCode)
					cmd.Parameters.AddWithValue("@Site_Code", recData.RoomCode)
					cmd.Parameters.AddWithValue("@Effective_Date", recData.EffectiveDate)
					resultData.DataCount = cmd.ExecuteNonQuery()
				End Using

				con.Close()
				resultData.Success = True
			End Using
		Catch ex As Exception
			resultData.Success = False
		Finally
		End Try

		Return resultData
	End Function


	Public Function LoadDistrictData() As ResultData
		Dim sqlString As New System.Text.StringBuilder

		sqlString.Length = 0
		sqlString.Append("SELECT" & " ")
		sqlString.Append("  LA0.[Lecture_Date]" & " ")
		sqlString.Append("  , LA0.[Teacher_Code]" & " ")
		sqlString.Append("  , CONCAT(TR.姓, '　', TR.名) As Full_Name" & " ")
		sqlString.Append("  , LA0.[Site_Code]" & " ")
		sqlString.Append("  , S.[教室名]" & " ")
		sqlString.Append("  , LA0.Effective_Date" & " ")
		sqlString.Append("  , LA0.Amount" & " ")
		sqlString.Append("FROM" & " ")
		sqlString.Append("  SELECT" & " ")
		sqlString.Append("    LA.[Lecture_Date]" & " ")
		sqlString.Append("    , LA.[Teacher_Code]" & " ")
		sqlString.Append("    , LA.[Site_Code]" & " ")
		sqlString.Append("    , MAX(TE.Effective_Date) As Effective_Date" & " ")
		sqlString.Append("    , MAX(TE.Amount) As Amount" & " ")
		sqlString.Append("  FROM" & " ")
		sqlString.Append("    " & DBTableConst.TABLE_NAME_LECTURE_ACTUAL & " LA" & " ")
		sqlString.Append("    LEFT JOIN (" & " ")
		sqlString.Append("      SELECT" & " ")
		sqlString.Append("        TEM.Teacher_Code" & " ")
		sqlString.Append("        , TEM.Site_Code" & " ")
		sqlString.Append("        , TEM.Effective_Date" & " ")
		sqlString.Append("        , TEM.Amount" & " ")
		sqlString.Append("      FROM" & " ")
		sqlString.Append("        " & DBTableConst.TABLE_NAME_TRANSPORT_EXPENSES & " TEM" & " ")
		sqlString.Append("        INNER JOIN (" & " ")
		sqlString.Append("          SELECT" & " ")
		sqlString.Append("            Teacher_Code" & " ")
		sqlString.Append("            , Site_Code" & " ")
		sqlString.Append("            , MAX(Effective_Date) As Effective_Date" & " ")
		sqlString.Append("          FROM")
		sqlString.Append("            " & DBTableConst.TABLE_NAME_TRANSPORT_EXPENSES & " ")
		sqlString.Append("          GROUP BY" & " ")
		sqlString.Append("            Teacher_Code" & " ")
		sqlString.Append("            , Site_Code" & " ")
		sqlString.Append("        ) TEG" & " ")
		sqlString.Append("          ON (" & " ")
		sqlString.Append("            TEM.Teacher_Code = TEG.Teacher_Code" & " ")
		sqlString.Append("            AND TEM.Site_Code = TEG.Site_Code" & " ")
		sqlString.Append("            AND TEM.Effective_Date = TEG.Effective_Date" & " ")
		sqlString.Append("          )" & " ")
		sqlString.Append("        ) TE" & " ")
		sqlString.Append("          ON (" & " ")
		sqlString.Append("            LA.Teacher_Code = TE.Teacher_Code" & " ")
		sqlString.Append("            AND LA.Site_Code = TE.Site_Code" & " ")
		sqlString.Append("            AND LA.Lecture_Date >= TE.Effective_Date" & " ")
		sqlString.Append("          )")
		sqlString.Append("      WHERE" & " ")
		sqlString.Append("        1=1" & " ")
		sqlString.Append("        AND [phase] = 2" & " ")
		sqlString.Append("      GROUP BY" & " ")
		sqlString.Append("        LA.[Teacher_Code]" & " ")
		sqlString.Append("        , LA.[Lecture_Date]" & " ")
		sqlString.Append("        , LA.[Site_Code]" & " ")
		sqlString.Append("        , TE.Effective_Date" & " ")
		sqlString.Append("    ) LA0" & " ")
		sqlString.Append("    LEFT JOIN" & " ")
		sqlString.Append("      " & DBTableConst.TABLE_NAME_TEACHER_REGISTRY & " TR" & " ")
		sqlString.Append("        ON (" & " ")
		sqlString.Append("          LA0.Teacher_Code = TR.講師コード" & " ")
		sqlString.Append("          AND TR.状態 IS NULL" & " ")
		sqlString.Append("        )")
		sqlString.Append("  ")
		sqlString.Append("    LEFT JOIN (" & " ")
		sqlString.Append("      SELECT" & " ")
		sqlString.Append("        [教室名]" & " ")
		sqlString.Append("        , [教室コード]" & " ")
		sqlString.Append("      FROM" & " ")
		sqlString.Append("        " & DBTableConst.TABLE_NAME_SITE & " S" & " ")
		sqlString.Append("          ON (" & " ")
		sqlString.Append("            LA0.Site_Code = S.[教室コード]" & " ")
		sqlString.Append("          )" & " ")
		sqlString.Append("ORDER BY" & " ")
		sqlString.Append("  LA0.[Teacher_Code]" & " ")
		sqlString.Append("  , LA0.[Lecture_Date]" & " ")
		sqlString.Append("  , LA0.[Site_Code]" & " ")
		sqlString.Append(";" & " ")

		Dim resultData As New ResultData
		Dim dt As New DataTable()

		Try
			Using conn As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
				Using cmd As New SqlCommand(sqlString.ToString(), conn)
					Using adpter As New SqlDataAdapter(cmd)
						adpter.Fill(dt)
					End Using
				End Using
			End Using
			resultData.Success = True
			resultData.ResDataTable = dt
			resultData.DataCount = dt.Rows.Count
		Catch ex As Exception
			resultData.Success = False
		End Try

		Return resultData
	End Function

End Class
