﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities

Public Class TeacherTran
    Inherits TransactionBase

    Public Sub New()
    End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' SELECT(コード＆名称)
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="teacherCode"></param>
    ''' <param name="subjectCode"></param>
    ''' <returns></returns>
    Public Function SqlSelectKeyValuePair(ByVal targetDate As Date, ByVal teacherCode As String, ByVal subjectCode As String) As DataTable
        ' 日付範囲指定
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        ' SQL作成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT" & " ")
        sqlString.Append("  LA." & W_Lecture_ActualEnum.講師コード.Column).Append(" As ").Append(TeacherRegistryEnum.講師コード.Column).Append(" ")
        sqlString.Append("  , MAX(CONCAT(LA." & W_Lecture_ActualEnum.講師コード.Column & ", '：', TR." & TeacherRegistryEnum.講師名.Column).Append("))").Append(" ")
        sqlString.Append("  As " & TeacherRegistryEnum.講師名.Column).Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & W_Lecture_ActualEnum.フェーズ.Table).Append(" LA").Append(" ")
        sqlString.Append("  LEFT JOIN (").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      講師コード").Append(" ")
        sqlString.Append("      , 講師名").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      " & TeacherRegistryEnum.姓.Table).Append(" ")
        sqlString.Append("  ) TR").Append(" ")
        sqlString.Append("    ON (").Append(" ")
        sqlString.Append("      LA." & W_Lecture_ActualEnum.講師コード.Column).Append(" =").Append(" ")
        sqlString.Append("      TR." & TeacherRegistryEnum.講師コード.Column).Append(" ")
        sqlString.Append("    )")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND " & W_Lecture_ActualEnum.日付.Column).Append(" >= '").Append(firstDay).Append("'").Append(" ")
        sqlString.Append("  AND " & W_Lecture_ActualEnum.日付.Column).Append(" <= '").Append(lastDay).Append("'").Append(" ")

        If StringUtil.IsNotNullOrWhiteSpace(subjectCode) Then
            sqlString.Append("  AND LA." & W_Lecture_ActualEnum.科目.Column).Append(" =").Append(" ")
            sqlString.Append("  " & W_Lecture_ActualEnum.科目.Param).Append(" ")
        End If

        sqlString.Append("GROUP BY").Append(" ")
        sqlString.Append("  LA." & W_Lecture_ActualEnum.講師コード.Column).Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  LA." & W_Lecture_ActualEnum.講師コード.Column).Append(" ")
        sqlString.Append(";")

        Return SqlUtil.ExecuteDataTable(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = W_Lecture_ActualEnum.科目.Param, .Value = subjectCode}
          )

    End Function

    ''' <summary>
    ''' 集計用出講データ作成
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="phase"></param>
    ''' <param name="dataType"></param>
    ''' <returns></returns>
    Public Function AnalysisCreateData(ByVal targetDate As Date, ByVal phase As Integer, ByVal dataType As Integer) As ResultData

        Dim resultData As New ResultData
        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO " & DBTableConst.TABLE_NAME_LECTURE_ACTUAL & " ")
        sqlString.Append("SELECT ")
        sqlString.Append("      " & phase & " As Phase ")
        sqlString.Append("    , " & dataType & " As Data_type ")
        sqlString.Append("    , RH.Teacher_Code As Teacher_Code ")
        sqlString.Append("    , RH.Lecture_Date As Lecture_Date ")
        sqlString.Append("    , RH.Koma_Seq As Koma_Seq ")
        sqlString.Append("    , RH.Site_Code As Site_Code ")
        sqlString.Append("    , RH.Grade As Grade ")
        sqlString.Append("    , RH.Class_Code As Class_Code ")
        sqlString.Append("    , RH.Subject As Subject ")
        sqlString.Append("    , RH.Text_Times As Text_Times ")
        sqlString.Append("    , RS.Start_Time As Start_Time ")
        sqlString.Append("    , RS.End_Time As End_Time ")
        sqlString.Append("    , NULL As Pinch_Type ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & DBTableConst.TABLE_NAME_LECTURE_PLAN & " RH ")
        sqlString.Append("    LEFT JOIN " & DBTableConst.TABLE_NAME_TIME_PATTERN & " SP ")
        sqlString.Append("        ON ( ")
        sqlString.Append("            RH.Lecture_Date = FORMAT(SP.Lecture_Date, 'yyyyMMdd') ")
        sqlString.Append("        )  ")
        sqlString.Append("    LEFT JOIN " & DBTableConst.TABLE_NAME_TIMETABLE_SITE & " RS ")
        sqlString.Append("        ON ( ")
        sqlString.Append("            RS.Site_Code = RH.Site_Code ")
        sqlString.Append("            AND RS.Schedule_Pattern = SP.Schedule_Pattern ")
        sqlString.Append("            AND RS.Koma_Seq = RH.Koma_Seq ")
        sqlString.Append("        ) ")
        sqlString.Append("WHERE ")
        sqlString.Append("    1 = 1 ")
        sqlString.Append("    AND RH.Lecture_Date >= '" & firstDay & "' ")
        sqlString.Append("    AND RH.Lecture_Date <= '" & lastDay & "' ")
        sqlString.Append(" ")
        sqlString.Append("ORDER BY ")
        sqlString.Append("    RH.Teacher_Code ")
        sqlString.Append("    , RH.Lecture_Date ")
        sqlString.Append("    , RH.Koma_Seq ")
        sqlString.Append("; ")

        Try
            Using sqlConnection As New SqlConnection(ConnectString)
                sqlConnection.Open()

                '本科実績データ投入
                Dim sqlCommand As SqlCommand
                sqlCommand = New SqlCommand(sqlString.ToString(), sqlConnection)
                resultData.DataCount = sqlCommand.ExecuteNonQuery()
            End Using

        Catch ex As SqlException
            resultData.Success = False
            resultData.ErrorCode = ex.Number
            Throw

        Catch ex As Exception
            resultData.Success = False
            Throw

        Finally

        End Try

        Return resultData
    End Function
End Class
