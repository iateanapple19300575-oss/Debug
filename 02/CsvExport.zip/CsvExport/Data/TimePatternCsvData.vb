﻿Public Class TimePatternCsvData

  ''' <summary>
  ''' 日付
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("日付"), CsvOrderAttrbute(1)>
  Public Property SchoolDay As String

  ''' <summary>
  ''' 曜日
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("曜日"), CsvOrderAttrbute(2)>
  Public Property DayOfWeek As String

  ''' <summary>
  ''' パターン
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("パターン"), CsvOrderAttrbute(3)>
  Public Property PatternName As String

End Class
