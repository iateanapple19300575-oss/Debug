﻿''' <summary>
''' 給与明細記載項目(CSV項目)
''' </summary>
Public Class PaySlipCsvData

	''' <summary>
	''' 講師コード
	''' </summary>
	''' <returns></returns>
	<CsvHeader("講師コード"), CsvOrderAttrbute(1)>
	Public Property TeacherCode As String

	''' <summary>
	''' 授業給（課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("授業給（課税）"), CsvOrderAttrbute(2)>
	Public Property TuitionFee As String

	''' <summary>
	''' 業務給（課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("業務給（課税）"), CsvOrderAttrbute(3)>
	Public Property WorkSalary As String

	''' <summary>
	''' 授業給　手当（課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("授業給　手当（課税）"), CsvOrderAttrbute(4)>
	Public Property TuitionAllowance As String

	''' <summary>
	''' 授業給　調整（課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("授業給　調整（課税）"), CsvOrderAttrbute(5)>
	Public Property TuitionSalaryAdj As String

	''' <summary>
	''' 特別1　手当（課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("特別1　手当（課税）"), CsvOrderAttrbute(6)>
	Public Property Special1Allowance As String

	''' <summary>
	''' 特別1　調整（課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("特別1　調整（課税）"), CsvOrderAttrbute(7)>
	Public Property Special1Adj As String

	''' <summary>
	''' 特別2　手当（非課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("特別2　手当（非課税）"), CsvOrderAttrbute(8)>
	Public Property Special2Allowance As String

	''' <summary>
	''' 特別2　調整（非課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("特別2　調整（非課税）"), CsvOrderAttrbute(9)>
	Public Property Special2Adj As String

	''' <summary>
	''' 交通費（非課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("交通費（非課税）"), CsvOrderAttrbute(10)>
	Public Property TranspoExpenses As String

	''' <summary>
	''' 交通費　調整（非課税）
	''' </summary>
	''' <returns></returns>
	<CsvHeader("交通費　調整（非課税）"), CsvOrderAttrbute(11)>
	Public Property TranspoExpensesAdj As String

	''' <summary>
	''' 有給使用日数
	''' </summary>
	''' <returns></returns>
	<CsvHeader("有給使用日数"), CsvOrderAttrbute(12)>
	Public Property PaidLeaveTaken As String

	''' <summary>
	''' 有給残
	''' </summary>
	''' <returns></returns>
	<CsvHeader("有給残"), CsvOrderAttrbute(13)>
	Public Property PaidLeaveNotTaken As String

End Class
