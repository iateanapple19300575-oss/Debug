﻿Public Class KyuyoData

  ''' <summary>
  ''' 社員番号
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("MM1"), CsvOrderAttrbute(1)>
  Public Property MM1 As String

  ''' <summary>
  ''' 本科
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS2"), CsvOrderAttrbute(2)>
  Public Property KS2 As Integer

  ''' <summary>
  '''単科特別選
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS3"), CsvOrderAttrbute(3)>
  Public Property KS3 As Integer

  ''' <summary>
  ''' クラス手当
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS4"), CsvOrderAttrbute(4)>
  Public Property KS4 As Integer

  ''' <summary>
  ''' 手当１
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS5"), CsvOrderAttrbute(5)>
  Public Property KS5 As Integer

  ''' <summary>
  ''' 手当２
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS6"), CsvOrderAttrbute(6)>
  Public Property KS6 As Integer

  ''' <summary>
  ''' 調整講師料
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS10"), CsvOrderAttrbute(7)>
  Public Property KS10 As Integer

  ''' <summary>
  ''' 交通費
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS11"), CsvOrderAttrbute(8)>
  Public Property KS11 As Integer

  ''' <summary>
  ''' 調整交通費
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KS12"), CsvOrderAttrbute(9)>
  Public Property KS12 As Integer

  ''' <summary>
  ''' 前渡金
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("KK11"), CsvOrderAttrbute(10)>
  Public Property KK11 As Integer

End Class
