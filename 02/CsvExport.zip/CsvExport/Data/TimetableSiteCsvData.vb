﻿Public Class TimetableSiteCsvData

  ''' <summary>
  ''' 年
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("年"), CsvOrderAttrbute(1)>
  Public Property Year As String

  ''' <summary>
  ''' 教室コード
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("教室コード"), CsvOrderAttrbute(2)>
  Public Property SiteCode As String

  ''' <summary>
  ''' 教室名
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("教室名"), CsvOrderAttrbute(3)>
  Public Property SiteName As String

  ''' <summary>
  ''' パターン名
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("パターン名"), CsvOrderAttrbute(4)>
  Public Property PatternName As String

  ''' <summary>
  ''' コマ1開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ1開始時間"), CsvOrderAttrbute(5)>
  Public Property StartTime1 As String

  ''' <summary>
  ''' コマ1終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ1終了時間"), CsvOrderAttrbute(6)>
  Public Property EndTime1 As String

  ''' <summary>
  ''' コマ2開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ2開始時間"), CsvOrderAttrbute(7)>
  Public Property StartTime2 As String

  ''' <summary>
  ''' コマ1終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ2終了時間"), CsvOrderAttrbute(8)>
  Public Property EndTime2 As String

  ''' <summary>
  ''' コマ3開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ3開始時間"), CsvOrderAttrbute(9)>
  Public Property StartTime3 As String

  ''' <summary>
  ''' コマ1終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ3終了時間"), CsvOrderAttrbute(10)>
  Public Property EndTime3 As String

  ''' <summary>
  ''' コマ4開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ4開始時間"), CsvOrderAttrbute(11)>
  Public Property StartTime4 As String

  ''' <summary>
  ''' コマ4終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ4終了時間"), CsvOrderAttrbute(12)>
  Public Property EndTime4 As String

  ''' <summary>
  ''' コマ5開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ5開始時間"), CsvOrderAttrbute(13)>
  Public Property StartTime5 As String

  ''' <summary>
  ''' コマ5終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ1終了時間"), CsvOrderAttrbute(14)>
  Public Property EndTime5 As String

  ''' <summary>
  ''' コマ6開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ1開始時間"), CsvOrderAttrbute(15)>
  Public Property StartTime6 As String

  ''' <summary>
  ''' コマ6終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ1終了時間"), CsvOrderAttrbute(16)>
  Public Property EndTime6 As String

  ''' <summary>
  ''' コマ7開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ7開始時間"), CsvOrderAttrbute(17)>
  Public Property StartTime7 As String

  ''' <summary>
  ''' コマ7終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ7終了時間"), CsvOrderAttrbute(18)>
  Public Property EndTime7 As String

  ''' <summary>
  ''' コマ8開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ8開始時間"), CsvOrderAttrbute(19)>
  Public Property StartTime8 As String

  ''' <summary>
  ''' コマ8終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ8終了時間"), CsvOrderAttrbute(20)>
  Public Property EndTime8 As String

  ''' <summary>
  ''' コマ9開始時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ9開始時間"), CsvOrderAttrbute(21)>
  Public Property StartTime9 As String

  ''' <summary>
  ''' コマ9終了時間
  ''' </summary>
  ''' <returns></returns>
  <CsvHeader("コマ9終了時間"), CsvOrderAttrbute(22)>
  Public Property EndTime9 As String

End Class
