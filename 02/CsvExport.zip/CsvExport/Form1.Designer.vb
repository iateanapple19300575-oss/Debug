﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.btnProc10 = New System.Windows.Forms.Button()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.btnProc11 = New System.Windows.Forms.Button()
		Me.btn入力03 = New System.Windows.Forms.Button()
		Me.SuspendLayout()
		'
		'btnProc10
		'
		Me.btnProc10.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.btnProc10.Location = New System.Drawing.Point(105, 94)
		Me.btnProc10.Name = "btnProc10"
		Me.btnProc10.Size = New System.Drawing.Size(230, 46)
		Me.btnProc10.TabIndex = 0
		Me.btnProc10.Text = "給与奉行用CSV作成（給与データ）"
		Me.btnProc10.UseVisualStyleBackColor = True
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.Label1.Location = New System.Drawing.Point(40, 38)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(68, 16)
		Me.Label1.TabIndex = 1
		Me.Label1.Text = "対象年月度"
		'
		'btnProc11
		'
		Me.btnProc11.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.btnProc11.Location = New System.Drawing.Point(105, 155)
		Me.btnProc11.Name = "btnProc11"
		Me.btnProc11.Size = New System.Drawing.Size(230, 46)
		Me.btnProc11.TabIndex = 2
		Me.btnProc11.Text = "給与奉行用CSV作成（社員データ）"
		Me.btnProc11.UseVisualStyleBackColor = True
		'
		'btn入力03
		'
		Me.btn入力03.Font = New System.Drawing.Font("游ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
		Me.btn入力03.Location = New System.Drawing.Point(105, 216)
		Me.btn入力03.Name = "btn入力03"
		Me.btn入力03.Size = New System.Drawing.Size(230, 46)
		Me.btn入力03.TabIndex = 3
		Me.btn入力03.Text = "交通費入力確認"
		Me.btn入力03.UseVisualStyleBackColor = True
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(800, 450)
		Me.Controls.Add(Me.btn入力03)
		Me.Controls.Add(Me.btnProc11)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.btnProc10)
		Me.Name = "Form1"
		Me.Text = "Form1"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents btnProc10 As Button
	Friend WithEvents Label1 As Label
	Friend WithEvents btnProc11 As Button
	Friend WithEvents btn入力03 As Button
End Class
